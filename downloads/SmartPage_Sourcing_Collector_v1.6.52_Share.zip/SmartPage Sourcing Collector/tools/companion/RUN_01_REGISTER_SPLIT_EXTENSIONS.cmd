﻿@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0\01_REGISTER_SPLIT_EXTENSIONS.ps1" -Approve
pause
