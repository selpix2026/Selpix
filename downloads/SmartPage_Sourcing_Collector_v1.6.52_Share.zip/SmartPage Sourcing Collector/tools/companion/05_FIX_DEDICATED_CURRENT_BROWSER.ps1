﻿$ErrorActionPreference='Stop'
Set-StrictMode -Version 2

$Base='C:\ProgramData\SmartPageEx\NetworkHostV33'
$Launcher=Join-Path $Base 'open-dedicated-window.ps1'
$TaskName='SmartPageEx Open Dedicated Browser'
$BackupRoot=Join-Path $Base 'collector-current-browser-fix-v126-backup'
$Marker='SPX_CURRENT_BROWSER_DEDICATED_V126'

function Assert-Admin {
  $id=[Security.Principal.WindowsIdentity]::GetCurrent()
  $p=New-Object Security.Principal.WindowsPrincipal($id)
  if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
    throw '관리자 권한이 필요합니다. RUN_05_CURRENT_BROWSER_DEDICATED_WINDOW_FIX.cmd를 우클릭하여 관리자 권한으로 실행하세요.'
  }
}
function Read-Utf8([string]$Path){ return [IO.File]::ReadAllText($Path,[Text.Encoding]::UTF8) }
function Write-Utf8Bom([string]$Path,[string]$Text){ [IO.File]::WriteAllText($Path,$Text,(New-Object Text.UTF8Encoding($true))) }
function Get-WatcherProcesses {
  @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object {
      $c=[string]$_.CommandLine
      $c -like '*NetworkHostV33*open-dedicated-window.ps1*' -and $c -like '*-Watch*'
    })
}
function Test-PowerShellSyntax([string]$Path){
  $tokens=$null;$errors=$null
  [void][Management.Automation.Language.Parser]::ParseFile($Path,[ref]$tokens,[ref]$errors)
  if($errors -and @($errors).Count -gt 0){ throw ('PowerShell syntax error: '+(@($errors)[0].Message)) }
}
function Wait-Ready([int]$Seconds=15){
  $readyPath=Join-Path $Base 'dedicated-window-launcher.ready'
  $deadline=(Get-Date).AddSeconds($Seconds)
  do{
    Start-Sleep -Milliseconds 300
    if(Test-Path -LiteralPath $readyPath -PathType Leaf){
      try{
        $r=Get-Content -LiteralPath $readyPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if($r.ready -eq $true){return $true}
      }catch{}
    }
  }while((Get-Date)-lt$deadline)
  return $false
}

Assert-Admin
if(-not (Test-Path -LiteralPath $Launcher -PathType Leaf)){throw ('전용창 launcher가 없습니다: '+$Launcher)}
$original=Read-Utf8 $Launcher
if($original -match [regex]::Escape($Marker)){
  Test-PowerShellSyntax $Launcher
  Write-Host 'CURRENT_BROWSER_PATCH=ALREADY_PRESENT'
  Write-Host 'FINAL=DEDICATED_CURRENT_BROWSER_V126_PASS'
  exit 0
}

# 실제 browser launch 한 줄만 찾습니다. NetworkHost/라우팅/프록시 로직은 수정하지 않습니다.
$launchPattern='(?im)^(?<indent>[ \t]*)(?<line>Start-Process\b[^\r\n]*-FilePath[ \t]+\$(?<exe>[A-Za-z_][A-Za-z0-9_]*)[^\r\n]*-ArgumentList[ \t]+\$argumentParts[^\r\n]*)$'
$m=[regex]::Match($original,$launchPattern)
if(-not $m.Success){
  $launchPattern='(?im)^(?<indent>[ \t]*)(?<line>Start-Process\b[^\r\n]*\$(?<exe>[A-Za-z_][A-Za-z0-9_]*)[^\r\n]*\$argumentParts[^\r\n]*)$'
  $m=[regex]::Match($original,$launchPattern)
}
if(-not $m.Success){throw 'launcher의 browser Start-Process + $argumentParts 실행 지점을 찾지 못했습니다. 안전을 위해 수정하지 않았습니다.'}
$exeVar=[string]$m.Groups['exe'].Value
if([string]::IsNullOrWhiteSpace($exeVar)){throw 'launcher browser executable 변수 확인 실패'}

$helper=@'
# SPX_CURRENT_BROWSER_DEDICATED_V126
function Resolve-SpxRequestedBrowserV126([object]$Request,[string]$FallbackExecutable){
  $family='chrome'
  try{
    $raw=[string]$Request.browserFamily
    if(-not [string]::IsNullOrWhiteSpace($raw)){$family=$raw.Trim().ToLowerInvariant()}
  }catch{}
  if(@('chrome','whale','edge') -notcontains $family){$family='chrome'}

  $candidates=New-Object 'System.Collections.Generic.List[string]'
  if($family -eq 'whale'){
    foreach($p in @(
      (Join-Path $env:LOCALAPPDATA 'Naver\Naver Whale\Application\whale.exe'),
      (Join-Path $env:ProgramFiles 'Naver\Naver Whale\Application\whale.exe')
    )){if(-not [string]::IsNullOrWhiteSpace([string]$p)){[void]$candidates.Add([string]$p)}}
    if(${env:ProgramFiles(x86)}){[void]$candidates.Add((Join-Path ${env:ProgramFiles(x86)} 'Naver\Naver Whale\Application\whale.exe'))}
  }elseif($family -eq 'edge'){
    foreach($p in @(
      (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
      (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe')
    )){if(-not [string]::IsNullOrWhiteSpace([string]$p)){[void]$candidates.Add([string]$p)}}
    if(${env:ProgramFiles(x86)}){[void]$candidates.Add((Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'))}
  }else{
    if(-not [string]::IsNullOrWhiteSpace($FallbackExecutable)){[void]$candidates.Add($FallbackExecutable)}
    foreach($p in @(
      (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
      (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
    )){if(-not [string]::IsNullOrWhiteSpace([string]$p)){[void]$candidates.Add([string]$p)}}
    if(${env:ProgramFiles(x86)}){[void]$candidates.Add((Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'))}
  }

  $exe=''
  foreach($candidate in $candidates){if(Test-Path -LiteralPath $candidate -PathType Leaf){$exe=$candidate;break}}
  if([string]::IsNullOrWhiteSpace($exe)){
    if($family -eq 'whale'){throw '현재 요청 브라우저는 Whale이지만 whale.exe를 찾지 못했습니다. Chrome으로 fallback하지 않습니다.'}
    if($family -eq 'edge'){throw '현재 요청 브라우저는 Edge이지만 msedge.exe를 찾지 못했습니다. Chrome으로 fallback하지 않습니다.'}
    throw 'Chrome 실행 파일을 찾지 못했습니다.'
  }

  $profileDir=if($family -eq 'whale'){'C:\SpxDedicatedProfileWhale'}elseif($family -eq 'edge'){'C:\SpxDedicatedProfileEdge'}else{'C:\SpxDedicatedProfile'}
  $displayName=if($family -eq 'whale'){'Whale'}elseif($family -eq 'edge'){'Edge'}else{'Chrome'}
  return [pscustomobject]@{Family=$family;DisplayName=$displayName;Executable=$exe;ProfileDir=$profileDir}
}
function Set-SpxDedicatedProfileArgumentV126([object[]]$ArgumentParts,[string]$ProfileDir){
  $out=New-Object 'System.Collections.Generic.List[object]'
  $replaced=$false
  foreach($arg in @($ArgumentParts)){
    $text=[string]$arg
    if($text -like '--user-data-dir=*'){
      [void]$out.Add(('--user-data-dir='+$ProfileDir));$replaced=$true
    }else{[void]$out.Add($arg)}
  }
  if(-not $replaced){[void]$out.Add(('--user-data-dir='+$ProfileDir))}
  return @($out)
}
'@

$preLaunch=@"
$helper
"@
# helper 함수는 Set-StrictMode 직후에 1회 삽입합니다.
$strict=[regex]::Match($original,'(?im)^Set-StrictMode[^\r\n]*\r?\n')
if($strict.Success){
  $patched=$original.Substring(0,$strict.Index+$strict.Length)+"`r`n"+$preLaunch+"`r`n"+$original.Substring($strict.Index+$strict.Length)
}else{
  $patched=$preLaunch+"`r`n"+$original
}

# helper 삽입으로 launch line index가 바뀌었으므로 다시 찾습니다.
$m2=[regex]::Match($patched,$launchPattern)
if(-not $m2.Success){
  $launchPattern2='(?im)^(?<indent>[ \t]*)(?<line>Start-Process\b[^\r\n]*\$(?<exe>[A-Za-z_][A-Za-z0-9_]*)[^\r\n]*\$argumentParts[^\r\n]*)$'
  $m2=[regex]::Match($patched,$launchPattern2)
}
if(-not $m2.Success){throw 'helper 삽입 후 browser launch 지점을 다시 찾지 못했습니다.'}
$indent=[string]$m2.Groups['indent'].Value
$launchLine=[string]$m2.Groups['line'].Value
$exeVar2=[string]$m2.Groups['exe'].Value
$inject=$indent+'$spxRequestedBrowserV126 = Resolve-SpxRequestedBrowserV126 -Request $request -FallbackExecutable ([string]$'+$exeVar2+")`r`n"+
        $indent+'$'+$exeVar2+' = [string]$spxRequestedBrowserV126.Executable'+"`r`n"+
        $indent+'$argumentParts = Set-SpxDedicatedProfileArgumentV126 -ArgumentParts @($argumentParts) -ProfileDir ([string]$spxRequestedBrowserV126.ProfileDir)'+"`r`n"+
        $indent+"Write-LaunchLog ('Requested browser=' + [string]`$spxRequestedBrowserV126.DisplayName + '; exe=' + [string]`$spxRequestedBrowserV126.Executable + '; profile=' + [string]`$spxRequestedBrowserV126.ProfileDir)"+"`r`n"
$patched=$patched.Substring(0,$m2.Index)+$inject+$launchLine+$patched.Substring($m2.Index+$m2.Length)

if($patched -notmatch [regex]::Escape($Marker)){throw 'current-browser patch marker missing before write'}
if($patched -notmatch 'SpxDedicatedProfileWhale'){throw 'Whale dedicated profile marker missing before write'}
if($patched -notmatch 'browserFamily'){throw 'browserFamily request reader missing before write'}

$tmp=Join-Path $env:TEMP ('spx-current-browser-v126-'+[guid]::NewGuid().ToString('N')+'.ps1')
try{Write-Utf8Bom $tmp $patched;Test-PowerShellSyntax $tmp}finally{Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue}

$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$backup=Join-Path $BackupRoot $stamp
New-Item -ItemType Directory -Path $backup -Force | Out-Null
Copy-Item -LiteralPath $Launcher -Destination (Join-Path $backup 'open-dedicated-window.ps1') -Force

try{
  try{Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue}catch{}
  Start-Sleep -Milliseconds 700
  foreach($proc in @(Get-WatcherProcesses)){try{Stop-Process -Id ([int]$proc.ProcessId) -Force -ErrorAction Stop}catch{}}
  Write-Utf8Bom $Launcher $patched
  Test-PowerShellSyntax $Launcher
  Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop
  if(-not (Wait-Ready 15)){throw 'launcher watcher READY 확인 실패'}
  $verify=Read-Utf8 $Launcher
  if($verify -notmatch [regex]::Escape($Marker) -or $verify -notmatch 'SpxDedicatedProfileWhale'){throw 'post verify marker mismatch'}
  Write-Host ('BACKUP='+$backup)
  Write-Host 'BROWSER_DISPATCH=CHROME_WHALE_EDGE_BY_REQUEST'
  Write-Host 'CHROME_PROFILE=C:\SpxDedicatedProfile'
  Write-Host 'WHALE_PROFILE=C:\SpxDedicatedProfileWhale'
  Write-Host 'EDGE_PROFILE=C:\SpxDedicatedProfileEdge'
  Write-Host 'WRONG_BROWSER_FALLBACK=BLOCKED'
  Write-Host 'CHROME_STOP=0 WHALE_STOP=0 EDGE_STOP=0 NETWORKHOST_RESTART=0 ROUTE_CHANGE=0 ADAPTER_CHANGE=0'
  Write-Host 'FINAL=DEDICATED_CURRENT_BROWSER_V126_PASS'
  exit 0
}catch{
  $failure=$_.Exception.Message
  try{
    $bak=Join-Path $backup 'open-dedicated-window.ps1'
    if(Test-Path -LiteralPath $bak){Copy-Item -LiteralPath $bak -Destination $Launcher -Force;Test-PowerShellSyntax $Launcher;try{Start-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue}catch{}}
  }catch{}
  throw ('CURRENT_BROWSER_V126 rolled back: '+$failure)
}
