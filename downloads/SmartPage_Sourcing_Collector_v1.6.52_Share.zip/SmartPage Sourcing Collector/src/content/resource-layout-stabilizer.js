/* SmartPage Sourcing Collector v1.2.2
 * Resource layout stabilizer.
 * Keeps Coupang search product media slots geometrically stable while network
 * image/media blocking is enabled. It never edits product DOM nodes or src URLs.
 */
(()=>{
  'use strict';
  const ROOT_CLASS='spx-resource-layout-stable';

  function mediaBlockEnabled(settings){
    const value=settings&&typeof settings==='object'?settings:{};
    const legacy=String(value.collectionResourceMode||'save').toLowerCase();
    const mode=String(value.collectionMediaMode||(legacy==='normal'?'load':'block')).toLowerCase();
    return mode!=='load';
  }

  function apply(settings){
    const root=document.documentElement;
    if(!root)return;
    const blocked=mediaBlockEnabled(settings);
    root.classList.toggle(ROOT_CLASS,blocked);
    /* v1.1.8: MAIN-world placeholder guard reads only this inert DOM flag.
       It never reads extension storage itself and never rewrites normal product-image URLs. */
    root.setAttribute('data-spx-image-download-mode',blocked?'block':'load');
  }

  try{
    chrome.storage.local.get({settings:{}},({settings}={})=>apply(settings));
    chrome.storage.onChanged.addListener((changes,areaName)=>{
      if(areaName!=='local'||!changes?.settings)return;
      apply(changes.settings.newValue||{});
    });
  }catch(_){ }
})();
