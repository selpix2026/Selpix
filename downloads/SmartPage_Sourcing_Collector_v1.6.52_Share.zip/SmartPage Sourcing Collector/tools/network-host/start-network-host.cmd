﻿@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-network-host.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo Network helper start failed. Error code: %RC%
pause
exit /b %RC%
