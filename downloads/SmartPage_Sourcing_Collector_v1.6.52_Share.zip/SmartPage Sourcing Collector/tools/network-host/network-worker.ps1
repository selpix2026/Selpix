﻿param([string]$RequestPath = '', [string]$ResultPath = '')
$ErrorActionPreference = 'Stop'
try {
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  [Console]::InputEncoding = $utf8
  [Console]::OutputEncoding = $utf8
  $OutputEncoding = $utf8
} catch { }
$BaseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($RequestPath)) { $RequestPath = Join-Path $BaseDir 'network-command-v3083.json' }
if ([string]::IsNullOrWhiteSpace($ResultPath)) { $ResultPath = Join-Path $BaseDir 'network-result-v3083.json' }
$RuntimePath = Join-Path $BaseDir 'network-runtime.json'
$GuardStatePath = Join-Path $BaseDir 'selected-route-guard.json'
$SystemPinStatePath = Join-Path $BaseDir 'system-route-pin.json'

function Write-JsonFile([string]$Path, $Value) {
  $temp = $Path + '.' + $PID + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
  $json = $Value | ConvertTo-Json -Depth 16 -Compress
  $parent = Split-Path -Parent $Path
  if (-not [string]::IsNullOrWhiteSpace($parent)) { New-Item -ItemType Directory -Path $parent -Force -ErrorAction SilentlyContinue | Out-Null }
  [IO.File]::WriteAllText($temp, $json, (New-Object Text.UTF8Encoding($false)))
  if (Test-Path -LiteralPath $Path) { Remove-Item -LiteralPath $Path -Force -ErrorAction Stop }
  [IO.File]::Move($temp, $Path)
}
function Read-JsonFile([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) { return $null }
  try { return Get-Content -LiteralPath $Path -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop } catch { return $null }
}
function Get-DefaultRouteSnapshot {
  $rows = Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue |
    Where-Object { $_.State -eq 'Alive' -or $null -eq $_.State } |
    ForEach-Object {
      $iface = Get-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $_.InterfaceIndex -ErrorAction SilentlyContinue | Select-Object -First 1
      $metric = if ($null -ne $iface) { [int]$iface.InterfaceMetric } else { 0 }
      [pscustomobject]@{
        InterfaceIndex=[int]$_.InterfaceIndex
        InterfaceAlias=[string]$_.InterfaceAlias
        RouteMetric=[int]$_.RouteMetric
        InterfaceMetric=$metric
        TotalMetric=([int]$_.RouteMetric+$metric)
      }
    } | Sort-Object TotalMetric,RouteMetric,InterfaceIndex
  return @($rows)
}
function Get-InterfaceSnapshot([int]$InterfaceIndex) {
  $iface = Get-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $InterfaceIndex -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($null -eq $iface) { return $null }
  return [pscustomobject]@{
    interfaceIndex=$InterfaceIndex
    originalAutomaticMetric=[string]$iface.AutomaticMetric
    originalInterfaceMetric=[int]$iface.InterfaceMetric
  }
}
function Set-InterfaceMetric([int]$InterfaceIndex,[int]$Metric) {
  Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $InterfaceIndex -AutomaticMetric Disabled -InterfaceMetric ([Math]::Max(1,$Metric)) -ErrorAction Stop
}
function Restore-MetricState([string]$StatePath,[string]$Label) {
  $state = Read-JsonFile $StatePath
  if ($null -eq $state -or -not $state.applied) {
    return [pscustomobject]@{ restored=$false; restoredCount=0; message=("$Label 변경 기록이 없습니다.") }
  }
  $changes = @()
  if ($null -ne $state.changes) {
    $changes = @($state.changes)
  } elseif ($null -ne $state.interfaceIndex) {
    $changes = @([pscustomobject]@{
      interfaceIndex=[int]$state.interfaceIndex
      originalAutomaticMetric=[string]$state.originalAutomaticMetric
      originalInterfaceMetric=[int]$state.originalInterfaceMetric
    })
  }
  $restored = 0
  foreach ($change in $changes) {
    $index = [int]$change.interfaceIndex
    if ($index -le 0) { continue }
    $iface = Get-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $index -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $iface) { continue }
    $auto = [string]$change.originalAutomaticMetric
    if ([string]::IsNullOrWhiteSpace($auto)) { $auto = 'Enabled' }
    if ($auto -match 'Enabled|True') {
      Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $index -AutomaticMetric Enabled -ErrorAction Stop
    } else {
      $metric = [Math]::Max(1,[int]$change.originalInterfaceMetric)
      Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $index -AutomaticMetric Disabled -InterfaceMetric $metric -ErrorAction Stop
    }
    $restored++
  }
  Remove-Item -LiteralPath $StatePath -Force -ErrorAction SilentlyContinue
  return [pscustomobject]@{ restored=($restored -gt 0); restoredCount=$restored; message=("$Label 기존 메트릭을 복원했습니다.") }
}
function Write-Result($Value) {
  Write-JsonFile $ResultPath $Value
}
function Get-UsableIpv4ForIndex([int]$InterfaceIndex) {
  if ($InterfaceIndex -le 0) { return $null }
  return Get-NetIPAddress -AddressFamily IPv4 -InterfaceIndex $InterfaceIndex -ErrorAction SilentlyContinue |
    Where-Object { $_.IPAddress -and $_.IPAddress -notlike '169.254.*' -and $_.IPAddress -ne '0.0.0.0' } |
    Select-Object -First 1
}

# v1.6.4 / Helper 3.0.42: legacy default-route helpers are restoration-only; normal operation never mutates InterfaceMetric.
# The phone tether may temporarily win Windows' automatic metric.  We never treat that
# as the user's normal Internet.  Instead choose an active physical non-tethering
# default-route candidate (Wi-Fi or Ethernet), preferring Windows' own Internet profile
# and route metric, then pin it before the Coupang-only tether adapter is applied.
function Test-LikelyTetheringAdapter($adapter) {
  if ($null -eq $adapter) { return $false }
  $text = (([string]$adapter.Name) + ' ' + ([string]$adapter.InterfaceDescription)).ToLowerInvariant()
  return ($text -match 'usb|rndis|ndis|tether|mobile|android|samsung|galaxy|iphone|apple|테더')
}
function Test-VirtualOrNonPhysicalAdapter($adapter) {
  if ($null -eq $adapter) { return $true }
  if ($null -ne $adapter.HardwareInterface -and -not [bool]$adapter.HardwareInterface) { return $true }
  $text = (([string]$adapter.Name) + ' ' + ([string]$adapter.InterfaceDescription)).ToLowerInvariant()
  return ($text -match 'virtual|hyper-v|vmware|virtualbox|wsl|vpn|bluetooth|loopback|tap|tunnel')
}
function Get-NormalDefaultRouteCandidates([int]$ExcludeInterfaceIndex = 0) {
  $items = @()
  foreach ($route in @(Get-DefaultRouteSnapshot)) {
    $index = [int]$route.InterfaceIndex
    if ($index -le 0 -or ($ExcludeInterfaceIndex -gt 0 -and $index -eq $ExcludeInterfaceIndex)) { continue }
    $adapter = Get-NetAdapter -InterfaceIndex $index -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $adapter -or [string]$adapter.Status -ne 'Up') { continue }
    if (Test-LikelyTetheringAdapter $adapter) { continue }
    if (Test-VirtualOrNonPhysicalAdapter $adapter) { continue }
    if ($null -eq (Get-UsableIpv4ForIndex $index)) { continue }
    $profile = Get-NetConnectionProfile -InterfaceIndex $index -ErrorAction SilentlyContinue | Select-Object -First 1
    $internetRank = if ($null -ne $profile -and [string]$profile.IPv4Connectivity -eq 'Internet') { 0 } else { 1 }
    $items += [pscustomobject]@{
      InterfaceIndex=$index
      InterfaceAlias=[string]$route.InterfaceAlias
      RouteMetric=[int]$route.RouteMetric
      TotalMetric=[int]$route.TotalMetric
      InternetRank=$internetRank
      AdapterId=if($null-ne$adapter.InterfaceGuid){[string]$adapter.InterfaceGuid}else{''}
      AdapterName=[string]$adapter.Name
      AdapterDescription=[string]$adapter.InterfaceDescription
    }
  }
  return @($items | Sort-Object InternetRank,TotalMetric,RouteMetric,InterfaceIndex)
}

# v1.6.2: a laptop can administratively turn Wi-Fi off when a new wired/RNDIS link appears.
# The saved normal adapter is the only adapter we are allowed to re-enable automatically.
# We never disable or restart the normal adapter here; this guard only restores availability,
# then Windows' existing saved Wi-Fi profile is allowed to reconnect normally.
function Restore-SavedNormalAdapterIfNeededV161($Saved) {
  $result = [ordered]@{
    attempted=$false; found=$false; enabled=$false; wlanAutoConfigRequested=$false
    ready=$false; adapterName=''; interfaceIndex=0; message=''
  }
  if ($null -eq $Saved -or -not $Saved.applied) { return [pscustomobject]$result }

  $adapter = $null
  $savedIndex = [int]$Saved.interfaceIndex
  if ($savedIndex -gt 0) {
    $adapter = Get-NetAdapter -InterfaceIndex $savedIndex -ErrorAction SilentlyContinue | Select-Object -First 1
  }
  if ($null -eq $adapter -and -not [string]::IsNullOrWhiteSpace([string]$Saved.adapterName)) {
    $adapter = Get-NetAdapter -Name ([string]$Saved.adapterName) -ErrorAction SilentlyContinue | Select-Object -First 1
  }
  if ($null -eq $adapter -and -not [string]::IsNullOrWhiteSpace([string]$Saved.adapterDescription)) {
    $matches = @(Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { [string]$_.InterfaceDescription -eq [string]$Saved.adapterDescription })
    if ($matches.Count -eq 1) { $adapter = $matches[0] }
  }
  if ($null -eq $adapter) { $result.message='저장된 일반 인터넷 어댑터를 찾지 못했습니다.'; return [pscustomobject]$result }
  if (Test-LikelyTetheringAdapter $adapter) { $result.message='저장된 어댑터가 휴대폰 테더링으로 판정되어 자동 복구하지 않았습니다.'; return [pscustomobject]$result }
  if (Test-VirtualOrNonPhysicalAdapter $adapter) { $result.message='저장된 어댑터가 가상/VPN 계열로 판정되어 자동 복구하지 않았습니다.'; return [pscustomobject]$result }

  $result.attempted=$true
  $result.found=$true
  $result.adapterName=[string]$adapter.Name
  $result.interfaceIndex=[int]$adapter.ifIndex
  $status=[string]$adapter.Status
  $adminStatus=[string]$adapter.AdminStatus
  $identity=(([string]$adapter.Name)+' '+([string]$adapter.InterfaceDescription)).ToLowerInvariant()
  $wifiLike=($identity -match 'wi-?fi|wireless|802\.11|wlan|무선')

  if ($status -match 'Disabled' -or $adminStatus -match 'Down|Disabled') {
    try {
      Enable-NetAdapter -Name ([string]$adapter.Name) -Confirm:$false -ErrorAction Stop
      $result.enabled=$true
    } catch {
      $result.message=('저장된 기본 인터넷 어댑터 활성화 실패: ' + $_.Exception.Message)
      return [pscustomobject]$result
    }
  }

  if ($wifiLike) {
    try {
      & netsh.exe wlan set autoconfig enabled=yes interface="$([string]$adapter.Name)" | Out-Null
      $result.wlanAutoConfigRequested=$true
    } catch { }
  }

  $deadline=(Get-Date).AddSeconds(12)
  do {
    Start-Sleep -Milliseconds 350
    $fresh=Get-NetAdapter -InterfaceIndex ([int]$adapter.ifIndex) -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null-ne$fresh -and [string]$fresh.Status -eq 'Up' -and $null-ne(Get-UsableIpv4ForIndex ([int]$adapter.ifIndex))) {
      $result.ready=$true
      $result.message=('저장된 기본 인터넷 어댑터 준비 완료: ' + [string]$fresh.Name)
      break
    }
  } while((Get-Date)-lt$deadline)
  if(-not$result.ready -and [string]::IsNullOrWhiteSpace([string]$result.message)){
    $result.message=('저장된 기본 인터넷 어댑터가 아직 연결되지 않았습니다: ' + [string]$adapter.Name)
  }
  return [pscustomobject]$result
}
function Ensure-NormalAdapterReadyV162($Request) {
  $result = [ordered]@{ attempted=$false; found=$false; enabled=$false; wlanAutoConfigRequested=$false; dhcpRenewAttempted=$false; ready=$false; adapterName=''; adapterDescription=''; interfaceIndex=0; message='' }
  if ($null -eq $Request) { $result.message='기본 인터넷 복구 요청이 없습니다.'; return [pscustomobject]$result }
  $selectedIndex=[int]$Request.interfaceIndex
  $requestedName=[string]$Request.adapterName
  $requestedDescription=[string]$Request.adapterDescription
  $adapter=$null
  if($selectedIndex-gt0){$adapter=Get-NetAdapter -InterfaceIndex $selectedIndex -ErrorAction SilentlyContinue | Select-Object -First 1}
  if($null-eq$adapter -and -not[string]::IsNullOrWhiteSpace($requestedName)){$adapter=Get-NetAdapter -Name $requestedName -ErrorAction SilentlyContinue | Select-Object -First 1}
  if($null-eq$adapter -and -not[string]::IsNullOrWhiteSpace($requestedDescription)){
    $matches=@(Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object{[string]$_.InterfaceDescription -eq $requestedDescription})
    if($matches.Count-eq1){$adapter=$matches[0]}
  }
  if($null-eq$adapter){$result.message='선택한 Wi-Fi/유선 기본 인터넷 어댑터를 찾지 못했습니다.';return[pscustomobject]$result}
  if(Test-LikelyTetheringAdapter $adapter){$result.message='휴대폰 USB 테더링은 기본 인터넷으로 복구하지 않습니다.';return[pscustomobject]$result}
  if(Test-VirtualOrNonPhysicalAdapter $adapter){$result.message='가상/VPN 어댑터는 기본 인터넷으로 복구하지 않습니다.';return[pscustomobject]$result}
  $result.attempted=$true;$result.found=$true;$result.adapterName=[string]$adapter.Name;$result.adapterDescription=[string]$adapter.InterfaceDescription;$result.interfaceIndex=[int]$adapter.ifIndex
  $identity=(([string]$adapter.Name)+' '+([string]$adapter.InterfaceDescription)).ToLowerInvariant()
  $wifiLike=($identity -match 'wi-?fi|wireless|802\.11|wlan|무선')
  $status=[string]$adapter.Status;$adminStatus=[string]$adapter.AdminStatus
  if($status-match'Disabled' -or $adminStatus-match'Down|Disabled'){
    try{Enable-NetAdapter -Name ([string]$adapter.Name) -Confirm:$false -ErrorAction Stop;$result.enabled=$true}catch{$result.message=('기본 인터넷 어댑터 활성화 실패: '+$_.Exception.Message);return[pscustomobject]$result}
  }
  if($wifiLike){
    try{Start-Service -Name WlanSvc -ErrorAction SilentlyContinue}catch{}
    try{& netsh.exe wlan set autoconfig enabled=yes interface="$([string]$adapter.Name)" | Out-Null;$result.wlanAutoConfigRequested=$true}catch{}
  }
  $deadline=(Get-Date).AddSeconds(16)
  do{
    Start-Sleep -Milliseconds 400
    $fresh=Get-NetAdapter -InterfaceIndex ([int]$result.interfaceIndex) -ErrorAction SilentlyContinue | Select-Object -First 1
    if($null-ne$fresh){$result.adapterName=[string]$fresh.Name;$result.adapterDescription=[string]$fresh.InterfaceDescription;$result.interfaceIndex=[int]$fresh.ifIndex}
    $usable=Get-UsableIpv4ForIndex ([int]$result.interfaceIndex)
    if($null-ne$fresh -and [string]$fresh.Status-eq'Up' -and $null-ne$usable){$result.ready=$true;$result.message=('기본 인터넷 어댑터 준비 완료: '+[string]$fresh.Name);break}
  }while((Get-Date)-lt$deadline)
  if(-not$result.ready){
    $renew=Invoke-TetherDhcpRenew ([int]$result.interfaceIndex)
    $result.dhcpRenewAttempted=[bool]$renew.attempted
    $renewDeadline=(Get-Date).AddSeconds(6)
    do{
      Start-Sleep -Milliseconds 500
      $fresh=Get-NetAdapter -InterfaceIndex ([int]$result.interfaceIndex) -ErrorAction SilentlyContinue | Select-Object -First 1
      $usable=Get-UsableIpv4ForIndex ([int]$result.interfaceIndex)
      if($null-ne$fresh -and [string]$fresh.Status-eq'Up' -and $null-ne$usable){$result.ready=$true;$result.message=('기본 인터넷 어댑터 DHCP 준비 완료: '+[string]$fresh.Name);break}
    }while((Get-Date)-lt$renewDeadline)
  }
  if(-not$result.ready -and [string]::IsNullOrWhiteSpace([string]$result.message)){$result.message=('Wi-Fi/유선 기본 인터넷 연결을 복구했지만 IPv4가 아직 준비되지 않았습니다: '+[string]$result.adapterName)}
  return [pscustomobject]$result
}

function Find-TetherAdapter([int]$InterfaceIndex,[string]$Name,[string]$Description) {
  $candidate = $null
  if ($InterfaceIndex -gt 0) { $candidate = Get-NetAdapter -InterfaceIndex $InterfaceIndex -ErrorAction SilentlyContinue | Select-Object -First 1 }
  if ($null -eq $candidate -and -not [string]::IsNullOrWhiteSpace($Name)) {
    $candidate = Get-NetAdapter -Name $Name -ErrorAction SilentlyContinue | Select-Object -First 1
  }
  if ($null -eq $candidate -and -not [string]::IsNullOrWhiteSpace($Description)) {
    $matches = @(Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { [string]$_.InterfaceDescription -eq $Description })
    if ($matches.Count -eq 1) { $candidate = $matches[0] }
  }
  return $candidate
}
function Invoke-TetherDhcpRenew([int]$InterfaceIndex) {
  $result = [ordered]@{ attempted=$false; returnCode=-1; error='' }
  if ($InterfaceIndex -le 0) { return [pscustomobject]$result }
  try {
    $config = Get-CimInstance Win32_NetworkAdapterConfiguration -ErrorAction Stop |
      Where-Object { [int]$_.InterfaceIndex -eq $InterfaceIndex } |
      Select-Object -First 1
    if ($null -eq $config) { $result.error='DHCP 구성 정보를 찾지 못했습니다.'; return [pscustomobject]$result }
    if (-not [bool]$config.DHCPEnabled) { $result.error='DHCP가 비활성화된 어댑터입니다.'; return [pscustomobject]$result }
    $result.attempted=$true
    $renew = Invoke-CimMethod -InputObject $config -MethodName RenewDHCPLease -ErrorAction Stop
    if ($null -ne $renew -and $null -ne $renew.ReturnValue) { $result.returnCode=[int]$renew.ReturnValue }
  } catch {
    $result.returnCode=-2
    $result.error=$_.Exception.Message
  }
  return [pscustomobject]$result
}

$request = $null
$activeStatePath = ''
try {
  $request = Read-JsonFile $RequestPath
  if ($null -eq $request) { throw '네트워크 안전가드 요청 파일이 없습니다.' }
  $requestId = [string]$request.requestId
  $mode = [string]$request.mode

  if ($mode -eq 'recover_window_ipv4') {
    $selectedIndex = [int]$request.interfaceIndex
    if ($selectedIndex -le 0) { throw 'IPv4 복구 대상 인터페이스 번호가 없습니다.' }

    # v4.1.76: 사용자 선택 USB/RNDIS만 복구합니다. 기본 Ethernet/Wi-Fi와 고정 IP는 건드리지 않습니다.
    # 169.254(APIPA)는 휴대폰 테더링 DHCP가 아직 복구되지 않은 상태이므로
    # 1차 DHCP 갱신 -> 짧은 대기 -> 대상 USB 어댑터 1회 재시작 -> 2차 DHCP 갱신 순으로 제한합니다.
    $requestedName=[string]$request.adapterName
    $requestedDescription=[string]$request.adapterDescription
    $adapter = Find-TetherAdapter $selectedIndex $requestedName $requestedDescription
    if ($null -eq $adapter) { throw 'IPv4 복구 대상 어댑터를 찾지 못했습니다.' }
    $stableName=[string]$adapter.Name
    $stableDescription=[string]$adapter.InterfaceDescription
    $identity = ($stableName + ' ' + $stableDescription).ToLowerInvariant()
    if ($identity -notmatch 'usb|rndis|ndis|tether|mobile|android|samsung|galaxy|iphone|apple|테더') {
      throw ('안전상 일반 네트워크 어댑터에는 DHCP 복구를 실행하지 않습니다: ' + [string]$adapter.Name)
    }

    $selectedIndex=[int]$adapter.ifIndex
    $usable = Get-UsableIpv4ForIndex $selectedIndex
    $renew1=[pscustomobject]@{attempted=$false;returnCode=-1;error=''}
    $renew2=[pscustomobject]@{attempted=$false;returnCode=-1;error=''}
    $restartAttempted=$false
    $restartSucceeded=$false
    $restartError=''

    if ($null -eq $usable) {
      $renew1=Invoke-TetherDhcpRenew $selectedIndex
      $firstDeadline=(Get-Date).AddSeconds(4)
      while($null-eq$usable -and (Get-Date)-lt$firstDeadline){
        Start-Sleep -Milliseconds 400
        $usable=Get-UsableIpv4ForIndex $selectedIndex
      }
    }

    if ($null -eq $usable) {
      $restartAttempted=$true
      try {
        $adapter = Find-TetherAdapter $selectedIndex $stableName $stableDescription
        if ($null -eq $adapter) { throw '재시작할 USB/RNDIS 어댑터를 다시 찾지 못했습니다.' }
        if ($null -ne (Get-Command Restart-NetAdapter -ErrorAction SilentlyContinue)) {
          Restart-NetAdapter -Name ([string]$adapter.Name) -Confirm:$false -ErrorAction Stop
        } else {
          Disable-NetAdapter -Name ([string]$adapter.Name) -Confirm:$false -ErrorAction Stop
          Start-Sleep -Milliseconds 900
          Enable-NetAdapter -Name ([string]$adapter.Name) -Confirm:$false -ErrorAction Stop
        }
        $restartSucceeded=$true
      } catch {
        $restartError=$_.Exception.Message
      }

      $returnDeadline=(Get-Date).AddSeconds(7)
      do {
        Start-Sleep -Milliseconds 500
        $adapter = Find-TetherAdapter $selectedIndex $stableName $stableDescription
        if ($null -ne $adapter) {
          $selectedIndex=[int]$adapter.ifIndex
          $usable=Get-UsableIpv4ForIndex $selectedIndex
        }
      } while($null-eq$usable -and (Get-Date)-lt$returnDeadline)

      if ($null -eq $usable -and $null -ne $adapter) {
        $renew2=Invoke-TetherDhcpRenew $selectedIndex
        $secondDeadline=(Get-Date).AddSeconds(9)
        while($null-eq$usable -and (Get-Date)-lt$secondDeadline){
          Start-Sleep -Milliseconds 500
          $adapter = Find-TetherAdapter $selectedIndex $stableName $stableDescription
          if ($null -ne $adapter) {
            $selectedIndex=[int]$adapter.ifIndex
            $usable=Get-UsableIpv4ForIndex $selectedIndex
          }
        }
      }
    }

    Write-Result ([ordered]@{
      ok=$true; requestId=$requestId; mode=$mode
      workerRevision='v4.1.78-rndis-fast-dhcp-recovery-v4'
      adapterId=[string]$request.adapterId
      adapterName=if($null-ne$adapter){[string]$adapter.Name}else{$requestedName}
      interfaceIndex=$selectedIndex
      ipv4Ready=($null -ne $usable)
      ipv4Address=if($null-ne$usable){[string]$usable.IPAddress}else{''}
      dhcpRenewAttempted=([bool]$renew1.attempted -or [bool]$renew2.attempted)
      dhcpRenewReturnCode=[int]$renew1.returnCode
      firstDhcpRenewReturnCode=[int]$renew1.returnCode
      secondDhcpRenewReturnCode=[int]$renew2.returnCode
      adapterRestartAttempted=$restartAttempted
      adapterRestartSucceeded=$restartSucceeded
      adapterRestartError=$restartError
      message=if($null-ne$usable){'휴대폰 USB 테더링 IPv4 준비를 확인했습니다.'}else{'USB/RNDIS DHCP 재갱신과 대상 어댑터 1회 재시작 후에도 사용 가능한 IPv4가 없습니다.'}
      completedAt=(Get-Date).ToUniversalTime().ToString('o')
    })
    exit 0
  }

  if ($mode -eq 'auto_pin_normal') {
    # v1.6.4 compatibility only: restore legacy Collector metric state, then observe Windows.
    $legacyRouteCleanupOnly=$true
    if (Test-Path -LiteralPath $GuardStatePath) { $null = Restore-MetricState $GuardStatePath '레거시 전용창 선택 어댑터' }
    if (Test-Path -LiteralPath $SystemPinStatePath) { $null = Restore-MetricState $SystemPinStatePath '레거시 Windows 기본망 고정' }
    Start-Sleep -Milliseconds 200
    $default = Get-DefaultRouteSnapshot | Select-Object -First 1
    Write-Result ([ordered]@{
      ok=($null-ne$default); requestId=$requestId; mode=$mode
      systemPinApplied=$false; alreadyPinned=$false; routeMutationDisabled=$true; legacyRouteCleanupOnly=$true
      systemDefaultInterfaceIndex=if($default){[int]$default.InterfaceIndex}else{0}
      systemDefaultInterfaceAlias=if($default){[string]$default.InterfaceAlias}else{''}
      message='Windows 기본 인터넷은 OS가 관리합니다. Collector는 인터페이스 메트릭을 변경하지 않습니다.'
      completedAt=(Get-Date).ToUniversalTime().ToString('o')
    })
    exit 0
  }

  if ($mode -eq 'restore_window') {
    $restore = Restore-MetricState $GuardStatePath '전용창 선택 어댑터'
    Start-Sleep -Milliseconds 500
    $default = (Get-DefaultRouteSnapshot | Select-Object -First 1)
    Write-Result ([ordered]@{
      ok=$true; requestId=$requestId; mode=$mode
      routeGuardRestored=[bool]$restore.restored
      legacyRouteCleanupOnly=$true
      restoredCount=[int]$restore.restoredCount
      systemDefaultInterfaceIndex=if($default){[int]$default.InterfaceIndex}else{0}
      systemDefaultInterfaceAlias=if($default){[string]$default.InterfaceAlias}else{''}
      message=[string]$restore.message
      completedAt=(Get-Date).ToUniversalTime().ToString('o')
    })
    exit 0
  }

  if ($mode -eq 'restore_system') {
    if (Test-Path -LiteralPath $GuardStatePath) { $null = Restore-MetricState $GuardStatePath '전용창 선택 어댑터' }
    $restore = Restore-MetricState $SystemPinStatePath 'Windows 기본망 고정'
    Start-Sleep -Milliseconds 700
    $default = (Get-DefaultRouteSnapshot | Select-Object -First 1)
    Write-Result ([ordered]@{
      ok=$true; requestId=$requestId; mode=$mode
      systemPinRestored=[bool]$restore.restored
      legacyRouteCleanupOnly=$true
      restoredCount=[int]$restore.restoredCount
      systemDefaultInterfaceIndex=if($default){[int]$default.InterfaceIndex}else{0}
      systemDefaultInterfaceAlias=if($default){[string]$default.InterfaceAlias}else{''}
      message=[string]$restore.message
      completedAt=(Get-Date).ToUniversalTime().ToString('o')
    })
    exit 0
  }

  if ($mode -eq 'pin_system') {
    # v1.6.4 compatibility: manual/default pin requests no longer mutate Windows routing.
    $legacyRouteCleanupOnly=$true
    if (Test-Path -LiteralPath $GuardStatePath) { $null = Restore-MetricState $GuardStatePath '레거시 전용창 선택 어댑터' }
    if (Test-Path -LiteralPath $SystemPinStatePath) { $null = Restore-MetricState $SystemPinStatePath '레거시 Windows 기본망 고정' }
    Start-Sleep -Milliseconds 200
    $default = Get-DefaultRouteSnapshot | Select-Object -First 1
    Write-Result ([ordered]@{
      ok=$true; requestId=$requestId; mode=$mode; systemPinApplied=$false; routeMutationDisabled=$true; legacyRouteCleanupOnly=$true
      systemDefaultInterfaceIndex=if($default){[int]$default.InterfaceIndex}else{0}
      systemDefaultInterfaceAlias=if($default){[string]$default.InterfaceAlias}else{''}
      message='Windows 기본 인터넷은 OS가 관리합니다. 기본망 고정 요청은 호환 모드에서 무시했습니다.'
      completedAt=(Get-Date).ToUniversalTime().ToString('o')
    })
    exit 0
  }

  if ($mode -ne 'prepare_window') { throw "지원하지 않는 네트워크 안전가드 작업입니다: $mode" }
  # v1.6.4: verify-only guard. Never change InterfaceMetric/RouteMetric.
  $legacyRouteCleanupOnly=$true
  if (Test-Path -LiteralPath $GuardStatePath) { $null = Restore-MetricState $GuardStatePath '레거시 전용창 선택 어댑터' }
  if (Test-Path -LiteralPath $SystemPinStatePath) { $null = Restore-MetricState $SystemPinStatePath '레거시 Windows 기본망 고정' }
  $selectedIndex=[int]$request.interfaceIndex
  if ($selectedIndex -le 0) { throw '선택 어댑터 인터페이스 번호가 없습니다.' }
  $defaultAfter = Get-DefaultRouteSnapshot | Select-Object -First 1
  if ($null -eq $defaultAfter) { throw 'Windows 기본 인터넷 경로를 확인할 수 없습니다. Collector는 기본경로를 변경하지 않습니다.' }
  if ([int]$defaultAfter.InterfaceIndex -eq $selectedIndex) {
    throw '선택한 전용 네트워크가 현재 Windows 기본 인터넷입니다. 일반 트래픽의 테더링 사용을 막기 위해 중단했습니다. Windows/노트북 네트워크 설정에서 Wi-Fi 또는 유선 기본 인터넷을 복구하세요.'
  }
  Write-Result ([ordered]@{
    ok=$true; requestId=$requestId; mode=$mode
    routeGuardApplied=$false; routeMutationDisabled=$true; legacyRouteCleanupOnly=$true
    selectedInterfaceIndex=$selectedIndex
    systemDefaultInterfaceIndex=[int]$defaultAfter.InterfaceIndex
    systemDefaultInterfaceAlias=[string]$defaultAfter.InterfaceAlias
    message=('Windows 라우팅은 변경하지 않았습니다. 기본 인터넷 {0}, 쿠팡 전용 소켓 Bind {1}.' -f [string]$defaultAfter.InterfaceAlias,[string]$request.adapterName)
    completedAt=(Get-Date).ToUniversalTime().ToString('o')
  })
  Write-JsonFile $RuntimePath ([ordered]@{
    ok=$true; mode='window'; selectedAdapterId=[string]$request.adapterId; selectedAdapterName=[string]$request.adapterName
    routingTableChanged=$false; routeGuardOnly=$false; selectedSocketBindOnly=$true; updatedAt=(Get-Date).ToUniversalTime().ToString('o')
  })
  exit 0
} catch {
  $detail = $_.Exception.Message
  try {
    if ($activeStatePath -eq $SystemPinStatePath) {
      $null = Restore-MetricState $SystemPinStatePath '실패한 Windows 기본망 고정'
    } elseif ($activeStatePath -eq $GuardStatePath) {
      $null = Restore-MetricState $GuardStatePath '실패한 전용창 안전가드'
    }
  } catch { }
  Write-Result ([ordered]@{
    ok=$false
    requestId=[string]$request.requestId
    mode=[string]$request.mode
    routeGuardApplied=$false
    systemPinApplied=$false
    error=$detail
    failedAt=(Get-Date).ToUniversalTime().ToString('o')
  })
  exit 1
}
