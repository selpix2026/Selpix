﻿@echo off
chcp 65001 >nul
setlocal
set "PS=%~dp0tools\network-host\reset-dedicated-profile-safe.ps1"
if not exist "%PS%" (
  echo [ERROR] Safe dedicated profile reset PowerShell file not found.
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS%"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo [ERROR] Dedicated profile safe reset was not completed.
if "%RC%"=="0" echo [OK] Dedicated profile was backed up and recreated. Network/server data was preserved.
pause
exit /b %RC%
