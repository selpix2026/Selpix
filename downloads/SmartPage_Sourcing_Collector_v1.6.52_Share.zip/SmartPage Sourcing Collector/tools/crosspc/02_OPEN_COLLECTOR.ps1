﻿param([ValidateSet('','chrome','whale')][string]$BrowserFamily='')
$ErrorActionPreference='Stop'
$SourceRoot=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Root=Join-Path $env:ProgramData 'SmartPageEx\SmartPage Sourcing Collector'
. (Join-Path $PSScriptRoot 'browser-launch-common.ps1')
# v1.6.5 existing-PC update path: Windows default Internet stays OS-managed.
# A newer extracted package is synchronized to ProgramData only when needed; ordinary launches never elevate.
$ExpectedNetworkBuild='v3.0.45-v1651-coupang-only'
$NetworkRestartRequiredFlag=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33\v160-networkhost-restart-required.json'
function Get-CollectorVersion([string]$Base){
  $path=Join-Path $Base 'manifest.json'
  if(-not(Test-Path -LiteralPath $path -PathType Leaf)){return $null}
  try{
    $json=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
    return [version]([string]$json.version)
  }catch{return $null}
}
function Invoke-ExistingPcRuntimeSyncV165{
  $sourceVersion=Get-CollectorVersion $SourceRoot
  $installedVersion=Get-CollectorVersion $Root
  if($null-eq$installedVersion){throw 'Collector 고정 설치본이 없습니다. 새 PC 또는 설치 복구는 RUN_00_INSTALL_OTHER_PC.cmd를 실행하세요.'}
  if($null-eq$sourceVersion){$sourceVersion=$installedVersion}
  $sourceIsNewer=$sourceVersion -gt $installedVersion
  $needNetworkHostRefresh=$false
  try{
    $health=Invoke-RestMethod -UseBasicParsing -Uri 'http://127.0.0.1:30765/health' -TimeoutSec 2 -ErrorAction Stop
    if([string]$health.buildMarker -ne $ExpectedNetworkBuild -or $health.proxyReady -ne $true){$needNetworkHostRefresh=$true}
  }catch{$needNetworkHostRefresh=$true}
  $needRuntimeSync=$sourceIsNewer -or $needNetworkHostRefresh
  if(-not$needRuntimeSync){return $false}

  # Never downgrade a newer fixed install. If this package is older, repair from the installed copy itself.
  $syncSourceRoot=if($sourceVersion -ge $installedVersion){$SourceRoot}else{$Root}
  $syncScript=Join-Path $syncSourceRoot 'tools\crosspc\10_SYNC_CURRENT_PACKAGE_TO_INSTALLED_ROOT.ps1'
  if(-not(Test-Path -LiteralPath $syncScript -PathType Leaf)){throw '기존 PC 자동 업데이트 도구를 찾지 못했습니다.'}
  Write-Host ('기존 PC 업데이트 적용 · package v'+$sourceVersion+' / installed v'+$installedVersion) -ForegroundColor Cyan
  & "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $syncScript -SourceRoot $syncSourceRoot -Quiet
  if($LASTEXITCODE -ne 0){throw ('기존 PC 자동 업데이트 실패 · ExitCode='+$LASTEXITCODE)}
  if(Test-Path -LiteralPath $NetworkRestartRequiredFlag -PathType Leaf){
    throw 'NetworkHost 새 버전 적용이 예약되었습니다. Windows를 1회 재시작한 뒤 Collector를 다시 여세요.'
  }
  return $true
}


$null=Invoke-ExistingPcRuntimeSyncV165
# open_coupang_window retains selected-adapter fail-closed validation and the canonical PAC.
$result=Invoke-SpxDedicatedRequest -LaunchMode 'selected-network' -StartUrl 'https://www.coupang.com/' -BrowserFamily $BrowserFamily -SourceRoot $Root
Write-Host ('Collector '+[string]$result.browserFamily+' 전용창을 열었습니다.') -ForegroundColor Green
if($result.registrationRequired -eq $true -or $result.extensionLoaded -eq $false){
 Write-Host ('이 브라우저 전용 프로필의 최초 확장 등록이 필요합니다. 등록할 폴더: '+[string]$result.expectedExtensionRoot) -ForegroundColor Yellow
}
