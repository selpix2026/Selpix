/* A skipped channel is not a new observation. Keep Naver evidence by family. */
(function(root){
  'use strict';
  const searchFields=['monthly_search_pc','monthly_search_mobile','monthly_search_volume','monthly_search_raw_pc','monthly_search_raw_mobile','monthly_search_keyword','monthly_search_source','monthly_search_volume_source','monthly_search_collected_at','monthly_search_status','monthly_search_error','monthly_search_cache_expires_at','monthly_search_raw_response','naver_competition_index','naver_monthly_pc_clicks','naver_monthly_mobile_clicks','naver_pc_ctr','naver_mobile_ctr','naver_ad_depth','naver_search_detail_status','naver_searchad_status','naver_searchad_error','naver_searchad_collected_at'];
  const trendFields=['monthly_search_trend_12m','shopping_search_trend_12m','monthly_search_trend_source','monthly_search_trend_status','monthly_search_trend_error','monthly_search_trend_collected_at','monthly_demand_period','naver_peak_month','naver_demand_range','naver_preregistration_period','seasonality_status','naver_trend_analysis_status','naver_datalab_status','naver_datalab_error','naver_datalab_collected_at'];
  const otherFields=['naver_shopping_status','naver_shopping_error','naver_shopping_collected_at','naver_shopping_category_id','naver_completion_status','naver_completion_reason'];
  const fields=[...searchFields,...trendFields,...otherFields];
  const has=(v)=>v!==null&&v!==undefined&&(typeof v!=='string'||v.trim()!=='')&&(!Array.isArray(v)||v.length>0);
  const numeric=(v)=>has(v)&&Number.isFinite(Number(v));
  function pick(row={}){const out={};for(const k of fields){const v=row[k]??row.external_metrics?.[k];if(v!==undefined)out[k]=v;}return out;}
  function strip(row={}){const out={...row};for(const k of fields)delete out[k];for(const k of ['external_metrics','collected_payload','grade_breakdown'])if(out[k]&&typeof out[k]==='object'&&!Array.isArray(out[k]))out[k]=strip(out[k]);return out;}
  function terminal(row,kind){const status=String(kind==='search'?(row.naver_searchad_status||row.monthly_search_status||''):(row.naver_datalab_status||row.monthly_search_trend_status||'')).toLowerCase();return ['no_data','not_available','insufficient'].includes(status)&&time(row,kind)>0;}
  function score(row,kind){if(kind==='search')return ['monthly_search_pc','monthly_search_mobile','monthly_search_volume','naver_pc_ctr','naver_mobile_ctr','naver_competition_index'].reduce((n,k)=>n+(k==='naver_competition_index'?has(row[k]):numeric(row[k])?1:0),0);const a=row.monthly_search_trend_12m||row.shopping_search_trend_12m;return Array.isArray(a)?a.length:0;}
  function time(row,kind){return Date.parse(kind==='search'?(row.naver_searchad_collected_at||row.monthly_search_collected_at||''):(row.naver_datalab_collected_at||row.monthly_search_trend_collected_at||''))||0;}
  function merge(canonical={},queue={}){
    const a=pick(canonical),b=pick(queue),out={};
    for(const [kind,keys] of [['search',searchFields],['trend',trendFields]]){
      const sa=score(a,kind),sb=score(b,kind);
      // A pending/error-only queue record must never hide canonical numeric/trend evidence.
      const bWins=(sb>0||terminal(b,kind))&&((sa===0&&!terminal(a,kind))||(time(b,kind)>time(a,kind)&&(sb>=sa||terminal(b,kind)))||(!time(a,kind)&&!time(b,kind)&&sb>sa));
      const first=bWins?a:b,last=bWins?b:a;
      for(const k of keys){if(!terminal(last,kind)&&has(first[k]))out[k]=first[k];if(Object.prototype.hasOwnProperty.call(last,k)&&(has(last[k])||/_error$/.test(k)))out[k]=last[k];}
    }
    const owner=(score(a,'search')+score(a,'trend')>0||terminal(a,'search')||terminal(a,'trend'))?a:b;
    for(const k of otherFields)if(Object.prototype.hasOwnProperty.call(owner,k))out[k]=owner[k];
    return out;
  }
  function carryForward(metric={},snapshot={}){return {...strip(metric),...pick(snapshot)};}
  function coupangOnly(row={},options={}){return options.coupangOnly===true||row.coupang_supplement_only===true||row.external_metrics?.coupang_supplement_only===true||row.collection_scope==='coupang';}
  root.SPXExternalMetricCompat={fields,searchFields,trendFields,pick,strip,merge,carryForward,coupangOnly};
})(globalThis);
