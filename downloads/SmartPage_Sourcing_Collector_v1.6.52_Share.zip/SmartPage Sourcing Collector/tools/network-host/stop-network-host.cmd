﻿@echo off
chcp 65001 >nul
powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0stop-network-host.ps1"
echo SmartPage Ex network helper stopped.
pause
