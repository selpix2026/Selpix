const $ = (id) => document.getElementById(id);
const msg = (text, cls) => { $('msg').textContent = text; $('msg').className = cls || ''; };
const OPTIONS_TAB_KEY='spxOptionsActiveTab';
const OPTIONS_BUILD_VERSION=String(chrome.runtime?.getManifest?.().version||'1.6.54');
const OPTIONS_RUNTIME_REPAIR_KEY='spxOptionsRuntimeRepairV30820';
const MANAGER_RESTORE_ADOPT_FLAG_V426='spxManagerAdoptRestoredLiveV426';
const MANAGER_LIVE_LOWLOAD_CHECKPOINT_KEY_V426='spxManagerLiveMirrorLowLoadCheckpointV426';
const WING_LOGIN_CREDENTIAL_KEY_V426='spxWingLoginCredentialV426';
function setWingLoginStatusV426(text,cls=''){const el=$('wingLoginStatus');if(!el)return;el.textContent=String(text||'');el.className='hint'+(cls?' '+cls:'');}
function wingCredentialInputV426(){return{version:2,username:String($('coupangWingId')?.value||'').trim(),password:String($('coupangWingPassword')?.value||''),autoLoginEnabled:$('coupangWingAutoLogin')?.checked!==false,updatedAt:Date.now()};}
async function loadWingCredentialLocalV426(legacySettings={}){const saved=await chrome.storage.local.get([WING_LOGIN_CREDENTIAL_KEY_V426,'settings']).catch(()=>({}));let row=saved?.[WING_LOGIN_CREDENTIAL_KEY_V426]&&typeof saved[WING_LOGIN_CREDENTIAL_KEY_V426]==='object'?saved[WING_LOGIN_CREDENTIAL_KEY_V426]:null;const legacyId=String(legacySettings?.coupangWingId||'').trim(),legacyPw=String(legacySettings?.coupangWingPassword||'');if(!row&&legacyId&&legacyPw){row={version:2,username:legacyId,password:legacyPw,autoLoginEnabled:legacySettings?.coupangWingAutoLogin!==false,updatedAt:Date.now(),migratedFrom:'settings'};await chrome.storage.local.set({[WING_LOGIN_CREDENTIAL_KEY_V426]:row});}
  const raw=saved?.settings&&typeof saved.settings==='object'?{...saved.settings}:null;if(raw&&(['coupangWingId','coupangWingPassword','coupangWingAutoLogin'].some((k)=>Object.prototype.hasOwnProperty.call(raw,k)))){delete raw.coupangWingId;delete raw.coupangWingPassword;delete raw.coupangWingAutoLogin;await chrome.storage.local.set({settings:raw});}
  row=row||{};if($('coupangWingId'))$('coupangWingId').value=String(row.username||'');if($('coupangWingPassword'))$('coupangWingPassword').value=String(row.password||'');if($('coupangWingAutoLogin'))$('coupangWingAutoLogin').checked=row.autoLoginEnabled!==false;const configured=Boolean(String(row.username||'').trim()&&String(row.password||''));setWingLoginStatusV426(configured?'로그인 정보 저장됨 · 기존 WING 세션 우선 사용':'저장된 WING 로그인 정보 없음',configured?'ok':'');return row;}
async function saveWingCredentialLocalV426({notify=true}={}){const row=wingCredentialInputV426();if(!row.username||!row.password){setWingLoginStatusV426('쿠팡 WING 아이디와 비밀번호를 모두 입력하세요.','bad');return false;}await chrome.storage.local.set({[WING_LOGIN_CREDENTIAL_KEY_V426]:row});setWingLoginStatusV426('로컬 저장 완료 · 기존 세션 우선 · 미로그인 시 자동 로그인','ok');if(notify)await SPX.util.sendMessage({type:'SPX_WING_LOGIN_CREDENTIAL_UPDATED_V426'}).catch(()=>null);return true;}
async function testWingLoginV426(){const button=$('testWingLogin');if(button)button.disabled=true;try{if(!await saveWingCredentialLocalV426({notify:false}))return false;setWingLoginStatusV426('WING 로그인 런타임 확인 중...','notice');let features=null;try{features=await SPX.util.sendMessage({type:'SPX_WING_LOGIN_FEATURES_V426'});}catch(_){}if(!features?.ok||features?.data?.loginTest!==true){setWingLoginStatusV426('확장 런타임 새로고침 필요 · chrome://extensions에서 SmartPage Sourcing Collector [새로고침] 후 다시 확인하세요.','notice');return false;}setWingLoginStatusV426('WING 로그인 상태 확인 중...','notice');const response=await SPX.util.sendMessage({type:'SPX_WING_LOGIN_TEST_V426'});const data=response?.data||{};if(response?.ok&&data.status==='ready'){const via=data.via==='auto_login'?'저장정보 자동 로그인':'기존 로그인 세션';setWingLoginStatusV426('로그인 확인 성공 · '+via+' · 조회수(28일) 수집 가능','ok');await SPX.util.sendMessage({type:'SPX_WING_LOGIN_CREDENTIAL_UPDATED_V426'}).catch(()=>null);return true;}if(data.status==='additional_auth'){setWingLoginStatusV426('추가 인증 필요 · 열린 WING 탭에서 CAPTCHA/2단계 인증을 완료하세요.','notice');return false;}if(data.status==='cooldown'){setWingLoginStatusV426('자동 로그인 쿨다운 중 · 계정 잠금 방지를 위해 잠시 후 다시 확인하세요.','notice');return false;}setWingLoginStatusV426('로그인 확인 실패 · '+String(data.message||data.reason||response?.error||'아이디/비밀번호 확인'),'bad');return false;}catch(error){const value=String(error?.message||error||'');if(/알 수 없는 요청|unknown request|receiving end does not exist|could not establish connection/i.test(value)){setWingLoginStatusV426('확장 런타임 새로고침 필요 · SmartPage Sourcing Collector [새로고침] 후 다시 확인하세요.','notice');return false;}setWingLoginStatusV426('로그인 확인 오류 · '+value,'bad');return false;}finally{if(button)button.disabled=false;}}
async function clearWingCredentialLocalV426(){await chrome.storage.local.remove(WING_LOGIN_CREDENTIAL_KEY_V426);if($('coupangWingId'))$('coupangWingId').value='';if($('coupangWingPassword'))$('coupangWingPassword').value='';if($('coupangWingAutoLogin'))$('coupangWingAutoLogin').checked=true;setWingLoginStatusV426('저장된 WING 로그인 정보를 삭제했습니다.');await SPX.util.sendMessage({type:'SPX_WING_LOGIN_CREDENTIAL_CLEARED_V426'}).catch(()=>null);}


function isMissingRuntimeReceiverError(error){
  const text=String(error?.message||error||'').toLowerCase();
  return text.includes('receiving end does not exist')||text.includes('could not establish connection')||text.includes('message port closed')||text.includes('message channel closed')||text.includes('before a response was received')||text.includes('asynchronous response')||text.includes('extension context invalidated');
}


function optionsLegacyRuntimeError(value){return /sendNativeMessage.*(?:is not a function|undefined)|(?:알 수 없는 요청|unknown request).*SPX_NETWORK/i.test(String(value?.error||value?.message||value||''));}
async function ensureOptionsRuntimeAligned(){
  let response=null;
  try{response=await SPX.util.sendMessage({type:'SPX_RUNTIME_INFO'});}catch(error){
    if(!optionsLegacyRuntimeError(error)&&!isMissingRuntimeReceiverError(error))throw error;
  }
  const runtimeBuild=String(response?.data?.runtimeBuild||'').trim();
  const manifestVersion=String(chrome.runtime?.getManifest?.().version||'').trim();
  const reason=`옵션 ${OPTIONS_BUILD_VERSION} · 서비스워커 ${runtimeBuild||'시작 대기'} · manifest ${manifestVersion||'확인 불가'}`;
  /* v3.0.8.20: 옵션 페이지는 서비스워커가 늦게 시작되거나 응답하지 않아도 로컬 설정을
     열 수 있어야 합니다. 이전 구현처럼 chrome.runtime.reload()를 호출하면 설정 탭이
     닫히거나 무한 재시작될 수 있으므로, manifest가 현재 빌드면 즉시 초기화합니다. */
  if(manifestVersion===OPTIONS_BUILD_VERSION){
    if(runtimeBuild&&runtimeBuild!==OPTIONS_BUILD_VERSION)msg(`서비스워커 갱신 대기 · ${reason} · 설정은 열어두고 저장 시 다시 확인합니다.`,'notice');
    return true;
  }
  msg(`확장 파일 버전 불일치 · ${reason} · chrome://extensions에서 SmartPage Sourcing Collector를 한 번 새로고침하세요.`,'bad');
  return false;
}

function activateOptionsTab(name,persist=true){const safe=['safety','integration'].includes(name)?name:'safety';document.querySelectorAll('[data-options-tab]').forEach((b)=>{const on=b.dataset.optionsTab===safe;b.classList.toggle('active',on);b.setAttribute('aria-selected',String(on));});document.querySelectorAll('[data-options-panel]').forEach((panel)=>panel.classList.toggle('active',panel.dataset.optionsPanel===safe));if(persist)chrome.storage.local.set({[OPTIONS_TAB_KEY]:safe}).catch(()=>{});}
document.querySelectorAll('[data-options-tab]').forEach((button)=>button.addEventListener('click',()=>activateOptionsTab(button.dataset.optionsTab)));
chrome.storage.local.get(OPTIONS_TAB_KEY).then((d)=>activateOptionsTab(d?.[OPTIONS_TAB_KEY]||'safety',false)).catch(()=>activateOptionsTab('safety',false));
const fmt = (n) => Number(n || 0).toLocaleString('ko-KR');
const formatKstDateTime=(value=Date.now())=>{const d=new Date(value);return Number.isFinite(d.getTime())?new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(d):'-';};
function setTimingPair(minId,maxId,minValue,maxValue){const minEl=$(minId),maxEl=$(maxId);if(minEl)minEl.value=String(Math.round(Number(minValue)||0));if(maxEl)maxEl.value=String(Math.round(Number(maxValue)||0));}
function readTimingPair(minId,maxId,defaultMin,defaultMax,{min=0,max=86400000}={}){let lo=Number($(minId)?.value),hi=Number($(maxId)?.value);if(!Number.isFinite(lo))lo=defaultMin;if(!Number.isFinite(hi))hi=defaultMax;lo=Math.max(min,Math.min(max,Math.round(lo)));hi=Math.max(lo,Math.min(max,Math.round(hi)));return[lo,hi];}
const averageMinutesFromMs=(minMs,maxMs)=>Math.max(0,Math.round(((Number(minMs)||0)+(Number(maxMs)||0))/120000));

/* type=number 입력란은 브라우저 규격상 값 자체에 쉼표를 넣을 수 없습니다.
   숫자 입력은 그대로 유지하고 오른쪽에 천 단위 쉼표 미리보기를 실시간 표시합니다. */
function normalizeNumericInputs() {
  document.querySelectorAll('input[type="number"]').forEach((input) => {
    const cleaned = String(input.value ?? '').replace(/,/g, '').trim();
    if (cleaned !== input.value) input.value = cleaned;
  });
}
function updateNumberCommaPreview(input) {
  if (!input || input.type !== 'number') return;
  let preview = input.parentElement?.querySelector(`.number-comma-preview[data-for="${CSS.escape(input.id || '')}"]`);
  if (!input.id) return;
  if (!preview) {
    preview = document.createElement('small');
    preview.className = 'number-comma-preview';
    preview.dataset.for = input.id;
    input.insertAdjacentElement('afterend', preview);
  }
  const value = Number(String(input.value || '').replace(/,/g, ''));
  preview.textContent = Number.isFinite(value) && Math.abs(value) >= 1000 ? value.toLocaleString('ko-KR') : '';
  preview.hidden = !preview.textContent;
}
function bindThousandsFormatting() {
  document.querySelectorAll('input[type="number"]').forEach((input) => {
    const update = () => updateNumberCommaPreview(input);
    input.addEventListener('input', update);
    input.addEventListener('change', update);
    update();
  });
}

async function refreshProtectedSettingsStatus(){
 const target=$('supabaseProtectedSettingsStatus');if(!target)return;
 let response;try{response=await SPX.util.sendMessage({type:'SPX_SECURE_SETTINGS_STATUS'});if(!response?.ok)throw new Error(response?.error||'상태 확인 실패');}
 catch(error){const current=await SPX.util.getSettings();let saved={};try{saved=(await requestLocalNetworkBridgeFromOptions({command:'load_profile_settings',extensionId:String(chrome.runtime?.id||'')},6500))?.settings||{};}catch(_){}response={current:{supabase:Boolean(current.supabaseUrl&&current.serviceKey)},protected:{supabase:Boolean(saved.supabaseUrl&&saved.serviceKey)},warning:error?.message||String(error)};}
 target.textContent=`현재 설정 ${response.current?.supabase?'준비됨':'누락'} · Windows 보호 백업 ${response.protected?.supabase?'준비됨':'없음'}${response.warning?' · '+response.warning:''}`;target.className='hint '+(response.protected?.supabase?'ok':'notice');
}

async function runSecureSettingsAction(scope,action,buttonId){
  const button=$(buttonId),original=button?.textContent||'';
  if(button){button.disabled=true;button.textContent=action==='backup'?'백업 중...':'복원 중...';}
  try{
    if(action==='backup'){
      if(scope==='supabase')await SPX.util.setSettings({supabaseUrl:$('url').value.trim().replace(/\/+$/,''),serviceKey:$('key').value.trim()});
    }
    let response=null;
    try{
      response=await SPX.util.sendMessage({type:action==='backup'?'SPX_SECURE_SETTINGS_BACKUP':'SPX_SECURE_SETTINGS_RESTORE',scope});
      if(!response?.ok)throw new Error(response?.error||'Windows 보호 설정 처리 실패');
    }catch(runtimeError){
      /* 업데이트 직후 이전 Service Worker가 새 메시지를 모를 수 있으므로 보호 백업/복원도
         상태 조회와 같은 로컬 브리지 직접 경로로 이어갑니다. */
      const extensionId=String(chrome.runtime?.id||'');
      if(action==='backup'){
        const current=await SPX.util.getSettings();
        let protectedSettings={};
        try{
          const loaded=await requestLocalNetworkBridgeFromOptions({command:'load_profile_settings',extensionId},6500);
          protectedSettings=loaded?.settings&&typeof loaded.settings==='object'?loaded.settings:{};
        }catch(_){}
        const patch=SPX.util.pickSensitiveSettings(current,scope);
        if(!Object.keys(patch).length)throw new Error('보호 백업할 연동 설정이 없습니다.');
        const saved=await requestLocalNetworkBridgeFromOptions({command:'save_profile_settings',extensionId,settings:{...protectedSettings,...patch}},10000);
        response={ok:true,scope,protectedBy:saved?.protectedBy||'Windows DPAPI LocalMachine',savedAt:saved?.savedAt||new Date().toISOString(),fallback:true};
      }else{
        const loaded=await requestLocalNetworkBridgeFromOptions({command:'load_profile_settings',extensionId},8000);
        if(loaded?.found!==true)throw new Error('Windows 보호 저장소에 복원할 연동 설정이 없습니다.');
        const patch=SPX.util.pickSensitiveSettings(loaded.settings||{},scope);
        if(!Object.keys(patch).length)throw new Error('선택한 범위의 보호 백업이 비어 있습니다.');
        await SPX.util.setSettings(patch);
        response={ok:true,scope,restoredFields:Object.keys(patch),sourceSavedAt:loaded.savedAt||'',fallback:true};
      }
      response.warning=`서비스워커 보조 경로 사용 · ${runtimeError?.message||runtimeError}`;
    }
    if(action==='restore'){
      const settings=await SPX.util.getSettings();
      {
        $('url').value=settings.supabaseUrl||'';
        $('key').value=settings.serviceKey||'';
      }
    }
    msg(`Supabase 연동 설정을 Windows DPAPI 보호 저장소에서 ${action==='backup'?'백업':'복원'}했습니다.${response?.warning?` ${response.warning}`:''}`, 'ok');
    await refreshProtectedSettingsStatus();
  }catch(error){msg(`Supabase 보호 ${action==='backup'?'백업':'복원'} 실패: ${error?.message||error}`,'bad');}
  finally{if(button){button.disabled=false;button.textContent=original;}}
}

function updateCategorySelectionCount() {
  const total = document.querySelectorAll('[data-cat]').length;
  const selected = document.querySelectorAll('[data-cat]:checked').length;
  const target = $('categorySelectionCount');
  if (target) target.textContent = `선택 ${selected}개 / 전체 ${total}개`;
}
function renderCategories(selected) {
  const grid = $('categoryGrid');
  if (!grid) return;
  const options = SPX.explore.categoryOptions();
  const selectedList = Array.isArray(selected) && selected.length ? selected : options.map((c) => c.id);
  const set = new Set(selectedList);
  grid.innerHTML = options.map((c) =>
    `<div class="cat-item"><input type="checkbox" id="cat_${c.id}" data-cat="${c.id}" ${set.has(c.id) ? 'checked' : ''}><label for="cat_${c.id}">${c.label}</label></div>`
  ).join('');
  updateCategorySelectionCount();
}
function selectedCategories() { return [...document.querySelectorAll('[data-cat]:checked')].map((el) => el.dataset.cat); }

const NETWORK_LOCAL_BRIDGE_URLS=['http://127.0.0.1:30765'];
const NETWORK_LOCAL_BRIDGE_TOKEN='spx-v7-8e3c0af4640b4a20a1d706a1fba5e6d7';
const NETWORK_ADAPTER_CACHE_KEY='spxNetworkAdapterCacheV22';
let currentPlatformOS='unknown';
let platformInfoPromise=null;
function getPlatformOS(){
  if(platformInfoPromise)return platformInfoPromise;
  platformInfoPromise=new Promise((resolve)=>{
    try{chrome.runtime.getPlatformInfo((info)=>{currentPlatformOS=String(info?.os||'unknown');renderNetworkHostRoute();resolve(currentPlatformOS);});}
    catch(_){currentPlatformOS='unknown';resolve(currentPlatformOS);}
  });
  return platformInfoPromise;
}
function isMacPlatform(){return currentPlatformOS==='mac';}
function renderNetworkHostRoute(){
  const el=$('networkHostRoute');if(!el)return;
  const platform=currentPlatformOS;
  if(platform==='mac'){el.textContent='OS 자동 분기 · macOS Host 사용 · com.smartpage.spx_network_macos_v1 · Wi-Fi / macOS가 노출한 USB 네트워크 / Ethernet 감지 · Galaxy ADB 별도 확인';el.className='hint ok';return;}
  if(platform==='win'){el.textContent='OS 자동 분기 · Windows Host 사용 · com.smartpage.spx_network_v7 · 기존 Windows Network Helper/브리지 기능 그대로 유지';el.className='hint ok';return;}
  el.textContent=`OS 자동 분기 · ${platform||'unknown'} · 현재는 Windows/macOS만 수집 네트워크 Host를 지원합니다.`;el.className='hint notice';
}
let networkAdapterSnapshot=[];
let networkStatusRefreshTimer=null;
let networkBridgeRecoveryPollTimer=null;
let networkBridgeRecoveryPollCount=0;
let macTransientEmptyAdapterReads=0;
const SPX_DEDICATED_READINESS_POLL_MS_V10159=300;
const SPX_DEDICATED_READINESS_MAX_MS_V10159=20000;
let dedicatedAdapterReadinessTimerV10159=null;
let dedicatedAdapterReadinessStartedAtV10159=0;
let dedicatedAdapterReadinessTargetV10159=null;
function stopNetworkBridgeRecoveryPoll(){
  if(networkBridgeRecoveryPollTimer){clearTimeout(networkBridgeRecoveryPollTimer);networkBridgeRecoveryPollTimer=null;}
  networkBridgeRecoveryPollCount=0;
}
function scheduleNetworkBridgeRecoveryPoll(){
  if(networkBridgeRecoveryPollTimer||networkBridgeRecoveryPollCount>=8)return;
  networkBridgeRecoveryPollTimer=setTimeout(async()=>{
    networkBridgeRecoveryPollTimer=null;
    networkBridgeRecoveryPollCount+=1;
    const data=await refreshNetworkStatus({list:false,userGesture:false}).catch(()=>null);
    if(data?.bridgeRecoveryPending===true&&data?.proxyReady!==true)scheduleNetworkBridgeRecoveryPoll();
    else stopNetworkBridgeRecoveryPoll();
  },1800);
}
async function saveNetworkAdapterCache(adapters=[],selectedId=''){
  if(!Array.isArray(adapters)||!adapters.length)return;
  try{await chrome.storage.local.set({[NETWORK_ADAPTER_CACHE_KEY]:{adapters,selectedId:String(selectedId||''),savedAt:Date.now()}});}catch(_){ }
}
async function loadNetworkAdapterCache(){
  try{return (await chrome.storage.local.get(NETWORK_ADAPTER_CACHE_KEY))?.[NETWORK_ADAPTER_CACHE_KEY]||null;}catch(_){return null;}
}
function selectedNetworkMode(){
  // v1.6.4: settings only manage the dedicated adapter. Windows default Internet is read-only/OS-managed.
  return 'window';
}
function adapterHasUsableIpv4(row){
  const ipv4=String(row?.ipv4Address||'').trim();
  if(!row?.id||!ipv4||ipv4.startsWith('169.254.'))return false;
  const status=String(row?.status||'').toLowerCase();
  /* macOS Host의 selectable은 "쿠팡 전용망으로 선택 가능"을 뜻합니다.
     활성 물리망이 en0 하나뿐이면 기본 인터넷은 정상이어도 selectable=false이므로,
     기본망 IPv4 준비 여부와 전용망 선택 가능 여부를 분리해서 판정합니다.
     Windows Host의 기존 selectable 의미는 그대로 보존합니다. */
  return !['down','notpresent','lowerlayerdown','disconnected'].includes(status)&&(isMacPlatform()||row?.selectable!==false);
}
function adapterIsInternetReady(row){
  /* 일부 USB 테더링/RNDIS 드라이버는 실제 인터넷 연결 중에도 .NET의 GatewayAddresses를
     비워서 보고합니다. 어댑터 목록에서는 사용 가능한 IPv4와 연결 상태를 기준으로 표시하고,
     실제 접속 가능 여부는 전용창 프록시가 소켓 연결 단계에서 최종 확인합니다. */
  return adapterHasUsableIpv4(row);
}
function adapterIsRecoverableTether(row){
  return Boolean(row?.recoverableTethering===true||(row?.hasLinkLocalIpv4===true&&adapterTetheringScore(row)>=80));
}
function stopDedicatedAdapterReadinessWatchV10159(){
  if(dedicatedAdapterReadinessTimerV10159){clearTimeout(dedicatedAdapterReadinessTimerV10159);dedicatedAdapterReadinessTimerV10159=null;}
  dedicatedAdapterReadinessStartedAtV10159=0;
  dedicatedAdapterReadinessTargetV10159=null;
}
function findDedicatedAdapterReadinessTargetV10159(target={}){
  const id=String(target?.id||'');
  const name=String(target?.name||'');
  const description=String(target?.description||'');
  return networkAdapterSnapshot.find((row)=>id&&String(row?.id||'')===id)
    ||networkAdapterSnapshot.find((row)=>name&&String(row?.name||'')===name&&(!description||String(row?.description||'')===description))
    ||networkAdapterSnapshot.find((row)=>row?.isSystemDefault!==true&&adapterTetheringScore(row)>=80)
    ||null;
}
function scheduleDedicatedAdapterReadinessWatchV10159(target=null){
  if(isMacPlatform())return;
  const current=target||findDedicatedAdapterReadinessTargetV10159(dedicatedAdapterReadinessTargetV10159||{});
  if(current&&adapterHasUsableIpv4(current)){
    const select=$('networkAdapterSelect');if(select&&current?.id)select.value=String(current.id);
    stopDedicatedAdapterReadinessWatchV10159();
    setNetworkStatus(`전용망 준비됨 · ${current.name||'USB 테더링'} · ${current.ipv4Address||'정상 IPv4'} · 기다림 없이 바로 선택 적용할 수 있습니다.`,'ok');
    return;
  }
  if(current&&adapterIsRecoverableTether(current)){
    dedicatedAdapterReadinessTargetV10159={id:String(current.id||''),name:String(current.name||''),description:String(current.description||'')};
  }else if(!dedicatedAdapterReadinessTargetV10159){
    return;
  }
  if(!dedicatedAdapterReadinessStartedAtV10159)dedicatedAdapterReadinessStartedAtV10159=Date.now();
  if(Date.now()-dedicatedAdapterReadinessStartedAtV10159>=SPX_DEDICATED_READINESS_MAX_MS_V10159){stopDedicatedAdapterReadinessWatchV10159();return;}
  if(dedicatedAdapterReadinessTimerV10159)return;
  dedicatedAdapterReadinessTimerV10159=setTimeout(async()=>{
    dedicatedAdapterReadinessTimerV10159=null;
    try{
      const data=await requestNetworkData({command:'list_adapters'},{userGesture:false});
      if(Array.isArray(data?.adapters)&&data.adapters.length){
        networkAdapterSnapshot=data.adapters;
        const selected=String($('networkAdapterSelect')?.value||dedicatedAdapterReadinessTargetV10159?.id||'');
        renderNetworkAdapters(networkAdapterSnapshot,selected,'window');
      }
      const current=findDedicatedAdapterReadinessTargetV10159(dedicatedAdapterReadinessTargetV10159||{});
      if(current&&adapterHasUsableIpv4(current)){
        const select=$('networkAdapterSelect');if(select&&current?.id)select.value=String(current.id);
        stopDedicatedAdapterReadinessWatchV10159();
        setNetworkStatus(`전용망 준비됨 · ${current.name||'USB 테더링'} · ${current.ipv4Address||'정상 IPv4'} · 기다림 없이 바로 선택 적용할 수 있습니다.`,'ok');
        return;
      }
    }catch(_){/* 로컬 브리지 순간 지연은 다음 300ms 확인에서 재시도 */}
    scheduleDedicatedAdapterReadinessWatchV10159();
  },SPX_DEDICATED_READINESS_POLL_MS_V10159);
}
function adapterCanBeDedicated(row){
  if(isMacPlatform()&&row?.selectable!==true)return false;
  return adapterIsInternetReady(row)||adapterIsRecoverableTether(row);
}
function adapterTetheringScore(row){
  const text=`${row?.name||''} ${row?.description||''} ${row?.type||''}`.toLowerCase();
  const ipv4=String(row?.ipv4Address||'');
  let score=0;
  if(/usb|rndis|ndis|tether|테더|mobile|phone|android|samsung|galaxy|iphone|apple/.test(text))score+=100;
  if(/ethernet|이더넷/.test(text))score+=15;
  if(row?.likelyTethering===true)score+=100;
  if(row?.hasGateway===true)score+=30;
  if(/^10\.|^192\.168\.|^172\.(1[6-9]|2\d|3[01])\./.test(ipv4))score+=15;
  if(/virtual|hyper-v|vmware|virtualbox|wsl|vpn|bluetooth|loopback/.test(text))score-=140;
  return score;
}
function adapterIsStrongTether(row){return adapterTetheringScore(row)>=80;}
function adapterIsVirtual(row){const text=`${row?.name||''} ${row?.description||''} ${row?.type||''}`.toLowerCase();return /virtual|hyper-v|vmware|virtualbox|wsl|vpn|bluetooth|loopback/.test(text);}
function adapterConnectionKind(row){
  const explicit=String(row?.connectionKind||'').toLowerCase();
  if(['tethering','wifi','ethernet','virtual','other'].includes(explicit))return explicit;
  const text=`${row?.name||''} ${row?.description||''} ${row?.hardwarePort||''} ${row?.type||''}`.toLowerCase();
  if(row?.likelyTethering===true||/iphone.*usb|usb.*iphone|usb|rndis|tether|테더|android|phone|galaxy|samsung/.test(text))return 'tethering';
  if(/wi-?fi|wifi|wireless|wlan|802\.11|airport/.test(text))return 'wifi';
  if(/ethernet|이더넷|thunderbolt|lan/.test(text))return 'ethernet';
  if(adapterIsVirtual(row))return 'virtual';
  return 'other';
}
function adapterKindLabel(row){
  const kind=adapterConnectionKind(row);
  return kind==='tethering'?'📱 휴대폰/USB 테더링':kind==='wifi'?'📶 Wi-Fi':kind==='ethernet'?'🔌 이더넷':kind==='virtual'?'🧩 가상/VPN':'🌐 기타 네트워크';
}
function adapterPhoneNameV1514(row){
  let model=String(row?.phoneModel||row?.adbDeviceModel||'').trim().replace(/_/g,'-');
  if(!model)return '';
  if(/^SM-/i.test(model))model=`Samsung ${model}`;
  return model;
}
function adapterEasyLabelV1514(row,{tether=false}={}){
  if(!row)return '';
  const ip=String(row?.ipv4Address||'').trim();
  if(tether||adapterConnectionKind(row)==='tethering'){
    const model=adapterPhoneNameV1514(row)||'휴대폰 테더링';
    return `${model}${ip?` · ${ip}`:''}`;
  }
  const kind=adapterConnectionKind(row);
  const prefix=kind==='wifi'?'Wi-Fi':kind==='ethernet'?'유선 인터넷':'기본 인터넷';
  const name=String(row?.name||'').trim();
  return `${prefix}${name&&!/^(wi-?fi|이더넷|ethernet)$/i.test(name)?` · ${name}`:''}${ip?` · ${ip}`:''}`;
}
function setNetworkSimpleStateV1514(id,text,state='wait'){
  const el=$(id);if(!el)return;el.textContent=text;el.className=`network-simple-state ${state}`;
}
function renderEasyNetworkSummaryV1514(data={},settings={}){
  const adapters=Array.isArray(data?.adapters)?data.adapters:networkAdapterSnapshot;
  const actualDefaultAdapter=adapters.find((row)=>row?.isSystemDefault===true||Number(row?.interfaceIndex)===Number(data?.systemDefaultInterfaceIndex))||null;
  const defaultOk=Boolean(actualDefaultAdapter&&adapterHasUsableIpv4(actualDefaultAdapter)&&!adapterIsVirtual(actualDefaultAdapter)&&!adapterIsStrongTether(actualDefaultAdapter));
  if(defaultOk)setNetworkSimpleStateV1514('networkSimpleDefault',`✅ Windows 기본 인터넷 · OS 관리 · ${adapterEasyLabelV1514(actualDefaultAdapter)}`,'ok');
  else if(actualDefaultAdapter&&adapterIsStrongTether(actualDefaultAdapter))setNetworkSimpleStateV1514('networkSimpleDefault',`🛑 Windows 기본 인터넷이 휴대폰 테더링입니다 · Collector는 기본 경로를 바꾸지 않으며 Fail-Closed합니다.`,'bad');
  else if(actualDefaultAdapter)setNetworkSimpleStateV1514('networkSimpleDefault',`⚠ Windows 기본 인터넷 확인 필요 · ${adapterEasyLabelV1514(actualDefaultAdapter)||actualDefaultAdapter.name||'현재 기본 연결'}`,'bad');
  else setNetworkSimpleStateV1514('networkSimpleDefault','○ Windows 기본 인터넷 확인 필요 · Wi-Fi/유선은 OS가 관리합니다.','bad');

  const selectedId=String(data?.windowAdapterId||data?.selectedAdapterId||settings?.collectionNetworkAdapterId||'');
  let tether=adapters.find((row)=>String(row?.id||'')===selectedId)||null;
  if(!tether||adapterConnectionKind(tether)!=='tethering')tether=adapters.filter((row)=>adapterConnectionKind(row)==='tethering').sort((a,b)=>adapterTetheringScore(b)-adapterTetheringScore(a))[0]||tether;
  const tetherApplied=Boolean(tether)&&(data?.mode==='window'||data?.windowAdapterEnabled===true)&&data?.strictIsolationOk===true;
  if(tetherApplied)setNetworkSimpleStateV1514('networkSimpleTether',`✅ 휴대폰 테더링 연결 완료 · ${adapterEasyLabelV1514(tether,{tether:true})}`,'ok');
  else if(tether)setNetworkSimpleStateV1514('networkSimpleTether',`📱 휴대폰 테더링 감지 · ${adapterEasyLabelV1514(tether,{tether:true})} · 전용 네트워크 연결을 누르세요`,'wait');
  else setNetworkSimpleStateV1514('networkSimpleTether','○ 휴대폰 테더링 연결 대기 · USB 테더링을 켜주세요','wait');

  const windowReady=tetherApplied&&data?.selectedNetworkReady!==false&&data?.proxyReady!==false;
  if(defaultOk&&windowReady)setNetworkSimpleStateV1514('networkSimpleRoute',`✅ 쿠팡 전용 경로 준비 · 쿠팡 → ${adapterEasyLabelV1514(tether,{tether:true})} / WING · Supabase · 일반 인터넷 → ${adapterEasyLabelV1514(actualDefaultAdapter)}`,'ok');
  else if(actualDefaultAdapter&&adapterIsStrongTether(actualDefaultAdapter))setNetworkSimpleStateV1514('networkSimpleRoute','🛑 Fail-Closed · 선택 테더링이 Windows 기본 인터넷인 동안 쿠팡 전용 수집을 시작하지 않습니다.','bad');
  else setNetworkSimpleStateV1514('networkSimpleRoute','③ 쿠팡 전용 경로 준비 전 · Windows 기본 인터넷과 별도의 휴대폰 테더링을 선택하세요.','wait');
}
function preferredSystemAdapter(adapters=[],data={}){
  const ready=adapters.filter(adapterIsInternetReady);
  if(!ready.length)return null;
  const normal=ready.filter((row)=>!adapterIsStrongTether(row)&&!adapterIsVirtual(row));
  if(!normal.length)return null;
  const configuredId=String(data?.configuredSystemAdapterId||'').trim();
  /* SPX_V160_MANUAL_DEFAULT_PRIORITY: 사용자가 이 PC에서 기본인터넷으로 직접 지정한
     Wi-Fi/이더넷은 Windows가 현재 다른 정상 어댑터를 기본경로로 보고하더라도 최우선으로
     유지합니다. 휴대폰 테더링이 꽂힐 때마다 Windows metric 순서가 달라지는 노트북을 위한
     PC별 고정 선택이며, 해당 어댑터가 사라지거나 IPv4가 없을 때만 자동 후보로 대체합니다. */
  if(configuredId){
    const configured=normal.find((row)=>String(row?.id||'')===configuredId);
    if(configured)return configured;
  }
  const actualDefault=normal.find((row)=>row?.isSystemDefault===true);
  if(actualDefault)return actualDefault;
  const pinnedId=String(data?.systemPinnedAdapterId||'').trim();
  if(pinnedId){
    const pinnedExact=normal.find((row)=>String(row?.id||'')===pinnedId);
    if(pinnedExact)return pinnedExact;
  }
  const pinned=normal.find((row)=>row?.isPinnedSystemAdapter===true);
  if(pinned)return pinned;
  const gatewayNormal=normal.sort((a,b)=>(Number(b?.hasGateway===true)-Number(a?.hasGateway===true))||(Number(b?.speed||0)-Number(a?.speed||0))||String(a?.name||'').localeCompare(String(b?.name||''),'ko'))[0];
  return gatewayNormal||normal[0]||null;
}
function preferredRecoverableSystemAdapterV162(adapters=[],data={}){
  const safe=adapters.filter((row)=>row?.id&&!adapterIsStrongTether(row)&&!adapterIsVirtual(row));
  if(!safe.length)return null;
  const configuredId=String(data?.configuredSystemAdapterId||'').trim();
  if(configuredId){const configured=safe.find((row)=>String(row?.id||'')===configuredId);if(configured)return configured;}
  const pinnedId=String(data?.systemPinnedAdapterId||'').trim();
  if(pinnedId){const pinned=safe.find((row)=>String(row?.id||'')===pinnedId);if(pinned)return pinned;}
  const kindRank=(row)=>adapterConnectionKind(row)==='wifi'?0:adapterConnectionKind(row)==='ethernet'?1:2;
  return safe.slice().sort((a,b)=>
    kindRank(a)-kindRank(b)||
    (Number(adapterHasUsableIpv4(b))-Number(adapterHasUsableIpv4(a)))||
    (Number(String(b?.status||'').toLowerCase()==='up')-Number(String(a?.status||'').toLowerCase()==='up'))||
    (Number(b?.hasGateway===true)-Number(a?.hasGateway===true))||
    String(a?.name||'').localeCompare(String(b?.name||''),'ko')
  )[0]||null;
}
function preferredDedicatedAdapter(adapters=[],data={}){
  const ready=adapters.filter(adapterCanBeDedicated);
  if(!ready.length)return null;
  const explicitId=String(data?.selectedAdapterId||data?.windowAdapterId||data?.configuredWindowAdapterId||'');
  if(explicitId){
    const exact=ready.find((row)=>String(row?.id||'')===explicitId&&row?.isSystemDefault!==true);
    if(exact)return exact;
  }
  const strong=ready.filter((row)=>row?.isSystemDefault!==true&&!adapterIsVirtual(row)&&adapterIsStrongTether(row))
    .sort((a,b)=>adapterTetheringScore(b)-adapterTetheringScore(a)||Number(a?.isSystemDefault===true)-Number(b?.isSystemDefault===true)||String(a?.name||'').localeCompare(String(b?.name||''),'ko'))[0];
  if(strong)return strong;
  const nonDefault=ready.filter((row)=>row?.isSystemDefault!==true&&!adapterIsVirtual(row))
    .sort((a,b)=>(Number(b?.dedicatedCandidate===true)-Number(a?.dedicatedCandidate===true))||(Number(b?.hasGateway===true)-Number(a?.hasGateway===true))||String(a?.name||'').localeCompare(String(b?.name||''),'ko'))[0];
  return nonDefault||ready.find((row)=>row?.isSystemDefault!==true&&!adapterIsVirtual(row))||null;
}
function renderNetworkAdapters(adapters=[],selectedId='',mode=selectedNetworkMode()){
  networkAdapterSnapshot=Array.isArray(adapters)?adapters:[];
  const select=$('networkAdapterSelect');if(!select)return;
  const activeMode=mode==='window'?'window':'system';
  const valid=networkAdapterSnapshot.filter((row)=>activeMode==='window'?adapterCanBeDedicated(row):(adapterIsInternetReady(row)&&!adapterIsStrongTether(row)&&!adapterIsVirtual(row))).sort((a,b)=>{
    if(activeMode==='system'){
      const aNormal=!adapterIsStrongTether(a)&&!adapterIsVirtual(a),bNormal=!adapterIsStrongTether(b)&&!adapterIsVirtual(b);
      if(aNormal!==bNormal)return aNormal?-1:1;
      if(Boolean(a?.isSystemDefault)!==Boolean(b?.isSystemDefault))return a?.isSystemDefault?-1:1;
      if(Boolean(a?.isPinnedSystemAdapter)!==Boolean(b?.isPinnedSystemAdapter))return a?.isPinnedSystemAdapter?-1:1;
    }else{
      if(Boolean(a?.isSelectedWindowAdapter)!==Boolean(b?.isSelectedWindowAdapter))return a?.isSelectedWindowAdapter?-1:1;
      if(Boolean(a?.isSystemDefault)!==Boolean(b?.isSystemDefault))return a?.isSystemDefault?1:-1;
      const kindOrder={tethering:0,wifi:1,ethernet:2,other:3,virtual:4};
      const ak=kindOrder[adapterConnectionKind(a)]??9,bk=kindOrder[adapterConnectionKind(b)]??9;
      if(ak!==bk)return ak-bk;
    }
    return String(a?.name||'').localeCompare(String(b?.name||''),'ko');
  });
  const invalid=networkAdapterSnapshot.filter((row)=>row&&row.id&&!(activeMode==='window'?adapterCanBeDedicated(row):(adapterIsInternetReady(row)&&!adapterIsStrongTether(row)&&!adapterIsVirtual(row))));
  const escape=(value)=>String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');
  const optionFor=(row)=>{
    const sameAsDefault=activeMode==='window'&&row.isSystemDefault===true;
    const sameAsPinned=activeMode==='window'&&row.isPinnedSystemAdapter===true&&row.isSystemDefault===true;
    const disabled=(sameAsDefault||sameAsPinned)?' disabled':'';
    const recovering=activeMode==='window'&&adapterIsRecoverableTether(row)&&!adapterIsInternetReady(row);
    const easy=adapterEasyLabelV1514(row,{tether:activeMode==='window'&&adapterConnectionKind(row)==='tethering'});
    const role=row.isPinnedSystemAdapter===true&&row.isSystemDefault===true?' · 기본 인터넷 고정됨':row.isSelectedWindowAdapter===true?' · 선택됨':row.isSystemDefault===true?' · 현재 기본 인터넷':'';
    const suffix=sameAsDefault?' · 기본 인터넷과 같아 선택 불가':recovering?' · 연결 확인 중':'';
    const label=`${easy||row.name||row.id}${role}${suffix}`;
    return `<option value="${escape(row.id)}"${disabled}>${escape(label)}</option>`;
  };
  const groupOrder=['tethering','wifi','ethernet','other','virtual'];
  const groupLabels={tethering:'📱 휴대폰/USB 테더링',wifi:'📶 Wi-Fi',ethernet:'🔌 이더넷',other:'🌐 기타 네트워크',virtual:'🧩 가상/VPN'};
  const validHtml=groupOrder.map((kind)=>{
    const rows=valid.filter((row)=>adapterConnectionKind(row)===kind);
    return rows.length?`<optgroup label="${groupLabels[kind]}">${rows.map(optionFor).join('')}</optgroup>`:'';
  }).join('');
  const invalidHtml=invalid.map((row)=>{
    const state=String(row.status||'상태 미확인');
    const ipv4=String(row.ipv4Address||'');
    const addresses=Array.isArray(row.addresses)?row.addresses.map(String):[];
    const linkLocal=ipv4.startsWith('169.254.')||addresses.some((value)=>value.startsWith('169.254.'));
    const reason=linkLocal?'169.254 자동 할당 IP · 테더링/네트워크 연결을 다시 확인하세요':
      (['down','notpresent','lowerlayerdown','disconnected'].includes(state.toLowerCase())?'연결 안 됨':(!ipv4?'IPv4 주소 없음':'연결 확인 필요'));
    const shownIpv4=ipv4||(addresses.find((value)=>/^\d+\.\d+\.\d+\.\d+$/.test(value))||'');
    const label=`${adapterKindLabel(row)} · ${row.name||row.description||row.id}${shownIpv4?` · ${shownIpv4}`:''} · ${reason}`;
    return `<option value="" disabled>${escape(label)}</option>`;
  }).join('');
  select.innerHTML=valid.length
    ? `${validHtml}${invalidHtml?`<optgroup label="⚠ 연결 확인이 필요한 어댑터">${invalidHtml}</optgroup>`:''}`
    : `<option value="">사용 가능한 IPv4 어댑터가 없습니다 — 어댑터 새로고침을 눌러주세요</option>${invalidHtml?`<optgroup label="감지된 어댑터">${invalidHtml}</optgroup>`:''}`;
  let preferred=String(selectedId||'');
  if(activeMode==='system'){
    const systemPreferred=preferredSystemAdapter(networkAdapterSnapshot,{configuredSystemAdapterId:preferred});
    preferred=String(systemPreferred?.id||'');
  }else{
    const explicit=valid.find((row)=>String(row.id)===preferred&&row.isSystemDefault!==true);
    if(!explicit)preferred=String(preferredDedicatedAdapter(networkAdapterSnapshot,{selectedAdapterId:preferred})?.id||'');
  }
  const eligible=(row)=>String(row.id)===preferred&&!(activeMode==='window'&&row.isSystemDefault===true);
  if(preferred&&valid.some(eligible))select.value=preferred;
  else{
    const first=activeMode==='window'?preferredDedicatedAdapter(valid):preferredSystemAdapter(valid);
    if(first)select.value=String(first.id);
  }
  select.dataset.validAdapterCount=String(valid.length);
  select.dataset.mode=activeMode;
}
async function ensureSelectedNetworkAdapter({userGesture=true}={}){
  let select=$('networkAdapterSelect');
  let adapterId=String(select?.value||'').trim();
  let adapter=networkAdapterSnapshot.find((row)=>String(row.id)===adapterId)||null;
  const acceptable=(row)=>selectedNetworkMode()==='window'?adapterCanBeDedicated(row):adapterIsInternetReady(row);
  if(adapterId&&acceptable(adapter)&&!(selectedNetworkMode()==='window'&&adapter?.isSystemDefault===true))return{select,adapterId,adapter};
  const data=await refreshNetworkStatus({list:true,userGesture});
  select=$('networkAdapterSelect');
  adapterId=String(select?.value||'').trim();
  adapter=networkAdapterSnapshot.find((row)=>String(row.id)===adapterId)||null;
  if(selectedNetworkMode()==='window'&&(!adapterId||!adapterCanBeDedicated(adapter)||adapter?.isSystemDefault===true)){
    adapter=preferredDedicatedAdapter(networkAdapterSnapshot,{selectedAdapterId:data?.windowAdapterId||data?.selectedAdapterId||''});
    adapterId=String(adapter?.id||'');if(select&&adapterId)select.value=adapterId;
  }
  if(adapterId&&acceptable(adapter))return{select,adapterId,adapter};
  const detected=networkAdapterSnapshot.filter((row)=>row?.id).map((row)=>{
    const ip=String(row.ipv4Address||'')||(Array.isArray(row.addresses)?row.addresses.find((value)=>/^\d+\.\d+\.\d+\.\d+$/.test(String(value)))||'':'');
    return `${row.name||row.description||'이름 없음'}${ip?`(${ip})`:''}`;
  }).slice(0,6).join(', ');
  const platformLabel=isMacPlatform()?'macOS':'Windows';
  const suffix=detected?` ${platformLabel} 감지 목록: ${detected}`:` ${platformLabel}가 네트워크 어댑터를 반환하지 않았습니다.`;
  const recoverable=networkAdapterSnapshot.find((row)=>adapterIsRecoverableTether(row)&&row?.isSystemDefault!==true);
  if(recoverable)throw new Error(`USB 테더링 어댑터 ${recoverable.name||'선택망'}는 감지됐지만 Windows가 169.254 자동할당 IPv4만 가지고 있습니다. Helper 3.0.33는 선택 적용/전용창 열기 시 DHCP 갱신과 해당 USB 어댑터 1회 재시작을 자동 시도합니다. 어댑터 새로고침 후 다시 선택하세요.`);
  throw new Error(`전용창에 사용할 어댑터를 찾지 못했습니다.${suffix} Wi-Fi/휴대폰 테더링/이더넷 연결 상태를 확인한 뒤 어댑터 새로고침을 눌러주세요.`);
}
function setNetworkStatus(text,kind='notice'){const el=$('networkStatus');if(!el)return;el.textContent=text;el.className=`hint ${kind}`;}
const NETWORK_WINDOWS_NATIVE_HOST_NAME='com.smartpage.spx_network_v7';
const NETWORK_MACOS_NATIVE_HOST_NAME='com.smartpage.spx_network_macos_v1';
let networkNativeBridgeRecoveryPromise=null;
function networkBridgeRecoverySafeCommand(command=''){
  return ['status','list_adapters','set_mode','set_system_adapter','clear_system_adapter','set_window_adapter','clear_window_adapter','open_coupang_window','integration_settings_status','load_integration_settings','save_integration_settings','open_integration_settings'].includes(String(command||''));
}
async function ensureNetworkBridgeViaNativeFromOptions(timeoutMs=12000){
  if(networkNativeBridgeRecoveryPromise)return networkNativeBridgeRecoveryPromise;
  networkNativeBridgeRecoveryPromise=new Promise((resolve,reject)=>{
    if(!chrome.runtime?.sendNativeMessage){reject(new Error('Chrome Native Messaging API를 사용할 수 없습니다.'));return;}
    let settled=false;
    const finish=(fn,value)=>{if(settled)return;settled=true;clearTimeout(timer);fn(value);};
    const timer=setTimeout(()=>finish(reject,new Error('로컬 브리지 자동복구 제한시간 초과')),Math.max(5000,Number(timeoutMs)||12000));
    try{
      chrome.runtime.sendNativeMessage(NETWORK_WINDOWS_NATIVE_HOST_NAME,{
        command:'ensure_bridge',
        extensionId:String(chrome.runtime?.id||''),
        extensionVersion:String(chrome.runtime?.getManifest?.().version||''),
      },(response)=>{
        const runtimeError=chrome.runtime.lastError;
        if(runtimeError){finish(reject,new Error(runtimeError.message||'Native Messaging 자동복구 실패'));return;}
        if(!response||response.ok===false){finish(reject,new Error(response?.error||response?.message||'로컬 브리지를 시작하지 못했습니다.'));return;}
        finish(resolve,response);
      });
    }catch(error){finish(reject,error);}
  }).finally(()=>{networkNativeBridgeRecoveryPromise=null;});
  return networkNativeBridgeRecoveryPromise;
}
async function requestLocalNetworkBridgeAttemptFromOptions(payload,timeoutMs=8000,maxAttemptsOverride=0){
  const allErrors=[];
  const command=String(payload?.command||'');
  const readOnly=['status','list_adapters','integration_settings_status','load_integration_settings'].includes(command);
  const maxAttempts=Math.max(1,Number(maxAttemptsOverride)|| (readOnly?3:1));
  for(let attempt=0;attempt<maxAttempts;attempt++){
    const errors=[];
    for(const baseUrl of NETWORK_LOCAL_BRIDGE_URLS){
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),Math.max(2500,Number(timeoutMs)||8000));
      try{
        const url=`${baseUrl}/api?token=${encodeURIComponent(NETWORK_LOCAL_BRIDGE_TOKEN)}`;
        const response=await fetch(url,{
          method:'POST',
          headers:{'Content-Type':'text/plain;charset=UTF-8'},
          body:JSON.stringify(payload||{}),
          cache:'no-store',
          credentials:'omit',
          redirect:'error',
          targetAddressSpace:'loopback',
          signal:controller.signal,
        });
        let data=null;
        try{data=await response.json();}catch(error){throw new Error(`응답 JSON 오류 · HTTP ${response.status}`);}
        if(!response.ok||!data||data.ok===false){
          const bridgeError=new Error(data?.error||`HTTP ${response.status}`);
          bridgeError.bridgeReached=true;
          bridgeError.status=response.status;
          throw bridgeError;
        }
        return data;
      }catch(error){
        if(error?.bridgeReached)throw error;
        const message=error?.name==='AbortError'?'응답 제한시간 초과':(error?.message||String(error));
        errors.push(`${baseUrl}: ${message}`);
      }finally{clearTimeout(timer);}
    }
    allErrors.push(...errors);
    if(attempt<maxAttempts-1)await new Promise((resolve)=>setTimeout(resolve,700*(attempt+1)));
  }
  const error=new Error([...new Set(allErrors)].join(' | ')||'로컬 브리지 응답 없음');
  error.bridgeReached=false;
  throw error;
}
async function requestLocalNetworkBridgeFromOptions(payload,timeoutMs=8000){
  const command=String(payload?.command||'');
  try{return await requestLocalNetworkBridgeAttemptFromOptions(payload,timeoutMs);}
  catch(firstError){
    if(firstError?.bridgeReached===true||!networkBridgeRecoverySafeCommand(command))throw firstError;
    try{
      setNetworkStatus('로컬 네트워크 브리지가 꺼져 있어 자동으로 다시 시작하는 중...','notice');
      await ensureNetworkBridgeViaNativeFromOptions(14000);
      await new Promise((resolve)=>setTimeout(resolve,350));
      return await requestLocalNetworkBridgeAttemptFromOptions(payload,timeoutMs,1);
    }catch(recoveryError){
      const first=String(firstError?.message||firstError||'로컬 브리지 연결 실패');
      const recovery=String(recoveryError?.message||recoveryError||'자동복구 실패');
      const error=new Error(`${first} · 자동복구 실패: ${recovery}`);
      error.cause=firstError;
      throw error;
    }
  }
}
const INTEGRATION_FILE_KEYS=Object.freeze(['supabaseUrl','serviceKey','geminiApiKey','geminiModel','openaiApiKey','openaiModel']);
function applyIntegrationSettingsToInputs(settings={}){
  if($('url'))$('url').value=String(settings.supabaseUrl||'');
  if($('key'))$('key').value=String(settings.serviceKey||'');
  for(const id of ['geminiApiKey','geminiModel','openaiApiKey','openaiModel'])if($(id))$(id).value=String(settings[id]||'');if($('geminiModel'))$('geminiModel').value=String(settings.geminiModel||'gemini-3.7-flash');if($('openaiModel'))$('openaiModel').value=String(settings.openaiModel||'gpt-5.6-terra');
}
function normalizeDirectIntegrationJson(raw=''){
  let text=String(raw||'').replace(/^\uFEFF/,'');
  let out='',inString=false,escaped=false,lineComment=false,blockComment=false;
  for(let i=0;i<text.length;i++){
    const c=text[i],n=text[i+1]||'';
    if(lineComment){if(c==='\n'){lineComment=false;out+=c;}continue;}
    if(blockComment){if(c==='*'&&n==='/'){blockComment=false;i++;}continue;}
    if(inString){out+=c;if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')inString=false;continue;}
    if(c==='"'){inString=true;out+=c;continue;}
    if(c==='/'&&n==='/'){lineComment=true;i++;continue;}
    if(c==='/'&&n==='*'){blockComment=true;i++;continue;}
    out+=c;
  }
  return out.replace(/,\s*([}\]])/g,'$1').trim();
}
function wingIntegrationCredentialFromSourceV431(source={}){const username=String(source?.coupangWingId??source?.wingId??'').trim(),password=String(source?.coupangWingPassword??source?.wingPassword??'');const raw=source?.coupangWingAutoLogin;const autoLoginEnabled=raw===undefined||raw===null||raw===''?true:!(raw===false||String(raw).trim().toLowerCase()==='false'||String(raw).trim()==='0');return{version:2,username,password,autoLoginEnabled,updatedAt:Date.now(),source:'integration-secrets',configured:Boolean(username&&password)};}
async function applyIntegrationWingCredentialV431(source={}){const row=wingIntegrationCredentialFromSourceV431(source);if(!row.configured)return{configured:false,updated:false};await chrome.storage.local.set({[WING_LOGIN_CREDENTIAL_KEY_V426]:{version:2,username:row.username,password:row.password,autoLoginEnabled:row.autoLoginEnabled,updatedAt:row.updatedAt,source:row.source}});if($('coupangWingId'))$('coupangWingId').value=row.username;if($('coupangWingPassword'))$('coupangWingPassword').value=row.password;if($('coupangWingAutoLogin'))$('coupangWingAutoLogin').checked=row.autoLoginEnabled;setWingLoginStatusV426('integration-secrets.json에서 WING 로그인 정보 불러옴 · 기존 세션 우선','ok');return{configured:true,updated:true};}
async function applyIntegrationSettingsObject(rawSettings={}){
  const source=rawSettings&&typeof rawSettings==='object'?(rawSettings.settings&&typeof rawSettings.settings==='object'?rawSettings.settings:rawSettings):{};
  const wing=await applyIntegrationWingCredentialV431(source).catch(()=>({configured:false,updated:false}));
  const clean={};
  for(const key of INTEGRATION_FILE_KEYS){const value=String(source[key]??'').trim();if(value)clean[key]=value;}
  /* v4.1.46: blank file entries never erase working credentials. Explicit deletion uses the clear buttons. */

  await SPX.util.setSettings(clean);
  const settings=await SPX.util.getSettings();applyIntegrationSettingsToInputs(settings);
  return {configuredCount:Object.values(clean).filter(Boolean).length+(wing?.configured?3:0),settings,preservedExisting:true,wingConfigured:wing?.configured===true};
}
async function selectIntegrationSettingsFileDirect(){
  const picker=$('integrationSettingsFilePicker');
  if(!picker)throw new Error('파일 선택 입력을 찾지 못했습니다.');
  picker.value='';picker.click();
}
async function importDirectIntegrationSettingsFile(file){
  if(!file)return null;
  const statusEl=$('integrationFileStatus'),pathEl=$('integrationFilePath');
  if(statusEl){statusEl.textContent='선택한 integration-secrets.json을 읽는 중...';statusEl.className='hint notice';}
  try{
    const raw=await file.text();
    const parsed=JSON.parse(normalizeDirectIntegrationJson(raw));
    const result=await applyIntegrationSettingsObject(parsed);
    if(pathEl)pathEl.textContent=`직접 선택 파일 · ${file.name} · 브라우저 보안상 전체 폴더 경로는 표시하지 않습니다.`;
    if(statusEl){statusEl.textContent=`직접 선택 불러오기 완료 · 설정 항목 ${Number(result.configuredCount||0)}개 반영`;statusEl.className='hint ok';}
    try{await SPX.util.sendMessage({type:'SPX_SECURE_SETTINGS_BACKUP',scope:'all'});}catch(_){}
    await refreshProtectedSettingsStatus().catch(()=>null);
    msg('선택한 integration-secrets.json의 전체 ID·Key를 반영했습니다.','ok');
    return result;
  }catch(error){
    const message=String(error?.message||error||'JSON 읽기 실패');
    if(statusEl){statusEl.textContent=`직접 선택 파일 읽기 실패 · ${message}`;statusEl.className='hint bad';}
    msg('integration-secrets.json 읽기 실패: '+message,'bad');
    throw error;
  }
}
async function requestIntegrationFile(type,directCommand){
  try{
    const response=await SPX.util.sendMessage({type});
    if(response?.ok)return response.data||response;
    throw new Error(response?.error||'연동 설정 파일 요청 실패');
  }catch(runtimeError){
    /* 이전 Service Worker가 남아 있어도 연동 파일은 Windows Native Messaging으로 직접 읽습니다.
       30765 브리지는 마지막 보조경로일 뿐, 인증정보의 필수 경로가 아닙니다. */
    try{return await requestWindowsNativeNetworkDirectFromOptions({command:directCommand},8000);}
    catch(nativeError){
      try{return await requestLocalNetworkBridgeFromOptions({command:directCommand},8000);}
      catch(bridgeError){const error=new Error(`연동 설정 파일 요청 실패 · Native ${nativeError?.message||nativeError} · Bridge ${bridgeError?.message||bridgeError}`);error.cause=runtimeError;throw error;}
    }
  }
}
async function loadIntegrationSettingsFile({silent=false,backup=false}={}){
  const statusEl=$('integrationFileStatus'),pathEl=$('integrationFilePath');
  if(!silent&&statusEl){statusEl.textContent='연동 설정 파일을 읽는 중...';statusEl.className='hint notice';}
  try{
    const data=await requestIntegrationFile('SPX_INTEGRATION_SETTINGS_LOAD','load_integration_settings');
    /* 파일 값은 런타임 설정과 직접 입력란에 함께 반영합니다. Network Helper가 없을 때는 직접 입력 저장이 독립 fallback입니다. */
    if(data?.settings&&typeof data.settings==='object')await applyIntegrationSettingsObject(data.settings);
    else{const settings=await SPX.util.getSettings();applyIntegrationSettingsToInputs(settings);}
    await loadWingCredentialLocalV426().catch(()=>null);
    if(pathEl)pathEl.textContent=`파일 위치 · ${data?.path||'C:\\ProgramData\\SmartPageEx\\NetworkHostV33\\integration-secrets.json'}`;
    if(statusEl){statusEl.textContent=`파일 불러오기 완료 · 설정 항목 ${Number(data?.configuredCount||Object.values(data?.settings||{}).filter(Boolean).length)}개 확인${data?.updatedAt?` · ${formatKstDateTime(data.updatedAt)}`:''}`;statusEl.className='hint ok';}
    if(backup){try{await SPX.util.sendMessage({type:'SPX_SECURE_SETTINGS_BACKUP',scope:'all'});}catch(_){} }
    return data;
  }catch(error){
    const message=String(error?.message||error||'연동 설정 파일 불러오기 실패');
    if(pathEl)pathEl.textContent='연동 설정 파일을 사용하려면 Network Helper 3.0.33 등록이 필요합니다. 직접 입력·저장은 보조도구 없이도 사용할 수 있습니다.';
    if(statusEl){statusEl.textContent=`파일 연결 실패 · ${message} · 기존 NetworkHostV33 상태와 tools\companion 등록을 확인하세요. 직접 입력값은 아래에서 저장할 수 있습니다.`;statusEl.className='hint bad';}
    if(!silent)msg('연동 설정 파일 연결 실패: '+message,'bad');
    throw error;
  }
}
async function refreshIntegrationSettingsFileStatus({silent=false}={}){
  const statusEl=$('integrationFileStatus'),pathEl=$('integrationFilePath');
  try{
    const data=await requestIntegrationFile('SPX_INTEGRATION_SETTINGS_STATUS','integration_settings_status');
    if(pathEl)pathEl.textContent=`파일 위치 · ${data?.path||'C:\\ProgramData\\SmartPageEx\\NetworkHostV33\\integration-secrets.json'}`;
    const cfg=data?.configured||{};
    const detail=cfg&&Object.keys(cfg).length?` · Supabase ${cfg.supabase?'확인':'미설정'} · AI ${cfg.ai?'확인':'미설정'} · WING ${cfg.wing?'확인':'미설정'}`:'';
    if(statusEl){statusEl.textContent=`파일 상태 정상 · 설정 항목 ${Number(data?.configuredCount||0)}개${detail}`;statusEl.className='hint ok';}
    return data;
  }catch(error){if(statusEl){statusEl.textContent=`파일 상태 확인 실패 · ${error?.message||error}`;statusEl.className='hint bad';}if(!silent)msg('연동 설정 파일 상태 확인 실패: '+(error?.message||error),'bad');throw error;}
}
async function openIntegrationSettingsFile(){
  const button=$('openIntegrationSettingsFile');if(button)button.disabled=true;
  try{
    let data=null;
    try{const response=await SPX.util.sendMessage({type:'SPX_INTEGRATION_SETTINGS_OPEN'});if(!response?.ok)throw new Error(response?.error||'파일 열기 실패');data=response.data||response;}
    catch(runtimeError){try{data=await requestWindowsNativeNetworkDirectFromOptions({command:'open_integration_settings'},8000);}catch(_nativeError){data=await requestLocalNetworkBridgeFromOptions({command:'open_integration_settings'},8000);}}
    if($('integrationFilePath'))$('integrationFilePath').textContent=`파일 위치 · ${data?.path||'C:\\ProgramData\\SmartPageEx\\NetworkHostV33\\integration-secrets.json'}`;
    if($('integrationFileStatus')){$('integrationFileStatus').textContent='메모장에서 연동 설정 파일을 열었습니다. 수정 후 저장하고 [파일 다시 불러오기]를 누르세요.';$('integrationFileStatus').className='hint notice';}
    return data;
  }catch(error){if($('integrationFileStatus')){$('integrationFileStatus').textContent=`파일 열기 실패 · ${error?.message||error} · Network Helper 3.0.33 재등록 필요 · 직접 입력 저장은 계속 사용할 수 있습니다.`;$('integrationFileStatus').className='hint bad';}throw error;}
  finally{if(button)button.disabled=false;}
}

function conciseNetworkError(error){
  const raw=String(error?.message||error||'네트워크 보조도구 응답 없음').replace(/\s+/g,' ').trim();
  console.debug('[SPX] 네트워크 상세 정보',raw);
  if(/작업.*실행 중|currently running|already running/i.test(raw))return '관리자 단발 작업이 이미 실행 중이었지만 현재 요청 결과를 받지 못했습니다. 연결·분리 상태를 다시 확인한 뒤 한 번만 재시도하세요.';
  const localBridgeDown=/127\.0\.0\.1:30765|로컬 브리지.*응답 제한시간|local bridge.*(?:timeout|timed out)|failed to fetch/i.test(raw);
  const nativeUnavailable=/native messaging host.*not found|specified native messaging host not found|forbidden/i.test(raw);
  if(localBridgeDown&&nativeUnavailable){const runtimeId=String(chrome.runtime?.id||'확인불가');return `로컬 브리지 127.0.0.1:30765가 꺼져 있고 Native Messaging 자동복구도 Chrome에서 열지 못했습니다. 현재 확장 ID ${runtimeId} · 동봉 설치기는 실제 호환 Helper 소스 검증 후 package marker와 사용자 HKCU Native Messaging 등록을 함께 복구합니다.`;}
  if(nativeUnavailable){const runtimeId=String(chrome.runtime?.id||'확인불가');return `Native Messaging 자동복구 경로를 Chrome이 열지 못했습니다. 현재 확장 ID ${runtimeId} · 허용 ID 자체보다 사용자 HKCU/HKLM 등록 상태를 우선 확인합니다. 기존 NetworkHostV33 설치 상태와 Collector companion 등록을 확인하세요.`;}
  if(localBridgeDown)return '로컬 브리지 127.0.0.1:30765가 응답하지 않습니다. 저장된 선택값은 유지합니다. 기존 NetworkHostV33의 30765 브리지와 Collector companion 등록을 확인하세요.';
  if(/응답 제한시간|did not answer|timed out|timeout/i.test(raw))return '네트워크 보조도구 응답이 늦습니다. 연결·분리 상태 다시 확인을 누른 뒤 재시도하세요.';
  if(/access.*denied|액세스가 거부/i.test(raw))return 'Windows 관리자 권한이 적용되지 않았습니다. 기존 NetworkHostV33 설치 상태와 Collector companion 등록을 다시 확인하세요.';
  if(/자동복구 실패/i.test(raw))return '로컬 브리지 자동복구가 완료되지 않았습니다. 선택한 어댑터는 유지되며, 계속 응답이 없을 때만 기존 NetworkHostV33 설치 상태와 Collector companion 등록을 다시 확인하세요.';
  if(/분리 안전검사|isolation/i.test(raw))return raw.split(' · ')[0]+' · 일반 인터넷과 USB 테더링 어댑터를 서로 다르게 선택하세요.';
  return raw.length>220?`${raw.slice(0,217)}...`:raw;
}
async function requestNativeNetworkDirectFromOptions(payload,timeoutMs=30000){
  return new Promise((resolve,reject)=>{
    if(!chrome.runtime?.sendNativeMessage){reject(new Error('Chrome Native Messaging API를 사용할 수 없습니다.'));return;}
    let settled=false;
    const finish=(fn,value)=>{if(settled)return;settled=true;clearTimeout(timer);fn(value);};
    const timer=setTimeout(()=>finish(reject,new Error('macOS Network Helper 응답 제한시간 초과')),Math.max(5000,Number(timeoutMs)||30000));
    try{
      chrome.runtime.sendNativeMessage(NETWORK_MACOS_NATIVE_HOST_NAME,{
        ...payload,
        extensionId:String(chrome.runtime?.id||''),
        extensionVersion:String(chrome.runtime?.getManifest?.().version||''),
      },(response)=>{
        const runtimeError=chrome.runtime.lastError;
        if(runtimeError){finish(reject,new Error(runtimeError.message||'macOS Native Messaging 연결 실패'));return;}
        if(!response||response.ok===false){finish(reject,new Error(response?.error||response?.message||'macOS Network Helper 명령 실패'));return;}
        finish(resolve,response);
      });
    }catch(error){finish(reject,error);}
  });
}
/* v4.1.73: Native status must never force bridgeRecoveryPending when the fixed V33 proxy is already ready. */
async function requestWindowsNativeNetworkDirectFromOptions(payload,timeoutMs=15000){
  return new Promise((resolve,reject)=>{
    if(!chrome.runtime?.sendNativeMessage){reject(new Error('Chrome Native Messaging API를 사용할 수 없습니다.'));return;}
    let settled=false;
    const finish=(fn,value)=>{if(settled)return;settled=true;clearTimeout(timer);fn(value);};
    const timer=setTimeout(()=>finish(reject,new Error('Windows Native Messaging 읽기 제한시간 초과')),Math.max(5000,Number(timeoutMs)||15000));
    try{
      chrome.runtime.sendNativeMessage(NETWORK_WINDOWS_NATIVE_HOST_NAME,{
        ...payload,
        extensionId:String(chrome.runtime?.id||''),
        extensionVersion:String(chrome.runtime?.getManifest?.().version||''),
      },(response)=>{
        const runtimeError=chrome.runtime.lastError;
        if(runtimeError){finish(reject,new Error(runtimeError.message||'Windows Native Messaging 연결 실패'));return;}
        if(!response||response.ok===false){finish(reject,new Error(response?.error||response?.message||'Windows Network Helper 읽기 실패'));return;}
        finish(resolve,{...response,networkTransport:'native_direct_options_fallback',bridgeRecoveryPending:response?.bridgeRecoveryPending===true,bridgeTransportAvailable:response?.proxyReady===true});
      });
    }catch(error){finish(reject,error);}
  });
}
function networkServiceWorkerMessage(payload={}){
  const command=String(payload?.command||'');
  const map={
    status:'SPX_NETWORK_STATUS',
    list_adapters:'SPX_NETWORK_LIST_ADAPTERS',
    set_mode:'SPX_NETWORK_SET_MODE',
    set_system_adapter:'SPX_NETWORK_SET_SYSTEM_ADAPTER',
    clear_system_adapter:'SPX_NETWORK_CLEAR_SYSTEM_ADAPTER',
    set_window_adapter:'SPX_NETWORK_SET_WINDOW_ADAPTER',
    clear_window_adapter:'SPX_NETWORK_CLEAR_WINDOW_ADAPTER',
    open_coupang_window:'SPX_NETWORK_OPEN_COUPANG_WINDOW',
    adb_status:'SPX_NETWORK_ADB_STATUS',
    adb_recover:'SPX_NETWORK_ADB_RECOVER',
  };
  const type=map[command];
  return type?{type,...payload}:null;
}
async function requestWindowsNetworkViaServiceWorker(payload,timeoutMs=90000){
  const message=networkServiceWorkerMessage(payload);
  if(!message)throw new Error(`지원하지 않는 Service Worker 네트워크 명령: ${payload?.command||'-'}`);
  const response=await SPX.util.sendMessage(message,Math.max(10000,Number(timeoutMs)||90000));
  if(response?.ok===true)return response.data||response;
  const data=response?.data&&typeof response.data==='object'?response.data:null;
  if((payload?.command==='status'||payload?.command==='list_adapters')&&Array.isArray(data?.adapters)&&data.adapters.length){
    return {...data,networkTransport:data.networkTransport||'service_worker_cached_fallback',bridgeRecoveryPending:true};
  }
  throw new Error(response?.error||'Service Worker 네트워크 요청 실패');
}
async function requestNetworkData(payload,{userGesture=false}={}){
  const command=String(payload?.command||'');
  const supported=new Set(['status','list_adapters','set_mode','set_system_adapter','clear_system_adapter','set_window_adapter','clear_window_adapter','open_coupang_window','adb_status','adb_recover']);
  if(!supported.has(command))throw new Error(`지원하지 않는 네트워크 명령: ${command||'-'}`);
  try{
    const platform=await getPlatformOS();
    const timeout=['status','list_adapters','adb_status'].includes(command)?6500:(command==='adb_recover'?30000:(command==='open_coupang_window'?90000:75000));
    if(platform==='mac')return await requestNativeNetworkDirectFromOptions({...payload,userGesture:userGesture===true},timeout);
    const fullPayload={...payload,...currentBrowserLaunchHintV126(),extensionId:String(chrome.runtime?.id||''),extensionVersion:String(chrome.runtime?.getManifest?.().version||''),userGesture:userGesture===true};
    /* v4.1.92: Windows 옵션화면의 설정 변경도 로컬 HTTP 브리지에 선행 의존하지 않습니다.
       v4.1.79에서는 30765가 내려간 동시에 USB/RNDIS가 169.254(APIPA)가 되면,
       set_window_adapter가 로컬 브리지부터 요구하여 Helper의 DHCP 자동복구 코드에 도달하지 못하는
       순환 실패가 있었습니다. 상태/목록은 기존처럼 Native 단발 조회를 사용하고, 실제 변경/전용창은
       Service Worker의 Native-direct 제어를 우선 사용합니다. Service Worker 전송 자체가 실패한 경우에만
       옵션 페이지에서 Native Messaging 직접 호출 후 마지막으로 로컬 브리지를 사용합니다. */
    if(command==='status'||command==='list_adapters'||command==='adb_status'){
      /* v1.2.2: 상태/목록도 Service Worker의 실시간 분리 교차검증을 우선 사용합니다.
         Options가 Native Host의 순간적인 strictIsolation=false를 직접 표시하여 정상 IF#7/IF#24 분리를
         실패로 보이게 하던 경로를 제거합니다. SW가 실패할 때만 Native/로컬 브리지로 fallback합니다. */
      try{
        return await requestWindowsNetworkViaServiceWorker(fullPayload,12000);
      }catch(serviceWorkerError){
        try{
          const native=await requestWindowsNativeNetworkDirectFromOptions(fullPayload,6500);
          if(native?.proxyReady!==true){ensureNetworkBridgeViaNativeFromOptions(16000).catch(()=>null);return {...native,bridgeRecoveryPending:true,bridgeTransportAvailable:false};}
          return native;
        }catch(nativeError){
          return await requestLocalNetworkBridgeFromOptions(fullPayload,6500);
        }
      }
    }
    try{
      return await requestWindowsNetworkViaServiceWorker(fullPayload,timeout);
    }catch(serviceWorkerError){
      try{
        const native=await requestWindowsNativeNetworkDirectFromOptions(fullPayload,Math.min(90000,Math.max(15000,timeout)));
        return {...native,networkTransport:'native_direct_options_mutation_fallback'};
      }catch(nativeError){
        console.debug('[SPX] Windows 옵션 네트워크 Native 직접변경 fallback 실패',{command,serviceWorkerError:String(serviceWorkerError?.message||serviceWorkerError||''),nativeError:String(nativeError?.message||nativeError||'')});
        return await requestLocalNetworkBridgeFromOptions(fullPayload,timeout);
      }
    }
  }catch(error){
    const platform=await getPlatformOS();
    const raw=String(error?.message||error||'');
    if(platform==='mac'&&/native messaging host.*not found|specified native messaging host not found|forbidden/i.test(raw))
      throw new Error('macOS Network Helper가 설치되지 않았습니다. 기존 SmartPage Ex macOS Network Helper 설치 상태를 확인하세요.');
    throw new Error(conciseNetworkError(error));
  }
}

async function requestLocalDataNative(payload,timeoutMs=30000){
  const response=await requestWindowsNativeNetworkDirectFromOptions(payload,timeoutMs);
  if(!response?.ok)throw new Error(response?.error||'Local DB 작업 실패');
  return response;
}
function dataKindLabel(kind='',protectedFlag=false){if(protectedFlag)return '보호';const k=String(kind||'').toLowerCase();if(k==='pre_restore')return '복구 전 보호';if(k==='pre_update')return '업데이트 전 보호';if(k==='legacy')return '기존 백업';return '백업';}
function dataRevisionLabel(row={}){return row?.revisionKnown===true?'서버 변경 기준 확인 가능':'서버 변경 기준 확인 불가';}
function setDataActionStatus(id,text,cls=''){const el=$(id);if(!el)return;el.textContent=text;el.className='hint'+(cls?` ${cls}`:'');}
function validExistingLive(info){return Boolean(info&&info.integrity===true&&Number(info.rowCount)>0&&String(info.buildState||'').toLowerCase()==='ready');}
async function localDataFolderStatus(){return requestLocalDataNative({command:'manager_data_folder_status'},12000);}
async function localLiveStatus(){return requestLocalDataNative({command:'live_db_status'},12000);}
async function localBackupCatalog(){return requestLocalDataNative({command:'backup_catalog_list'},30000);}
async function renderDataManagementStatus({showList=false}={}){
  let folder=null,live=null,catalog=null,checkpoint=null;
  try{folder=await localDataFolderStatus();}catch(error){folder={configured:false,error:error?.message||String(error)};}
  if($('dataFolderPath'))$('dataFolderPath').textContent=folder?.configured===true?(folder.path||'-'):`미지정${folder?.error?` · ${folder.error}`:''}`;
  if(folder?.configured===true){
    try{live=await localLiveStatus();}catch(error){live={ready:false,error:error?.message||String(error)};}
    try{catalog=await localBackupCatalog();}catch(error){catalog={error:error?.message||String(error)};}
  }
  const cpData=await chrome.storage.local.get(MANAGER_LIVE_LOWLOAD_CHECKPOINT_KEY_V426).catch(()=>({}));checkpoint=cpData?.[MANAGER_LIVE_LOWLOAD_CHECKPOINT_KEY_V426]||null;
  const liveLines=[];
  if(folder?.configured!==true)liveLines.push('데이터 폴더: 미지정');
  else if(live?.ready===true){liveLines.push(`Local DB: ${fmt(live.count||0)}개 · 정상`);liveLines.push(`무결성: ${live.integrity===true?'정상':'확인 필요'}`);liveLines.push(`Generation: ${live.generation||'확인 불가'}`);liveLines.push(`Revision: ${live.revisionKnown===true?'확인 가능':'서버 변경 기준 확인 불가'}`);liveLines.push(`마지막 백업: ${live.lastBackupAt?formatKstDateTime(live.lastBackupAt):'없음'}`);}else{liveLines.push(`Local DB: ${live?.error||'준비되지 않음'}`);}
  if(live?.buildingDbExists===true||live?.building?.exists===true)liveLines.push(`중단 building DB: ${live?.building?.generation||'세대 확인 필요'}`);
  if(checkpoint&&checkpoint.complete!==true)liveLines.push('이전 중단 작업이 발견되었습니다. 현재 Local DB에는 영향이 없습니다.');
  if($('localDbSummary'))$('localDbSummary').textContent=liveLines.join('\n');
  const entries=Array.isArray(catalog?.catalog?.entries)?catalog.catalog.entries:Array.isArray(catalog?.entries)?catalog.entries:[];
  const newest=entries.slice().sort((a,b)=>Date.parse(b.createdAt||0)-Date.parse(a.createdAt||0))[0]||null;
  if($('recentBackupSummary'))$('recentBackupSummary').textContent=newest?`최근 백업 ${formatKstDateTime(newest.createdAt)}\n${fmt(newest.rowCount||0)}개 · ${dataKindLabel(newest.kind,newest.protected)} · ${newest.integrity===true?'정상':'오류'}\n${dataRevisionLabel(newest)}`:'정상 백업 없음';
  const plan=catalog?.plan||null,approved=Boolean(catalog?.catalog?.policyApproved);
  if($('backupRetentionPreview')){
    if(plan){const del=Array.isArray(plan.delete)?plan.delete.length:Number(plan.deleteCount||0),keep=Array.isArray(plan.keep)?plan.keep.length:Number(plan.keepCount||0),protectedCount=entries.filter(x=>x?.protected===true).length;$('backupRetentionPreview').textContent=`${approved?'보관정책 적용 중':'최초 적용 전 dry-run'} · 정리 예정 ${fmt(del)}개 · 유지 ${fmt(keep)}개 · 보호 ${fmt(protectedCount)}개${catalog?.catalogRebuilt?' · 기존 파일을 검사해 목록을 재구축했습니다.':''}`;}
    else $('backupRetentionPreview').textContent=catalog?.error||'백업 정책 확인 전';
  }
  if(showList)renderBackupList(entries);
  return{folder,live,catalog,entries,checkpoint};
}
function renderBackupList(entries=[]){const root=$('backupList');if(!root)return;root.hidden=false;root.innerHTML='';if(!entries.length){root.textContent='표시할 정상 백업이 없습니다.';return;}const sorted=entries.slice().sort((a,b)=>Date.parse(b.createdAt||0)-Date.parse(a.createdAt||0));for(const row of sorted){const box=document.createElement('div');box.className='backup-list-row';const meta=document.createElement('div');meta.className='backup-list-meta';const lock=row.protected===true?' <span class="data-badge lock">🔒 보호</span>':'';meta.innerHTML=`<b>${formatKstDateTime(row.createdAt)}${lock}</b>${fmt(row.rowCount||0)}개 · ${dataKindLabel(row.kind,row.protected)} · ${row.integrity===true?'정상':'오류'}<br>${dataRevisionLabel(row)} · ${String(row.filename||'')}`;const actions=document.createElement('div');actions.className='backup-list-actions';const restore=document.createElement('button');restore.type='button';restore.className='danger';restore.textContent='복구하기';restore.addEventListener('click',()=>restoreBackupFromOptions(row));const protect=document.createElement('button');protect.type='button';protect.className='ghost';protect.textContent=row.protected?'보호 해제':'보호';protect.addEventListener('click',()=>setBackupProtectedFromOptions(row,!row.protected));const del=document.createElement('button');del.type='button';del.className='danger';del.textContent='삭제';del.disabled=row.protected===true;del.addEventListener('click',()=>deleteBackupFromOptions(row));actions.append(restore,protect,del);box.append(meta,actions);root.append(box);}}
async function chooseDataFolderFromOptions(){const button=$('chooseDataFolder');if(button)button.disabled=true;try{setDataActionStatus('existingDbStatus','Windows 폴더 선택창을 여는 중...','notice');const picked=await requestLocalDataNative({command:'choose_manager_data_folder',save:true},10*60*1000);if(picked?.cancelled===true){setDataActionStatus('existingDbStatus','폴더 선택을 취소했습니다.');return;}setDataActionStatus('existingDbStatus','데이터 폴더를 변경했습니다. 경로 변경만으로 서버 전체 다운로드는 실행하지 않습니다.','ok');await renderDataManagementStatus({showList:!$('backupList')?.hidden});}catch(error){setDataActionStatus('existingDbStatus',`폴더 선택 실패 · ${error?.message||error}`,'bad');}finally{if(button)button.disabled=false;}}
async function importExistingDbFromOptions(){const button=$('importExistingDb');if(button)button.disabled=true;try{setDataActionStatus('existingDbStatus','기존 DB 폴더를 선택하세요.','notice');const picked=await requestLocalDataNative({command:'choose_manager_data_folder',save:false},10*60*1000);if(picked?.cancelled===true){setDataActionStatus('existingDbStatus','선택을 취소했습니다.');return;}const live=picked?.live||null;if(validExistingLive(live)){await requestLocalDataNative({command:'set_manager_data_folder',path:picked.path},15000);await chrome.storage.local.set({[MANAGER_RESTORE_ADOPT_FLAG_V426]:{pending:true,source:'existing-db-import',at:Date.now(),path:picked.path,revisionKnown:live.revisionKnown===true}});setDataActionStatus('existingDbStatus',`기존 DB ${fmt(live.rowCount||0)}개 검사 완료 · 이 PC의 Local DB로 연결했습니다. ${live.revisionKnown===true?'이후 서버 변경분 동기화를 사용할 수 있습니다.':'서버 변경 기준 확인 불가 · 자동 전체 다운로드는 실행하지 않습니다.'}`,'ok');await renderDataManagementStatus({showList:true});return;}
      await requestLocalDataNative({command:'set_manager_data_folder',path:picked.path},15000);const catalog=await localBackupCatalog().catch(()=>null),entries=Array.isArray(catalog?.catalog?.entries)?catalog.catalog.entries:[];setDataActionStatus('existingDbStatus',entries.length?`Live DB는 없지만 정상 백업 ${fmt(entries.length)}개를 찾았습니다. [백업 목록]에서 복구할 파일을 선택하세요.`:'사용 가능한 Live DB/백업을 찾지 못했습니다. 서버 DB 전체 다시 받기는 사용자가 명시적으로 선택할 때만 실행됩니다.',entries.length?'notice':'bad');await renderDataManagementStatus({showList:true});
  }catch(error){setDataActionStatus('existingDbStatus',`기존 DB 검사 실패 · ${error?.message||error}`,'bad');}finally{if(button)button.disabled=false;}}

async function showBackupListFromOptions(){try{await renderDataManagementStatus({showList:true});}catch(error){setDataActionStatus('backupRetentionPreview',`백업 목록 실패 · ${error?.message||error}`,'bad');}}
async function setBackupProtectedFromOptions(row,protect){try{await requestLocalDataNative({command:'backup_set_protected',filename:row.filename,protected:protect},30000);await renderDataManagementStatus({showList:true});}catch(error){alert(`보호 상태 변경 실패: ${error?.message||error}`);}}
async function deleteBackupFromOptions(row){if(!confirm(`${row.filename}\n\n이 백업을 삭제할까요? 보호 백업과 최소 복구 지점은 삭제할 수 없습니다.`))return;try{await requestLocalDataNative({command:'backup_delete',filename:row.filename},30000);await renderDataManagementStatus({showList:true});}catch(error){alert(`백업 삭제 실패: ${error?.message||error}`);}}
async function pruneOldBackupsFromOptions(){try{const preview=await requestLocalDataNative({command:'backup_retention_preview'},30000),plan=preview?.plan||{},del=Array.isArray(plan.delete)?plan.delete.length:Number(plan.deleteCount||0),keep=Array.isArray(plan.keep)?plan.keep.length:Number(plan.keepCount||0);if($('backupRetentionPreview'))$('backupRetentionPreview').textContent=`dry-run · 삭제 예정 ${fmt(del)}개 · 유지 ${fmt(keep)}개 · 승인 전 삭제 0`;if(!del)return;if(!confirm(`오래된 백업 정리 미리보기\n\n삭제 예정 ${fmt(del)}개\n유지 ${fmt(keep)}개\n\n보호 백업과 최소 복구 지점은 유지됩니다. 실제 정리할까요?`))return;const applied=await requestLocalDataNative({command:'backup_retention_apply',confirm:true},60000);if($('backupRetentionPreview'))$('backupRetentionPreview').textContent=`정리 완료 · 삭제 ${fmt(applied.deleted||0)}개`;await renderDataManagementStatus({showList:true});}catch(error){setDataActionStatus('backupRetentionPreview',`백업 정리 실패 · ${error?.message||error}`,'bad');}}
async function restoreBackupFromOptions(row){if(!confirm(`${row.filename}\n${fmt(row.rowCount||0)}개\n\n이 백업을 복구할까요?\n현재 Live DB는 먼저 보호 백업으로 저장하고, 검증된 경우에만 교체합니다. 서버에는 접속하지 않습니다.`))return;try{const result=await requestLocalDataNative({command:'backup_restore',filename:row.filename},2*60*1000);await chrome.storage.local.set({[MANAGER_RESTORE_ADOPT_FLAG_V426]:{pending:true,source:'backup-restore',at:Date.now(),filename:row.filename,revisionKnown:result.revisionKnown===true}});setDataActionStatus('existingDbStatus',`백업 복구 완료 · ${fmt(result.rowCount||0)}개 · ${result.revisionKnown===true?'서버 변경 기준 확인 가능':'서버 변경 기준 확인 불가'} · 서버 자동 동기화 0`,'ok');await renderDataManagementStatus({showList:true});}catch(error){setDataActionStatus('existingDbStatus',`백업 복구 실패 · 기존 Live DB 유지 · ${error?.message||error}`,'bad');}}
function bindDataManagementUi(){
  $('chooseDataFolder')?.addEventListener('click',chooseDataFolderFromOptions);$('checkLocalDbStatus')?.addEventListener('click',()=>renderDataManagementStatus({showList:!$('backupList')?.hidden}));$('importExistingDb')?.addEventListener('click',importExistingDbFromOptions);$('showBackupList')?.addEventListener('click',showBackupListFromOptions);$('pruneOldBackups')?.addEventListener('click',pruneOldBackupsFromOptions);
  document.querySelector('[data-options-tab="data"]')?.addEventListener('click',()=>renderDataManagementStatus({showList:false}).catch(()=>{}));
}
bindDataManagementUi();
function checkNetworkModeRadio(mode='window'){
  const select=$('networkAdapterSelect');
  if(select){select.disabled=false;select.setAttribute('aria-disabled','false');}
  const refresh=$('refreshNetworkAdapters');if(refresh){refresh.disabled=false;refresh.setAttribute('aria-disabled','false');}
  const label=$('networkAdapterLabel');
  if(label){label.textContent='전용 네트워크 (휴대폰 테더링)';label.dataset.tip='쿠팡 전용 트래픽에만 사용할 휴대폰 테더링을 선택합니다. Windows 기본 인터넷은 OS가 관리하며 Collector가 변경하지 않습니다.';}
  const row=select?.closest('.network-adapter-row');if(row)row.classList.remove('disabled');
  const restore=$('restoreNetworkMode');if(restore){restore.textContent='전용 네트워크 해제';restore.dataset.tip='쿠팡 전용 선택망만 해제합니다. Windows 기본 인터넷에는 손대지 않습니다.';}
  const ipButton=$('changePublicIpNow');if(ipButton){ipButton.disabled=false;ipButton.title=isMacPlatform()?'선택한 macOS 전용망의 공인 IP를 확인하면서 USB ADB로 Galaxy 비행기모드를 전환합니다.':'선택한 USB 테더링의 공인 IP를 변경하고 네트워크를 안정화합니다.';}
  renderNetworkAdapters(networkAdapterSnapshot,select?.value||'','window');
}
function cleanNetworkDisplayTextV103(value,fallback=''){
  const text=String(value??'').normalize('NFC').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,'').trim();
  if(!text)return fallback;
  // Windows PowerShell/native helper의 과거 CP949↔UTF-8 깨짐값은 UI에 노출하지 않습니다.
  // U+FFFD 뒤에 결합문자가 붙은 '�̴��� 3' 같은 형태도 전체 이름을 폐기하고 안전한 기본명으로 대체합니다.
  if(/[\uFFFD]/u.test(text)||/\?[^\s?]*\?/.test(text)||/[癤풱곸꽭섏씠吏뺤옣꾨줈洹몃옩]/.test(text))return fallback;
  return text;
}
function currentBrowserLaunchHintV126(){
  const ua=String(globalThis.navigator?.userAgent||'');
  if(/Whale\//i.test(ua))return{browserFamily:'whale',browserExecutableName:'whale.exe',browserDisplayName:'Whale'};
  if(/Edg\//i.test(ua))return{browserFamily:'edge',browserExecutableName:'msedge.exe',browserDisplayName:'Edge'};
  return{browserFamily:'chrome',browserExecutableName:'chrome.exe',browserDisplayName:'Chrome'};
}
function networkPublicIpText(data={}){const ip=String(data.publicIp||data.public_ip||'').trim(),pending=Boolean(data.publicIpError)&&data.publicIpLookupOk!==true;return ip?` · 외부 공인 IP ${ip}${pending?' · 최근 확인값·재확인 대기':''}`:(data.publicIpError?` · 공인 IP 확인 대기`:'');}
function startNetworkStatusLiveRefresh(){
  if(networkStatusRefreshTimer)return;
  networkStatusRefreshTimer=setInterval(()=>{if(document.visibilityState==='visible')refreshNetworkStatus({list:false}).catch(()=>null);},60000);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')refreshNetworkStatus({list:false}).catch(()=>null);});
}
function renderAdbConnectionStateV168(data={}){
  const el=$('adbConnectionStatus');if(!el)return;
  const state=String(data?.adbDeviceState||'').toLowerCase();
  const model=String(data?.adbDeviceModel||'').trim();
  const serial=String(data?.adbDeviceSerial||'').trim();
  const action=String(data?.recoveryAction||'').trim();
  if(data?.adbReady===true||state==='device'){el.textContent=`ADB 연결 상태 · 연결됨${model?` · ${model}`:''}${serial?` · ${serial}`:''}${action&&action!=='status-only'?` · ${action}`:''}`;el.className='hint ok';return;}
  if(state==='unauthorized'){el.textContent='ADB 연결 상태 · 휴대폰 승인 필요 · 휴대폰 잠금을 해제하고 USB 디버깅 허용 창에서 이 컴퓨터를 항상 허용하세요.';el.className='hint bad';return;}
  if(state==='offline'){el.textContent='ADB 연결 상태 · offline · 자동 연결/복구를 한 번 실행해보세요.';el.className='hint notice';return;}
  if(state==='server-down'){el.textContent='ADB 연결 상태 · ADB 서버 응답 없음 · 자동 연결/복구를 실행하세요.';el.className='hint bad';return;}
  if(state==='adb-missing'){el.textContent='ADB 연결 상태 · Platform-Tools를 찾지 못했습니다 · RUN_00_INSTALL_OTHER_PC.cmd로 보조도구를 복구하세요.';el.className='hint bad';return;}
  if(state==='not-connected'){el.textContent='ADB 연결 상태 · 휴대폰 미연결 · USB 케이블과 USB 디버깅을 확인하세요.';el.className='hint notice';return;}
  el.textContent='ADB 연결 상태 · 확인 필요';el.className='hint notice';
}
async function refreshAdbConnectionV168({repair=false}={}){
  const statusButton=$('checkAdbConnection'),repairButton=$('repairAdbConnection');
  if(statusButton)statusButton.disabled=true;if(repairButton)repairButton.disabled=true;
  const el=$('adbConnectionStatus');if(el){el.textContent=repair?'ADB 자동 연결/복구 중...':'ADB 연결 상태 확인 중...';el.className='hint notice';}
  try{
    const data=await requestNetworkData({command:repair?'adb_recover':'adb_status'},{userGesture:true});
    renderAdbConnectionStateV168(data);
    if(repair&&data?.adbReady===true)msg('ADB 연결을 확인했습니다.','ok');
    else if(repair&&String(data?.adbDeviceState||'').toLowerCase()==='unauthorized')msg('휴대폰 화면에서 USB 디버깅 허용을 눌러주세요.','bad');
    else if(repair&&data?.adbReady!==true)msg('ADB 자동 복구를 마쳤지만 휴대폰 연결 확인이 필요합니다.','bad');
    return data;
  }catch(error){
    const message=conciseNetworkError(error);if(el){el.textContent=`ADB 연결/복구 실패 · ${message}`;el.className='hint bad';}throw error;
  }finally{if(statusButton)statusButton.disabled=false;if(repairButton)repairButton.disabled=false;}
}

async function refreshNetworkStatus({list=false,userGesture=false}={}){
  setNetworkStatus(list?`${isMacPlatform()?'macOS':'Windows'} 네트워크 어댑터 목록을 불러오는 중...`:'수집 네트워크 상태를 확인하는 중...','notice');
  try{
    let data=await requestNetworkData({command:list?'list_adapters':'status'},{userGesture});
    const settings=await SPX.util.getSettings().catch(()=>({}));
    const helperMode=data.mode==='window'||data.windowAdapterEnabled===true?'window':(data.mode==='system'?'system':'');
    const desiredWindow=settings.collectionNetworkMode==='window'&&Boolean(String(settings.collectionNetworkAdapterId||'').trim());
    const activeMode=(helperMode==='window'||desiredWindow)?'window':'system';
    const reportedMode=activeMode;
    const pickerMode='window';
    const adapters=Array.isArray(data.adapters)?data.adapters:networkAdapterSnapshot;
    if(helperMode==='window'){
      const helperAdapterId=String(data.windowAdapterId||data.selectedAdapterId||'').trim();
      const helperAdapterName=String(data.windowAdapterName||data.selectedAdapterName||'').trim();
      if(helperAdapterId&&(settings.collectionNetworkMode!=='window'||String(settings.collectionNetworkAdapterId||'')!==helperAdapterId||String(settings.collectionNetworkAdapterName||'')!==helperAdapterName)){
        SPX.util.setSettings({collectionNetworkMode:'window',collectionNetworkAdapterId:helperAdapterId,collectionNetworkAdapterName:helperAdapterName}).catch(()=>null);
      }
    }
    const defaultAdapter=adapters.find((row)=>row?.isSystemDefault===true||Number(row?.interfaceIndex)===Number(data.systemDefaultInterfaceIndex))||null;
    const systemChoice=(defaultAdapter&&!adapterIsStrongTether(defaultAdapter)&&!adapterIsVirtual(defaultAdapter))?defaultAdapter:null;
    let selectedId=String(data.windowAdapterId||data.selectedAdapterId||settings.collectionNetworkAdapterId||$('networkAdapterSelect')?.value||'');
    if(Array.isArray(data.adapters)){
      let liveAdapters=data.adapters;
      if(isMacPlatform()&&liveAdapters.length===0&&networkAdapterSnapshot.length>0){
        macTransientEmptyAdapterReads+=1;
        if(macTransientEmptyAdapterReads<3){
          liveAdapters=networkAdapterSnapshot;
          data.adapters=liveAdapters;
          data.adapterListTransientEmpty=true;
        }
      }else if(liveAdapters.length>0){
        macTransientEmptyAdapterReads=0;
      }
      renderNetworkAdapters(liveAdapters,selectedId,pickerMode);
      selectedId=String($('networkAdapterSelect')?.value||selectedId||'');
      await saveNetworkAdapterCache(liveAdapters,selectedId);
    }
    renderEasyNetworkSummaryV1514(data,settings);
    renderAdbConnectionStateV168(data);
    checkNetworkModeRadio('window');
    if(selectedId&&$('networkAdapterSelect')&&[...$('networkAdapterSelect').options].some((option)=>option.value===selectedId&&!option.disabled))$('networkAdapterSelect').value=selectedId;
    const helperVersion=String(data.helperVersion||'').trim();
    const helperVersionParts=helperVersion.split('.').map((part)=>Number.parseInt(part,10));
    const helperVersionValid=helperVersionParts.length>=3&&helperVersionParts.slice(0,3).every(Number.isFinite);
    const minimumCoreHelperVersion=isMacPlatform()?[0,0,0]:[3,0,33];
    const dhcpRecoveryHelperVersion=[99,0,0]; // DHCP recovery remains available; v4.1.92 keeps USB/RNDIS DHCP recovery while Windows dedicated-window control prefers Native Messaging and verifies the live /health endpoint.
    const versionBelow=(parts,min)=>!helperVersionValid||parts[0]<min[0]||(parts[0]===min[0]&&parts[1]<min[1])||(parts[0]===min[0]&&parts[1]===min[1]&&parts[2]<min[2]);
    const helperVersionTooOld=Boolean(helperVersion)&&versionBelow(helperVersionParts,minimumCoreHelperVersion);
    if(helperVersionTooOld){
      setNetworkStatus(`네트워크 보조도구 다시 설치 필요 · 현재 ${helperVersion||'확인 불가'} · RUN_00_INSTALL_OTHER_PC.cmd를 다시 실행하세요.`,'bad');
      return data;
    }
    const chosen=networkAdapterSnapshot.find((row)=>String(row.id)===String(selectedId||''))||null;
    if(activeMode==='window'&&!isMacPlatform()&&chosen&&adapterIsRecoverableTether(chosen)&&!adapterHasUsableIpv4(chosen)){
      setNetworkStatus(`전용망 준비 감지 중 · ${chosen.name||'USB 테더링'} · 정상 IPv4가 생기는 즉시 자동 표시합니다.`,'notice');
      scheduleDedicatedAdapterReadinessWatchV10159(chosen);
    }else if(activeMode!=='window'||(chosen&&adapterHasUsableIpv4(chosen))){
      stopDedicatedAdapterReadinessWatchV10159();
    }
    const helperSupportsDhcpRecovery=true; // v4.1.46: restored v4.1.1-compatible helper is accepted; APIPA is handled as adapter readiness, not version rejection
    const helperNeedsDhcpUpgrade=!isMacPlatform()&&!helperSupportsDhcpRecovery&&chosen&&adapterIsRecoverableTether(chosen)&&!adapterIsInternetReady(chosen);
    if(helperNeedsDhcpUpgrade){
      setNetworkStatus(`현재 Network Helper ${helperVersion}는 전용창 핵심 기능과 호환되지만, ${chosen.name||'선택 USB 테더링'}이 정상 IPv4를 받지 못해 자동 DHCP 복구가 필요합니다. 이 경우에만 호환 Helper 복구가 필요합니다.`,'bad');
      return data;
    }
    if(data?.bridgeRecoveryPending===true&&data?.proxyReady!==true){
      const adapterName=String(chosen?.name||data.windowAdapterName||data.selectedAdapterName||data.systemDefaultInterfaceAlias||'Windows 어댑터');
      setNetworkStatus(`전용창 준비 중 · ${adapterName} · 잠시 후 상태 다시 확인을 눌러주세요.`,'notice');
      scheduleNetworkBridgeRecoveryPoll();
      return data;
    }
    stopNetworkBridgeRecoveryPoll();
    const helperCompatSuffix='';
    const adbReady=data.adbReady===true;
    const adbSuffix=adbReady?' · 차단 자동복구 ADB 준비':' · 차단 자동복구 ADB 미준비';
    const dnsSuffix=data.selectedNetworkDnsMode==='system_dns_fallback'?' · DNS 이름해석은 Windows 기본망 보조 · 실제 쿠팡 TCP는 선택망 고정':'';
    const adapterLabel=activeMode==='window'
      ?String(data.windowAdapterName||data.selectedAdapterName||chosen?.name||'')
      :String(data.systemPinnedAdapterName||chosen?.name||'');
    if(isMacPlatform()&&list&&data.androidUsbAdbConnected===true&&data.usbTetheringInterfaceExposed!==true){
      setNetworkStatus('갤럭시 USB/ADB 연결은 확인됐지만 macOS가 Android USB 테더링을 네트워크 인터페이스로 노출하지 않았습니다. 확장프로그램이 숨은 USB망을 강제로 만들거나 기본 라우팅을 바꾸지는 않습니다. Mac에서 Galaxy 핫스팟이 별도 Wi-Fi로 보이면 그 Wi-Fi를 전용망으로 선택하고 USB는 ADB 자동 IP 변경용으로 사용할 수 있습니다.','notice');
      return data;
    }
    if(reportedMode==='adapter'){
      setNetworkStatus('이전 버전의 Windows 라우팅 설정이 감지되었습니다. v1.6.9은 기존 metric 상태만 1회 복원하고 이후 Windows 기본 인터넷을 변경하지 않습니다.','notice');
    }else if(activeMode==='window'&&helperMode!=='window'&&desiredWindow){
      setNetworkStatus(`전용창 선택 복구 대기 · 저장된 USB 테더링 선택은 유지합니다 · ${settings.collectionNetworkAdapterName||'선택 어댑터'} · 보조도구가 Windows 어댑터·IPv4를 다시 확인하는 중입니다.`,'notice');
    }else if(activeMode==='window'&&data.strictIsolationOk!==true){
      setNetworkStatus(`기본 인터넷/휴대폰 테더링 분리 확인 실패 · ${data.isolationMessage||'두 연결이 서로 다른지 확인하고 다시 연결하세요.'}`,'bad');
    }else if(activeMode==='window'&&!isMacPlatform()&&data.selectedNetworkReady!==true){
      setNetworkStatus(`휴대폰 테더링 연결 확인 필요 · ${adapterEasyLabelV1514(chosen,{tether:true})||adapterLabel||'휴대폰 테더링'} · 모바일 데이터와 USB 테더링을 확인한 뒤 ‘선택 연결’을 다시 눌러주세요.`,'bad');
    }else if(activeMode==='window'){
      if(isMacPlatform())setNetworkStatus(`macOS 선택 네트워크 전용창 준비 완료 · ${adapterLabel||'선택 어댑터'} · 쿠팡 도메인만 선택망 사용 · 나머지 트래픽은 ${data.systemDefaultInterfaceAlias||'macOS 기본 인터넷'} DIRECT · 실제 이미지는/데이터는 기존 방식 유지` ,data.proxyReady===false?'bad':'ok');
      else {
        const tetherLabel=adapterEasyLabelV1514(chosen,{tether:true})||adapterLabel||'휴대폰 테더링';
        const baseLabel=adapterEasyLabelV1514(systemChoice||defaultAdapter)||cleanNetworkDisplayTextV103(data.systemDefaultInterfaceAlias,cleanNetworkDisplayTextV103(data.systemPinnedAdapterName,'기본 인터넷'));
        setNetworkStatus(data.proxyReady===false
          ?`전용창 준비 확인 필요 · 휴대폰 테더링 ${tetherLabel} · 상태 다시 확인을 눌러주세요.`
          :`전용창 준비 완료 · 쿠팡 쇼핑 → ${tetherLabel} / 일반 인터넷·WING·Supabase → ${baseLabel}`,
          data.proxyReady===false?'bad':'ok');
      }
    }else{
      if(isMacPlatform()){
        setNetworkStatus(`macOS 기본 인터넷 · ${data.systemDefaultInterfaceAlias||defaultAdapter?.name||'확인 중'} · 시스템 설정이 기본 라우팅을 관리합니다. 전용 수집은 위의 ‘선택 네트워크 전용창’에서 기본망과 다른 Wi-Fi/테더링/이더넷을 선택하세요.`,'ok');
        return data;
      }
      const defaultName=cleanNetworkDisplayTextV103(data.systemDefaultInterfaceAlias,cleanNetworkDisplayTextV103(defaultAdapter?.name,'확인 중'));
      const chosenName=String(systemChoice?.name||adapterLabel||'');
      const tetherDefault=defaultAdapter&&adapterTetheringScore(defaultAdapter)>=80;
      const pinnedIndex=Number(data.systemPinnedInterfaceIndex||0),defaultIndex=Number(data.systemDefaultInterfaceIndex||defaultAdapter?.interfaceIndex||0);
      const pinRouteMatches=data.systemPinHealthy===true||(pinnedIndex>0&&defaultIndex===pinnedIndex);
      const fixedOk=data.systemPinApplied===true&&String(data.systemPinnedAdapterId||'')===String(systemChoice?.id||'')&&pinRouteMatches&&!tetherDefault;
      if(fixedOk){
        setNetworkStatus(`Windows 기본망 고정 완료 · ${chosenName||defaultName}${data.systemDefaultInterfaceIpv4?` · ${data.systemDefaultInterfaceIpv4}`:''} · USB 테더링 연결 후에도 일반 브라우저·Windows는 이 경로를 우선 사용합니다.`,'ok');
      }else if(tetherDefault&&systemChoice&&String(systemChoice.id)!==String(defaultAdapter?.id||'')){
        setNetworkStatus(`주의 · 현재 Windows 기본 경로가 USB 테더링 ${defaultName}으로 바뀌었습니다. 목록의 ${chosenName}을 선택한 뒤 ‘선택 적용’을 눌러 일반 인터넷 기본망으로 고정하세요.`,'bad');
      }else{
        setNetworkStatus(`Windows 기본 인터넷 후보 · ${chosenName||defaultName}${systemChoice?.ipv4Address?` · ${systemChoice.ipv4Address}`:''} · ‘선택 적용’을 누르면 USB 테더링 연결 후에도 이 어댑터를 기본 경로로 유지합니다.`,'notice');
      }
    }
    return data;
  }catch(error){
    const detail=error?.message||String(error);
    const cached=await loadNetworkAdapterCache();
    if(Array.isArray(cached?.adapters)&&cached.adapters.length){
      const settings=await SPX.util.getSettings().catch(()=>({}));
      const activeMode=selectedNetworkMode();
      const preferred=activeMode==='window'
        ?String(settings.collectionNetworkAdapterId||$('networkAdapterSelect')?.value||cached.selectedId||'')
        :String(settings.collectionSystemAdapterId||$('networkAdapterSelect')?.value||'');
      renderNetworkAdapters(cached.adapters,preferred,activeMode);
      const ageMinutes=Math.max(0,Math.round((Date.now()-Number(cached.savedAt||Date.now()))/60000));
      setNetworkStatus(`보조도구 재연결 대기 · 최근 감지 어댑터 목록을 유지합니다(${ageMinutes}분 전) · ${detail}`,'notice');
    }else{
      setNetworkStatus(`보조도구 연결 실패 · ${detail}`,'bad');
    }
    return null;
  }
}
let networkUiMutationPromise=null;
function setNetworkMutationButtonsBusy(busy=false,label='',activeButtonId='applyNetworkMode'){
  for(const id of ['autoFixDefaultNetwork','applyNetworkMode','openCoupangNetworkWindow','restoreNetworkMode','changePublicIpNow']){
    const button=$(id);if(!button)continue;
    if(busy){button.dataset.originalText=button.dataset.originalText||button.textContent;button.dataset.originalDisabled=button.disabled?'1':'0';button.disabled=true;}
    else{button.disabled=button.dataset.originalDisabled==='1';delete button.dataset.originalDisabled;if(button.dataset.originalText){button.textContent=button.dataset.originalText;delete button.dataset.originalText;}}
  }
  const active=$(activeButtonId)||$('applyNetworkMode');if(busy&&active&&label)active.textContent=label;
}
async function runNetworkUiMutation(label,task,activeButtonId='applyNetworkMode'){
  if(networkUiMutationPromise)return networkUiMutationPromise;
  setNetworkMutationButtonsBusy(true,label||'적용 중...',activeButtonId);
  networkUiMutationPromise=Promise.resolve().then(task).finally(()=>{networkUiMutationPromise=null;setNetworkMutationButtonsBusy(false,'',activeButtonId);});
  return networkUiMutationPromise;
}
let startupDefaultPinAttemptedV1514=false;
async function autoFixDefaultInternetV1514({refresh=true,quiet=false}={}){
  // v1.6.4 compatibility only. Never pin/repair the Windows default route.
  const data=refresh?await requestNetworkData({command:'list_adapters'},{userGesture:false}).catch(()=>null):null;
  if(Array.isArray(data?.adapters)&&data.adapters.length)networkAdapterSnapshot=data.adapters;
  const settings=await SPX.util.getSettings().catch(()=>({}));
  renderEasyNetworkSummaryV1514(data||{},settings);
  if(!quiet)setNetworkStatus('Windows 기본 인터넷은 OS가 관리합니다. Collector는 기본 라우팅을 변경하지 않습니다.','notice');
  return{ok:true,skipped:true,routeMutationDisabled:true,data};
}
async function scheduleStartupDefaultPinV1514(){
  // retained for older callers; v1.6.4 only refreshes read-only status.
  if(startupDefaultPinAttemptedV1514)return null;startupDefaultPinAttemptedV1514=true;
  return refreshNetworkStatus({list:true,userGesture:false}).catch(()=>null);
}
async function applySelectedNetworkMode(forceMode=null){
  let select=$('networkAdapterSelect');
  let adapterId=String(select?.value||'').trim();
  let adapter=networkAdapterSnapshot.find((row)=>String(row.id)===adapterId)||null;
  ({select,adapterId,adapter}=await ensureSelectedNetworkAdapter({userGesture:true}));
  if(adapter?.isSystemDefault===true)throw new Error('선택한 휴대폰 테더링이 현재 Windows 기본 인터넷입니다. Collector는 기본 경로를 바꾸지 않으므로 Wi-Fi/유선 기본 인터넷이 복구될 때까지 Fail-Closed합니다.');
  if(adapter&&adapterIsRecoverableTether(adapter)&&!adapterHasUsableIpv4(adapter))scheduleDedicatedAdapterReadinessWatchV10159(adapter);
  setNetworkStatus('Windows 기본 인터넷은 그대로 둔 채 쿠팡 전용 네트워크만 확인하는 중...','notice');
  const data=await requestNetworkData({command:'set_window_adapter',adapterId,adapterName:adapter?.name||'',adapterDescription:adapter?.description||''},{userGesture:true});
  if(data?.strictIsolationOk!==true)throw new Error(`선택망 분리 안전검사 실패 · ${data.isolationMessage||'선택 테더링이 Windows 기본 인터넷인지 확인하세요. Collector는 기본 라우팅을 변경하지 않습니다.'}`);
  const appliedAdapterId=String(data.windowAdapterId||data.selectedAdapterId||adapterId||'');
  const appliedAdapterName=String(data.windowAdapterName||data.selectedAdapterName||adapter?.name||'');
  await SPX.util.setSettings({collectionNetworkMode:'window',collectionNetworkAdapterId:appliedAdapterId,collectionNetworkAdapterName:appliedAdapterName});
  checkNetworkModeRadio('window');
  renderEasyNetworkSummaryV1514(data,await SPX.util.getSettings().catch(()=>({})));
  const actualDefault=networkAdapterSnapshot.find((row)=>row?.isSystemDefault===true||Number(row?.interfaceIndex)===Number(data.systemDefaultInterfaceIndex))||null;
  setNetworkStatus(`전용 네트워크 연결 완료 · ${adapterEasyLabelV1514(adapter,{tether:true})||appliedAdapterName||appliedAdapterId} · 쿠팡 지정 트래픽만 선택망 사용 / WING·Supabase·일반 인터넷 → ${adapterEasyLabelV1514(actualDefault)||cleanNetworkDisplayTextV103(data.systemDefaultInterfaceAlias,'Windows 기본 인터넷')}`,'ok');
  return data;
}
async function clearCurrentNetworkSelection(){
  setNetworkStatus('쿠팡 전용 네트워크 선택만 해제하는 중...','notice');
  const data=await requestNetworkData({command:'clear_window_adapter'},{userGesture:true});
  await SPX.util.setSettings({collectionNetworkMode:'system',collectionNetworkAdapterId:'',collectionNetworkAdapterName:'',collectionSystemAdapterId:'',collectionSystemAdapterName:''});
  checkNetworkModeRadio('window');
  await refreshNetworkStatus({list:true,userGesture:true});
  return data;
}
async function getNetworkRecoverySnapshot(){
  const response=await SPX.util.sendMessage({type:'SPX_GET_NETWORK_RECOVERY_STATE'}).catch(()=>null);
  return response?.data?.networkRecovery||{};
}
function formatNetworkRecoveryTime(ms){
  const total=Math.max(0,Math.ceil((Number(ms)||0)/1000));
  const min=Math.floor(total/60),sec=total%60;
  return `${String(min).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
}
let manualIpPollTimer=null;
function stopManualIpPolling(){if(manualIpPollTimer){clearInterval(manualIpPollTimer);manualIpPollTimer=null;}}
async function pollManualIpProgress(){
  const recovery=await getNetworkRecoverySnapshot();
  const status=String(recovery?.status||'');
  if(status==='resetting'){
    const left=Math.max(0,Number(recovery.estimatedResetCompleteAt||0)-Date.now());
    setNetworkStatus(`${recovery.phaseLabel||'비행기 모드·모바일 데이터 재연결과 새 IP 확인 중'}${left?` · 예상 ${formatNetworkRecoveryTime(left)}`:''}`,'notice');
    return true;
  }
  if(status==='finalizing'){
    setNetworkStatus(recovery.phaseLabel||'IP 변경 확인 완료 · 현재 탭 새로고침 중','notice');
    return true;
  }
  if(status==='failed'){
    setNetworkStatus(`${recovery.phaseLabel||'IP 변경 실패'} · ${recovery.lastError||'공인 IP가 바뀌지 않았거나 보조도구 응답을 확인하지 못했습니다.'}`,'bad');
    stopManualIpPolling();const btn=$('changePublicIpNow');if(btn)btn.disabled=selectedNetworkMode()!=='window';
    return false;
  }
  if(status==='cancelled'){
    setNetworkStatus(recovery.phaseLabel||'IP 변경을 중단했습니다.','notice');
    stopManualIpPolling();const btn=$('changePublicIpNow');if(btn)btn.disabled=selectedNetworkMode()!=='window';
    return false;
  }
  if(status==='completed'){
    setNetworkStatus(`${recovery.phaseLabel||'IP 변경·♻+🧹 정리 완료'}${recovery.publicIp?` · 새 공인 IP ${recovery.publicIp}`:''}`,'ok');
    stopManualIpPolling();const btn=$('changePublicIpNow');if(btn)btn.disabled=selectedNetworkMode()!=='window';
    return false;
  }
  stopManualIpPolling();const btn=$('changePublicIpNow');if(btn)btn.disabled=selectedNetworkMode()!=='window';
  setNetworkStatus('IP↻ 진행 상태 확인 불가 · 현재 위치를 유지하고 상태를 다시 확인하세요.','notice');
  return false;
}
async function changePublicIpNow(){
  if(selectedNetworkMode()!=='window')throw new Error(isMacPlatform()?'선택 네트워크 전용창 모드에서 macOS 전용망을 먼저 적용하세요.':'선택 네트워크 전용창 모드에서 USB 테더링 어댑터를 먼저 적용하세요.');
  const btn=$('changePublicIpNow');if(btn)btn.disabled=true;
  setNetworkStatus(`수동 IP 변경 요청 · 수집 일시중지 → ♻ → 🧹 → ${isMacPlatform()?'USB ADB로 선택망 유형에 맞춰 갤럭시 모바일 데이터 또는 비행기 모드 재연결':'비행기 모드 ON(설정 시간) → OFF'} → 새 IP 확인 → 현재 탭 새로고침 순서로 진행합니다.`,'notice');
  let response;
  try{response=await SPX.util.sendMessage({type:'SPX_MANUAL_IP_CHANGE',source:'options_button'});
    if(!response?.ok)throw new Error(response?.error||'수동 IP 변경을 시작하지 못했습니다.');
  }catch(error){stopManualIpPolling();if(btn)btn.disabled=selectedNetworkMode()!=='window';throw error;}
  stopManualIpPolling();
  const active=await pollManualIpProgress().catch(()=>false);
  if(active)manualIpPollTimer=setInterval(()=>pollManualIpProgress().catch(()=>{stopManualIpPolling();if(btn)btn.disabled=selectedNetworkMode()!=='window';}),1000);
  else if(btn)btn.disabled=selectedNetworkMode()!=='window';
  return response;
}
async function openCoupangDedicatedWindow(){
  checkNetworkModeRadio('window');
  const {adapterId,adapter}=await ensureSelectedNetworkAdapter({userGesture:true});
  const adapterName=adapter?.name||'';
  await SPX.util.setSettings({collectionNetworkMode:'window',collectionNetworkAdapterId:adapterId,collectionNetworkAdapterName:adapterName}).catch(()=>{});
  setNetworkStatus('선택망 확인 → 필요 시 USB IPv4 자동복구 → 전용창 실행 중...','notice');
  /* v4.1.46: v4.1.1처럼 helper 한 명령이 선택망 적용과 전용창 실행을 연속 처리합니다.
     set_window_adapter → Service Worker → open_window의 중복 왕복을 제거합니다. */
  const data=await requestNetworkData({
    command:'open_coupang_window',adapterId,adapterName,startUrl:'https://www.coupang.com/np/search?q=%EC%83%81%ED%92%88&channel=user',singleTab:true,forceRuntimeRestart:false,
  },{userGesture:true});
  if(data?.strictIsolationOk!==true)throw new Error(`선택망 분리 안전검사 실패 · ${data?.isolationMessage||'Windows 기본 경로와 선택 어댑터를 다시 확인하세요.'}`);
  if(data?.windowOpened===false)throw new Error(data?.error||'전용창 실행 확인을 받지 못했습니다.');
  renderEasyNetworkSummaryV1514(data,await SPX.util.getSettings().catch(()=>({})));
  setNetworkStatus(`전용창 준비 완료 · ${adapterEasyLabelV1514(adapter,{tether:true})||adapterName||data.selectedAdapterName||adapterId}${networkPublicIpText(data)} · 쿠팡만 선택망 사용 · 일반 브라우저·Supabase는 ${isMacPlatform()?'macOS 기본망':'Windows 기본망'} 유지`,'ok');
  return data;
}

let optionsCoreHydratedV433=false;
function setOptionsCoreHydratedV433(ready,message=''){optionsCoreHydratedV433=ready===true;const save=$('save');if(save){save.disabled=!optionsCoreHydratedV433;save.setAttribute('aria-disabled',optionsCoreHydratedV433?'false':'true');}if(message)msg(message,optionsCoreHydratedV433?'ok':'notice');}
let optionsDeferredHydrationStartedV431=false;
function scheduleOptionsDeferredHydrationV431(){
  if(optionsDeferredHydrationStartedV431)return;optionsDeferredHydrationStartedV431=true;
  /* Standalone Collector v1.0.0 fast start: independent reads start together after local first paint.
     Network readiness never waits for integration-file/, and those diagnostics never
     block the saved Local settings UI. */
  setTimeout(()=>{
    void refreshNetworkStatus({list:true}).then(()=>startNetworkStatusLiveRefresh()).catch(()=>startNetworkStatusLiveRefresh());
    void loadIntegrationSettingsFile({silent:true,backup:false}).catch(()=>null);
    void refreshProtectedSettingsStatus().catch(()=>null);
    void refreshIntegrationSettingsFileStatus({silent:true}).catch(()=>null);
  },0);
}

async function initOptions() {
  setOptionsCoreHydratedV433(false,'로컬 설정 확인 중...');
  /* Local settings own first paint. OS/NetworkHost detection is background-only. */
  void getPlatformOS().then(()=>renderNetworkHostRoute()).catch(()=>null);
  /* v3.0.20: 전체 자동 탐색 카테고리는 네트워크 상태조회보다 먼저 로컬 설정에서 즉시 렌더링합니다.
     느린 보조도구 조회가 끝날 때까지 categoryGrid가 비어 있어 저장이 오판되는 회귀를 막습니다. */
  const initialSettings = await SPX.util.getSettings();
  renderCategories(initialSettings.fullExploreCategories);
  const s = initialSettings;
  $('url').value = s.supabaseUrl;
  $('key').value = s.serviceKey;
  if ($('geminiApiKey')) $('geminiApiKey').value = s.geminiApiKey || '';
  if ($('openaiApiKey')) $('openaiApiKey').value = s.openaiApiKey || '';
  await loadWingCredentialLocalV426(s).catch(()=>null);
  if ($('autoDiscover')) if ($('autoDiscover')) $('autoDiscover').checked = !!s.autoDiscover;
  if ($('autoUpload')) if ($('autoUpload')) $('autoUpload').checked = !!s.autoUpload;
  if ($('sourceDataCollection')) if ($('sourceDataCollection')) $('sourceDataCollection').checked = s.sourceDataCollection !== false;
  if ($('adaptiveFastCollect')) if ($('adaptiveFastCollect')) $('adaptiveFastCollect').checked = s.adaptiveFastCollect !== false;
  if ($('maxKeywords')) if ($('maxKeywords')) $('maxKeywords').value = s.maxKeywordsPerRun;
  if ($('maxPages')) if ($('maxPages')) $('maxPages').value = s.maxPagesPerKeyword;
  if ($('winnerMonthlySalesMin')) if ($('winnerMonthlySalesMin')) $('winnerMonthlySalesMin').value = s.winnerMonthlySalesMin;
  if ($('winnerReviewMin')) if ($('winnerReviewMin')) $('winnerReviewMin').value = s.winnerReviewMin;
  if ($('winnerReviewMax')) if ($('winnerReviewMax')) $('winnerReviewMax').value = s.winnerReviewMax;
  if ($('winnerRecentReviewMin')) if ($('winnerRecentReviewMin')) $('winnerRecentReviewMin').value = s.winnerRecentReviewMin;
  if ($('sourceDataTargetOrganic')) if ($('sourceDataTargetOrganic')) $('sourceDataTargetOrganic').value = s.sourceDataTargetOrganic || 60;
  if ($('sourceDataMaxProducts')) if ($('sourceDataMaxProducts')) $('sourceDataMaxProducts').value = s.sourceDataMaxProducts || 200;
  if ($('lowReviewSampleSize')) if ($('lowReviewSampleSize')) $('lowReviewSampleSize').value = s.lowReviewSampleSize ?? 4;
  if ($('autoWeeklyRecollectEnabled')) if ($('autoWeeklyRecollectEnabled')) $('autoWeeklyRecollectEnabled').checked = s.autoWeeklyRecollectEnabled !== false;
  if ($('autoWeeklyRecollectDays')) if ($('autoWeeklyRecollectDays')) $('autoWeeklyRecollectDays').value = s.autoWeeklyRecollectDays ?? 7;
  if ($('organicSampleSize')) if ($('organicSampleSize')) $('organicSampleSize').value = s.organicSampleSize ?? 50;
  if ($('humanDelayEnabled')) if ($('humanDelayEnabled')) $('humanDelayEnabled').checked = s.humanDelayEnabled !== false;
  if ($('humanDelayMinMs')) if ($('humanDelayMinMs')) $('humanDelayMinMs').value = s.humanDelayMinMs ?? 2500;
  if ($('humanDelayMaxMs')) if ($('humanDelayMaxMs')) $('humanDelayMaxMs').value = s.humanDelayMaxMs ?? 4500;
  if ($('nextNavigationDelayMinMs')) if ($('nextNavigationDelayMinMs')) $('nextNavigationDelayMinMs').value = s.nextNavigationDelayMinMs ?? 180;
  if ($('nextNavigationDelayMaxMs')) if ($('nextNavigationDelayMaxMs')) $('nextNavigationDelayMaxMs').value = s.nextNavigationDelayMaxMs ?? 420;
  if ($('humanRetryMax')) if ($('humanRetryMax')) $('humanRetryMax').value = s.humanRetryMax ?? 2;
  if ($('humanRetryMinMs')) if ($('humanRetryMinMs')) $('humanRetryMinMs').value = s.humanRetryMinMs ?? 3000;
  if ($('humanRetryMaxMs')) if ($('humanRetryMaxMs')) $('humanRetryMaxMs').value = s.humanRetryMaxMs ?? 12000;
  if ($('candidates')) if ($('candidates')) $('candidates').value = s.candidatesPerKeyword;
  if ($('minIntent')) if ($('minIntent')) $('minIntent').value = s.minIntentScore;
  if ($('minSample')) if ($('minSample')) $('minSample').value = 8;
  if ($('seedCount')) if ($('seedCount')) $('seedCount').value = s.fullExploreSeedCount;
  if ($('cooldownDays')) if ($('cooldownDays')) $('cooldownDays').value = s.fullExploreCooldownDays;
  if ($('seasonBoost')) if ($('seasonBoost')) $('seasonBoost').checked = s.fullExploreSeasonBoost !== false;
  if ($('autoRefill')) if ($('autoRefill')) $('autoRefill').checked = s.fullExploreAutoRefill !== false;
  if ($('continuousExplore')) if ($('continuousExplore')) $('continuousExplore').checked = s.continuousExplore !== false;
  setTimingPair('continuousRetryMinMs','continuousRetryMaxMs',s.continuousRetryMinMs ?? (Number(s.continuousRetryMinutes||5)*60000),s.continuousRetryMaxMs ?? (Number(s.continuousRetryMinutes||5)*60000));
  if ($('maxRefills')) if ($('maxRefills')) $('maxRefills').value = s.fullExploreMaxRefills;
  $('humanRestRequestMin').value = s.humanRestRequestMin ?? 10;
  $('humanRestRequestMax').value = s.humanRestRequestMax ?? 15;
  $('humanRestMinMs').value = s.humanRestMinMs ?? 10000;
  $('humanRestMaxMs').value = s.humanRestMaxMs ?? 15000;
  if($('airplaneHoldMs'))$('airplaneHoldMs').value = Math.max(4,Math.min(300,Math.round(Number(s.airplaneHoldMs ?? 20000)/1000)));
  if($('closeCollectorTabOnLongRest'))$('closeCollectorTabOnLongRest').checked = false;
  $('clearBrowsingDataBeforeResume').checked = s.clearBrowsingDataBeforeResume !== false;
  $('keywordTaxonomyEnabled').checked = s.keywordTaxonomyEnabled !== false;
  $('keywordBroadWords').value = s.keywordBroadWords || '';
  $('keywordBroadCombinations').value = s.keywordBroadCombinations || '';
  setTimingPair('serverCacheMinMs','serverCacheMaxMs',s.serverCacheMinMs ?? (Number(s.serverCacheMinutes||10)*60000),s.serverCacheMaxMs ?? (Number(s.serverCacheMinutes||10)*60000));
  setTimingPair('serverHealthCacheMinMs','serverHealthCacheMaxMs',s.serverHealthCacheMinMs ?? (Number(s.serverHealthCacheMinutes||15)*60000),s.serverHealthCacheMaxMs ?? (Number(s.serverHealthCacheMinutes||15)*60000));
  $('serverPageSize').value = s.serverPageSize ?? 1000;
  setTimingPair('serverPatchDebounceMinMs','serverPatchDebounceMaxMs',s.serverPatchDebounceMinMs ?? s.serverPatchDebounceMs ?? 2200,s.serverPatchDebounceMaxMs ?? s.serverPatchDebounceMs ?? 2800);
  $('serverRequestPacingEnabled').checked = s.serverRequestPacingEnabled !== false;
  $('serverRequestDelayMinMs').value = s.serverRequestDelayMinMs ?? 120;
  $('serverRequestDelayMaxMs').value = s.serverRequestDelayMaxMs ?? 350;
  $('periodicMemoryCleanupEnabled').checked = s.periodicMemoryCleanupEnabled === true;
  $('memoryCleanupEveryCollections').value = s.memoryCleanupEveryCollections ?? 20;
  setTimingPair('memoryCleanupIntervalMinMs','memoryCleanupIntervalMaxMs',s.memoryCleanupIntervalMinMs ?? (Number(s.memoryCleanupIntervalMinutes||60)*60000),s.memoryCleanupIntervalMaxMs ?? (Number(s.memoryCleanupIntervalMinutes||60)*60000));
  $('periodicBrowsingCleanupEnabled').checked = s.periodicBrowsingCleanupEnabled === true;
  $('browsingCleanupEveryCollections').value = s.browsingCleanupEveryCollections ?? 50;
  setTimingPair('browsingCleanupIntervalMinMs','browsingCleanupIntervalMaxMs',s.browsingCleanupIntervalMinMs ?? (Number(s.browsingCleanupIntervalMinutes||180)*60000),s.browsingCleanupIntervalMaxMs ?? (Number(s.browsingCleanupIntervalMinutes||180)*60000));
  $('detailConcurrency').value = s.detailConcurrency ?? 1;
  $('manualDetailConcurrency').value = s.manualDetailConcurrency ?? 3;
  $('manualDetailDelayMinMs').value = s.manualDetailDelayMinMs ?? 900;
  $('manualDetailDelayMaxMs').value = s.manualDetailDelayMaxMs ?? 1600;
  $('manualDetailRestMinMs').value = s.manualDetailRestMinMs ?? 4000;
  $('manualDetailRestMaxMs').value = s.manualDetailRestMaxMs ?? 7000;
  $('failFastDetailEnabled').checked = s.failFastDetailEnabled !== false;
  $('initialStateFastParse').checked = s.initialStateFastParse !== false;
  const initialNetworkMode=s.collectionNetworkMode==='window'?'window':'system';
  checkNetworkModeRadio(initialNetworkMode);
  const cachedNetworkAdapters=await loadNetworkAdapterCache();
  if(Array.isArray(cachedNetworkAdapters?.adapters)&&cachedNetworkAdapters.adapters.length){
    const cachedSelected=initialNetworkMode==='window'
      ?(s.collectionNetworkAdapterId||cachedNetworkAdapters.selectedId||'')
      :(s.collectionSystemAdapterId||'');
    renderNetworkAdapters(cachedNetworkAdapters.adapters,cachedSelected,initialNetworkMode);
  }
  const initialSelected=initialNetworkMode==='window'?s.collectionNetworkAdapterId:s.collectionSystemAdapterId;
  if(initialSelected&&$('networkAdapterSelect')&&[...$('networkAdapterSelect').options].some((option)=>option.value===String(initialSelected)&&!option.disabled)){
    const row=networkAdapterSnapshot.find((item)=>String(item?.id||'')===String(initialSelected));
    const safe=initialNetworkMode==='window'?!(row?.isPinnedSystemAdapter===true&&row?.isSystemDefault===true):!adapterIsStrongTether(row);
    if(safe)$('networkAdapterSelect').value=String(initialSelected);
  }

  $('retention').value = s.retentionDays;
  $('rawRetention').value = s.rawRetentionDays;
  $('sp').value = s.smartpageOrigin;
  const migration = await chrome.storage.local.get(SPX.util.SETTINGS_MIGRATION_KEY);
  const recovered = migration?.[SPX.util.SETTINGS_MIGRATION_KEY]?.recovered ? ' · 기존 Supabase 설정 복구됨' : '';
  const supa = s.supabaseUrl && s.serviceKey ? ' · Supabase 설정 저장됨' : ' · Supabase 설정 필요';
  setOptionsCoreHydratedV433(true);
  msg(`설정 준비 완료 · IndexedDB ${SPX.db.DB_NAME} v${SPX.db.DB_VERSION}${supa}${recovered}`, s.supabaseUrl && s.serviceKey ? 'ok' : 'notice');
  scheduleOptionsDeferredHydrationV431();
}

bindThousandsFormatting();


$('categoryGrid')?.addEventListener('change', (event) => {
  if (event.target?.matches?.('[data-cat]')) updateCategorySelectionCount();
});
$('selectAllCategories')?.addEventListener('click', () => {
  document.querySelectorAll('[data-cat]').forEach((el) => { el.checked = true; });
  updateCategorySelectionCount();
});
$('clearCategories')?.addEventListener('click', () => {
  document.querySelectorAll('[data-cat]').forEach((el) => { el.checked = false; });
  updateCategorySelectionCount();
});

$('refreshNetworkAdapters')?.addEventListener('click',()=>refreshNetworkStatus({list:true,userGesture:true}));
$('checkNetworkHost')?.addEventListener('click',()=>refreshNetworkStatus({list:true,userGesture:true}));
$('checkAdbConnection')?.addEventListener('click',()=>refreshAdbConnectionV168({repair:false}).catch((error)=>msg('ADB 상태 확인 실패: '+(error?.message||error),'bad')));
$('repairAdbConnection')?.addEventListener('click',()=>refreshAdbConnectionV168({repair:true}).catch((error)=>msg('ADB 자동 연결/복구 실패: '+(error?.message||error),'bad')));
$('applyNetworkMode')?.addEventListener('click',async()=>{try{await runNetworkUiMutation('적용 중...',()=>applySelectedNetworkMode());msg('수집 네트워크 설정을 적용했습니다.','ok');}catch(error){const detail=conciseNetworkError(error);setNetworkStatus(`네트워크 적용 실패 · ${detail}`,'bad');msg(`수집 네트워크 적용 실패 · ${detail}`,'bad');}});
$('openCoupangNetworkWindow')?.addEventListener('click',async()=>{try{await runNetworkUiMutation('전용창 여는 중...',()=>openCoupangDedicatedWindow(),'openCoupangNetworkWindow');msg('선택 네트워크 전용창을 열었습니다.','ok');}catch(error){const detail=conciseNetworkError(error);setNetworkStatus(`선택 네트워크 전용창 열기 실패 · ${detail}`,'bad');msg(`선택 네트워크 전용창 열기 실패 · ${detail}`,'bad');}});
$('changePublicIpNow')?.addEventListener('click',async()=>{try{await changePublicIpNow();msg('IP 변경과 네트워크 안정화를 시작했습니다. 진행 단계는 이 화면과 사이드바에 표시됩니다.','ok');}catch(error){const btn=$('changePublicIpNow');if(btn)btn.disabled=selectedNetworkMode()!=='window';setNetworkStatus(`IP 변경 시작 실패 · ${error?.message||String(error)}`,'bad');msg('IP 변경 시작 실패: '+(error?.message||error),'bad');}});
$('restoreNetworkMode')?.addEventListener('click',async()=>{try{await runNetworkUiMutation('해제 중...',()=>clearCurrentNetworkSelection());msg('쿠팡 전용 네트워크 선택을 해제했습니다. Windows 기본 인터넷은 변경하지 않았습니다.','ok');}catch(error){const detail=conciseNetworkError(error);setNetworkStatus(`전용 네트워크 해제 실패 · ${detail}`,'bad');msg(`전용 네트워크 해제 실패 · ${detail}`,'bad');}});
getPlatformOS().then(()=>{renderNetworkHostRoute();checkNetworkModeRadio(selectedNetworkMode());}).catch(()=>null);

$('openIntegrationSettingsFile')?.addEventListener('click',()=>openIntegrationSettingsFile().catch((error)=>msg('연동 설정 파일 열기 실패: '+(error?.message||error),'bad')));
$('selectIntegrationSettingsFile')?.addEventListener('click',()=>selectIntegrationSettingsFileDirect().catch((error)=>msg('파일 선택 열기 실패: '+(error?.message||error),'bad')));
$('integrationSettingsFilePicker')?.addEventListener('change',(event)=>{const file=event.target?.files?.[0]||null;if(file)importDirectIntegrationSettingsFile(file).catch(()=>{});});
$('refreshIntegrationSettingsFileStatus')?.addEventListener('click',()=>refreshIntegrationSettingsFileStatus({silent:false}).catch(()=>null));

/* v3.0.20: Service Worker/네트워크 진단과 무관하게 카테고리 UI부터 비동기 선렌더링합니다. */
SPX.util.getSettings().then((quick)=>renderCategories(quick.fullExploreCategories)).catch(()=>renderCategories([]));
ensureOptionsRuntimeAligned().then((ready)=>{if(ready)return initOptions();setOptionsCoreHydratedV433(false,'확장 런타임 준비가 끝나지 않아 저장을 잠갔습니다. 이 설정 화면을 새로고침하세요.');return null;}).catch((error) => {setOptionsCoreHydratedV433(false);msg('설정 초기화 실패 · 저장 잠금 유지: ' + (SPX.db?.describeError?.(error) || error?.message || String(error)), 'bad');});

$('saveWingLogin')?.addEventListener('click',()=>saveWingCredentialLocalV426().catch((error)=>setWingLoginStatusV426('WING 로그인 저장 실패 · '+String(error?.message||error||''),'bad')));
$('testWingLogin')?.addEventListener('click',()=>testWingLoginV426());
$('clearWingLogin')?.addEventListener('click',()=>clearWingCredentialLocalV426().catch((error)=>setWingLoginStatusV426('WING 로그인 정보 삭제 실패 · '+String(error?.message||error||''),'bad')));
$('toggleWingPassword')?.addEventListener('click',()=>{const input=$('coupangWingPassword');if(!input)return;const show=input.type==='password';input.type=show?'text':'password';$('toggleWingPassword').textContent=show?'비밀번호 숨기기':'비밀번호 보기';});

$('save').addEventListener('click', async () => {
  if(!optionsCoreHydratedV433){msg('설정 불러오기가 완료되지 않아 저장하지 않았습니다. 화면을 새로고침한 뒤 ‘설정 준비 완료’를 확인하세요.','bad');return;}
  normalizeNumericInputs();
  let localSettingsSaved=false;
  let backgroundApplyWarning='';
  try {
    const url = $('url').value.trim().replace(/\/+$/, '');
    if (url && !/^https:\/\/[\w-]+\.supabase\.co$/.test(url)) { msg('Supabase URL 형식을 확인하세요.', 'bad'); return; }

    /* 초기 화면을 아주 빠르게 저장해도 빈 categoryGrid를 '미선택'으로 오판하지 않습니다. */
    if (!document.querySelector('[data-cat]')) {
      const quickSettings = await SPX.util.getSettings();
      renderCategories(quickSettings.fullExploreCategories);
    }
    const selectedCats = selectedCategories();
    const savedCategories=(await SPX.util.getSettings()).fullExploreCategories;
    const cats=selectedCats.length?selectedCats:(Array.isArray(savedCategories)&&savedCategories.length?savedCategories:SPX.explore.categoryOptions().map(c=>c.id));
    /* 상세 수집량·일반 요청 지연은 사이드바의 Lite/Pro 수집 설정에서 별도로 저장합니다.
       옵션 화면에서 제거된 입력란을 다시 읽지 않아 null.value 저장 오류를 만들지 않습니다. */
    const humanRestRequestMin = Math.min(200, Math.max(2, +$('humanRestRequestMin').value || 10));
    const humanRestRequestMax = Math.max(humanRestRequestMin, Math.min(300, Math.max(2, +$('humanRestRequestMax').value || 15)));
    const humanRestMinMs = Math.min(600000, Math.max(1000, +$('humanRestMinMs').value || 10000));
    const humanRestMaxMs = Math.max(humanRestMinMs, Math.min(900000, Math.max(1000, +$('humanRestMaxMs').value || 15000)));
    const airplaneHoldMs = Math.min(300000, Math.max(4000, (+$('airplaneHoldMs').value || 20)*1000));
    const [continuousRetryMinMs,continuousRetryMaxMs]=readTimingPair('continuousRetryMinMs','continuousRetryMaxMs',270000,330000,{min:1000,max:86400000});
    const continuousRetryMinutes=averageMinutesFromMs(continuousRetryMinMs,continuousRetryMaxMs);
    const [serverCacheMinMs,serverCacheMaxMs]=readTimingPair('serverCacheMinMs','serverCacheMaxMs',540000,660000,{min:1000,max:86400000});
    const [serverHealthCacheMinMs,serverHealthCacheMaxMs]=readTimingPair('serverHealthCacheMinMs','serverHealthCacheMaxMs',810000,990000,{min:1000,max:86400000});
    const serverCacheMinutes=averageMinutesFromMs(serverCacheMinMs,serverCacheMaxMs);
    const serverHealthCacheMinutes=averageMinutesFromMs(serverHealthCacheMinMs,serverHealthCacheMaxMs);
    const serverPageSize = Math.min(1000, Math.max(50, +$('serverPageSize').value || 1000));
    const [serverPatchDebounceMinMs,serverPatchDebounceMaxMs]=readTimingPair('serverPatchDebounceMinMs','serverPatchDebounceMaxMs',2200,2800,{min:500,max:10000});
    const serverPatchDebounceMs=Math.round((serverPatchDebounceMinMs+serverPatchDebounceMaxMs)/2);
    const serverRequestDelayMinMs = Math.min(5000, Math.max(0, Number.isFinite(+$('serverRequestDelayMinMs').value) ? +$('serverRequestDelayMinMs').value : 120));
    const serverRequestDelayMaxMs = Math.max(serverRequestDelayMinMs, Math.min(10000, Number.isFinite(+$('serverRequestDelayMaxMs').value) ? +$('serverRequestDelayMaxMs').value : 350));
    const memoryCleanupEveryCollections = Math.min(10000, Math.max(0, Number.isFinite(+$('memoryCleanupEveryCollections').value) ? +$('memoryCleanupEveryCollections').value : 20));
    const [memoryCleanupIntervalMinMs,memoryCleanupIntervalMaxMs]=readTimingPair('memoryCleanupIntervalMinMs','memoryCleanupIntervalMaxMs',3300000,3900000,{min:0,max:86400000});
    const memoryCleanupIntervalMinutes=averageMinutesFromMs(memoryCleanupIntervalMinMs,memoryCleanupIntervalMaxMs);
    const browsingCleanupEveryCollections = Math.min(10000, Math.max(0, Number.isFinite(+$('browsingCleanupEveryCollections').value) ? +$('browsingCleanupEveryCollections').value : 50));
    const [browsingCleanupIntervalMinMs,browsingCleanupIntervalMaxMs]=readTimingPair('browsingCleanupIntervalMinMs','browsingCleanupIntervalMaxMs',9900000,11700000,{min:0,max:86400000});
    const browsingCleanupIntervalMinutes=averageMinutesFromMs(browsingCleanupIntervalMinMs,browsingCleanupIntervalMaxMs);
    const detailConcurrency = Math.min(2, Math.max(1, +$('detailConcurrency').value || 1));
    const manualDetailConcurrency = Math.min(5, Math.max(1, +$('manualDetailConcurrency').value || 3));
    const manualDetailDelayMinMs = Math.min(10000, Math.max(200, +$('manualDetailDelayMinMs').value || 900));
    const manualDetailDelayMaxMs = Math.max(manualDetailDelayMinMs, Math.min(20000, +$('manualDetailDelayMaxMs').value || 1600));
    const manualDetailRestMinMs = Math.min(120000, Math.max(1000, +$('manualDetailRestMinMs').value || 4000));
    const manualDetailRestMaxMs = Math.max(manualDetailRestMinMs, Math.min(180000, +$('manualDetailRestMaxMs').value || 7000));
    await SPX.util.setSettings({
      supabaseUrl: url, serviceKey: $('key').value.trim(),
      geminiApiKey: String($('geminiApiKey')?.value || '').trim(),
      geminiModel:String($('geminiModel')?.value||'gemini-3.7-flash'),
      openaiApiKey: String($('openaiApiKey')?.value || '').trim(),
      openaiModel:String($('openaiModel')?.value||'gpt-5.6-terra'),
      humanRestRequestMin,
      humanRestRequestMax,
      humanRestMinMs,
      humanRestMaxMs,
      airplaneHoldMs,
      closeCollectorTabOnLongRest: false,
      clearBrowsingDataBeforeResume: $('clearBrowsingDataBeforeResume').checked,
      keywordTaxonomyEnabled: $('keywordTaxonomyEnabled').checked,
      keywordBroadWords: $('keywordBroadWords').value.trim(),
      keywordBroadCombinations: $('keywordBroadCombinations').value.trim(),
      serverCacheMinMs, serverCacheMaxMs, serverHealthCacheMinMs, serverHealthCacheMaxMs, serverCacheMinutes, serverHealthCacheMinutes, serverPageSize, serverPatchDebounceMinMs, serverPatchDebounceMaxMs, serverPatchDebounceMs,
      serverRequestPacingEnabled: $('serverRequestPacingEnabled').checked, serverRequestDelayMinMs, serverRequestDelayMaxMs,
      periodicMemoryCleanupEnabled:$('periodicMemoryCleanupEnabled').checked, memoryCleanupEveryCollections, memoryCleanupIntervalMinMs, memoryCleanupIntervalMaxMs, memoryCleanupIntervalMinutes, periodicBrowsingCleanupEnabled:$('periodicBrowsingCleanupEnabled').checked, browsingCleanupEveryCollections, browsingCleanupIntervalMinMs, browsingCleanupIntervalMaxMs, browsingCleanupIntervalMinutes, detailConcurrency, manualDetailConcurrency, manualDetailDelayMinMs, manualDetailDelayMaxMs, manualDetailRestMinMs, manualDetailRestMaxMs,
      failFastDetailEnabled: $('failFastDetailEnabled').checked,
      initialStateFastParse: $('initialStateFastParse').checked,

      fullExploreCategories: cats,
      retentionDays: Math.min(730, Math.max(30, +$('retention').value || 90)),
      rawRetentionDays: Math.min(365, Math.max(7, +$('rawRetention').value || 30)),
      smartpageOrigin: $('sp').value.trim().replace(/\/+$/, ''),
    });
    localSettingsSaved=true;
    /* 설정값 저장 성공 여부와 서비스워커 부가 적용을 분리합니다. MV3 서비스워커가 저장 직후
       재시작되어 응답 채널이 닫혀도 이미 저장된 설정을 실패로 되돌리지 않습니다. */
    /* 서비스워커에 별도 메시지를 보내지 않습니다. chrome.storage.onChanged 수신기가
       저장된 설정을 자동 적용하므로 MV3 응답 채널 종료 오류가 발생할 경로 자체를 제거합니다. */
    backgroundApplyWarning+=' · 백그라운드 자동 적용';
    const verified = await SPX.util.getSettings();
    const rawStored = await chrome.storage.local.get(SPX.util.SETTINGS_KEY);
    const stored = rawStored?.[SPX.util.SETTINGS_KEY] || {};
    const requested = {
      airplaneHoldMs,
      serverCacheMinMs, serverCacheMaxMs, serverHealthCacheMinMs, serverHealthCacheMaxMs, serverCacheMinutes, serverHealthCacheMinutes, serverPageSize, serverPatchDebounceMinMs, serverPatchDebounceMaxMs, serverPatchDebounceMs,
      serverRequestPacingEnabled: $('serverRequestPacingEnabled').checked, serverRequestDelayMinMs, serverRequestDelayMaxMs,
      periodicMemoryCleanupEnabled:$('periodicMemoryCleanupEnabled').checked, memoryCleanupEveryCollections, memoryCleanupIntervalMinMs, memoryCleanupIntervalMaxMs, memoryCleanupIntervalMinutes, periodicBrowsingCleanupEnabled:$('periodicBrowsingCleanupEnabled').checked, browsingCleanupEveryCollections, browsingCleanupIntervalMinMs, browsingCleanupIntervalMaxMs, browsingCleanupIntervalMinutes, detailConcurrency, manualDetailConcurrency, manualDetailDelayMinMs, manualDetailDelayMaxMs, manualDetailRestMinMs, manualDetailRestMaxMs,
      failFastDetailEnabled:$('failFastDetailEnabled').checked,
      initialStateFastParse:$('initialStateFastParse').checked,

    };
    if (url && (!verified.supabaseUrl || !verified.serviceKey)) throw new Error('Supabase 설정 저장 검증에 실패했습니다.');
    const mismatches = Object.entries(requested).filter(([key,value]) => stored[key] !== value);
    if (mismatches.length) throw new Error(`수집 설정 저장 검증 실패: ${mismatches.map(([key])=>key).join(', ')}`);
    msg(`저장·검증 완료 · 쿠팡 차단 복구는 ♻+🧹 정리 후 비행기모드 ${Math.round(airplaneHoldMs/1000)}초 설정 적용 · 새 IP 확인 → 현재 탭 새로고침${verified.supabaseUrl && verified.serviceKey ? ' · Supabase 설정 확인' : ''}${backgroundApplyWarning}`, 'ok');
  } catch (error) {
    if(localSettingsSaved&&isMissingRuntimeReceiverError(error)){
      msg('설정은 정상 저장되었습니다. 확장 백그라운드가 잠시 재시작 중이라 부가 설정은 다음 실행 때 자동 적용됩니다. 이 설정 화면만 한 번 새로고침하세요.', 'ok');
      return;
    }
    msg('설정 저장 실패: ' + (error?.message || error), 'bad');
  }
});

const PERFORMANCE_DEFAULTS = Object.freeze({
  serverCacheMinMs:540000, serverCacheMaxMs:660000, serverHealthCacheMinMs:810000, serverHealthCacheMaxMs:990000, serverPageSize:1000, serverPatchDebounceMinMs:2200, serverPatchDebounceMaxMs:2800, serverPatchDebounceMs:2500,
  serverRequestPacingEnabled:true, serverRequestDelayMinMs:120, serverRequestDelayMaxMs:350,
  detailConcurrency:1,
  manualDetailConcurrency:3, manualDetailDelayMinMs:900, manualDetailDelayMaxMs:1600,
  manualDetailRestMinMs:4000, manualDetailRestMaxMs:7000, failFastDetailEnabled:true, initialStateFastParse:true,
});
$('resetPerformanceSettings')?.addEventListener('click',(event)=>{
  event.preventDefault();event.stopPropagation();
  for(const [id,value] of Object.entries(PERFORMANCE_DEFAULTS)){
    const el=$(id);if(!el)continue;if(el.type==='checkbox')el.checked=Boolean(value);else el.value=String(value);
    if(el.type==='number')updateNumberCommaPreview(el);
  }
  msg('서버·화면 성능 최적화를 기본값으로 되돌렸습니다. 저장 버튼을 누르면 적용됩니다.','notice');
});

function aiConnectionPayload(provider){
  const selected=provider==='openai'?'openai':'gemini';
  return {
    provider:selected,
    apiKey:selected==='openai'?String($('openaiApiKey')?.value||'').trim():String($('geminiApiKey')?.value||'').trim(),
    model:selected==='openai'?String($('openaiModel')?.value||'gpt-5.6-terra'):String($('geminiModel')?.value||'gemini-3.7-flash'),
  };
}
async function testAiProviderConnection(provider){
  await loadIntegrationSettingsFile({silent:true,backup:false}).catch(()=>null);
  const selected=provider==='openai'?'openai':'gemini',status=$('aiMarketConnectionStatus'),payload=aiConnectionPayload(selected);
  if(!payload.apiKey){if(status){status.textContent=`${selected==='openai'?'GPT':'Gemini'} API Key를 입력하세요.`;status.className='hint bad';}return;}
  if(status){status.textContent=`${selected==='openai'?'GPT':'Gemini'} 연결 테스트 중...`;status.className='hint notice';}
  try{
    await SPX.util.setSettings(selected==='openai'
      ?{openaiApiKey:payload.apiKey,openaiModel:payload.model}
      :{geminiApiKey:payload.apiKey,geminiModel:payload.model});
    const response=await SPX.util.sendMessage({type:'SPX_AI_MARKET_TEST',...payload});
    if(!response?.ok)throw new Error(response?.error||'AI 연결 테스트 실패');
    if(status){status.textContent=`${selected==='openai'?'GPT':'Gemini'} 연결 정상 · ${response.data?.model||payload.model}`;status.className='hint ok';}
  }catch(error){if(status){status.textContent=`${selected==='openai'?'GPT':'Gemini'} 연결 실패 · ${error?.message||String(error)}`;status.className='hint bad';}}
}
$('testGeminiConnection')?.addEventListener('click',()=>testAiProviderConnection('gemini'));
$('testOpenAiConnection')?.addEventListener('click',()=>testAiProviderConnection('openai'));
$('clearAiMarketCredentials')?.addEventListener('click',async()=>{
  if(!confirm('Gemini·GPT API 키를 모두 지울까요?'))return;
  if($('geminiApiKey'))$('geminiApiKey').value='';if($('openaiApiKey'))$('openaiApiKey').value='';
  await SPX.util.clearSensitiveSettings(['geminiApiKey','geminiModel','openaiApiKey','openaiModel']);
  const status=$('aiMarketConnectionStatus');if(status){status.textContent='AI 인증정보를 지웠습니다.';status.className='hint notice';}
});

$('memoryCleanupNow')?.addEventListener('click',async()=>{const btn=$('memoryCleanupNow');if(btn)btn.disabled=true;$('memoryCleanupStatus').textContent='정리 중...';try{const r=await SPX.util.sendMessage({type:'SPX_MEMORY_CLEANUP_NOW',source:'options'});if(!r?.ok)throw new Error(r?.error||'메모리 정리 실패');$('memoryCleanupStatus').textContent=r?.data?.message||'정리 완료';}catch(error){$('memoryCleanupStatus').textContent='정리 실패 · '+(error?.message||String(error));}finally{if(btn)btn.disabled=false;}});
$('cacheCookieCleanupNow')?.addEventListener('click',async()=>{if(!confirm('쿠팡 쇼핑(coupang.com·www.coupang.com)의 캐시와 사이트 저장소(CacheStorage·IndexedDB·LocalStorage·ServiceWorker 등)를 정리합니다. 쿠팡/WING 로그인 쿠키와 wing.coupang.com 저장소는 삭제하지 않습니다. 계속할까요?'))return;const btn=$('cacheCookieCleanupNow');if(btn)btn.disabled=true;$('cacheCookieCleanupStatus').textContent='WING 로그인은 유지하고 쿠팡 쇼핑 캐시를 정리 중...';try{const r=await SPX.util.sendMessage({type:'SPX_CLEAR_BROWSING_DATA_PRESERVE_LOGIN',source:'options',removeCoupangSiteData:true});if(!r?.ok)throw new Error(r?.error||'쿠팡 쇼핑 캐시 정리 실패');$('cacheCookieCleanupStatus').textContent=r?.message||'WING 로그인 유지 · 쿠팡 쇼핑 캐시 정리 완료';}catch(error){$('cacheCookieCleanupStatus').textContent='정리 실패 · '+(error?.message||String(error));}finally{if(btn)btn.disabled=false;}});

$('serverRestore').addEventListener('click', async () => {
  msg('Supabase 서버 대기열과 진행 상태를 복원 중...');
  const r = await SPX.util.sendMessage({ type: 'SPX_SERVER_RESTORE', force: true, reason: '옵션 화면 수동 복원' });
  if (!r?.ok) { msg('서버 작업 복원 실패: ' + (r?.error || '응답 없음'), 'bad'); return; }
  const notice = r.restoreNotice || r.data?.notice;
  $('multiPcState').textContent = notice?.message || '서버 작업 복원을 완료했습니다.';
  msg('서버 작업 복원을 완료했습니다.', 'ok');
});

$('serverBackup').addEventListener('click', async () => {
  msg('현재 자동수집 상태를 서버에 저장 중...');
  const r = await SPX.util.sendMessage({ type: 'SPX_SERVER_SYNC_NOW' });
  if (!r?.ok) { msg('서버 상태 저장 실패: ' + (r?.error || '응답 없음'), 'bad'); return; }
  $('multiPcState').textContent = '현재 상태 서버 저장 완료 · ' + formatKstDateTime();
  msg('현재 상태를 서버에 저장했습니다.', 'ok');
});

$('test').addEventListener('click', async () => {
  await loadIntegrationSettingsFile({silent:true,backup:false}).catch(()=>null);
  $('schemaHelp').hidden = true;
  msg('프로젝트·키·DB 스키마를 확인 중...');
  await SPX.util.setSettings({ supabaseUrl: $('url').value.trim().replace(/\/+$/, ''), serviceKey: $('key').value.trim() });
  const r = await SPX.util.sendMessage({ type: 'SPX_TEST' });
  if (!r?.ok) { msg((r?.needsOptions ? '설정 저장 필요: ' : '연결 실패: ') + (r?.error || '응답 없음'), r?.needsOptions ? 'notice' : 'bad'); return; }
  if (!r?.ready) { $('schemaHelp').hidden = false; msg(r.message || 'DB 스키마 설치가 필요합니다.', 'notice'); return; }
  msg('연결 정상: 프로젝트 URL, service_role 키, DB 테이블과 업로드 함수를 모두 확인했습니다.', 'ok');
});

$('copySchema').addEventListener('click', async () => {
  try {
    const r = await fetch(SPX.util.extensionUrl('supabase_schema.sql'));
    const sql = await r.text();
    await navigator.clipboard.writeText(sql);
    msg('DB 스키마 SQL을 복사했습니다. Supabase SQL Editor에 붙여넣고 Run을 누르세요.', 'ok');
  } catch (error) { msg('SQL 복사 실패: ' + (error?.message || error), 'bad'); }
});
$('openSqlEditor').addEventListener('click', () => {
  const raw = $('url').value.trim();
  let target = 'https://supabase.com/dashboard/projects';
  try { const ref = new URL(raw).hostname.split('.')[0]; if (ref) target = `https://supabase.com/dashboard/project/${ref}/sql/new`; } catch (_) {}
  chrome.tabs.create({ url: target });
});
$('purge').addEventListener('click', async () => {
  const s = await SPX.util.getSettings();
  const n = await SPX.db.purge(s.retentionDays, s.rawRetentionDays);
  msg(`${n}건 정리했습니다.`, 'ok');
});
$('clear').addEventListener('click', async () => {
  if (!confirm('상품 원본·소싱 분석·키워드 대기열을 모두 삭제합니다. 계속할까요?')) return;
  await SPX.db.clearAll();
  msg('로컬 DB를 비웠습니다.', 'ok');
});

$('clearServer').addEventListener('click', async () => {
  if (!confirm('Supabase 서버의 keyword_metrics 수집 데이터를 모두 삭제합니다. 로컬 DB는 유지됩니다. 계속할까요?')) return;
  const typed = prompt('실수 방지를 위해 서버삭제를 입력하세요.');
  if (typed !== '서버삭제') {
    msg('서버 데이터 삭제를 취소했습니다.', 'notice');
    return;
  }
  const button = $('clearServer');
  button.disabled = true;
  try {
    msg('자동수집을 중단하고 서버 데이터를 삭제 중입니다...');
    const r = await SPX.util.sendMessage({ type: 'SPX_SERVER_DELETE_ALL' });
    if (!r?.ok) {
      msg('서버 데이터 삭제 실패: ' + (r?.error || '응답 없음'), 'bad');
      return;
    }
    const deleted = Number.isFinite(Number(r.data?.deleted)) ? `${fmt(r.data.deleted)}건` : '전체';
    const dbWarning = r.stopped?.dbWarning ? ` · 로컬 대기열 정리 경고: ${r.stopped.dbWarning}` : '';
    msg(`서버 keyword_metrics ${deleted}을 삭제했습니다. 로컬 DB는 유지됩니다.${dbWarning}`, r.stopped?.dbWarning ? 'notice' : 'ok');
  } catch (error) {
    msg('서버 데이터 삭제 실패: ' + (error?.message || error), 'bad');
  } finally {
    button.disabled = false;
  }
});

$('backupSupabaseCredentials')?.addEventListener('click',()=>runSecureSettingsAction('supabase','backup','backupSupabaseCredentials'));
$('restoreSupabaseCredentials')?.addEventListener('click',()=>runSecureSettingsAction('supabase','restore','restoreSupabaseCredentials'));
$('clearSupabaseCredentials')?.addEventListener('click',async()=>{
  if(!confirm('이 PC의 Supabase URL과 Service Role Key를 명시적으로 지울까요? Windows 보호 백업은 별도로 유지됩니다.'))return;
  $('url').value='';$('key').value='';
  await SPX.util.clearSensitiveSettings(['supabaseUrl','serviceKey']);
  msg('현재 프로필의 Supabase 설정을 지웠습니다. 보호 백업은 유지됩니다.','ok');
  await refreshProtectedSettingsStatus();
});

/* [v2.0.4] 각 입력란의 되돌리기(↺) 아이콘 - 클릭하면 그 필드만 기본값으로 되돌린다(저장은 아직 안 함,
   저장·검증 버튼을 눌러야 실제 반영됨). */
document.querySelectorAll('.field-reset').forEach((btn) => {
  btn.addEventListener('click', () => {
    const targetId = btn.dataset.resetFor;
    const input = $(targetId);
    if (!input) return;
    input.value = input.dataset.default ?? input.value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
  });
});

/* SPX_V433_OPTIONS_HYDRATION_SAVE_GUARD_FIX1 */
