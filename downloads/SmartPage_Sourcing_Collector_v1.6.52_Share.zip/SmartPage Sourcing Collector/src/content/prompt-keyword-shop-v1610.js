/* v1.6.10: observes only REAL seller/brand shop full-product pages opened by the user/collector.
   Never opens new tabs, never changes network, block detection, or recovery. */
(function(){
  const p=String(location.pathname||'');
  if(!/(?:brandshops?|vendors?|sellers?|stores?)/i.test(p))return;
  const SPX=globalThis.SPX||{},K=SPX.promptKeywords;
  if(!K||globalThis.__SPX_PROMPT_SHOP_V1610__)return;
  globalThis.__SPX_PROMPT_SHOP_V1610__=true;
  const sort=new URL(location.href).searchParams.get('sorter')||'';
  if(!['saleCountDesc','latestAsc','scoreDesc'].includes(sort))return;
  // Only source rows from the actually rendered 'all products' section.
  function parse(){
    if(!/전체\s*상품|전체\s*제품/i.test(document.body?.innerText||''))return [];
    const rows=[];const seen=new Set();
    for(const card of document.querySelectorAll('li.search-product, li[class*="search-product"], [data-product-id], [class*="ProductCard"]')){
      const title=card.querySelector('.name,[class*="product-name"],[class*="ProductName"],[data-testid*="name"]');
      const name=String(title?.textContent||title?.getAttribute('title')||'').replace(/\s+/g,' ').trim();
      if(name.length<5||name.length>220||seen.has(name))continue;seen.add(name);
      const price=Number(String(card.querySelector('.price-value,[class*="price-value"],[class*="priceValue"]')?.textContent||'').replace(/[^\d]/g,''))||null;
      const rc=String(card.querySelector('.rating-total-count,[class*="rating-total-count"],[class*="reviewCount"]')?.textContent||'').replace(/[^\d]/g,'');
      const reviews=rc?Number(rc):null;
      const badge=String(card.textContent||'').slice(-250);
      rows.push({name,price,reviews,rank:rows.length+1,isAd:/광고|Sponsored/i.test(String(card.querySelector('[class*="ad-badge"]')?.textContent||'')),isSellerRocket:/판매자로켓|로켓그로스/.test(badge),deliveryType:/판매자로켓|로켓그로스/.test(badge)?'로켓그로스':(/로켓배송/.test(badge)?'로켓배송':'일반배송')});
      if(rows.length>=60)break;
    }
    return rows;
  }
  async function run(){
    const settings=(await chrome.storage.local.get(K.SETTINGS_KEY))[K.SETTINGS_KEY]||{};
    if(settings.keyword1!==true)return;
    const rows=parse();if(!rows.length)return;
    const response=await chrome.runtime.sendMessage({type:'SPX_PROMPT_KEYWORDS_REGISTER_V1610',mode:'shop',sort,products:rows,keyword:'seller-shop-observed'});
    if(response?.ok===true)console.info('[SPX 키워드1] 관찰된 브랜드샵 상품',rows.length,'개 · 원본 후보',response.eligible||0,'개 · 로컬 발견 신규',response.local?.added||0,'개 · 서버 발견 신규',response.server?.added||0,'개',response.server?.error||'');
  }
  if(document.readyState==='complete')setTimeout(()=>run().catch(()=>{}),1200);
  else window.addEventListener('load',()=>setTimeout(()=>run().catch(()=>{}),1200),{once:true});
})();
