/* coupang-parser.js — 쿠팡 검색결과 DOM 파서
 *
 * 쿠팡은 클래스명을 자주 바꾸고 일부는 해시로 난독화합니다.
 * 그래서 한 가지 셀렉터에 의존하지 않고 3중 전략을 씁니다.
 *
 *   전략 A (legacy) : li.search-product  — 오래된 마크업
 *   전략 B (modern) : li[class*="ProductUnit"] — 최근 마크업
 *   전략 C (anchor) : /vp/products/{id} 링크에서 역추적 — 마크업이 또 바뀌어도 살아남음
 *
 * C가 최후의 보루입니다. 상품 링크 형식은 URL 구조라 클래스명보다 훨씬 안 바뀝니다.
 */
(function () {
  const SPX = (globalThis.SPX = globalThis.SPX || {});

  SPX.isPromotionalUiText = (value) => !!SPX.discovery?.isBlockedKeyword?.(value);
  SPX.filterSearchUiTerms = (values) => SPX.discovery?.filterKeywordTerms?.(values) || (values || []);
  const { parseNum } = SPX.util;

  const PID_RE = /\/vp\/products\/(\d+)/;

  const cleanProductName = (value) => SPX.util?.cleanCatalogProductName?.(value) || String(value || '').replace(/\s+/g, ' ').trim().slice(0, 300);

  /* v4.0.0: 효자상품을 향후 ChatGPT 시각분석·1688/타오바오/도매 소싱에 재사용할 수 있도록
     검색/상세 DOM에서 대표이미지 URL만 가볍게 보존합니다. 이미지 바이너리는 저장하지 않습니다. */
  function normalizeProductImageUrl(value, base = location?.href || 'https://www.coupang.com/') {
    let raw=String(value||'').trim();
    if(!raw||/^data:/i.test(raw)||/^blob:/i.test(raw))return null;
    if(raw.includes(','))raw=raw.split(',')[0].trim().split(/\s+/)[0];
    if(raw.startsWith('//'))raw=`https:${raw}`;
    try{raw=new URL(raw,base).href;}catch(_){return null;}
    if(!/^https?:/i.test(raw))return null;
    if(/(?:badge|icon|logo|sprite|rocket|ad[-_]?badge|loading|placeholder|transparent|blank)\.(?:png|gif|svg|webp)(?:\?|$)/i.test(raw))return null;
    return raw.slice(0,2000);
  }
  function srcsetImageCandidates(value){
    return String(value||'').split(',').map((part)=>String(part||'').trim().split(/\s+/)[0]).filter(Boolean);
  }
  function imageFromNode(img, base){
    if(!img)return null;
    const direct=[img.currentSrc,img.getAttribute?.('src'),img.getAttribute?.('data-src'),img.getAttribute?.('data-lazy-src'),img.getAttribute?.('data-original'),img.getAttribute?.('data-img-src'),img.getAttribute?.('data-image-src'),img.getAttribute?.('data-image-url'),img.getAttribute?.('data-thumbnail-url'),img.getAttribute?.('data-thumb')];
    for(const value of direct){const url=normalizeProductImageUrl(value,base);if(url)return url;}
    const srcsets=[img.getAttribute?.('srcset'),img.getAttribute?.('data-srcset')];
    for(const srcset of srcsets){for(const value of srcsetImageCandidates(srcset).reverse()){const url=normalizeProductImageUrl(value,base);if(url)return url;}}
    for(const attr of [...(img.attributes||[])]){
      if(!/(?:src|image|img|thumb|lazy|original)/i.test(String(attr?.name||'')))continue;
      const values=/srcset/i.test(String(attr?.name||''))?srcsetImageCandidates(attr?.value):[attr?.value];
      for(const value of values){const url=normalizeProductImageUrl(value,base);if(url)return url;}
    }
    return null;
  }
  function imageFromJsonProduct(value, base, depth=0, seen=new WeakSet(), budget={count:0}){
    if(value==null||depth>4||budget.count++>160)return null;
    if(typeof value==='string')return normalizeProductImageUrl(value,base);
    if(typeof value!=='object')return null;
    if(seen.has(value))return null;seen.add(value);
    const preferred=['imageUrl','image_url','productImageUrl','product_image_url','productImage','thumbnailUrl','thumbnail_url','thumbnail','image','imagePath','image_path','vendorItemImage','representativeImage','mainImage','squareImage'];
    for(const key of preferred){if(!Object.prototype.hasOwnProperty.call(value,key))continue;const found=imageFromJsonProduct(value[key],base,depth+1,seen,budget);if(found)return found;}
    for(const [key,child] of Object.entries(value)){if(!/(?:image|img|thumb|photo|picture)/i.test(key))continue;const found=imageFromJsonProduct(child,base,depth+1,seen,budget);if(found)return found;}
    /* 현재 쿠팡 JSON은 이미지가 media/assets/product/data 같은 중간 객체 아래로 이동하는 경우가 있어
       컨테이너 객체만 제한적으로 한 단계 더 따라갑니다. 문자열 일반 필드는 훑지 않아 상품 URL 오탐을 막습니다. */
    for(const [key,child] of Object.entries(value)){
      if(!child||typeof child!=='object'||!/(?:media|asset|gallery|resource|product|item|content|data|detail|main)/i.test(key))continue;
      const found=imageFromJsonProduct(child,base,depth+1,seen,budget);if(found)return found;
    }
    return null;
  }
  function imageFromCard(card, anchor){
    const base=anchor?.href||location?.href;
    const nodes=[anchor?.querySelector?.('img'),card?.querySelector?.('img[class*="image" i]'),card?.querySelector?.('img'),...(card?.querySelectorAll?.('picture img, picture source, source[srcset], img')||[])].filter(Boolean);
    for(const node of nodes){const url=imageFromNode(node,base);if(url)return url;}
    const styleNodes=[anchor,card,...(card?.querySelectorAll?.('[style*="background" i]')||[])].filter(Boolean);
    for(const node of styleNodes){
      const style=String(node.getAttribute?.('style')||'');
      for(const match of style.matchAll(/url\(["']?([^"')]+)["']?\)/gi)){const url=normalizeProductImageUrl(match?.[1],base);if(url)return url;}
    }
    const html=String(card?.outerHTML||anchor?.outerHTML||'').replace(/\u002F/gi,'/').replace(/\\\//g,'/');
    const attrMatch=html.match(/(?:imageUrl|image_url|productImageUrl|thumbnailUrl|thumbnail_url|data-image-url|data-image-src|data-src|src)\s*[=:]\s*["']([^"']+)["']/i);
    const attrUrl=normalizeProductImageUrl(attrMatch?.[1],base);if(attrUrl)return attrUrl;
    const cdnMatch=html.match(/https?:\/\/[^"'<>\s]+\.(?:jpg|jpeg|png|webp)(?:\?[^"'<>\s]*)?/i);
    return normalizeProductImageUrl(cdnMatch?.[0],base);
  }
  function detailMainImageUrl(doc, html, url){
    const meta=doc?.querySelector?.('meta[property="og:image"],meta[name="twitter:image"],meta[itemprop="image"]');
    const metaUrl=normalizeProductImageUrl(meta?.getAttribute?.('content'),url);if(metaUrl)return metaUrl;
    const selectors=['[class*="prod-image" i] img','[class*="product-image" i] img','[class*="productImage" i] img','img[itemprop="image"]','img[class*="main" i]'];
    for(const sel of selectors){const found=imageFromNode(doc?.querySelector?.(sel),url);if(found)return found;}
    const raw=String(html||'');
    const m=raw.match(/["'](?:imageUrl|image_url|productImage|thumbnailUrl|thumbnail)["']\s*:\s*["']([^"']+)["']/i);return normalizeProductImageUrl(m?.[1],url);
  }

  /* 판매가격과 같은 숫자 형식으로 노출되는 적립금·캐시·포인트를 가격으로 오인하지 않습니다. */
  const REWARD_MONEY_RE = /적립|캐시|포인트|쿠페이머니|쿠팡머니|리워드|reward|cash[\s_-]*back|cashback|point|benefit|saving|earn(?:ed|ing)?|accumulation/i;
  const stripRewardMoneyText = (value) => String(value ?? '')
    .replace(/(?:최대\s*)?[\d,]+\s*원[^0-9]{0,40}(?:적립|캐시|포인트|쿠페이머니|쿠팡머니|리워드|reward|cash[\s_-]*back|cashback|point)/gi, ' ')
    .replace(/(?:적립|캐시|포인트|쿠페이머니|쿠팡머니|리워드|reward|cash[\s_-]*back|cashback|point)[^0-9]{0,40}(?:최대\s*)?[\d,]+\s*원/gi, ' ');
  function directNodeText(node) {
    return [...(node?.childNodes || [])]
      .filter((child) => child?.nodeType === Node.TEXT_NODE)
      .map((child) => String(child.textContent || '').replace(/\s+/g, ' ').trim())
      .filter(Boolean).join(' ');
  }
  function moneyNodeMetaEvidence(node) {
    const parts=[]; let cursor=node;
    for(let depth=0;cursor&&depth<3;depth+=1,cursor=cursor.parentElement){
      parts.push(cursor.id||'', typeof cursor.className==='string'?cursor.className:'', cursor.getAttribute?.('data-testid')||'', cursor.getAttribute?.('aria-label')||'', cursor.getAttribute?.('title')||'');
    }
    return parts.join(' ');
  }
  function isRewardPriceNode(node){
    if(!node)return false;
    if(REWARD_MONEY_RE.test(moneyNodeMetaEvidence(node)))return true;
    const own=directNodeText(node) || (!(node.children?.length)?String(node.textContent||'').replace(/\s+/g,' ').trim():'');
    if(!REWARD_MONEY_RE.test(own))return false;
    /* 한 노드에 9,900원과 495원 적립이 같이 있으면 노드 전체를 버리지 않고 적립액만 제거합니다. */
    return !/([0-9][0-9,]{1,})\s*원/.test(stripRewardMoneyText(own));
  }

  function txt(el, sel) {
    const n = el.querySelector(sel);
    return n ? n.textContent.trim() : null;
  }

  /** 카드 가격 우선순위: 와우 회원가 → 실제 할인가/쿠폰가 → 일반 판매가.
   * 취소선·정가·할인율 영역은 제외하고 같은 우선순위 안에서는 가장 낮은 유효 가격을 선택합니다. */
  function parsePrice(value) {
    if (typeof value === 'number') return Number.isFinite(value) && value >= 10 && value <= 100000000 ? value : null;
    const rawText=String(value??'').trim();
    const text=stripRewardMoneyText(rawText).trim();
    /* 할인율·수량·리뷰·적립금 숫자를 가격으로 오인하지 않도록 문자열에서는 ‘원’이 붙은 금액을 우선합니다.
       JSON/메타처럼 값 자체가 숫자만 있는 경우에만 단독 숫자도 허용합니다. */
    const wonValues=[...text.matchAll(/([0-9][0-9,]{1,})\s*원/g)]
      .map((match)=>Number(String(match[1]).replace(/,/g,'')))
      .filter((number)=>Number.isFinite(number)&&number>=10&&number<=100000000);
    if(wonValues.length)return wonValues[0];
    if(/^\s*[0-9][0-9,]*(?:\.\d+)?\s*$/.test(text)){
      const number=Number(text.replace(/,/g,''));
      return Number.isFinite(number)&&number>=10&&number<=100000000?number:null;
    }
    return null;
  }
  function labeledPriceFromText(value,labels=[]){
    const text=String(value||'').replace(/\s+/g,' '),values=[];
    for(const label of labels){
      const re=new RegExp(`(?:${label})\\s*[:：]?\\s*([\\d,]{2,})\\s*원`,'ig');
      for(const match of text.matchAll(re)){const parsed=parsePrice(`${match[1]}원`);if(parsed!==null)values.push(parsed);}
    }
    return values.length?Math.min(...values):null;
  }

  function isOriginalPriceNode(node){
    if(!node)return false;
    if(node.closest?.('del,s,strike,[class*="original" i],[class*="base-price" i],[class*="list-price" i],[class*="retail-price" i],[class*="discount-rate" i]'))return true;
    const style=String(node.getAttribute?.('style')||'');
    return /line-through/i.test(style);
  }
  function lowestPriceFromNodes(root,selectors){
    /* 셀렉터 배열은 정확도 순서입니다. 모든 셀렉터 값을 한데 섞어 최솟값을 고르면
       .price-value로 표시된 ‘최대 495원 적립’을 실제 9,900원보다 먼저 고르는 오류가 생깁니다. */
    for(const selector of selectors){
      const values=[];
      for(const node of root?.querySelectorAll?.(selector)||[]){
        if(isOriginalPriceNode(node)||isRewardPriceNode(node))continue;
        const value=parsePrice(node.getAttribute?.('content')||node.textContent);
        if(value!==null)values.push(value);
      }
      if(values.length)return Math.min(...values);
    }
    return null;
  }
  function firstCompactPriceNode(root){
    for(const node of root?.querySelectorAll?.('strong,em,span,b')||[]){
      if(isOriginalPriceNode(node)||isRewardPriceNode(node))continue;
      const text=String(node.textContent||'').replace(/\s+/g,' ').trim();
      if(!text||text.length>48||!/\d[\d,]*\s*원/.test(text))continue;
      const value=parsePrice(text);if(value!==null)return value;
    }
    return null;
  }
  function priceFromText(el) {
    if (!el) return null;
    /* 1순위 와우 회원 할인가 → 2순위 일반/쿠폰 할인가 → 3순위 일반 판매가.
       적립·캐시·포인트와 취소선 정가는 각 단계에서 공통으로 제외합니다. */
    const wow=lowestPriceFromNodes(el,['[class*="wow-price" i]','[class*="wowPrice" i]','[class*="member-price" i]','[class*="memberPrice" i]','[data-testid*="wow-price" i]','[data-testid*="member-price" i]','[aria-label*="와우" i]']);
    const sale=lowestPriceFromNodes(el,['[class*="sale-price" i]','[class*="salePrice" i]','[class*="discount-price" i]','[class*="discountPrice" i]','[class*="coupon-price" i]','[class*="final-price" i]','.prod-sale-price','.price-value','[class*="priceValue"]','[data-testid*="price" i]']);
    const regular=lowestPriceFromNodes(el,['[class*="regular-price" i]','[class*="regularPrice" i]','[class*="selling-price" i]','[class*="sellingPrice" i]','[class*="current-price" i]','.prod-price','[itemprop="price"]']);
    let resolved=null;
    if(wow!==null)resolved=wow;
    else if(sale!==null)resolved=sale;
    else if(regular!==null)resolved=regular;
    if(resolved!==null)return resolved;

    const text=String(el.textContent||'').replace(/\s+/g,' ');
    const wowText=parsePrice(text.match(/(?:와우(?:\s*회원)?가|회원가)\s*[:：]?\s*([\d,]{2,})\s*원/i)?.[1]);
    const saleText=parsePrice(text.match(/(?:쿠폰\s*할인가|즉시\s*할인가|할인가)\s*[:：]?\s*([\d,]{2,})\s*원/i)?.[1]);
    const regularText=parsePrice(text.match(/(?:일반\s*판매가|판매가|정상가)\s*[:：]?\s*([\d,]{2,})\s*원/i)?.[1]);
    if(wowText!==null)return wowText;
    else if(saleText!==null)return saleText;
    else if(regularText!==null)return regularText;

    const clone=el.cloneNode?.(true);
    clone?.querySelectorAll?.('del,s,strike,[class*="original" i],[class*="base-price" i],[class*="list-price" i],[class*="retail-price" i],[class*="discount-rate" i]').forEach((node)=>node.remove());
    for(const node of [...(clone?.querySelectorAll?.('*')||[])])if(isRewardPriceNode(node))node.remove();
    return firstCompactPriceNode(clone) ?? parsePrice(clone?.textContent||text);
  }

  function normalizeRatingValue(value, { percent = false } = {}) {
    if (value === null || value === undefined || value === '') return null;
    const match = String(value).replace(/,/g, '').match(/-?\d+(?:\.\d+)?/);
    if (!match) return null;
    let number = Number(match[0]);
    if (!Number.isFinite(number)) return null;
    if (percent && number > 5 && number <= 100) number /= 20;
    if (number < 0 || number > 5) return null;
    return Math.round(number * 100) / 100;
  }

  /** 쿠팡의 별점은 텍스트, aria-label, meta, data 속성, 별 채움 width 등 여러 형태로 노출됩니다. */
  function ratingFromElement(root) {
    if (!root?.querySelectorAll) return { value:null, source:null };
    const nodes = [root, ...root.querySelectorAll('[itemprop="ratingValue"],meta[itemprop="ratingValue"],[data-rating],[data-rating-score],[data-star-rating],[data-rating-value],[data-score],[data-percent],[aria-valuenow],[aria-valuetext],[aria-label*="별점" i],[aria-label*="평점" i],[aria-label*="rating" i],[title*="별점" i],[title*="평점" i],[class*="rating" i],[class*="star" i]')].slice(0,180);
    for (const node of nodes) {
      const attributes = ['content','data-rating','data-rating-score','data-star-rating','data-rating-value','data-score','aria-valuenow','aria-valuetext','aria-label','title','alt'];
      for (const attr of attributes) {
        const raw = node?.getAttribute?.(attr);
        if (!raw) continue;
        const explicit = String(raw).match(/(?:별점|평점|rating|star(?:\s*rating)?)\s*[:：]?\s*([0-5](?:\.\d{1,2})?)/i)
          || String(raw).match(/([0-5](?:\.\d{1,2})?)\s*(?:점|\/\s*5|out\s+of\s+5)/i);
        const value = normalizeRatingValue(explicit?.[1] ?? (/^(?:[0-5](?:\.\d{1,2})?)$/.test(String(raw).trim()) ? raw : null));
        if (value !== null) return { value, source:`검색/상세 DOM ${attr}` };
      }
      const style = String(node?.getAttribute?.('style') || '');
      const percentRaw=node?.getAttribute?.('data-percent')||node?.getAttribute?.('data-rating-percent')||null;
      const width = style.match(/(?:width|--rating-percent|--percent|--rating)\s*:\s*(\d+(?:\.\d+)?)%/i);
      const widthValue = normalizeRatingValue(width?.[1]??percentRaw, { percent:true });
      if (widthValue !== null && /rating|star/i.test(`${node?.className||''} ${node?.id||''}`)) return { value:widthValue, source:'별점 채움 비율' };
      /* v4.0.70: 쿠팡이 width를 inline style이 아니라 CSS class로 적용하는 검색카드도 있습니다.
         rating/star 채움 레이어와 부모 폭의 실제 렌더링 비율을 이용해 0~5점으로 복구합니다. */
      try{
        const nodeName=`${node?.className||''} ${node?.id||''}`;
        const parent=node?.parentElement,parentName=`${parent?.className||''} ${parent?.id||''}`;
        if(/rating/i.test(nodeName)&&/star|rating/i.test(parentName)){
          const childWidth=Number(node?.getBoundingClientRect?.().width)||0,parentWidth=Number(parent?.getBoundingClientRect?.().width)||0;
          if(childWidth>0&&parentWidth>0&&childWidth<=parentWidth*1.02){
            const ratio=Math.max(0,Math.min(1,childWidth/parentWidth)),computed=Math.round(ratio*5*100)/100;
            if(computed>0&&computed<=5)return{value:computed,source:'별점 CSS 렌더링 채움 비율'};
          }
        }
      }catch(_){}
      const text = String(node?.textContent || '').replace(/\s+/g,' ').trim();
      if (!text || text.length > 120) continue;
      const explicit = text.match(/(?:별점|평점|rating|star(?:\s*rating)?)\s*[:：]?\s*([0-5](?:\.\d{1,2})?)/i)
        || text.match(/([0-5](?:\.\d{1,2})?)\s*(?:점|\/\s*5|out\s+of\s+5)/i);
      const numericRatingNode=/rating|star/i.test(`${node?.className||''} ${node?.id||''}`)&&/^[0-5](?:\.\d{1,2})?$/.test(text)?text:null;
      const value = normalizeRatingValue(explicit?.[1] ?? numericRatingNode);
      if (value !== null) return { value, source:numericRatingNode?'별점 숫자 노드':'별점 텍스트' };
    }
    /* 검색카드·상세페이지가 별점 DOM을 숨긴 경우 JSON-LD/Next 데이터의 aggregateRating을 복구합니다. */
    const scripts=[...(root.querySelectorAll?.('script[type="application/ld+json"],script[type="application/json"],script#__NEXT_DATA__')||[])].slice(0,40);
    for(const script of scripts){
      const raw=String(script?.textContent||'');
      if(!raw||raw.length>4_000_000)continue;
      const patterns=[
        /["']ratingValue["']\s*:\s*["']?([0-5](?:\.\d{1,2})?)/i,
        /["'](?:averageRating|ratingAverage|ratingScore|starRating)["']\s*:\s*["']?([0-5](?:\.\d{1,2})?)/i,
        /\\?"ratingValue\\?"\s*:\s*\\?"?([0-5](?:\.\d{1,2})?)/i,
      ];
      for(const pattern of patterns){
        const value=normalizeRatingValue(raw.match(pattern)?.[1]);
        if(value!==null)return{value,source:'JSON-LD/내장 데이터 별점'};
      }
    }
    return { value:null, source:null };
  }

  /** "(1,234)" 또는 "리뷰 1,234" 패턴 */
  function reviewsFromText(el) {
    const t = el.textContent || '';
    const m = t.match(/\(\s*([\d,]+)\s*\)/);
    if (m) return parseNum(m[1]);
    const m2 = t.match(/리뷰\s*([\d,만천.]+)/);
    return m2 ? parseNum(m2[1]) : null;
  }

  function isPriceLikeProductName(value) {
    const text = String(value || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
    return !text || /^(?:최대\s*)?[\d,]+(?:\.\d+)?\s*원?(?:부터)?$/i.test(text) || /^[\d,.%원~+\-\s]+$/.test(text);
  }

  function nameFromCard(card, anchor = null) {
    /* 가격/할인 영역의 느슨한 .name 클래스와 충돌하지 않도록 상품명 경로를 우선합니다. */
    const selectors = [
      'div.descriptions-inner div.name', 'a > dl > dd > div.name',
      '[data-testid*="product-name" i]', '[class*="productName"]', '[class*="ProductName"]',
      'h2[class*="name" i]', 'h3[class*="name" i]'
    ];
    for (const selector of selectors) {
      const value = txt(card, selector);
      if (!value || value.length < 2 || isPriceLikeProductName(value)) continue;
      const clean = cleanProductName(value);
      if (clean && !isPriceLikeProductName(clean) && !SPX.isPromotionalUiText?.(clean)) return clean;
    }
    const candidates = [anchor?.getAttribute?.('title'), anchor?.getAttribute?.('aria-label')];
    for (const candidate of candidates) {
      const value = String(candidate || '').replace(/\s+/g, ' ').trim();
      if (!value || isPriceLikeProductName(value) || SPX.isPromotionalUiText?.(value)) continue;
      const clean = cleanProductName(value);
      if (clean && !isPriceLikeProductName(clean)) return clean;
    }
    return '';
  }

  function isRocketEl(el) {
    if (!el?.querySelectorAll) return false;
    if (el.querySelector('[class*="rocket"], [class*="Rocket"], [data-testid*="rocket" i], [aria-label*="rocket" i], [aria-label*="로켓" i]')) return true;
    const imgs = el.querySelectorAll('img');
    for (const i of imgs) {
      const source = `${i.alt || ''} ${i.title || ''} ${i.getAttribute('src') || ''} ${i.getAttribute('aria-label') || ''}`;
      if (/로켓|rocket/i.test(source)) return true;
    }
    return false;
  }

  function isAdEl(el) {
    if (!el) return false;
    /* 광고 표시는 효자상품 후보 판정보다 먼저 식별합니다. 쿠팡의 구형·신형 배지와
       data/aria 표기를 함께 보되, badge처럼 우연히 ad 문자가 포함된 일반 클래스는 제외합니다. */
    if (el.querySelector('.ad-badge, .ad-badge-text, [class*="search-product__ad-badge" i], [class*="AdMark"], [class*="adMark"], [class*="advertisement" i], [data-ad="true"], [data-is-ad="true"], [aria-label="광고"], [aria-label="AD" i]')) return true;
    const classTokens = [...(el.classList || [])].map((value) => String(value || '').toLowerCase());
    if (classTokens.some((value) => /(?:^|[-_])(?:ad|ads|advert|advertisement)(?:$|[-_])/.test(value))) return true;
    const exactBadge = [...(el?.querySelectorAll?.('span,em,i,strong,div') || [])]
      .some((node) => /^(?:광고|AD)$/i.test(String(node.textContent || '').trim()));
    return exactBadge;
  }


  function deliveryTypeFromBadgeImage(img) {
    if (!img) return null;
    const source = normalizeDeliveryEvidence(`${img.alt || ''} ${img.title || ''} ${img.getAttribute?.('src') || ''} ${img.getAttribute?.('data-src') || ''} ${img.getAttribute?.('aria-label') || ''}`);
    if (!source) return null;
    if (/로켓\s*프레시|로켓프레시|rocket[_\s-]*fresh/i.test(source)) return '로켓프레시';
    if (/로켓\s*직구|로켓직구|개인통관고유부호|rocket[_\s-]*(?:global|overseas)|global[_\s-]*rocket|(?:^|[\/_-])jikgu(?:[\/_.-]|$)|rocket_global/i.test(source)) return '로켓직구';
    if (/로켓\s*설치|로켓설치|설치배송|rocket[_\s-]*install/i.test(source)) return '로켓설치';
    if (/로켓\s*그로스|로켓그로스|rocket[_\s-]*growth/i.test(source)) return '로켓그로스';
    if (/logo_rocket_merchant_medium(?:_v3_r3)?|판매자\s*로켓|판매자로켓|seller[_\s-]*rocket|rocket[_\s-]*merchant/i.test(source)) return '판매자로켓';
    if (/logo_rocket_filter_medium|로켓\s*배송|로켓배송|로켓\s*와우|로켓와우|rocket[_\s-]*(?:logo|delivery|wow)/i.test(source)) return '로켓배송';
    return null;
  }

  function rocketTypeFromEl(el) {
    return getDeliveryType(el);
  }

  function deliveryFlags(rocketType) {
    const type = String(rocketType || '배송유형 미확인').trim();
    const sellerRocket = type === '판매자로켓' || type === '로켓그로스';
    return {
      isCoupangRocket: type === '로켓배송',
      isSellerRocket: sellerRocket,
      isRocketFresh: type === '로켓프레시',
      isRocketGlobal: type === '로켓직구',
      isRocketInstall: type === '로켓설치',
      isGeneralDelivery: type === '일반배송',
      isDeliveryUnknown: ['배송유형 미확인','배송확인실패'].includes(type),
    };
  }

  function normalizeDeliveryEvidence(value) {
    return String(value || '')
      .replace(/\\u([0-9a-f]{4})/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)))
      .replace(/&nbsp;|&#160;/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/[\r\n\t]+/g, ' ')
      /* 무료배송 안내 속 '로켓배송 상품 N원 이상 구매 시'는 현재 상품의 배송 배지가 아닙니다. */
      .replace(/무료배송\s*\(\s*로켓배송\s*상품\s*[\d,]+\s*원\s*이상\s*구매\s*시\s*\)/gi, ' 무료배송 ')
      .replace(/로켓배송\s*상품(?:과|을)?\s*(?:함께\s*)?[\d,]+\s*원\s*이상\s*구매\s*시/gi, ' ')
      .replace(/로켓배송\s*상품(?:과|을)?\s*함께\s*구매\s*시/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function deliveryTypeFromEvidence(value) {
    const source = normalizeDeliveryEvidence(value);
    if (!source) return null;
    /* 공식 배지 파일명과 img src/alt 키워드는 본문 추천상품 문구보다 우선합니다. */
    if (/로켓\s*프레시|로켓프레시|rocket[_\s-]*fresh/i.test(source)) return '로켓프레시';
    if (/로켓\s*직구|로켓직구|개인통관고유부호|rocket[_\s-]*(?:global|overseas)|global[_\s-]*rocket|(?:^|[\/_-])jikgu(?:[\/_.-]|$)|rocket_global/i.test(source)) return '로켓직구';
    if (/로켓\s*설치|로켓설치|설치배송|rocket[_\s-]*install/i.test(source)) return '로켓설치';
    if (/로켓\s*그로스|로켓그로스|rocket[_\s-]*growth/i.test(source)) return '로켓그로스';
    if (/logo_rocket_merchant_medium(?:_v3_r3)?|판매자\s*로켓|판매자로켓|seller[_\s-]*rocket|rocket[_\s-]*merchant/i.test(source)) return '판매자로켓';
    if (/logo_rocket_filter_medium|로켓\s*배송|로켓배송|로켓\s*와우|로켓와우|rocket[_\s-]*(?:logo|delivery|wow)/i.test(source)) return '로켓배송';
    /* 상세페이지 배지는 아이콘의 "로켓"과 옆의 "내일"이 분리된 경우가 많습니다. */
    if (/(?:^|[\s>"'_-])로켓(?:[\s<"'_-]|$)/i.test(source) && /(?:내일|오늘|도착|무료배송|와우)/i.test(source)) return '로켓배송';
    if (/rocket/i.test(source) && /(?:tomorrow|today|delivery|arriv|wow)/i.test(source)) return '로켓배송';
    if (/일반배송|판매자배송|업체배송|택배배송|일반택배|배송사\s*[:：]?\s*(?:cj대한통운|대한통운|한진택배|롯데택배|로젠택배|우체국택배|경동택배|대신택배|일양로지스|천일택배|합동택배)|cj대한통운|한진택배|롯데택배|로젠택배|우체국택배|경동택배|대신택배|일양로지스|천일택배|합동택배/i.test(source)) return '일반배송';
    /* 로켓 계열 근거가 없고 일반 배송 문구만 있는 판매자 상품을 미확인으로 남기지 않습니다. */
    if (/(?:도착\s*(?:예정|보장)|배송\s*예정|배송비|무료배송|착불|택배\s*발송)/i.test(source)) return '일반배송';
    return null;
  }

  /* 명시적인 로켓 계열 근거는 일반 배송 문구보다 항상 우선합니다.
     상세페이지에는 무료배송·도착예정 문구와 로켓 배지가 동시에 존재하므로,
     첫 번째로 발견된 일반배송 근거를 즉시 확정하면 모든 상품이 일반배송으로 눌릴 수 있습니다. */
  const DELIVERY_TYPE_PRIORITY = Object.freeze({
    '배송유형 미확인': 0, '배송확인실패': 0, '일반배송': 10,
    '로켓배송': 60, '판매자로켓': 70, '로켓그로스': 75,
    '로켓직구': 80, '로켓설치': 85, '로켓프레시': 90,
  });

  function deliveryPriority(type) {
    return DELIVERY_TYPE_PRIORITY[String(type || '').trim()] || 0;
  }

  function choosePreferredDeliveryType(...values) {
    let best = null;
    for (const value of values.flat(Infinity)) {
      const type = typeof value === 'string' ? value : value?.type;
      if (!type) continue;
      if (!best || deliveryPriority(type) > deliveryPriority(best)) best = type;
    }
    return best;
  }

  function deliveryNodeEvidence(node) {
    if (!node) return '';
    return [
      node.getAttribute?.('alt'), node.getAttribute?.('title'), node.getAttribute?.('aria-label'),
      node.getAttribute?.('src'), node.getAttribute?.('srcset'), node.getAttribute?.('data-src'),
      node.getAttribute?.('data-lazy-src'), node.getAttribute?.('data-testid'),
      node.getAttribute?.('data-delivery-type'), node.getAttribute?.('data-badge-type'),
      node.getAttribute?.('href'), node.getAttribute?.('xlink:href'), node.id,
      typeof node.className === 'string' ? node.className : node.className?.baseVal,
    ].filter(Boolean).join(' ');
  }

  function recordDeliveryCandidate(box, type, source) {
    if (!box || !type) return;
    if (!box.deliveryType || deliveryPriority(type) > deliveryPriority(box.deliveryType)) {
      box.deliveryType = type;
      box.deliverySource = source || box.deliverySource || null;
    }
  }

  /** 3단계 Catch-all 배송 판별기.
   * 1) 공식 뱃지·이미지·SVG·클래스/aria/data 속성,
   * 2) 택배사 명칭, 3) 도착예정·배송비·무료배송·착불 안전망.
   * 로켓 계열 근거를 모두 비교한 뒤에만 일반배송으로 fallback 합니다. */
  function getDeliveryType(target) {
    if (!target) return '일반배송';
    if (!target.querySelectorAll) return deliveryTypeFromEvidence(target) || '일반배송';

    const candidates = [];
    const addEvidence = (value) => {
      const type = deliveryTypeFromEvidence(value);
      if (type) candidates.push(type);
    };

    /* img alt뿐 아니라 src/srcset/data-src, picture source, SVG use, 난독화된 data 속성까지 확인합니다. */
    const badgeNodes = [target, ...target.querySelectorAll(
      'img,source,svg,use,[class*="rocket" i],[id*="rocket" i],[data-testid*="rocket" i],' +
      '[data-delivery-type],[data-badge-type],[aria-label*="로켓" i],[aria-label*="rocket" i],' +
      '[title*="로켓" i],[title*="rocket" i]'
    )].slice(0, 260);
    for (const node of badgeNodes) {
      if (node?.tagName === 'IMG') {
        const badge = deliveryTypeFromBadgeImage(node);
        if (badge) candidates.push(badge);
      }
      addEvidence(deliveryNodeEvidence(node));
    }

    /* 카드 텍스트는 뱃지 근거를 모은 다음 평가합니다. 일반배송 문구가 먼저 보여도 로켓 근거를 덮지 못합니다. */
    const cardText = String(target.innerText || target.textContent || '').replace(/\s+/g, ' ').trim();
    addEvidence(cardText);
    const explicit = choosePreferredDeliveryType(candidates);
    if (explicit && explicit !== '일반배송') return explicit;

    /* 클래스가 rocket 한 단어만 가진 구형 카드도 쿠팡 직매입 로켓으로 보존합니다. */
    const structuralEvidence = badgeNodes.map(deliveryNodeEvidence).join(' ');
    if ((/rocket/i.test(structuralEvidence) || isRocketEl(target)) && !/판매자\s*로켓|판매자로켓|merchant|growth|fresh|global|install/i.test(structuralEvidence)) {
      return '로켓배송';
    }

    /* 2·3단계 일반배송 판정 및 최종 기본값. */
    return explicit || deliveryTypeFromEvidence(cardText) || '일반배송';
  }

  function cleanSellerName(value) {
    let text = normalizeDeliveryEvidence(value)
      .replace(/^(?:판매자|스토어|판매처|vendor|seller|merchant)\s*[:：]?\s*/i, '')
      .replace(/\s*(?:판매자 상품 보러가기|판매자정보|판매자 정보|다른 판매자 보기).*$/i, '')
      .trim();
    if (!text || text.length > 120) return null;
    if (/^(?:미확인|쿠팡|coupang|판매자|스토어|판매처|브랜드샵|다른 판매자 보기|판매자 상품 보러가기)$/i.test(text)) return null;
    if (/^[\d,]+\s*원$/.test(text)) return null;
    return text.slice(0, 120);
  }

  function sellerTypeFromDelivery(deliveryType) {
    if (['로켓배송','로켓프레시'].includes(deliveryType)) return '쿠팡판매';
    if (['판매자로켓','로켓그로스','일반배송'].includes(deliveryType)) return '일반판매자';
    return null;
  }

  SPX.parsePrice = parsePrice;
  SPX.getDeliveryType = getDeliveryType;
  SPX.detectDeliveryTypeFromEvidence = deliveryTypeFromEvidence;
  SPX.cleanSellerName = cleanSellerName;
  SPX.cleanProductName = cleanProductName;
  SPX.isAdProductCard = isAdEl;
  SPX.isSoldOutProductCard = soldOutFromEl;

  function soldOutFromEl(el) {
    if (!el) return false;
    if (el.querySelector?.('.out-of-stock, [class*="out-of-stock" i], [class*="outOfStock"], [class*="sold-out" i], [class*="soldOut"], [data-sold-out="true"], [data-out-of-stock="true"], [aria-label*="품절"]')) return true;
    return /일시\s*품절|품절(?!\s*임박)|판매\s*중지|판매\s*종료/i.test(String(el?.textContent || '').replace(/\s+/g, ' '));
  }

  function soldOutFromDetailDocument(doc) {
    if (!doc) return false;
    const direct = doc.querySelector?.('.prod-atf .out-of-stock, .prod-buy .out-of-stock, [class*="prod-atf" i] [class*="outOfStock"], [class*="prod-buy" i] [class*="soldOut"], button[disabled][aria-label*="품절"], [data-sold-out="true"], [data-out-of-stock="true"]');
    if (direct) return true;
    const purchaseRoots = [
      doc.querySelector?.('.prod-atf'), doc.querySelector?.('.prod-buy'), doc.querySelector?.('[class*="prod-atf" i]'),
      doc.querySelector?.('[class*="product-main" i]'), doc.querySelector?.('[data-testid*="purchase" i]')
    ].filter(Boolean);
    return purchaseRoots.some((root) => /일시\s*품절|품절(?!\s*임박)|판매\s*중지|판매\s*종료/i.test(String(root.textContent || '').replace(/\s+/g, ' ')));
  }

  function sellerFromEl(el) {
    const value = txt(el, '[data-testid*="seller" i], [data-testid*="vendor" i], [class*="seller" i], [class*="vendor" i], [class*="storeName" i]');
    if (value) return cleanSellerName(value);
    const text = String(el?.textContent || '').replace(/\s+/g, ' ');
    return cleanSellerName(text.match(/판매자\s*[:：]\s*([^|·,/]{2,60})/i)?.[1]);
  }

  function brandFromEl(el) {
    const value = txt(el, '[class*="brand"], [class*="Brand"]');
    return value ? value.replace(/^브랜드\s*[:：]?\s*/,'').slice(0,120) : null;
  }

  function idsFromUrl(url) {
    try {
      const parsed = new URL(url, location.origin);
      return {
        itemId: parsed.searchParams.get('itemId') || null,
        vendorItemId: parsed.searchParams.get('vendorItemId') || null,
      };
    } catch (_) { return { itemId: null, vendorItemId: null }; }
  }

  function normalizeKeywordText(value) {
    return String(value || '').normalize('NFKC').toLowerCase().replace(/[^0-9a-z가-힣]+/g, '');
  }

  function recommendationKeywordRelevance(keyword, productName) {
    const keywordNorm = normalizeKeywordText(keyword);
    const nameNorm = normalizeKeywordText(productName);
    if (!keywordNorm || !nameNorm) return { score:0, status:'키워드 미확인' };
    if (nameNorm.includes(keywordNorm)) return { score:100, status:'대표키워드 직접 포함' };
    const tokens = String(keyword || '').normalize('NFKC').toLowerCase()
      .split(/[^0-9a-z가-힣]+/).map((v) => v.trim()).filter((v) => v.length >= 2);
    if (!tokens.length) return { score:0, status:'관련성 미확인' };
    const matched = tokens.filter((token) => nameNorm.includes(normalizeKeywordText(token))).length;
    const score = Math.round(matched / tokens.length * 100);
    return { score, status:score >= 60 ? '대표키워드 관련성 확인' : '대표키워드 관련성 부족' };
  }

  function comparisonCardRoot(anchor, boundary) {
    const selectors = ['li','article','[data-product-id]','[class*="product" i]','[class*="item" i]'];
    for (const selector of selectors) {
      const found = anchor.closest?.(selector);
      if (found && (!boundary || boundary.contains(found))) return found;
    }
    let node = anchor;
    for (let depth = 0; depth < 4 && node?.parentElement && (!boundary || node.parentElement !== boundary); depth++) {
      node = node.parentElement;
      if ((node.querySelectorAll?.('a[href*="/vp/products/"]').length || 0) <= 3) return node;
    }
    return anchor.parentElement || anchor;
  }

  function extractComparisonProducts(doc, detailUrl, allowedSections = null) {
    if (!doc) return [];
    // Section titles change frequently. The option controls product groups,
    // not a hard-coded heading catalogue. Only this first detail document is scanned.
    if(allowedSections===false||allowedSections?.enabled===false)return [];
    const headingCandidates=[...doc.querySelectorAll('h2,h3,h4,h5,strong,b,[role="heading"]')]
      .filter(node=>String(node.textContent||'').replace(/\s+/g,' ').trim().length<=80);
    const containers = [];
    for (const heading of headingCandidates.slice(0, 12)) {
      let node = heading.parentElement;
      for (let depth = 0; depth < 6 && node && !['BODY','HTML'].includes(node.tagName); depth++, node = node.parentElement) {
        const count = node.querySelectorAll?.('a[href*="/vp/products/"]').length || 0;
        if (count >= 1 && count <= 60) {
          containers.push({ node, label:String(heading.textContent||'추천상품').replace(/\s+/g,' ').trim() });
          break;
        }
      }
    }
    for(const node of doc.querySelectorAll('section,[role="region"],[class*="recommend" i],[class*="carousel" i],[class*="related" i],[data-testid*="recommend" i]')){
      const count=node.querySelectorAll('a[href*="/vp/products/"]').length;
      if(count>=1&&count<=60&&!containers.some(group=>group.node===node))containers.push({node,label:String(node.querySelector('h2,h3,[role="heading"]')?.textContent||'상세 추천상품').trim().slice(0,80)});
    }
    const currentPid = String(detailUrl || '').match(PID_RE)?.[1] || null;
    const out = new Map();
    for (const { node, label } of containers) {
      for (const anchor of [...node.querySelectorAll('a[href*="/vp/products/"]')].slice(0, 40)) {
        let href = anchor.getAttribute('href') || '';
        try { href = new URL(href, detailUrl || location.origin).href; } catch (_) {}
        const pid = String(href).match(PID_RE)?.[1] || null;
        if (!pid || pid === currentPid) continue;
        const ids=idsFromUrl(href);
        const offerKey=[pid,ids.vendorItemId||ids.itemId||'',href].join('|');
        if(out.has(offerKey))continue;
        const card = comparisonCardRoot(anchor, node);
        const img = anchor.querySelector('img') || card?.querySelector?.('img');
        const rawName = anchor.getAttribute('title') || anchor.getAttribute('aria-label') || img?.alt
          || txt(card, '[class*="name" i], [class*="title" i]') || anchor.textContent || '';
        const name = cleanProductName(rawName);
        if (!name || name.length < 2) continue;
        const rocketType = rocketTypeFromEl(card) || '배송유형 미확인';
        const imageUrl=imageFromCard(card,anchor);
        const ratingInfo=ratingFromElement(card);
        out.set(offerKey, {
          pid:String(pid),itemId:ids.itemId,vendorItemId:ids.vendorItemId,
          productUrl:href,
          imageUrl,image_url:imageUrl,thumbnail_url:imageUrl,
          name,
          price:priceFromText(card),
          reviews:reviewsFromText(card) ?? null,
          rating:ratingInfo.value,
          ratingSource:ratingInfo.source,
          isRocket:['로켓배송','판매자로켓','로켓그로스','로켓프레시','로켓직구','로켓설치'].includes(rocketType),
          rocketType,
          isAd:isAdEl(card),
          isSoldOut:soldOutFromEl(card),
          seller:sellerFromEl(card),
          brand:brandFromEl(card),
          sourceType:'detail_comparison_candidate',
          discoverySource:'상품 상세페이지 추천',
          recommendationLabel:label,
          recommendationVerified:false,
          recommendationOriginPid:currentPid,
          recommendationOriginUrl:detailUrl || null,
          rank:9000 + out.size + 1,
        });
      }
    }
    return [...out.values()].slice(0, 24);
  }

  function finalizeItems(items, strategy) {
    let organicRank = 0, adRank = 0;
    return (items || []).map((item, index) => {
      const ids = idsFromUrl(item.productUrl);
      const isAd = !!item.isAd;
      const rocketType = item.rocketType || (item.isRocket ? '로켓배송' : '배송유형 미확인');
      const flags = deliveryFlags(rocketType);
      const imageUrl=normalizeProductImageUrl(item.image_url||item.imageUrl||item.thumbnail_url||item.thumbnail||item.image,item.productUrl||location?.href);
      return {
        ...item, ...ids,
        imageUrl:imageUrl||null,image_url:imageUrl||null,thumbnail_url:imageUrl||null,
        name: cleanProductName(item.name || item.product_name || ''),
        exposureRank: index + 1,
        organicRank: isAd ? null : ++organicRank,
        adRank: isAd ? ++adRank : null,
        rocketType,
        deliveryTypeRaw: rocketType,
        deliverySource: item.deliverySource || (rocketType !== '배송유형 미확인' ? '검색결과 배송 배지·문구' : null),
        deliveryCheckStatus: item.deliveryCheckStatus || (rocketType !== '배송유형 미확인' ? '검색결과 확인' : '미확인'),
        isRocket: ['로켓배송','판매자로켓','로켓그로스','로켓프레시','로켓직구','로켓설치'].includes(rocketType),
        ...flags,
        parserStrategy: strategy,
        collectedAt: new Date().toISOString(),
      };
    });
  }

  // ---------- 전략 A: legacy ----------
  function strategyLegacy() {
    const lis = document.querySelectorAll('li.search-product');
    if (!lis.length) return null;
    const out = [];
    lis.forEach((li, i) => {
      const pid = li.dataset.productId || (li.querySelector('a')?.href || '').match(PID_RE)?.[1];
      if (!pid) return;
      const anchor=li.querySelector('a[href*="/vp/products/"]');
      const imageUrl=imageFromCard(li,anchor);
      const ratingInfo=ratingFromElement(li);
      out.push({
        pid: String(pid),
        productUrl: anchor?.href || null,
        imageUrl,image_url:imageUrl,thumbnail_url:imageUrl,
        name: nameFromCard(li, anchor),
        price: priceFromText(li),
        reviews: parseNum(txt(li, '.rating-total-count')) ?? reviewsFromText(li) ?? null,
        rating: ratingInfo.value,
        ratingSource: ratingInfo.source,
        isRocket: isRocketEl(li),
        rocketType: rocketTypeFromEl(li),
        isAd: li.classList.contains('search-product__ad-badge') || isAdEl(li),
        isSoldOut: soldOutFromEl(li),
        seller: sellerFromEl(li),
        brand: brandFromEl(li),
        rank: i + 1,
      });
    });
    return out.length ? { items: out, strategy: 'legacy' } : null;
  }

  // ---------- 전략 B: modern ----------
  function strategyModern() {
    const lis = document.querySelectorAll(
      'li[class*="ProductUnit_productUnit"], li[class*="productUnit"], #product-list > li'
    );
    if (!lis.length) return null;
    const out = [];
    lis.forEach((li, i) => {
      const a = li.querySelector('a[href*="/vp/products/"]');
      const pid = a && (a.href.match(PID_RE) || [])[1];
      if (!pid) return;
      const imageUrl=imageFromCard(li,a);
      const ratingInfo=ratingFromElement(li);
      out.push({
        pid: String(pid),
        productUrl: a?.href || null,
        imageUrl,image_url:imageUrl,thumbnail_url:imageUrl,
        name: nameFromCard(li, a),
        price: priceFromText(li),
        reviews: parseNum(txt(li, '[class*="ratingCount"]')) ?? reviewsFromText(li) ?? null,
        rating: ratingInfo.value,
        ratingSource: ratingInfo.source,
        isRocket: isRocketEl(li),
        rocketType: rocketTypeFromEl(li),
        isAd: isAdEl(li),
        isSoldOut: soldOutFromEl(li),
        seller: sellerFromEl(li),
        brand: brandFromEl(li),
        rank: i + 1,
      });
    });
    return out.length ? { items: out, strategy: 'modern' } : null;
  }

  // ---------- 전략 C: anchor 역추적 (최후의 보루) ----------
  function strategyAnchor() {
    const anchors = document.querySelectorAll('a[href*="/vp/products/"]');
    if (!anchors.length) return null;
    const seen = new Map();
    let rank = 0;
    anchors.forEach((a) => {
      const pid = (a.href.match(PID_RE) || [])[1];
      if (!pid || seen.has(pid)) return;
      if (isInsideExcludedWidget(a)) return;
      // 카드 컨테이너 찾기: li 우선, 없으면 적당한 크기의 조상
      let card = a.closest('li');
      if (!card) {
        card = a;
        for (let d = 0; d < 4 && card.parentElement; d++) {
          card = card.parentElement;
          if (card.offsetHeight > 150) break;
        }
      }
      const price = priceFromText(card);
      if (!price) return; // 가격 없으면 상품 카드가 아님 (배너·추천 링크 등)
      const imageUrl=imageFromCard(card,a);
      const ratingInfo=ratingFromElement(card);
      seen.set(pid, {
        pid: String(pid),
        productUrl: a.href || null,
        imageUrl,image_url:imageUrl,thumbnail_url:imageUrl,
        name: nameFromCard(card, a),
        price,
        reviews: reviewsFromText(card) ?? null,
        rating: ratingInfo.value,
        ratingSource: ratingInfo.source,
        isRocket: isRocketEl(card),
        rocketType: rocketTypeFromEl(card),
        isAd: isAdEl(card),
        isSoldOut: soldOutFromEl(card),
        seller: sellerFromEl(card),
        brand: brandFromEl(card),
        rank: ++rank,
      });
    });
    const out = [...seen.values()];
    return out.length ? { items: out, strategy: 'anchor' } : null;
  }

  // ---------- 전략 D: 상품 링크 기반 범용 카드 ----------
  /* [v2.2.2] 요청 반영: 보조 전략(generic-card·anchor)은 페이지 전체에서 상품 링크를 긁다 보니
     "같이 보면 좋은 상품"·"이 상품을 검색한 다른 분들이 함께 본 상품"·"한정 시간 특가 상품"·
     "최근 다른 고객이 많이 구매한 상품" 같은 검색어와 무관한 추천/프로모션 위젯도 섞일 위험이
     있었다. 정확한 클래스명을 알 수 없어, 조상 요소 중 이런 위젯 제목 문구를 포함하는 컨테이너가
     있으면 그 안의 상품은 제외하는 방식으로 방어한다. */
  const WIDGET_EXCLUDE_TEXT = /같이\s*보면\s*좋은\s*상품|이\s*상품을\s*검색한\s*다른\s*분들이\s*함께\s*본\s*상품|한정\s*시간\s*특가\s*상품|최근\s*다른\s*고객이\s*많이\s*구매한\s*상품|함께\s*본\s*상품|이\s*상품과\s*함께|자주\s*함께\s*구매/;
  function isInsideExcludedWidget(el) {
    let cursor = el;
    for (let depth = 0; depth < 8 && cursor; depth += 1, cursor = cursor.parentElement) {
      /* 컨테이너 자신의 헤더/타이틀 텍스트만 확인(내부 상품명까지 전부 훑으면 오탐 위험이 커서
         첫 300자 정도로 제한). */
      const headingText = String(cursor.querySelector?.('h1,h2,h3,h4,[class*="title" i],[class*="heading" i]')?.textContent || '').slice(0, 300);
      if (WIDGET_EXCLUDE_TEXT.test(headingText)) return true;
    }
    return false;
  }
  function strategyGenericCard() {
    const anchors = [...document.querySelectorAll('a[href*="/vp/products/"]')];
    if (!anchors.length) return null;
    const seen = new Map();
    let rank = 0;
    for (const a of anchors) {
      const pid = (String(a.href || '').match(PID_RE) || [])[1];
      if (!pid || seen.has(pid)) continue;
      if (isInsideExcludedWidget(a)) continue;
      let card = a.closest('[data-product-id], [data-productid], article, li, [class*="product" i]') || a.parentElement;
      let cursor = card;
      for (let depth = 0; depth < 6 && cursor; depth++, cursor = cursor.parentElement) {
        if (priceFromText(cursor)) { card = cursor; break; }
      }
      if (!card) continue;
      const price = priceFromText(card);
      if (!price) continue;
      const name = nameFromCard(card, a);
      if (!name) continue;
      const imageUrl=imageFromCard(card,a);
      const ratingInfo=ratingFromElement(card);
      seen.set(pid, {
        pid:String(pid), productUrl:a.href || null, imageUrl,image_url:imageUrl,thumbnail_url:imageUrl, name, price,
        reviews:reviewsFromText(card) ?? null, rating:ratingInfo.value, ratingSource:ratingInfo.source,
        isRocket:isRocketEl(card), rocketType:rocketTypeFromEl(card), isAd:isAdEl(card),
        isSoldOut:soldOutFromEl(card), seller:sellerFromEl(card), brand:brandFromEl(card), rank:++rank,
      });
    }
    const out=[...seen.values()];
    return out.length ? { items:out, strategy:'generic-card' } : null;
  }

  function strategyInitialState(){
    if(SPX.parserSettings?.initialStateFastParse===false)return null;
    const roots=[];
    for(const script of document.querySelectorAll('script#__NEXT_DATA__,script[type="application/json"],script:not([src])')){
      const raw=String(script.textContent||'').trim();
      if(!raw||raw.length<20||raw.length>8_000_000)continue;
      if(!(raw.startsWith('{')||raw.startsWith('[')))continue;
      try{roots.push(JSON.parse(raw));}catch(_){}
      if(roots.length>=8)break;
    }
    if(!roots.length)return null;
    const out=new Map();let visited=0;
    const visit=(value,depth=0)=>{
      if(!value||typeof value!=='object'||depth>12||visited++>120000)return;
      if(Array.isArray(value)){for(const child of value)visit(child,depth+1);return;}
      const pid=String(value.productId??value.product_id??value.productNo??'').replace(/\D/g,'');
      const name=cleanProductName(value.productName??value.product_name??value.title??value.name??'');
      const vendorItemId=String(value.vendorItemId??value.vendor_item_id??'').replace(/\D/g,'');
      const itemId=String(value.itemId??value.item_id??'').replace(/\D/g,'');
      const priceCandidates=[value.wowPrice,value.wowMemberPrice,value.memberPrice,value.finalPrice,value.salePrice,value.discountPrice,value.discountedPrice,value.sellingPrice,value.price];
      const price=priceCandidates.map(priceNumber).find((number)=>number!==null)??null;
      if(pid&&name&&price){
        const key=`${pid}:${vendorItemId||itemId||''}`;
        if(!out.has(key)){
          const params=new URLSearchParams();if(itemId)params.set('itemId',itemId);if(vendorItemId)params.set('vendorItemId',vendorItemId);
          const url=value.productUrl||value.product_url||value.url||`https://www.coupang.com/vp/products/${pid}${params.size?`?${params}`:''}`;
          const evidence=JSON.stringify(value).slice(0,20000);
          const imageUrl=imageFromJsonProduct(value,String(url));
          out.set(key,{pid,productUrl:String(url),imageUrl,image_url:imageUrl,thumbnail_url:imageUrl,name,price,reviews:parseNum(value.reviewCount??value.ratingCount??value.reviews)??null,rating:normalizeRatingValue(value.rating??value.ratingScore??value.ratingValue),ratingSource:normalizeRatingValue(value.rating??value.ratingScore??value.ratingValue)!==null?'검색결과 JSON':null,isRocket:/rocket|로켓/i.test(evidence),rocketType:deliveryTypeFromEvidence(evidence)||'배송유형 미확인',isAd:value.isAd===true||value.ad===true||String(value.adBadge||'').length>0,isSoldOut:value.soldOut===true||value.isSoldOut===true||/품절|sold.?out/i.test(String(value.status||'')),seller:String(value.sellerName??value.vendorName??''),brand:String(value.brandName??value.brand??''),rank:Number(value.rank??value.searchRank)||out.size+1,itemId:itemId||null,vendorItemId:vendorItemId||null});
        }
      }
      for(const child of Object.values(value))if(child&&typeof child==='object')visit(child,depth+1);
    };
    for(const root of roots)visit(root,0);
    const items=[...out.values()];
    return items.length?{items,strategy:'initial-state-json'}:null;
  }

  function safeStrategy(name, fn, errors) {
    try { return fn(); }
    catch (error) {
      errors.push(`${name}: ${error?.message || String(error)}`);
      return null;
    }
  }

  /** 파싱 실행. 한 전략의 DOM 오류가 전체 자동수집을 중단하지 않도록 독립 실행합니다. */
  SPX.parseSearchPage = function () {
    const errors=[];
    const results = [
      safeStrategy('initial-state-json', strategyInitialState, errors),
      safeStrategy('legacy', strategyLegacy, errors),
      safeStrategy('modern', strategyModern, errors),
      safeStrategy('generic-card', strategyGenericCard, errors),
      safeStrategy('anchor', strategyAnchor, errors),
    ].filter(Boolean);
    if (!results.length) {
      return { items: [], strategy: 'none', diagnostic: { ...diagnose(), parserErrors:errors } };
    }
    results.sort((a, b) => b.items.length - a.items.length);
    const best = results[0];
    /* v4.0.70: 최다 상품 전략을 유지하되, 다른 전략이 같은 PID에서 실제 DOM 별점/이미지를
       확보했다면 그 보강값만 합칩니다. initial-state-json이 상품 수는 가장 많지만 rating을
       비우는 경우에도 화면 카드의 별점을 버리지 않습니다. 가격·리뷰·배송·순위는 best 전략을
       그대로 유지하므로 핵심 집계 범위에는 영향을 주지 않습니다. */
    const mediaByPid=new Map();
    const validRating=(value)=>{const n=Number(value);return Number.isFinite(n)&&n>0&&n<=5?n:null;};
    for(const result of results){
      for(const row of result.items||[]){
        const pid=String(row?.pid||String(row?.productUrl||row?.product_url||'').match(PID_RE)?.[1]||'');
        if(!pid)continue;
        const prior=mediaByPid.get(pid)||{};
        const image=normalizeProductImageUrl(row?.image_url||row?.imageUrl||row?.thumbnail_url,row?.productUrl||row?.product_url||location?.href);
        const rating=validRating(row?.rating??row?.averageRating??row?.average_rating??row?.ratingValue??row?.starRating??row?.detailRating??row?.detail_rating);
        mediaByPid.set(pid,{
          image:prior.image||image||null,
          rating:prior.rating||rating||null,
          ratingSource:prior.ratingSource||(rating?(row?.ratingSource||row?.rating_source||`${result.strategy} 검색카드 별점`):null),
        });
      }
    }
    const bestWithMedia=(best.items||[]).map((row)=>{
      const pid=String(row?.pid||String(row?.productUrl||row?.product_url||'').match(PID_RE)?.[1]||'');
      const supplement=mediaByPid.get(pid)||{};
      const image=normalizeProductImageUrl(row?.image_url||row?.imageUrl||row?.thumbnail_url,row?.productUrl||row?.product_url||location?.href)||supplement.image||null;
      const ownRating=validRating(row?.rating??row?.averageRating??row?.average_rating??row?.ratingValue??row?.starRating??row?.detailRating??row?.detail_rating);
      const rating=ownRating||supplement.rating||null;
      const patch={};
      if(image)Object.assign(patch,{imageUrl:image,image_url:image,thumbnail_url:image});
      if(rating)Object.assign(patch,{rating,averageRating:rating,average_rating:rating,ratingSource:row?.ratingSource||row?.rating_source||supplement.ratingSource||'검색카드 별점',ratingStatus:'confirmed'});
      return Object.keys(patch).length?{...row,...patch}:row;
    });
    return {
      items: finalizeItems(bestWithMedia, best.strategy),
      strategy: best.strategy,
      tried: results.map((r) => `${r.strategy}:${r.items.length}`),
      diagnostic: errors.length ? { parserErrors:errors } : null,
    };
  };

  /** 0건일 때 원인 추적용. 콘솔에 찍어서 셀렉터 수정 근거로 씁니다. */
  function diagnose() {
    return {
      url: location.href,
      liCount: document.querySelectorAll('li').length,
      productAnchors: document.querySelectorAll('a[href*="/vp/products/"]').length,
      hasProductList: !!document.querySelector('#productList, #product-list'),
      sampleLiClasses: [...document.querySelectorAll('li')]
        .slice(0, 30)
        .map((l) => l.className)
        .filter(Boolean)
        .slice(0, 10),
      hint:
        '이 객체를 그대로 복사해서 개발자에게 전달하면 셀렉터를 맞출 수 있습니다. ' +
        'productAnchors가 0이면 페이지가 아직 로딩 중이거나 검색결과 페이지가 아닙니다.',
    };
  }

  SPX.diagnose = diagnose;


  function cleanPath(parts) {
    const out = [];
    const noise = /^(홈|home|쿠팡\s*홈|coupang\s*home|쿠팡\s*수입|쿠팡수입|전체|카테고리|검색결과|쿠팡|이전|다음|더보기)$/i;
    for (const raw of parts || []) {
      const value = String(raw || '')
        .replace(/&gt;|›|»|＞/g, '>')
        .replace(/\u003e/gi, '>')
        .replace(/\s+/g, ' ')
        .replace(/^\s*[>\/·|-]+|[>\/·|-]+\s*$/g, '')
        .trim();
      if (!value || noise.test(value) || value.length > 80) continue;
      if (!out.includes(value)) out.push(value);
    }
    return out;
  }

  function splitCategoryPath(value) {
    if (!value) return [];
    return cleanPath(String(value)
      .replace(/\\u003e/gi, '>')
      .replace(/&gt;|›|»|＞/g, '>')
      .split(/\s*>\s*|\s*\/\s*|\s*·\s*|\s*\|\s*/));
  }

  function pushCategoryCandidate(list, parts, source, categoryId = null, score = 0) {
    const clean = cleanPath(parts);
    if (!clean.length) return;
    const path = clean.join(' > ');
    if (/^(상품형|혼합형|정보형)$/i.test(path)) return;
    const existing = list.find((row) => row.path === path);
    const row = { path, parts: clean, source, categoryId: categoryId ? String(categoryId) : null, score: Number(score) || 0 };
    if (!existing) list.push(row);
    else {
      if (row.score > existing.score) existing.score = row.score;
      if (!existing.categoryId && row.categoryId) existing.categoryId = row.categoryId;
      if (row.source && !String(existing.source || '').includes(row.source)) existing.source = `${existing.source} + ${row.source}`;
    }
  }

  function parseJsonRows(doc) {
    const rows = [];
    doc.querySelectorAll('script[type="application/ld+json"], script[type="application/json"], script#__NEXT_DATA__').forEach((node) => {
      const raw = String(node.textContent || '').trim();
      if (!raw || raw.length > 6_000_000 || !/^[\[{]/.test(raw)) return;
      try { rows.push(JSON.parse(raw)); } catch (_) {}
    });
    return rows;
  }

  function walkJson(value, visit, depth = 0, seen = new WeakSet()) {
    if (depth > 18 || value === null || value === undefined) return;
    if (typeof value !== 'object') return;
    if (seen.has(value)) return;
    seen.add(value);
    visit(value, depth);
    if (Array.isArray(value)) {
      for (const row of value) walkJson(row, visit, depth + 1, seen);
    } else {
      for (const row of Object.values(value)) walkJson(row, visit, depth + 1, seen);
    }
  }

  function extractCategoryCandidatesFromJson(jsonRows, candidates, reviewBox) {
    const sellerKeys = /^(?:sellerName|vendorName|merchantName|storeName|vendorDisplayName|sellerDisplayName|mallName|shopName)$/i;
    const deliveryKeys = /(delivery|shipping|rocket|fulfillment|logistics|badge|serviceType)/i;
    for (const root of jsonRows || []) {
      walkJson(root, (row) => {
        if (!row || typeof row !== 'object') return;
        const typeRaw = row['@type'];
        const types = Array.isArray(typeRaw) ? typeRaw : [typeRaw];
        if (types.includes('BreadcrumbList') || Array.isArray(row.itemListElement)) {
          const parts = (row.itemListElement || []).map((item) => item?.item?.name || item?.name || item?.title).filter(Boolean);
          pushCategoryCandidate(candidates, parts, '상품 상세페이지 JSON breadcrumb', null, 120 + parts.length * 5);
        }
        if (types.includes('Product') || row.aggregateRating || row.reviewCount !== undefined || row.ratingCount !== undefined) {
          const ar = row.aggregateRating || row.rating || {};
          const rc = ar.reviewCount ?? ar.ratingCount ?? row.reviewCount ?? row.ratingCount;
          if (reviewBox.count === null && rc !== undefined && rc !== null) {
            const n = Number(String(rc).replace(/,/g, ''));
            if (Number.isFinite(n)) reviewBox.count = n;
          }
          /* v4.0.31: 쿠팡 상품 JSON은 aggregateRating.ratingValue 외에도
             rating 자체가 숫자이거나 averageRating/ratingScore/starRating 형태로 내려오는 경우가 있습니다.
             사이드바/관리표 상세수집이 같은 구조를 읽도록 안전한 0~5 값만 정규화합니다. */
          const rv = (typeof ar==='number'||typeof ar==='string')
            ? ar
            : (ar?.ratingValue ?? ar?.averageRating ?? ar?.ratingAverage ?? ar?.ratingScore ?? ar?.starRating
              ?? row.ratingValue ?? row.averageRating ?? row.ratingAverage ?? row.ratingScore ?? row.starRating ?? row.reviewRating);
          if (reviewBox.rating === null) { const normalizedRating=normalizeRatingValue(rv); if(normalizedRating!==null){reviewBox.rating=normalizedRating;reviewBox.ratingSource='상품 상세페이지 JSON 별점';} }
          reviewBox.name = reviewBox.name || row.name || row.productName || null;
          const brandValue = typeof row.brand === 'string' ? row.brand : (row.brand?.name || row.brand?.brandName);
          const sellerValue = row.offers?.seller?.name || row.seller?.name || row.vendor?.name || row.merchant?.name || row.sellerName || row.vendorName || row.merchantName || row.storeName;
          reviewBox.brand = reviewBox.brand || brandValue || null;
          const cleanedSeller = cleanSellerName(sellerValue);
          if (!reviewBox.seller && cleanedSeller) { reviewBox.seller = cleanedSeller; reviewBox.sellerSource = '상품 상세페이지 JSON 판매자'; }
          if (row.category) pushCategoryCandidate(candidates, splitCategoryPath(row.category), '상품 상세페이지 Product.category', row.categoryId, 100);
        }
        for (const [key, val] of Object.entries(row)) {
          if (typeof val === 'string' && /(categoryPath|fullCategoryPath|displayCategoryPath|breadcrumbPath|categoryHierarchyName)/i.test(key)) {
            pushCategoryCandidate(candidates, splitCategoryPath(val), `상품 상세페이지 JSON ${key}`, row.categoryId, 115);
          }
          if (Array.isArray(val) && /(breadcrumb|categoryHierarchy|categoryPath|categories)/i.test(key)) {
            const parts = val.map((item) => typeof item === 'string' ? item : item?.name || item?.categoryName || item?.displayName || item?.title).filter(Boolean);
            pushCategoryCandidate(candidates, parts, `상품 상세페이지 JSON ${key}`, row.categoryId, 105 + parts.length * 3);
          }
          if (!reviewBox.seller && sellerKeys.test(key)) {
            const cleanedSeller = cleanSellerName(typeof val === 'string' ? val : (val?.name || val?.displayName));
            if (cleanedSeller) { reviewBox.seller = cleanedSeller; reviewBox.sellerSource = `상품 상세페이지 JSON ${key}`; }
          }
          if (deliveryKeys.test(key)) {
            const raw = typeof val === 'string' || typeof val === 'number' || typeof val === 'boolean'
              ? `${key}:${val}`
              : `${key}:${val?.name || val?.type || val?.label || val?.text || ''}`;
            const type = deliveryTypeFromEvidence(raw);
            if (type) recordDeliveryCandidate(reviewBox, type, `상품 상세페이지 JSON ${key}`);
          }
        }
      });
    }
  }

  function extractCategoryCandidatesFromRawHtml(html, candidates) {
    const patterns = [
      [/(?:"categoryPath"|"fullCategoryPath"|"displayCategoryPath"|"breadcrumbPath")\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"/gi, 95],
      [/(?:"categoryNamePath"|"categoryHierarchyName")\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"/gi, 90],
    ];
    for (const [re, score] of patterns) {
      let m;
      while ((m = re.exec(html)) && re.lastIndex < 5_000_000) {
        let value = m[1];
        try { value = JSON.parse(`"${value}"`); } catch (_) {}
        pushCategoryCandidate(candidates, splitCategoryPath(value), '상품 상세페이지 원문 categoryPath', null, score);
      }
    }
  }

  function extractSearchCategoryContext() {
    if (typeof document === 'undefined') return { categoryPath: null, categoryId: null, source: '미확인' };
    const candidates = [];
    const selectors = [
      '[class*="breadcrumb"] a', '[class*="Breadcrumb"] a',
      'nav[aria-label*="breadcrumb" i] a', '[data-testid*="breadcrumb" i] a',
      '.breadcrumb a', '#breadcrumb a',
      '[class*="category"] [aria-current="page"]', '[class*="Category"] [aria-current="page"]'
    ];
    for (const selector of selectors) {
      const parts = cleanPath([...document.querySelectorAll(selector)].map((el) => el.textContent));
      pushCategoryCandidate(candidates, parts, '쿠팡 검색페이지 breadcrumb', null, 80 + parts.length * 3);
    }
    const selectedLinks = [...document.querySelectorAll('a[href*="/np/categories/"], a[href*="categoryId="]')]
      .filter((a) => a.getAttribute('aria-current') === 'page' || /selected|active|current/i.test(a.className || '') || /selected|active|current/i.test(a.parentElement?.className || ''));
    if (selectedLinks.length) {
      const parts = cleanPath(selectedLinks.map((a) => a.textContent));
      const href = selectedLinks[selectedLinks.length - 1]?.href || '';
      const id = href.match(/\/np\/categories\/(\d+)/)?.[1] || href.match(/[?&]categoryId=(\d+)/)?.[1] || null;
      pushCategoryCandidate(candidates, parts, '쿠팡 검색페이지 선택 카테고리', id, 75 + parts.length * 3);
    }
    let categoryId = null;
    try { categoryId = new URL(location.href).searchParams.get('categoryId'); } catch (_) {}
    const best = candidates.sort((a, b) => b.score - a.score || b.parts.length - a.parts.length)[0];
    return {
      categoryPath: best?.path || null,
      categoryId: best?.categoryId || categoryId || null,
      source: best?.source || (categoryId ? '검색 URL categoryId' : '미확인'),
    };
  }

  SPX.parseSearchCategoryContext = extractSearchCategoryContext;

  function extractSellerFromDocument(doc, html) {
    const selectors = [
      '[data-testid*="seller" i]', '[data-testid*="vendor" i]',
      '[class*="seller-name" i]', '[class*="sellerName" i]', '[class*="vendor-name" i]',
      '[class*="vendorName" i]', '[class*="storeName" i]',
      'a[href*="/vp/vendors/"]', 'a[href*="vendorId="]'
    ];
    for (const selector of selectors) {
      for (const node of doc.querySelectorAll(selector)) {
        const cleaned = cleanSellerName(node.textContent || node.getAttribute('title') || node.getAttribute('aria-label'));
        if (cleaned) return { seller: cleaned, source: `상품 상세페이지 DOM ${selector}` };
      }
    }
    const text = String(doc.body?.textContent || '').replace(/\s+/g, ' ');
    const textPatterns = [
      /판매자\s*[:：]\s*([가-힣A-Za-z0-9][가-힣A-Za-z0-9&().,_+\-\s]{1,60}?)(?=\s*(?:판매자 상품|상품문의|배송|사이즈|색상|쿠폰|적립|$))/i,
      /판매처\s*[:：]\s*([가-힣A-Za-z0-9][가-힣A-Za-z0-9&().,_+\-\s]{1,60}?)(?=\s*(?:배송|상품|$))/i,
    ];
    for (const re of textPatterns) {
      const m = text.match(re);
      const cleaned = cleanSellerName(m?.[1]);
      if (cleaned) return { seller: cleaned, source: '상품 상세페이지 판매자 표기' };
    }
    const rawPatterns = [
      /"(?:sellerName|vendorName|merchantName|storeName|vendorDisplayName|sellerDisplayName)"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"/gi,
      /(?:sellerName|vendorName|merchantName|storeName)\\?"?\s*[:=]\s*\\?"([^"\\]{2,120})/gi,
    ];
    for (const re of rawPatterns) {
      let m;
      while ((m = re.exec(html)) && re.lastIndex < 6_000_000) {
        let value = m[1];
        try { value = JSON.parse(`"${value}"`); } catch (_) {}
        const cleaned = cleanSellerName(value);
        if (cleaned) return { seller: cleaned, source: '상품 상세페이지 원문 판매자' };
      }
    }
    return { seller: null, source: null };
  }

  const PRIMARY_PRODUCT_EXCLUDED_SELECTOR='[class*="recommend" i],[id*="recommend" i],[class*="also" i],[id*="also" i],[class*="related" i],[id*="related" i],[class*="carousel" i],[class*="widget" i],[class*="advert" i],[class*="ads" i],[data-component*="recommend" i]';
  function isInsideExcludedProductWidget(node,root){
    if(!node||!root)return false;
    const excluded=node.closest?.(PRIMARY_PRODUCT_EXCLUDED_SELECTOR);
    return !!(excluded&&excluded!==root&&root.contains?.(excluded));
  }
  function queryPrimaryProductNodes(root,selectors){
    const source=root?.__spxPrimarySource||root;
    if(!source?.querySelectorAll)return [];
    return [...source.querySelectorAll(selectors)].filter((node)=>!isInsideExcludedProductWidget(node,source));
  }
  function primaryProductText(root){
    const source=root?.__spxPrimarySource||root;
    if(!source)return '';
    const textNodeFlag=source.ownerDocument?.defaultView?.NodeFilter?.SHOW_TEXT??globalThis.NodeFilter?.SHOW_TEXT??4;
    const walker=source.ownerDocument?.createTreeWalker?.(source,textNodeFlag);
    if(!walker)return String(source.textContent||'');
    const out=[];let node;
    while((node=walker.nextNode())){
      const parent=node.parentElement;
      if(parent&&!isInsideExcludedProductWidget(parent,source))out.push(node.nodeValue||'');
    }
    return out.join(' ');
  }
  function primaryProductMarkupEvidence(root){
    const source=root?.__spxPrimarySource||root;if(!source)return '';
    const attrs=['class','id','src','srcset','href','xlink:href','data-component','data-testid','aria-label','alt','title'];
    const nodes=queryPrimaryProductNodes(source,'[class],[id],[src],[srcset],[href],[data-component],[data-testid],[aria-label],[alt],[title]');
    return nodes.slice(0,2400).map((node)=>`${String(node.tagName||'').toLowerCase()} ${attrs.map((name)=>node.getAttribute?.(name)||'').filter(Boolean).join(' ')}`).join(' ');
  }
  function clonePrimaryProductRoot(doc){
    const source=doc.querySelector('.prod-buy, .prod-atf, [class*="prod-buy" i], [class*="product-buy" i], [data-component="product-atf"]')||doc.querySelector('#contents')||doc.body;
    if(!source)return source;
    /* v1.1.0: 거대한 상세 DOM deep clone 대신 읽기 전용 경량 facade를 사용합니다. */
    return {
      __spxPrimarySource:source,
      querySelectorAll:(selectors)=>queryPrimaryProductNodes(source,selectors),
      get textContent(){return primaryProductText(source);},
      get innerHTML(){return primaryProductMarkupEvidence(source);}
    };
  }
  function cleanOptionLabel(value){
    const lines=String(value||'').split(/\n+/).map((v)=>String(v).replace(/\s+/g,' ').trim()).filter(Boolean),out=[];
    for(let line of lines){line=line.replace(/[\d,]{3,}\s*원(?:부터|~)?/g,' ').replace(/\d+\s*%\s*(?:할인)?/g,' ').replace(/(?:와우|쿠폰|회원|할인)?가\s*[:：]?/g,' ').replace(/품절|일시품절|선택|필수|무료배송|도착보장|구매하기/g,' ').replace(/\s+/g,' ').trim();if(line&&!/^[-·|/]+$/.test(line)&&!out.includes(line))out.push(line);}
    return out.join(' / ');
  }
  function extractDetailPriceAndSelectedOption(doc,html,url){
    const root=clonePrimaryProductRoot(doc),raw=String(html||''),u=new URL(url,location.origin),itemId=u.searchParams.get('itemId')||'',vendorItemId=u.searchParams.get('vendorItemId')||'',productId=(u.pathname.match(/products\/(\d+)/)||[])[1]||'';
    let skuRawCache=null;
    const getSkuRawFallback=()=>{
      if(skuRawCache!==null)return skuRawCache;
      const slices=[];
      for(const token of [vendorItemId,itemId].filter(Boolean)){
        let from=0;
        for(let i=0;i<8;i++){
          const at=raw.indexOf(token,from);if(at<0)break;
          slices.push(raw.slice(Math.max(0,at-12000),Math.min(raw.length,at+12000)));from=at+token.length;
        }
      }
      skuRawCache=slices.join(' ')||raw.slice(0,500000);
      return skuRawCache;
    };
    const num=(value)=>parsePrice(value);
    const dom=(selectors)=>lowestPriceFromNodes(root,selectors);
    const skuObjects=[];
    const representativeOptionObjects=[];
    for(const jsonRoot of parseJsonRows(doc)){
      walkJson(jsonRoot,(row)=>{
        if(!row||typeof row!=='object'||Array.isArray(row))return;
        const rowVendor=String(row.vendorItemId??row.vendor_item_id??row.vendorId??'').replace(/\D/g,'');
        const rowItem=String(row.itemId??row.item_id??'').replace(/\D/g,'');
        const hasOptionField=['selectedOption','selectedOptionName','optionName','optionValue','vendorItemName','itemName','displayName'].some((key)=>row[key]!=null);
        const hasPriceField=['wowPrice','wowMemberPrice','membershipPrice','memberPrice','finalPrice','salePrice','discountPrice','sellingPrice','regularPrice','normalPrice','unitPrice','price'].some((key)=>row[key]!=null);
        const rowProduct=String(row.productId??row.product_id??row.productNo??'').replace(/\D/g,'');
        const vendorMatch=vendorItemId&&rowVendor===String(vendorItemId).replace(/\D/g,'');
        const itemMatch=itemId&&rowItem===String(itemId).replace(/\D/g,'');
        const productMatch=productId&&rowProduct===String(productId).replace(/\D/g,'');
        if((vendorMatch||itemMatch)&&!skuObjects.includes(row))skuObjects.push(row);
        /* URL에 itemId가 없거나 현재 옵션 식별자가 바뀐 상품은 동일 productId 안의 첫 대표 옵션으로 보완합니다. */
        if(hasOptionField&&hasPriceField&&(productMatch||(!rowProduct&&rowVendor))&&!representativeOptionObjects.includes(row))representativeOptionObjects.push(row);
      });
    }
    if(!skuObjects.length&&representativeOptionObjects.length)skuObjects.push(representativeOptionObjects[0]);
    const objectValues=(keys)=>{
      /* 키 배열 자체가 우선순위입니다. 같은 SKU 안에서도 적립·캐시 하위 객체는 완전히 제외합니다. */
      for(const wantedKey of keys){
        const values=[];
        const visit=(obj,depth=0,path='')=>{
          if(!obj||typeof obj!=='object'||depth>4)return;
          for(const [key,value] of Object.entries(obj)){
            const nextPath=`${path}.${key}`;
            if(REWARD_MONEY_RE.test(nextPath))continue;
            if(String(key).toLowerCase()===String(wantedKey).toLowerCase()){
              const parsed=num(typeof value==='object'?(value?.value??value?.amount??value?.price):value);
              if(parsed!==null)values.push(parsed);
            }
            if(depth<4&&!Array.isArray(value)&&value&&typeof value==='object'&&/(price|pricing|offer|sale|discount|membership|wow|product|item|vendor)/i.test(key))visit(value,depth+1,nextPath);
          }
        };
        for(const obj of skuObjects)visit(obj);
        if(values.length)return Math.min(...values);
      }
      return null;
    };
    let rawNumericFieldMapCache=null;
    const getRawNumericFieldMap=()=>{
      if(rawNumericFieldMapCache)return rawNumericFieldMapCache;
      const skuRaw=getSkuRawFallback(),map=new Map();
      const re=/"([A-Za-z][A-Za-z0-9_]*)"\s*:\s*"?([\d,]+)"?/g;
      for(const match of skuRaw.matchAll(re)){
        const around=skuRaw.slice(Math.max(0,match.index-120),Math.min(skuRaw.length,match.index+match[0].length+120));
        if(REWARD_MONEY_RE.test(around))continue;
        const value=num(match[2]);if(value===null)continue;
        const key=String(match[1]||'').toLowerCase(),values=map.get(key)||[];values.push(value);map.set(key,values);
      }
      rawNumericFieldMapCache=map;return map;
    };
    const jsonValues=(keys)=>{
      const map=getRawNumericFieldMap();
      for(const key of keys){
        const values=map.get(String(key).toLowerCase())||[];
        if(values.length)return Math.min(...values);
      }
      return null;
    };
    const rootText=String(root?.textContent||'').replace(/\s+/g,' ');
    const validPrices=(values)=>values.flat(Infinity).map((value)=>num(value)).filter((value)=>value!==null);
    const lowest=(values)=>{const valid=validPrices(values);return valid.length?Math.min(...valid):null;};
    const objectPriceCandidates=(keys)=>keys.map((key)=>objectValues([key]));
    const jsonPriceCandidates=(keys)=>keys.map((key)=>jsonValues([key]));
    const domPriceCandidates=(selectors)=>selectors.map((selector)=>dom([selector]));
    const labelPriceCandidates=(labels)=>labels.map((label)=>labeledPriceFromText(rootText,[label]));
    const wowKeys=['wowPrice','wowMemberPrice','wowMemberSalePrice','wowDiscountPrice','wowOnlyPrice','wowDealPrice','membershipPrice','memberPrice','memberSalePrice','memberDiscountPrice'];
    const couponKeys=['couponPrice','couponDiscountPrice','couponSalePrice','couponAppliedPrice','discountCouponPrice','instantCouponPrice','benefitPrice','promotionPrice','promoPrice','finalBenefitPrice'];
    const saleKeys=['finalPrice','salePrice','discountPrice','discountedPrice','sellingPrice','salesPrice','dealPrice','currentPrice'];
    const wowSelectors=['[class*="wow-price" i]','[class*="wowPrice" i]','[class*="wow_only" i]','[class*="wowOnly" i]','[class*="member-price" i]','[class*="memberPrice" i]','[data-testid*="wow" i][data-testid*="price" i]','[data-testid*="member" i][data-testid*="price" i]','[aria-label*="와우" i]'];
    const couponSelectors=['[class*="coupon-price" i]','[class*="couponPrice" i]','[class*="coupon-discount" i]','[class*="benefit-price" i]','[class*="promotion-price" i]','[data-testid*="coupon" i][data-testid*="price" i]','[data-testid*="benefit" i][data-testid*="price" i]','[aria-label*="쿠폰" i]'];
    const saleSelectors=['.prod-sale-price','.total-price strong','.prod-price .total-price','[class*="sale-price" i]','[class*="discount-price" i]','[class*="final-price" i]','[class*="price-value" i]','[data-testid*="sale" i][data-testid*="price" i]','[data-testid*="discount" i][data-testid*="price" i]'];
    const wowPrice=lowest([objectPriceCandidates(wowKeys),jsonPriceCandidates(wowKeys),domPriceCandidates(wowSelectors),labelPriceCandidates(['와우\\s*(?:회원\\s*)?(?:할인가|전용가|특가|회원가)','와우가','회원\\s*전용가'])]);
    const couponPrice=lowest([objectPriceCandidates(couponKeys),jsonPriceCandidates(couponKeys),domPriceCandidates(couponSelectors),labelPriceCandidates(['쿠폰\\s*(?:적용\\s*)?(?:할인가|적용가|혜택가)','쿠폰가','최종\\s*혜택가'])]);
    const salePrice=lowest([objectPriceCandidates(saleKeys),jsonPriceCandidates(saleKeys),domPriceCandidates(saleSelectors),labelPriceCandidates(['즉시\\s*할인가','할인가','판매가'])]);
    const metaPrice=num(doc.querySelector('meta[property="product:price:amount"],meta[property="og:price:amount"]')?.content);
    /* raw HTML의 일반적인 "price" 키는 추천상품·다른 옵션 가격과 섞일 수 있으므로 SKU가 일치한 JSON 객체에서만 허용합니다. */
    const regularPrice=objectValues(['regularPrice','normalPrice','unitPrice','price'])
      ??dom(['[class*="regular-price" i]','[class*="normal-price" i]','[class*="current-price" i]'])
      ??labeledPriceFromText(rootText,['일반\\s*판매가','정상\\s*판매가','현재\\s*판매가'])
      ??metaPrice
      ??jsonValues(['regularPrice','normalPrice','unitPrice']);
    const preferredBenefitPrice=lowest([wowPrice,couponPrice]);
    const price=preferredBenefitPrice??salePrice??regularPrice;
    const priceSource=preferredBenefitPrice!==null
      ? (wowPrice!==null&&couponPrice!==null?'상품 상세페이지 와우·쿠폰 최저 적용가':wowPrice!==null?'상품 상세페이지 와우 적용가':'상품 상세페이지 쿠폰 적용가')
      : salePrice!==null?'상품 상세페이지 할인가':regularPrice!==null?(metaPrice===regularPrice?'상품 상세페이지 현재 판매가 meta':'상품 상세페이지 일반 판매가'):'';

    /* 현재 URL의 SKU는 가격 판정에만 사용하고 옵션명 자체는 저장하지 않습니다. */
    const optionNameFromObject=(obj)=>{
      for(const key of ['selectedOptionName','selectedOption','optionName','optionValue','vendorItemName','itemName','displayName']){
        let value=obj?.[key];
        if(value&&typeof value==='object')value=value.name||value.label||value.text||value.value;
        value=cleanOptionLabel(value);if(value&&value.length<=160)return value;
      }
      return '';
    };
    const selectedFromDom=[];
    for(const el of root?.querySelectorAll?.('select[class*="option" i] option:checked,input[type="radio"]:checked + label,input[type="radio"]:checked ~ label,[aria-checked="true"],[aria-selected="true"],[class*="option" i] .selected,[class*="selected-option" i]')||[]){
      const value=cleanOptionLabel(el.textContent||el.getAttribute?.('aria-label')||el.getAttribute?.('title'));
      if(value&&!selectedFromDom.includes(value))selectedFromDom.push(value);
    }
    let selectedOption=selectedFromDom.join(' / ');
    if(!selectedOption){
      for(const option of root?.querySelectorAll?.('select[class*="option" i] option:not([disabled]),select[name*="option" i] option:not([disabled])')||[]){
        if(!option.value||/^선택|필수|옵션/i.test(String(option.textContent||'').trim()))continue;
        selectedOption=cleanOptionLabel(option.textContent);if(selectedOption)break;
      }
    }
    if(!selectedOption){
      const current=skuObjects.find((obj)=>optionNameFromObject(obj));
      selectedOption=optionNameFromObject(current);
    }
    if(!selectedOption){
      const skuRaw=getSkuRawFallback();
      for(const key of ['selectedOption','selectedOptionName','optionName','vendorItemName','itemName']){
        const re=new RegExp(`"${key}"\\s*:\\s*"([^"\\n]{1,240})"`,'ig');
        const match=re.exec(skuRaw);if(!match)continue;
        let value=match[1];try{value=JSON.parse(`"${value}"`);}catch(_){}
        selectedOption=cleanOptionLabel(value);if(selectedOption)break;
      }
    }
    return {price,wowPrice,couponPrice,salePrice,regularPrice,selectedOption,priceSource};
  }

  function extractDeliveryFromDocument(doc, html) {
    const primaryRoot = clonePrimaryProductRoot(doc);
    const roots = primaryRoot ? [primaryRoot] : [doc];
    const candidates = [];
    const add = (raw, source) => {
      const type = deliveryTypeFromEvidence(raw);
      if (type) candidates.push({ type, source });
    };
    const selectors = [
      'input[type="radio"]:checked + label', 'input[type="radio"]:checked ~ label', '[aria-checked="true"]',
      '[data-testid*="rocket" i]', '[data-testid*="delivery" i]', '[data-testid*="shipping" i]',
      '[data-delivery-type]', '[data-badge-type]', '[class*="rocket" i]', '[class*="delivery" i]',
      '[class*="shipping" i]', '[class*="badge" i]', '[id*="rocket" i]', '[id*="delivery" i]'
    ];
    for (const root of roots) {
      for (const node of [...root.querySelectorAll('img,source,svg,use')].slice(0, 420)) {
        const raw = deliveryNodeEvidence(node);
        const badge = node.tagName === 'IMG' ? deliveryTypeFromBadgeImage(node) : null;
        if (badge) candidates.push({ type:badge, source:'상품 상세페이지 배송 뱃지 이미지' });
        add(raw, '상품 상세페이지 배송 뱃지 이미지·SVG');
      }
      for (const selector of selectors) {
        for (const node of [...root.querySelectorAll(selector)].slice(0, 160)) {
          add(`${deliveryNodeEvidence(node)} ${node.textContent || ''}`, '상품 상세페이지 배송 뱃지·문구');
        }
      }
    }

    /* 모든 후보를 수집한 후 우선순위를 비교해, 무료배송 문구가 로켓 뱃지를 일반배송으로 덮지 못하게 합니다. */
    let best = null;
    for (const candidate of candidates) {
      if (!best || deliveryPriority(candidate.type) > deliveryPriority(best.type)) best = candidate;
    }
    if (best && best.type !== '일반배송') return { deliveryType:best.type, source:best.source };

    /* DOM 클래스가 난독화된 경우 원문에서 본상품 주변의 짧은 문맥만 검사합니다. */
    const plainText = String(primaryRoot?.textContent || '').replace(/\s+/g, ' ').slice(0, 500_000);
    const textWindows = plainText.match(/.{0,90}(?:로켓\s*프레시|판매자\s*로켓|판매자로켓|로켓\s*그로스|로켓\s*직구|로켓\s*설치|로켓\s*배송|로켓배송|일반배송|판매자배송).{0,140}/gi) || [];
    const primaryHtml = String(primaryRoot?.innerHTML || '');
    const rawWindows = primaryHtml.match(/.{0,120}(?:rocket[_\s-]*(?:fresh|merchant|growth|global|install|delivery|wow)|logo_rocket_[^<"']{0,80}|판매자\s*로켓|로켓\s*(?:프레시|그로스|직구|설치|배송)).{0,180}/gi) || [];
    for (const raw of [...textWindows.slice(0, 60), ...rawWindows.slice(0, 160)]) add(raw, '상품 상세페이지 원문 배송 뱃지');

    best = null;
    for (const candidate of candidates) {
      if (!best || deliveryPriority(candidate.type) > deliveryPriority(best.type)) best = candidate;
    }
    if (best && best.type !== '일반배송') return { deliveryType:best.type, source:best.source };

    /* 로켓 계열 근거가 없을 때만 택배사·배송 안내를 일반배송으로 확정합니다. */
    const carrierWindows = plainText.match(/.{0,50}(?:배송사|택배사|cj\s*대한통운|대한통운|한진택배|롯데택배|로젠택배|우체국택배|경동택배|대신택배|일양로지스|천일택배|합동택배|일반택배).{0,50}/gi) || [];
    for (const raw of carrierWindows.slice(0, 30)) {
      if (deliveryTypeFromEvidence(raw) === '일반배송') return { deliveryType:'일반배송', source:'상품 상세페이지 택배사 정보' };
    }
    if (/(?:도착\s*(?:예정|보장)|배송\s*예정|배송비|무료배송|착불|택배\s*발송)/i.test(plainText)) {
      return { deliveryType:'일반배송', source:'상품 상세페이지 일반 배송 문구' };
    }
    return { deliveryType:'일반배송', source:'상품 상세페이지 로켓 뱃지 없음·일반배송 fallback' };
  }


  function extractDetailInfo(html, url, detailOptions = {}) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const candidates = [];
    const reviewBox = { count: null, rating: null, ratingSource:null, name: null, seller: null, sellerSource: null, brand: null, deliveryType: null, deliverySource: null, monthlyPurchaseCount:null, monthlyPurchaseSource:null, soldOut: soldOutFromDetailDocument(doc) };
    const jsonRows = parseJsonRows(doc);
    const priceOptions=extractDetailPriceAndSelectedOption(doc,html,url);
    extractCategoryCandidatesFromJson(jsonRows, candidates, reviewBox);
    reviewBox.name=txt(doc,'h1.prod-buy-header__title, h1[class*="title" i], h1')||reviewBox.name;
    const jsonDeliveryType = reviewBox.deliveryType;
    const jsonDeliverySource = reviewBox.deliverySource;
    const domDelivery = extractDeliveryFromDocument(doc, html);
    /* 본상품 DOM의 명시적 로켓/판매자로켓 뱃지를 최우선으로 사용합니다.
       DOM이 단순 fallback 일반배송일 때는 JSON의 명시적 로켓 근거를 보존해 직매입 상품 유입을 막습니다. */
    if (domDelivery.deliveryType && domDelivery.deliveryType !== '일반배송') {
      reviewBox.deliveryType = domDelivery.deliveryType;
      reviewBox.deliverySource = domDelivery.source;
    } else if (jsonDeliveryType && jsonDeliveryType !== '일반배송') {
      reviewBox.deliveryType = jsonDeliveryType;
      reviewBox.deliverySource = jsonDeliverySource;
    } else {
      reviewBox.deliveryType = domDelivery.deliveryType || jsonDeliveryType || '일반배송';
      reviewBox.deliverySource = domDelivery.source || jsonDeliverySource || '상품 상세페이지 일반배송 fallback';
    }

    const breadcrumbSelectors = [
      '[class*="breadcrumb"] a', '[class*="Breadcrumb"] a',
      'nav[aria-label*="breadcrumb" i] a', '[data-testid*="breadcrumb" i] a',
      '.breadcrumb a', '#breadcrumb a',
      '[class*="breadcrumb"] span', '[class*="Breadcrumb"] span'
    ];
    for (const selector of breadcrumbSelectors) {
      const parts = cleanPath([...doc.querySelectorAll(selector)].map((el) => el.textContent));
      pushCategoryCandidate(candidates, parts, `상품 상세페이지 DOM ${selector}`, null, 110 + parts.length * 4);
    }

    const metaValues = [
      doc.querySelector('meta[property="product:category"]')?.content,
      doc.querySelector('meta[name="category"]')?.content,
      doc.querySelector('meta[property="og:category"]')?.content,
    ].filter(Boolean);
    for (const value of metaValues) pushCategoryCandidate(candidates, splitCategoryPath(value), '상품 상세페이지 meta category', null, 85);

    const categoryLinkGroups = [];
    for (const a of doc.querySelectorAll('a[href*="/np/categories/"], a[href*="categoryId="]')) {
      const parent = a.closest('nav,[class*="breadcrumb"],[class*="Breadcrumb"],[class*="category"],[class*="Category"]') || a.parentElement;
      if (!parent) continue;
      if (!categoryLinkGroups.includes(parent)) categoryLinkGroups.push(parent);
    }
    for (const group of categoryLinkGroups.slice(0, 12)) {
      const links = [...group.querySelectorAll('a[href*="/np/categories/"], a[href*="categoryId="]')];
      const parts = cleanPath(links.map((a) => a.textContent));
      const href = links[links.length - 1]?.getAttribute('href') || '';
      const id = href.match(/\/np\/categories\/(\d+)/)?.[1] || href.match(/[?&]categoryId=(\d+)/)?.[1] || null;
      pushCategoryCandidate(candidates, parts, '상품 상세페이지 카테고리 링크', id, 75 + parts.length * 3);
    }

    extractCategoryCandidatesFromRawHtml(html, candidates);

    if (reviewBox.count === null) {
      const text = doc.body?.textContent || '';
      const patterns = [
        /상품평\s*([\d,]+)\s*개/, /리뷰\s*([\d,]+)\s*개/, /\(([\d,]+)\)\s*개의\s*상품평/,
        /상품평\s*\(([\d,]+)\)/
      ];
      for (const re of patterns) {
        const m = text.match(re);
        if (m) { reviewBox.count = parseNum(m[1]); break; }
      }
    }

    if (reviewBox.rating === null) {
      const domRating=ratingFromElement(doc);
      if(domRating.value!==null){reviewBox.rating=domRating.value;reviewBox.ratingSource=`상품 상세페이지 ${domRating.source}`;}
    }
    if (reviewBox.rating === null) {
      const raw=String(html||'');
      const rawPatterns=[
        /["'](?:ratingValue|ratingScore|averageRating|reviewRating|starRating|ratingAverage)["']\s*:\s*["']?([0-5](?:\.\d{1,2})?)/i,
        /(?:ratingValue|ratingScore|averageRating|reviewRating|starRating|ratingAverage)\s*[=:]\s*["']?([0-5](?:\.\d{1,2})?)/i,
        /(?:별점|평점)\s*[:：]?\s*([0-5](?:\.\d{1,2})?)/i,
      ];
      for(const re of rawPatterns){const match=raw.match(re);const value=normalizeRatingValue(match?.[1]);if(value!==null){reviewBox.rating=value;reviewBox.ratingSource='상품 상세페이지 원문 별점';break;}}
    }

    /* 쿠팡 상세페이지의 최근 구매 문구가 있으면 28일 판매 실측 단서로 우선 사용합니다.
       과거 화면의 '최근 한 달/30일' 문구도 읽되 저장·표시 기준은 28일로 통일합니다. */
    {
      const detailText=String(doc.body?.textContent||'').replace(/\s+/g,' ');
      const purchasePatterns=[
        /최근\s*(?:한\s*)?달\s*([\d,]+)\s*(?:명|개)\s*(?:이상\s*)?구매/i,
        /최근\s*28일\s*([\d,]+)\s*(?:명|개)\s*(?:이상\s*)?구매/i,
        /최근\s*30일\s*([\d,]+)\s*(?:명|개)\s*(?:이상\s*)?구매/i,
        /한\s*달\s*([\d,]+)\s*(?:명|개)\s*(?:이상\s*)?구매/i,
      ];
      for(const re of purchasePatterns){const m=detailText.match(re);if(m){reviewBox.monthlyPurchaseCount=parseNum(m[1]);reviewBox.monthlyPurchaseSource='상품 상세페이지 최근 28일 구매 문구';break;}}
      if(reviewBox.monthlyPurchaseCount===null){
        const raw=String(html||'');const m=raw.match(/"(?:monthlyPurchaseCount|recentMonthPurchaseCount|monthlyOrderCount)"\s*:\s*"?([\d,]+)"?/i);
        if(m){reviewBox.monthlyPurchaseCount=parseNum(m[1]);reviewBox.monthlyPurchaseSource='상품 상세페이지 원문 월구매 값';}
      }
    }

    let categoryId = null;
    for (const row of candidates) if (!categoryId && row.categoryId) categoryId = row.categoryId;
    if (!categoryId) {
      for (const a of doc.querySelectorAll('a[href]')) {
        const href = a.getAttribute('href') || '';
        const m = href.match(/\/np\/categories\/(\d+)/) || href.match(/[?&]categoryId=(\d+)/);
        if (m) { categoryId = m[1]; break; }
      }
    }
    try {
      const u = new URL(url, location.origin);
      categoryId = categoryId || u.searchParams.get('categoryId') || null;
    } catch (_) {}

    if (!reviewBox.seller) {
      const sellerInfo = extractSellerFromDocument(doc, html);
      reviewBox.seller = sellerInfo.seller;
      reviewBox.sellerSource = sellerInfo.source;
    }
    if (!reviewBox.brand) {
      reviewBox.brand = txt(doc, '[class*="brand" i]') || null;
      if (reviewBox.brand) reviewBox.brand = reviewBox.brand.replace(/^브랜드\s*[:：]?\s*/,'').slice(0,120);
    }

    const best = candidates
      .filter((row) => row.parts.length >= 2)
      .sort((a, b) => b.score - a.score || b.parts.length - a.parts.length || b.path.length - a.path.length)[0]
      || candidates.sort((a, b) => b.score - a.score || b.parts.length - a.parts.length)[0];

    return {
      categoryPath: best?.path || null,
      categoryId: best?.categoryId || categoryId || null,
      categorySource: best?.source || null,
      categoryCandidates: candidates.slice(0, 10),
      detailReviews: reviewBox.count,
      detailRating: reviewBox.rating,
      detailRatingSource: reviewBox.ratingSource,
      detailName: reviewBox.name,
      detailCanonicalUrl:doc.querySelector('link[rel="canonical"]')?.getAttribute('href')||doc.querySelector('meta[property="og:url"]')?.getAttribute('content')||null,
      detailImageUrl: detailMainImageUrl(doc, html, url),
      detailMonthlyPurchaseCount: reviewBox.monthlyPurchaseCount,
      detailMonthlyPurchaseSource: reviewBox.monthlyPurchaseSource,
      seller: reviewBox.seller,
      sellerSource: reviewBox.sellerSource,
      sellerType: sellerTypeFromDelivery(reviewBox.deliveryType),
      brand: reviewBox.brand,
      deliveryType: reviewBox.deliveryType,
      deliverySource: reviewBox.deliverySource,
      soldOut: !!reviewBox.soldOut,
      detailPrice: priceOptions.price,
      detailPriceSource: priceOptions.priceSource,
      detailWowPrice: priceOptions.wowPrice,
      detailCouponPrice: priceOptions.couponPrice,
      detailSalePrice: priceOptions.salePrice,
      detailRegularPrice: priceOptions.regularPrice,
      detailOption: priceOptions.selectedOption,
      detailOptions: [],
      comparisonProducts: detailOptions.includeRecommendations===false?[]:extractComparisonProducts(doc, url, detailOptions.recommendationSections ?? null),
    };
  }

  async function fetchDetail(item, timeoutMs = 10000, detailOptions = {}) {
    item={...item,detailFetchVerified:false};
    const url = item?.productUrl;
    if (!url) return item;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, {
        credentials: 'include', signal: controller.signal, cache: 'no-store', redirect: 'follow',
        headers: { Accept: 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8' },
      });
      if (!response.ok) {
        if([403,426,429].includes(Number(response.status))){
          const reason=`상품 상세페이지 HTTP ${response.status}${response.status===429?' Too Many Requests':response.status===403?' Forbidden / Access Denied':' Upgrade Required / 접근 제한'}`;
          const blockedError=new Error(reason);blockedError.code='COUPANG_BLOCKED';blockedError.blockSource='detail-fetch';blockedError.statusCode=Number(response.status);throw blockedError;
        }
        const prior=String(item.rocketType||item.deliveryTypeRaw||'배송유형 미확인');return { ...item, rocketType:prior==='배송유형 미확인'?'배송확인실패':prior, deliveryTypeRaw:prior==='배송유형 미확인'?'배송확인실패':prior, ...deliveryFlags(prior==='배송유형 미확인'?'배송확인실패':prior), deliverySource:`상품 상세페이지 HTTP ${response.status} · 기존값 보존`, deliveryCheckStatus:'확인 실패·기존값 보존', categoryFetchStatus: `HTTP ${response.status}` };
      }
      const html = await response.text();
      if(/captcha|보안문자|사람인지 확인|비정상적인 접근|접근이 제한/i.test(html)){
        const manualVerification=/captcha|보안문자|사람인지 확인/i.test(html);
        const reason=manualVerification?'상품 상세페이지 CAPTCHA / 보안문자 감지':'상품 상세페이지 Access Denied / 접근 제한 감지';
        const blockedError=new Error(reason);blockedError.code='COUPANG_BLOCKED';blockedError.blockSource='detail-fetch';blockedError.manualVerification=manualVerification;throw blockedError;
      }
      const info = extractDetailInfo(html, response.url || url, detailOptions);
      const expectedPid=String(item.pid||item.product_id||String(url).match(PID_RE)?.[1]||'');
      const actualPid=String(response.url||url).match(PID_RE)?.[1]||'';
      const canonicalPid=String(info.detailCanonicalUrl||'').match(PID_RE)?.[1]||actualPid;
      const urlOffer=idsFromUrl(url),actualOffer=idsFromUrl(response.url||url);
      const expectedOffer={itemId:String(item.itemId||item.item_id||urlOffer.itemId||''),vendorItemId:String(item.vendorItemId||item.vendor_item_id||urlOffer.vendorItemId||'')};
      const offerMatches=(!expectedOffer.vendorItemId||expectedOffer.vendorItemId===actualOffer.vendorItemId)&&(!expectedOffer.itemId||expectedOffer.itemId===actualOffer.itemId);
      if(!expectedPid||actualPid!==expectedPid||canonicalPid!==expectedPid||!offerMatches||!String(info.detailName||'').trim()){
        return{...item,detailFetchVerified:false,deliveryCheckStatus:'상세 상품 식별 미확인',categoryFetchStatus:'상품 불일치 또는 상세 미확인'};
      }
      const priorDelivery = item.rocketType && item.rocketType !== '배송유형 미확인' ? item.rocketType : null;
      /* 정상 상품 상세페이지에서 쿠팡 직매입·판매자로켓 배지가 모두 없으면 일반배송으로 기록합니다.
         추론 여부는 source/status에 남겨 결과값과 근거를 분리합니다. */
      const detailDelivery = info.deliveryType || null;
      const detailIsExplicitRocket = detailDelivery && detailDelivery !== '일반배송';
      const priorIsDirectRocket = ['로켓배송','로켓프레시'].includes(priorDelivery);
      /* 상세페이지의 명시적 로켓 계열은 갱신하되, 상세가 일반배송 fallback일 뿐이면
         검색 카드에서 이미 잡은 쿠팡 직매입 로켓/프레시 판정을 절대 낮추지 않습니다. */
      const resolvedDeliveryType = detailIsExplicitRocket
        ? detailDelivery
        : (priorIsDirectRocket ? priorDelivery : (detailDelivery || priorDelivery || '일반배송'));
      const deliveryInferred = resolvedDeliveryType === '일반배송' && /fallback|추정/i.test(String(info.deliverySource || ''));
      return {
        ...item,
        categoryPath: info.categoryPath || item.categoryPath || null,
        categoryId: info.categoryId || item.categoryId || null,
        categorySource: info.categoryPath ? (info.categorySource || '상품 상세페이지 실측') : (item.categorySource || null),
        categoryCandidates: info.categoryCandidates || [],
        categoryFetchStatus: info.categoryPath ? '확인' : '미확인',
        searchReviews: item.searchReviews ?? item.reviews ?? null,
        detailReviews: info.detailReviews ?? null,
        reviews: info.detailReviews ?? item.reviews ?? null,
        rating: info.detailRating ?? item.rating ?? null,
        ratingSource: info.detailRating !== null && info.detailRating !== undefined ? (info.detailRatingSource || '상품 상세페이지 별점') : (item.ratingSource || null),
        ratingCheckedAt: info.detailRating !== null && info.detailRating !== undefined ? new Date().toISOString() : (item.ratingCheckedAt || null),
        name: cleanProductName(info.detailName || '') || cleanProductName(item.name || '') || String(info.detailName || item.name || '').trim(),
        detailFetchVerified:true,detailFetchedAt:new Date().toISOString(),
        imageUrl: info.detailImageUrl || item.imageUrl || item.image_url || item.thumbnail_url || null,
        image_url: info.detailImageUrl || item.image_url || item.imageUrl || item.thumbnail_url || null,
        thumbnail_url: info.detailImageUrl || item.thumbnail_url || item.image_url || item.imageUrl || null,
        price: info.detailPrice ?? item.price ?? null,
        priceSource: info.detailPrice != null ? (info.detailPriceSource || '상품 상세페이지 현재 판매가') : (item.priceSource || null),
        wow_price: info.detailWowPrice ?? item.wow_price ?? item.wowPrice ?? null,
        coupon_price: info.detailCouponPrice ?? item.coupon_price ?? item.couponPrice ?? null,
        sale_price: info.detailSalePrice ?? item.sale_price ?? item.salePrice ?? null,
        regular_price: info.detailRegularPrice ?? item.regular_price ?? item.regularPrice ?? null,
        seller: info.seller || item.seller || (['로켓배송','로켓프레시'].includes(resolvedDeliveryType) ? '쿠팡판매' : null),
        sellerDisplay: info.seller || item.seller || info.sellerType || item.sellerType || null,
        sellerType: info.sellerType || item.sellerType || sellerTypeFromDelivery(resolvedDeliveryType) || null,
        sellerSource: info.seller ? (info.sellerSource || '상품 상세페이지 실측') : (item.sellerSource || null),
        sellerCheckStatus: info.seller ? '확인' : (item.seller ? '검색결과 확인' : '미확인'),
        sellerCheckedAt: info.seller ? new Date().toISOString() : (item.sellerCheckedAt || null),
        brand: info.brand || item.brand || null,
        isSoldOut: !!(info.soldOut || item.isSoldOut),
        rocketType: resolvedDeliveryType,
        deliveryTypeRaw: resolvedDeliveryType,
        isRocket: ['로켓배송','판매자로켓','로켓그로스','로켓프레시','로켓직구','로켓설치'].includes(resolvedDeliveryType),
        ...deliveryFlags(resolvedDeliveryType),
        deliverySource: info.deliveryType ? (info.deliverySource || '상품 상세페이지 실측') : (priorDelivery ? (item.deliverySource || '검색결과 배송 배지·문구') : '상품 상세페이지 로켓 배지 없음 · 일반배송 추정'),
        deliveryCheckStatus: deliveryInferred ? '상세페이지 확인·일반배송 추정' : (info.deliveryType ? '확인' : '검색결과 확인'),
        deliveryCheckedAt: new Date().toISOString(),
        reviewSource: info.detailReviews !== null ? '상품 상세페이지 실측' : (item.reviewSource || '검색결과'),
        reviewCheckedAt: info.detailReviews !== null ? new Date().toISOString() : (item.reviewCheckedAt || null),
        detailMonthlyPurchaseCount: info.detailMonthlyPurchaseCount ?? item.detailMonthlyPurchaseCount ?? null,
        monthlyPurchaseCount: info.detailMonthlyPurchaseCount ?? item.monthlyPurchaseCount ?? null,
        monthlyPurchaseSource: info.detailMonthlyPurchaseSource || item.monthlyPurchaseSource || null,
        comparisonProducts: (info.comparisonProducts || []).map((row) => ({
          ...row,
          recommendationOriginPid: item.pid || item.product_id || row.recommendationOriginPid || null,
          recommendationOriginUrl: item.productUrl || item.product_url || row.recommendationOriginUrl || null,
        })),
      };
    } catch (error) {
      /* v4.1.0: 상세 요청에서 실제 쿠팡 차단이 확인되면 일반 상세 실패로 삼키지 않습니다.
         현재 검색 DOM은 그대로 살아 있을 수 있으므로 상위 자동수집이 체크포인트를 저장하고
         IP 변경 후 같은 문서에서 이어서 수집할 기회를 갖도록 COUPANG_BLOCKED를 그대로 전달합니다. */
      if(error?.code==='COUPANG_BLOCKED')throw error;
      /* 재수집 요청 자체가 실패했을 때 기존 상품명·판매가·배송유형을 실패값으로 덮어쓰지 않습니다.
         기존 배송값이 없을 때만 확인 실패로 표시하고, 화면에는 보존 여부를 근거로 남깁니다. */
      const prior=String(item.rocketType||item.deliveryTypeRaw||'배송유형 미확인');
      const preserved=prior!=='배송유형 미확인'&&prior!=='배송확인실패';
      const type=preserved?prior:'배송확인실패';
      return { ...item, rocketType:type, deliveryTypeRaw:type, ...deliveryFlags(type), deliverySource:`${error?.name === 'AbortError' ? '상품 상세페이지 확인 시간 초과' : '상품 상세페이지 요청 실패'}${preserved?' · 기존값 보존':''}`, deliveryCheckStatus:preserved?'확인 실패·기존값 보존':'확인 실패', categoryFetchStatus: error?.name === 'AbortError' ? '시간 초과' : '요청 실패' };
    } finally {
      clearTimeout(timer);
    }
  }

  SPX.enrichProductDetails = async function (items, options = {}) {
    const rows = Array.isArray(items) ? [...items] : [];
    const delaySettings = typeof SPX.util?.getSettings==='function' ? await SPX.util.getSettings().catch(()=>({humanDelayEnabled:true,humanDelayMinMs:2500,humanDelayMaxMs:4500})) : {humanDelayEnabled:true,humanDelayMinMs:2500,humanDelayMaxMs:4500};
    const manualMode=options.manualMode===true;
    const automatedFastPath=options.automatedFastPath===true;
    const randomInt=(min,max)=>SPX.util?.randomInt?.(min,max)??(min+Math.floor(Math.random()*(max-min+1)));
    const waitHuman = async (kind='normal') => {
      if(delaySettings.humanDelayEnabled===false)return 0;
      const rest=kind==='rest';
      let min=manualMode?(rest?delaySettings.manualDetailRestMinMs:delaySettings.manualDetailDelayMinMs):(rest?delaySettings.humanRestMinMs:delaySettings.humanDelayMinMs);
      let max=manualMode?(rest?delaySettings.manualDetailRestMaxMs:delaySettings.manualDetailDelayMaxMs):(rest?delaySettings.humanRestMaxMs:delaySettings.humanDelayMaxMs);
      /* v3.0.8.29: 연속탐색의 fastDetail은 예전 코드에서 상한만 4.5초라 기본 2.5~4.5초와
         사실상 동일했습니다. 상세상품 N/N이 느려진 핵심 원인이므로 자동 상세만 0.65~1.3초,
         주기 휴식은 2.5~4.5초 범위로 줄입니다. 단건 수동 지연값은 기존 설정을 그대로 존중합니다. */
      if(options.fastDetail===true&&automatedFastPath){
        /* v1.3.9: 자동수집은 이미 카드에서 확보한 값을 재검증하지 않는 대상만 상세로 보냅니다.
           이 요청들 사이의 고정 대기만 줄이며 대상 선정·파싱·병합·차단감지는 그대로 유지합니다. */
        if(rest){min=500;max=900;}else{min=120;max=280;}
      }else if(options.fastDetail===true&&!manualMode){if(rest){min=Math.min(Number(min)||2500,2500);max=Math.min(Number(max)||4500,4500);}else{min=650;max=1300;}}
      const safeMin=Math.max(0,Number(min)||0),safeMax=Math.max(safeMin,Number(max)||safeMin);
      const ms=Math.max(0,randomInt(safeMin,safeMax));
      if(ms>0){if(typeof SPX.util?.sleep==='function')await SPX.util.sleep(ms);else await new Promise((resolve)=>setTimeout(resolve,ms));}
      return ms;
    };
    const rawLimit = Number(options.limit);
    const baseLimit = Number.isFinite(rawLimit) ? Math.max(0, Math.min(80, rawLimit)) : 16;
    const externallyActive = typeof options.shouldContinue === 'function' ? options.shouldContinue : () => true;
    let detailStopped=false;
    const shouldContinue=()=>!detailStopped&&externallyActive();
    const reportProgress = typeof options.onProgress === 'function' ? options.onProgress : () => {};
    const checkpoint=()=>{if(shouldContinue()&&typeof options.onCheckpoint==='function')options.onCheckpoint(rows.map(row=>({...row})));};
    const priorityPids = new Set((options.priorityPids || []).map(String));
    /* v4.0.30: 효자 후보는 PID가 있는데 검색 DOM 전략에 따라 productUrl만 빠지는 경우가 있습니다.
       이 상태를 상세수집 불가로 버리지 않고 PID/itemId/vendorItemId로 정상 상세 URL을 복원합니다. */
    const ensureDetailProductUrl=(item={})=>{
      const direct=String(item?.productUrl||item?.product_url||item?.url||'').trim();
      if(/^https:\/\/(?:www\.)?coupang\.com\/vp\/products\/\d+/i.test(direct))return direct;
      const pid=String(item?.pid||item?.product_id||'').replace(/\D/g,'');
      if(!pid)return direct;
      const params=new URLSearchParams();
      const itemId=String(item?.itemId||item?.item_id||'').replace(/\D/g,'');
      const vendorItemId=String(item?.vendorItemId||item?.vendor_item_id||'').replace(/\D/g,'');
      if(itemId)params.set('itemId',itemId);if(vendorItemId)params.set('vendorItemId',vendorItemId);
      return `https://www.coupang.com/vp/products/${pid}${params.size?`?${params.toString()}`:''}`;
    };
    for(const item of rows){if(!item||typeof item!=='object')continue;const url=ensureDetailProductUrl(item);if(url){item.productUrl=url;if(!item.product_url)item.product_url=url;if(!item.url)item.url=url;}}
    const unresolved = (item) => {
      const delivery = String(item?.rocketType || item?.deliveryTypeRaw || '배송유형 미확인');
      return delivery === '배송유형 미확인' || delivery === '배송확인실패';
    };
    const finiteDetailValue=(...values)=>{for(const value of values){if(value===null||value===undefined||value==='')continue;const n=Number(value);if(Number.isFinite(n))return n;}return null;};
    /* v3.0.7.29: 검색카드에 이미 배송·별점·리뷰·판매가가 모두 있는 효자후보까지
       상세페이지를 다시 열던 중복 요청을 제거합니다. 상세 확인은 실제 누락값이 있는
       후보에만 수행하고, 카드에서 확보한 값은 그대로 최종 집계에 사용합니다. */
    const needsPriorityVerification=(item)=>{
      const rating=finiteDetailValue(item?.rating,item?.averageRating,item?.average_rating,item?.ratingValue,item?.starRating,item?.star_rating,item?.detailRating,item?.detail_rating);
      const reviews=finiteDetailValue(item?.reviews,item?.searchReviews,item?.detailReviews,item?.cumulative_reviews,item?.review_count);
      const price=finiteDetailValue(item?.price,item?.sale_price,item?.discountPrice,item?.wowPrice);
      const observedSales=finiteDetailValue(item?.observed_monthly_sales,item?.detail_monthly_purchase_count,item?.monthly_purchase_count,item?.recent_purchase_count,item?.estimated_monthly_sales,item?.monthly_sales);
      const image=String(item?.imageUrl||item?.image_url||item?.thumbnail_url||item?.thumbnail||item?.productImage||item?.product_image||'').trim();
      return unresolved(item)||rating===null||rating<=0||reviews===null||price===null||observedSales===null||!image;
    };
    const failFastEnabled = delaySettings.failFastDetailEnabled !== false;
    const minDetailPrice = Math.max(0, Number(options.minDetailPrice) || 0);
    const maxDetailPrice = Math.max(minDetailPrice, Number(options.maxDetailPrice) || Number.MAX_SAFE_INTEGER);
    const passesFailFast = (item) => {
      if (!item || item.isAd || item.isSoldOut) return false;
      const detailUrl=ensureDetailProductUrl(item);if(!detailUrl)return false;
      item.productUrl=detailUrl;if(!item.product_url)item.product_url=detailUrl;if(!item.url)item.url=detailUrl;
      const knownDelivery=getDeliveryType(item.rocketType||item.deliveryTypeRaw||item.delivery_type||'');
      /* 쿠팡 직매입 로켓배송·로켓프레시는 상세 요청 전 즉시 제외합니다. */
      if(knownDelivery==='로켓배송'||knownDelivery==='로켓프레시')return false;
      if (!failFastEnabled) return true;
      const price = Number(item.price);
      if (Number.isFinite(price) && (price < minDetailPrice || price > maxDetailPrice)) return false;
      if (!Number.isFinite(price) && !priorityPids.has(String(item?.pid || item?.product_id || ''))) return false;
      return true;
    };
    const ranked = rows
      .map((item, index) => ({ item, index }))
      .filter(({ item }) => {
        if(SPX.isSupplementaryProduct?.(item))return false;
        if(!passesFailFast(item))return false;
        const priority=priorityPids.has(String(item?.pid || item?.product_id || ''));
        return unresolved(item)||(priority&&needsPriorityVerification(item));
      })
      .sort((a, b) => {
        const ap = priorityPids.has(String(a.item?.pid || a.item?.product_id || '')) ? 1 : 0;
        const bp = priorityPids.has(String(b.item?.pid || b.item?.product_id || '')) ? 1 : 0;
        if (ap !== bp) return bp - ap;
        const au = unresolved(a.item) ? 1 : 0, bu = unresolved(b.item) ? 1 : 0;
        if (au !== bu) return bu - au;
        const ar = Number(a.item?.reviews) || 0, br = Number(b.item?.reviews) || 0;
        if (ar !== br) return br - ar;
        return Number(a.item?.organicRank ?? a.item?.rank ?? 999999) - Number(b.item?.organicRank ?? b.item?.rank ?? 999999);
      });
    const priorityCount = ranked.filter(({ item }) => priorityPids.has(String(item?.pid || item?.product_id || ''))).length;
    /* v4.0.30: 효자 후보 17개 중 일부만 이미지·별점을 갖는 현상을 막기 위해 우선 효자 후보의
       누락 상세값은 최대 40개까지 확인합니다. 일반 상품 표본을 늘리는 것이 아니라 priorityPids 중
       실제 누락값이 있는 후보만 대상이므로 등급·수집 표본은 바뀌지 않습니다. */
    const priorityCap=40;
    const priorityLimit=Math.max(baseLimit,Math.min(priorityCap,Number(options.priorityLimit)||priorityCap));
    const limit = Math.min(80, Math.max(baseLimit, Math.min(priorityCount,priorityLimit)));
    const targetIndexes = ranked.slice(0, limit);
    const wantsRecommendations=options.collectComparisonCandidates!==false&&options.mediaOnly!==true&&String(options.keyword||'').trim();
    const requestedSeedLimit=Number(options.comparisonSeedLimit);
    const seedLimit=Number.isFinite(requestedSeedLimit)?Math.max(0,Math.min(3,requestedSeedLimit)):3;
    if(wantsRecommendations&&seedLimit&&targetIndexes.length===0){
      const selected=new Set(targetIndexes.map(row=>row.index));
      const seeds=rows.map((item,index)=>({item,index})).filter(({item})=>item&&!SPX.isSupplementaryProduct?.(item)&&!item.isAd&&!item.isSoldOut&&ensureDetailProductUrl(item));
      for(const seed of seeds.slice(0,seedLimit)){
        if(selected.has(seed.index)||(seed.item.comparisonProducts||[]).length)continue;
        selected.add(seed.index);targetIndexes.push(seed);
      }
    }
    const restRequestMin=Math.max(2,Math.min(200,Number(delaySettings.humanRestRequestMin)||10));
    const restRequestMax=Math.max(restRequestMin,Math.min(300,Number(delaySettings.humanRestRequestMax)||15));
    const randomRestCount=()=>SPX.util?.randomInt?.(restRequestMin,restRequestMax)??(restRequestMin+Math.floor(Math.random()*(restRequestMax-restRequestMin+1)));
    let detailRequestCount=0,nextDetailRestAt=randomRestCount(),cursor=0;
    const configuredConcurrency=manualMode?(options.concurrency??delaySettings.manualDetailConcurrency):(options.concurrency??delaySettings.detailConcurrency);
    const requestedConcurrency=Number(configuredConcurrency)||(manualMode?3:1);
    const concurrency=Math.max(1,Math.min(manualMode?5:2,options.fastDetail===true&&!manualMode?Math.max(2,requestedConcurrency):requestedConcurrency));
    const takeNext=()=>cursor<targetIndexes.length?targetIndexes[cursor++]:null;
    const worker=async()=>{
      while(shouldContinue()){
        const target=takeNext();if(!target)break;
        const requestNumber=++detailRequestCount;reportProgress(`상세상품 ${requestNumber}/${targetIndexes.length} 준비`);
        const restDue=delaySettings.humanDelayEnabled!==false&&requestNumber>=nextDetailRestAt;
        if(restDue)nextDetailRestAt=requestNumber+randomRestCount();
        await waitHuman(restDue?'rest':'normal');
        if(!shouldContinue())break;
        const itemTimeoutMs=Math.max(9000,Math.min(30000,Number(options.itemTimeoutMs)||15000));
        let hardTimer=0;
        const timeoutRow=new Promise((resolve)=>{hardTimer=setTimeout(()=>resolve({...target.item,detailTimedOut:true,deliverySource:`상품 상세 확인 ${Math.round(itemTimeoutMs/1000)}초 초과 · 검색카드 기존값 보존`,deliveryCheckStatus:'시간 초과·기존값 보존',categoryFetchStatus:'시간 초과'}),itemTimeoutMs);});
        let fetched;try{fetched=await Promise.race([fetchDetail(target.item,Math.min(10000,itemTimeoutMs-1000),{recommendationSections:options.recommendationSections,keyword:options.keyword}),timeoutRow]);}catch(error){detailStopped=true;throw error;}finally{clearTimeout(hardTimer);}
        if(!shouldContinue())break;
        if(options.mediaOnly===true){
          const base=target.item||{},rating=finiteDetailValue(fetched?.rating,fetched?.averageRating,fetched?.average_rating,fetched?.ratingValue,fetched?.starRating,fetched?.detailRating),image=String(fetched?.imageUrl||fetched?.image_url||fetched?.thumbnail_url||fetched?.thumbnail||'').trim();
          rows[target.index]={...base,productUrl:fetched?.productUrl||base.productUrl,product_url:fetched?.product_url||base.product_url||fetched?.productUrl,url:fetched?.url||base.url||fetched?.productUrl};
          if(rating!==null&&rating>0){rows[target.index].rating=rating;rows[target.index].averageRating=rating;rows[target.index].average_rating=rating;rows[target.index].ratingSource=fetched?.ratingSource||fetched?.rating_source||'상품 상세페이지 미디어 보강';}
          if(image){rows[target.index].imageUrl=image;rows[target.index].image_url=image;rows[target.index].thumbnail_url=image;}
        }else rows[target.index]=fetched;
        checkpoint();
        reportProgress(`상세상품 ${requestNumber}/${targetIndexes.length} 완료${rows[target.index]?.detailTimedOut?' · 시간초과 건너뜀':''}`);
      }
    };
    await Promise.all(Array.from({length:Math.min(concurrency,targetIndexes.length||1)},()=>worker()));

    /* '함께 비교하면 좋을 상품'은 노출 자체로 효자상품에 포함하지 않습니다.
       대표키워드 관련성 → 상세페이지 재방문 → 배송유형·판매자·리뷰·품절을 다시 확인한 뒤,
       일반배송·판매자로켓·로켓그로스 상품만 보조 후보로 추가합니다. */
    if ((options.collectComparisonCandidates !== false || options.supplementaryCandidates) && shouldContinue()) {
      const observed=new Map();
      for(const source of options.collectComparisonCandidates!==false?rows:[])for(const item of source?.comparisonProducts||[]){
        const key=[item.pid||'',item.vendorItemId||item.itemId||'',item.name||''].join('|');
        if(!observed.has(key))observed.set(key,item);
      }
      if(observed.size&&typeof options.onRecommendationCandidates==='function')await options.onRecommendationCandidates([...observed.values()]);
      if(!shouldContinue())return rows;
      const keyword = String(options.keyword || '').trim();
      const offerKey=row=>SPX.productIdentityKey?.(row)||[row?.pid||row?.product_id||'',row?.vendorItemId||row?.vendor_item_id||row?.itemId||'',row?.rocketType||row?.deliveryTypeRaw||''].join('|');
      // Delivery can be unknown on one card. Exact seller/option IDs still identify a reusable offer.
      const requestKey=row=>{
        const url=ensureDetailProductUrl(row);let params;
        try{params=new URL(url).searchParams;}catch(_){}
        const vendor=String(row?.vendorItemId||row?.vendor_item_id||params?.get('vendorItemId')||'');
        const item=String(row?.itemId||row?.item_id||params?.get('itemId')||'');
        return [String(row?.pid||row?.product_id||''),vendor?'vendor:'+vendor:item?'item:'+item:'default'].join('|');
      };
      const existing = new Set(rows.map(requestKey));
      const verifiedOffers=new Set(rows.map(offerKey));
      const candidates = [];
      const configuredLimit=Number(options.comparisonCandidateLimit);
      const comparisonLimit = Number.isFinite(configuredLimit)?Math.max(0,Math.min(20,configuredLimit)):8;
      const addCandidate=(candidate,isSort=false)=>{
          const pid = String(candidate?.pid || candidate?.product_id || '');
          if (!pid || existing.has(requestKey(candidate)) || candidate?.isAd || candidate?.isSoldOut) return;
          const url=ensureDetailProductUrl(candidate);if(!url)return;
          const knownDelivery=getDeliveryType(candidate.rocketType||candidate.deliveryTypeRaw||candidate.deliveryType||'');
          if(isSort&&(['로켓배송','로켓프레시','로켓직구'].includes(knownDelivery)||Number(candidate.reviews)>SPX.WINNER_REVIEW_MAX))return;
          const relevance = recommendationKeywordRelevance(keyword, candidate.name || candidate.product_name);
          if (relevance.score < 60) return;
          existing.add(requestKey(candidate));
          candidates.push({
            ...candidate,
            productUrl:url,
            keywordRelevanceScore:relevance.score,
            keywordRelevanceStatus:relevance.status,
            sourceType:isSort?'keyword_sort_candidate':'detail_comparison_candidate',
            discoverySource:isSort?`키워드2 ${candidate.sourceSort==='latestAsc'?'최신순':'판매량순'} 1페이지`:`상품 상세페이지 ${candidate.recommendationLabel||'추천상품'}`,
          });
      };
      for(const candidate of observed.values()){
        if(candidates.length>=comparisonLimit)break;
        addCandidate(candidate);
      }
      const sorted=await (options.supplementaryCandidates||[]);
      if(!shouldContinue())return rows;
      const recommendationCount=candidates.length;
      const configuredSortLimit=Number(options.supplementaryCandidateLimit);
      const sortLimit=Number.isFinite(configuredSortLimit)?Math.max(0,Math.min(20-recommendationCount,configuredSortLimit)):Math.min(8,20-recommendationCount);
      for(const candidate of Array.isArray(sorted)?sorted:[]){
        if(candidates.length-recommendationCount>=sortLimit)break;
        addCandidate(candidate,true);
      }
      const comparisonTargets=candidates;
      /* v3.0.7.29: 추천상품 상세 확인을 1개씩 직렬로 처리하면 실패 타임아웃까지
         최대 8개가 누적되어 수십 초가 추가됩니다. 자동수집은 최대 2개, 단건 분석은
         최대 3개만 동시에 확인해 차단 위험은 낮게 유지하면서 대기시간을 줄입니다. */
      const comparisonConcurrency=Math.max(1,Math.min(manualMode?3:2,Number(options.comparisonConcurrency)||(manualMode?3:2)));
      let comparisonCursor=0;
      const verifyComparison=async()=>{
        while(shouldContinue()){
          const index=comparisonCursor++;if(index>=comparisonTargets.length)break;
          const candidate=comparisonTargets[index];const isSort=candidate.sourceType==='keyword_sort_candidate';
          reportProgress(`${isSort?'키워드2 보조상품':'추천상품'} 상세 ${index+1}/${comparisonTargets.length} 확인`);
          await waitHuman('normal');if(!shouldContinue())break;
          let item;
          try{item=await fetchDetail(candidate,7000,{includeRecommendations:false,keyword});}catch(error){detailStopped=true;throw error;}
          if(!shouldContinue())break;
          const delivery=String(item?.rocketType||item?.deliveryTypeRaw||'배송유형 미확인');
          const allowed=['판매자로켓','로켓그로스','일반배송'].includes(delivery);
          const relevance=recommendationKeywordRelevance(keyword,item?.name||item?.product_name);
          const verified=allowed&&!item?.isAd&&!item?.isSoldOut
            &&relevance.score>=60
            &&item?.detailFetchVerified===true;
          const finalOffer=offerKey(item);
          if(verified&&!verifiedOffers.has(finalOffer)){
            verifiedOffers.add(finalOffer);
            rows.push({
            ...item,
            sourceType:isSort?'keyword_sort_verified':'detail_comparison_verified',
            discoverySource:`${candidate.discoverySource} · 상세 재검증`,
            recommendationVerified:true,
            keywordRelevanceScore:relevance.score,
            keywordRelevanceStatus:relevance.status,
            rank:null,
            exposureRank:null,rankGlobal:null,
            organicRank:null,
            parserStrategy:isSort?'keyword-sort-verified':'detail-comparison-verified',
            });
            checkpoint();
          }
        }
      };
      await Promise.all(Array.from({length:Math.min(comparisonConcurrency,comparisonTargets.length||1)},()=>verifyComparison()));
      checkpoint();
    }
    return rows;
  };

  SPX.parseProductDetailHtml = extractDetailInfo;
  SPX.extractComparisonProducts = extractComparisonProducts;
  SPX.recommendationKeywordRelevance = recommendationKeywordRelevance;


  function visibleText(el) {
    if (!el) return '';
    try {
      const style = getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      if (style.display === 'none' || style.visibility === 'hidden' || rect.width <= 0 || rect.height <= 0) return '';
    } catch (_) {}
    return String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function numberAfterLabel(text, labels) {
    for (const label of labels) {
      const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const re = new RegExp(`${escaped}\\s*(?:[:：]|-|–)?\\s*(?:약\\s*)?([0-9][0-9,]*(?:\\.[0-9]+)?)\\s*(만|천|억)?`, 'i');
      const m = text.match(re);
      if (!m) continue;
      let value = Number(String(m[1]).replace(/,/g, ''));
      if (!Number.isFinite(value)) continue;
      if (m[2] === '천') value *= 1000;
      if (m[2] === '만') value *= 10000;
      if (m[2] === '억') value *= 100000000;
      return Math.round(value);
    }
    return null;
  }

  function textAfterLabel(text, labels) {
    for (const label of labels) {
      const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const m = text.match(new RegExp(`${escaped}\\s*(?:[:：]|-|–)?\\s*([^|·,/]{1,24})`, 'i'));
      if (m) return m[1].trim();
    }
    return null;
  }

  /**
   * SellerLife/셀러라이프처럼 다른 확장프로그램이 쿠팡 페이지 DOM에 표시한 값의 선택적 감지입니다.
   * 다른 확장프로그램의 비공개 API나 chrome-extension:// iframe에는 접근하지 않습니다.
   */
  SPX.parseExternalMarketMetrics = function () {
    if (typeof document === 'undefined') return { detected: false };
    const labels = ['최근 1달','1달 예상','경쟁강도','상품수','평균가','최대판매가','총리뷰수'];
    const candidates = [];
    for (const el of document.querySelectorAll('aside,section,article,table,div')) {
      const text = visibleText(el);
      if (text.length < 20 || text.length > 1800) continue;
      const hits = labels.reduce((n, label) => n + (text.includes(label) ? 1 : 0), 0);
      if (hits >= 3) candidates.push({ el, text, hits });
    }
    candidates.sort((a,b) => b.hits-a.hits || a.text.length-b.text.length);
    const best = candidates[0];
    if (!best) return { detected: false };
    const text = best.text;
    const sourceName = /셀러라이프|seller\s*life|셀록홈즈/i.test(text) ? 'SellerLife 화면 DOM' : '외부 시장분석 화면 DOM';
    const monthlySearch = numberAfterLabel(text, ['최근 1달 검색량','최근 1달','월간 검색량','월 검색량']);
    const estimatedSales = numberAfterLabel(text, ['1달 예상 판매량','월 예상 판매량','예상 판매량']);
    const estimatedRevenue = numberAfterLabel(text, ['1달 예상 매출','월 예상 매출','예상 매출','월매출']);
    return {
      detected: true,
      source: sourceName,
      monthly_search_volume: monthlySearch,
      estimated_monthly_sales: estimatedSales,
      estimated_monthly_revenue: estimatedRevenue,
      competition_strength: textAfterLabel(text, ['경쟁강도','경쟁 강도']),
      product_count: numberAfterLabel(text, ['상품수','상품 수']),
      average_price: numberAfterLabel(text, ['평균가','평균 가격']),
      max_sale_price: numberAfterLabel(text, ['최대판매가','최대 판매가']),
      total_reviews: numberAfterLabel(text, ['총리뷰수','총 리뷰수','전체 리뷰수']),
      captured_at: new Date().toISOString(),
      raw_preview: text.slice(0, 500),
    };
  };

  /** [v2.7.2] 스크롤과 DOM 파싱을 같은 프레임에서 실행하지 않습니다.
   *  이동 → 비동기 렌더링 정지 확인 → 가벼운 개수 확인 → 다음 이동 순서로 분리합니다. */
  SPX.autoScroll = async function (onTick, shouldContinue = null, options = {}) {
    const canContinue = () => !shouldContinue || shouldContinue() !== false;
    const randomInt=(min,max)=>SPX.util.randomInt?.(Math.round(min),Math.round(max))??Math.round(min+Math.random()*(max-min));
    const expandedRange=(rawMin,rawMax,fallbackMin,fallbackMax)=>{
      let min=Number(rawMin),max=Number(rawMax);
      if(!Number.isFinite(min)||min<=0)min=fallbackMin;
      if(!Number.isFinite(max)||max<=0)max=fallbackMax;
      if(max<min)[min,max]=[max,min];
      if(max===min){const spread=Math.max(18,Math.round(min*.12));min=Math.max(1,min-spread);max+=spread;}
      return [Math.round(min),Math.round(max)];
    };
    const rangeValue=(min,max)=>options.random===true?randomInt(min,max):Math.round((Number(min)+Number(max))/2);
    const isBackground=()=>typeof options.isBackground==='function'?options.isBackground()===true:document.visibilityState!=='visible';
    const wait=async(ms)=>{
      const delay=Math.max(0,Math.round(Number(ms)||0));
      if(typeof options.wait==='function')return options.wait(delay);
      return SPX.util.sleep(delay);
    };
    const nextFrame=()=>isBackground()?wait(45):new Promise((resolve)=>{
      let done=false;const fallback=setTimeout(()=>{if(done)return;done=true;resolve();},120);
      requestAnimationFrame(()=>{if(done)return;done=true;clearTimeout(fallback);resolve();});
    });
    const smoothScrollBy=async(distance,duration=randomInt(220,460))=>{
      const total=Math.round(Number(distance)||0);
      if(!total||!canContinue())return canContinue();
      /* 백그라운드 탭에서는 requestAnimationFrame이 완전히 멈출 수 있습니다.
         이때는 애니메이션 프레임을 기다리지 않고 같은 거리만 즉시 이동하고,
         서비스워커 기반 wait로 DOM 로딩 시간을 줍니다. 수집 범위/판정은 바꾸지 않습니다. */
      if(isBackground()){
        window.scrollBy(0,total);
        await wait(Math.max(60,Math.min(180,Math.round(Number(duration)||100))));
        return canContinue();
      }
      const started=performance.now();
      let previous=0;
      while(canContinue()){
        await nextFrame();
        const elapsed=performance.now()-started;
        const t=Math.min(1,elapsed/Math.max(80,duration));
        /* 실제 휠처럼 처음에는 움직임이 붙고 마지막에는 미세하게 감속합니다. */
        const eased=1-Math.pow(1-t,3);
        const target=Math.round(total*eased);
        const delta=target-previous;
        if(delta){window.scrollBy(0,delta);previous=target;}
        if(t>=1)break;
      }
      return canContinue();
    };
    const resolveProductMutationTarget=()=>{
      const direct=document.querySelector('#productList,.search-product-list,[class*="search-product-list" i],[data-testid*="product-list" i],[class*="search-product" i][class*="list" i]');
      if(direct)return direct;
      const firstProduct=document.querySelector('a[href*="/vp/products/"]');
      return firstProduct?.closest?.('ul,ol,[role="list"],[class*="list" i]')||document.body;
    };
    const waitForDomQuiet=async(baseMin,baseMax)=>{
      const [pauseMin,pauseMax]=expandedRange(baseMin,baseMax,250,850);
      await wait(rangeValue(pauseMin,pauseMax));
      const mutationTarget=resolveProductMutationTarget();
      if(!canContinue()||!mutationTarget)return false;
      const quietFor=randomInt(100,220),maxWait=randomInt(900,1650),started=performance.now();
      let lastMutation=performance.now();
      const observer=new MutationObserver(()=>{lastMutation=performance.now();});
      observer.observe(mutationTarget,{subtree:true,childList:true,attributes:false});
      try{
        while(canContinue()&&performance.now()-started<maxWait){
          await nextFrame();
          await nextFrame();
          if(performance.now()-lastMutation>=quietFor)return true;
        }
        return canContinue();
      }finally{observer.disconnect();}
    };
    const fastScrollV1714=options.fastMode===true; // OPT-IN only, not a change to stable/manual mode
    const [stepMin,stepMax]=expandedRange(options.stepMin,options.stepMax,150,450);
    const [delayBaseMin,delayBaseMax]=expandedRange(options.delayMin,options.delayMax,250,850);
    let lastCount=-1,stable=0,scrollsUntilPause=randomInt(3,5);
    for(let i=0;i<40;i++){
      if(!canContinue())return false;
      /* High-speed: move directly in conservative, viewport-relative steps.
         Keep DOM quiet checks, per-card parsing, stop and block recovery unchanged. */
      const step=rangeValue(stepMin,stepMax); /* v1.7.15: no viewport override or hidden 650px cap */
      const overshoot=!fastScrollV1714&&Math.random()<0.20;
      let actualStep=step;
      if(overshoot){
        const extra=randomInt(50,150);
        actualStep=step+extra;
        if(!await smoothScrollBy(actualStep,randomInt(250,520)))return false;
        await wait(randomInt(200,400));
        const correction=randomInt(30,80);
        if(!await smoothScrollBy(-correction,randomInt(120,260)))return false;
        actualStep-=correction;
      }else if(fastScrollV1714){
        window.scrollBy(0,step);
      }else{
        if(!await smoothScrollBy(step,randomInt(220,480)))return false;
      }
      document.dispatchEvent(new CustomEvent('spx:auto-scroll-tick',{detail:{step:actualStep,direction:1,pattern:overshoot?'overshoot-correct':'ease-out'}}));
      scrollsUntilPause-=1;
      if(scrollsUntilPause<=0){
        if(!fastScrollV1714&&Math.random()<0.30)await wait(randomInt(1500,3500));
        scrollsUntilPause=randomInt(3,5);
      }
      const quiet=await waitForDomQuiet(delayBaseMin,delayBaseMax); /* v1.7.15: use exact configured delay range */
      if(!quiet||!canContinue())return false;
      /* DOM이 멈춘 뒤 링크 수만 확인합니다. 상품 파싱·집계는 자동스크롤 종료 후 실행됩니다. */
      const count=document.querySelectorAll('a[href*="/vp/products/"]').length;
      if(onTick)onTick(count);
      /* High-speed avoids declaring a stable list complete before reaching the page bottom. */
      if(count===lastCount){stable+=1;if(stable>=3&&(!fastScrollV1714||window.scrollY+window.innerHeight>=Math.max(document.body?.scrollHeight||0,document.documentElement?.scrollHeight||0)-32))break;}else{stable=0;lastCount=count;}
      const height=Math.max(document.body?.scrollHeight||0,document.documentElement?.scrollHeight||0);
      if(window.scrollY+window.innerHeight>=height-randomInt(8,32))break;
    }
    if(!canContinue())return false;
    window.scrollTo({top:0,left:0,behavior:'auto'});
    await waitForDomQuiet(250,550);
    return canContinue();
  };

  /** 검색결과의 전체 상품 수를 가능한 범위에서 추출합니다. 실패하면 null.
   * 화면 문구뿐 아니라 Next.js/쿠팡 초기 JSON의 totalCount 계열도 확인합니다.
   * 현재 페이지 카드 수는 전체상품수로 사용하지 않습니다.
   */
  SPX.parseResultTotal = function () {
    const validTotal = (value) => {
      const n = Number(String(value ?? '').replace(/[^0-9]/g, ''));
      return Number.isFinite(n) && n >= 1 && n <= 100000000 ? n : null;
    };
    const selectors = [
      '[class*="searchResult"]', '[class*="resultCount"]', '[class*="totalCount"]',
      '[data-testid*="result-count" i]', '[aria-label*="검색결과"]', '#searchOptionForm', '.search-query-result'
    ];
    const texts = [];
    for (const sel of selectors) document.querySelectorAll(sel).forEach((el) => texts.push(el.textContent || ''));
    texts.push((document.body?.innerText || '').slice(0, 30000));
    const patterns = [
      /(?:총|전체)\s*([\d,]+)\s*(?:개|건)/,
      /([\d,]+)\s*개의\s*검색결과/,
      /검색결과\s*(?:총\s*)?([\d,]+)\s*(?:개|건)/,
      /([\d,]+)\s*(?:개|건)의\s*상품/
    ];
    for (const text of texts) for (const re of patterns) {
      const match = String(text || '').match(re); const n = validTotal(match?.[1]); if (n) return n;
    }
    const jsonPatterns = [
      /["'](?:totalCount|totalResultCount|searchResultCount|totalProducts|productCount|totalProductCount|totalElements)["']\s*:\s*["']?([\d,]+)["']?/ig,
      /\\"(?:totalCount|totalResultCount|searchResultCount|totalProducts|productCount|totalProductCount|totalElements)\\"\s*:\s*\\?"?([\d,]+)\\?"?/ig
    ];
    for (const script of document.scripts || []) {
      const text = String(script.textContent || '');
      if (!text || text.length > 3000000) continue;
      for (const re of jsonPatterns) {
        re.lastIndex = 0;
        let match;
        while ((match = re.exec(text))) { const n = validTotal(match[1]); if (n) return n; }
      }
    }
    return null;
  };

})();
