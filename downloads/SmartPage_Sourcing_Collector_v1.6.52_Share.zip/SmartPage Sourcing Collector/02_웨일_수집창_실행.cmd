@echo off
chcp 65001 >nul
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\crosspc\02_OPEN_COLLECTOR.ps1" -BrowserFamily whale
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" pause
exit /b %RC%
