﻿@echo off
setlocal
echo ==== SmartPage Ex Network Helper V7 Diagnostics ====
echo.
echo.
echo [Windows network adapters - independent of SmartPage Helper]
powershell -NoProfile -Command "Get-NetAdapter -ErrorAction SilentlyContinue ^| Sort-Object ifIndex ^| Select-Object ifIndex,Name,InterfaceDescription,Status,LinkSpeed ^| Format-Table -AutoSize"
echo.
echo [Windows IPv4 default route]
powershell -NoProfile -Command "Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue ^| Sort-Object RouteMetric,ifMetric ^| Select-Object ifIndex,InterfaceAlias,NextHop,RouteMetric,ifMetric ^| Format-Table -AutoSize"
echo.
echo [Processes]
tasklist /FI "IMAGENAME eq SpxNetworkHost.exe"
tasklist /FI "IMAGENAME eq powershell.exe"
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter 'Name=''powershell.exe''' ^| Where-Object { $_.CommandLine -like '*run-network-host.ps1*' } ^| Select-Object ProcessId,CommandLine ^| Format-List"
echo.
echo [Native launcher / runtime files]
dir "%ProgramData%\SmartPageEx\NetworkHostV33\SpxNetworkHost.exe" 2^>nul
dir "%ProgramData%\SmartPageEx\NetworkHostV33\SpxNetworkHost*.dll" 2^>nul
dir "%ProgramData%\SmartPageEx\NetworkHostV33\run-network-host.ps1" 2^>nul
echo.
echo [Ports]
netstat -ano | findstr ":30765 :30766 :30767 :30768 :30769"
echo [Previous V31 ports - diagnostic only]
netstat -ano | findstr ":29765 :29766 :29767 :29768 :29769"
echo.
echo [Native Messaging manifest]
if exist "%ProgramData%\SmartPageEx\NetworkHostV33\com.smartpage.spx_network_v7.json" (
  type "%ProgramData%\SmartPageEx\NetworkHostV33\com.smartpage.spx_network_v7.json"
) else (
  echo Native Messaging manifest not found.
)
echo.
echo [Installed helper config]
if exist "%ProgramData%\SmartPageEx\NetworkHostV33\network-host-config.json" (
  type "%ProgramData%\SmartPageEx\NetworkHostV33\network-host-config.json"
) else (
  echo Network helper config not found.
)
echo.
echo [Native Messaging registry]
reg query "HKCU\Software\Google\Chrome\NativeMessagingHosts\com.smartpage.spx_network_v7" /ve
reg query "HKLM\Software\Google\Chrome\NativeMessagingHosts\com.smartpage.spx_network_v7" /ve
reg query "HKLM\Software\WOW6432Node\Google\Chrome\NativeMessagingHosts\com.smartpage.spx_network_v7" /ve
echo.
echo [Interactive bridge task]
schtasks /Query /TN "SmartPageEx Network Local Bridge" /V /FO LIST
echo.
schtasks /Query /TN "SmartPageEx Network Bridge Recovery" /V /FO LIST
echo.
echo [Interactive browser launcher task]
schtasks /Query /TN "SmartPageEx Open Dedicated Browser" /V /FO LIST
echo.
echo [Install report]
if exist "%ProgramData%\SmartPageEx\NetworkHostV33\network-host-v18-install-report.txt" (
  type "%ProgramData%\SmartPageEx\NetworkHostV33\network-host-v18-install-report.txt"
) else (
  echo No V18 install report.
)
echo.
echo [Last installer status]
if exist "%TEMP%\SmartPageEx-network-install-status.txt" (
  type "%TEMP%\SmartPageEx-network-install-status.txt"
) else (
  echo No installer status file.
)
echo.
echo [Interactive launcher ready]
if exist "%ProgramData%\SmartPageEx\NetworkHostV33\dedicated-window-launcher.ready" (
  type "%ProgramData%\SmartPageEx\NetworkHostV33\dedicated-window-launcher.ready"
) else (
  echo Interactive launcher is not ready.
)
echo.
echo [Latest dedicated window result]
if exist "%ProgramData%\SmartPageEx\NetworkHostV33\dedicated-window-result.json" (
  type "%ProgramData%\SmartPageEx\NetworkHostV33\dedicated-window-result.json"
) else (
  echo No dedicated window result.
)
echo.
echo [Recent bridge log]
if exist "%ProgramData%\SmartPageEx\NetworkHostV33\local-bridge.log" (
  powershell -NoProfile -Command "Get-Content -LiteralPath '%ProgramData%\SmartPageEx\NetworkHostV33\local-bridge.log' -Tail 50"
) else (
  echo No bridge log.
)
echo.
echo [Recent dedicated browser launch log]
if exist "%ProgramData%\SmartPageEx\NetworkHostV33\dedicated-window-launch.log" (
  powershell -NoProfile -Command "Get-Content -LiteralPath '%ProgramData%\SmartPageEx\NetworkHostV33\dedicated-window-launch.log' -Tail 50"
) else (
  echo No dedicated browser launch log.
)
echo.
echo === Administrator one-shot routing runner log ===
if exist "%ProgramData%\SmartPageEx\NetworkHostV33\network-switch-runner.log" powershell -NoProfile -Command "Get-Content -LiteralPath '%ProgramData%\SmartPageEx\NetworkHostV33\network-switch-runner.log' -Tail 30"
echo.
echo === Administrator one-shot routing task ===
schtasks /Query /TN "SmartPageEx Network Switch" /V /FO LIST
echo.
echo === v3.0.8.2 command queues ===
for %%D in (network-command-queue-v3082 network-processing-queue-v3082 network-result-queue-v3082) do (
  echo [%%D]
  if exist "%ProgramData%\SmartPageEx\NetworkHostV33\%%D" (dir /B "%ProgramData%\SmartPageEx\NetworkHostV33\%%D") else (echo not found)
)
echo.
pause
