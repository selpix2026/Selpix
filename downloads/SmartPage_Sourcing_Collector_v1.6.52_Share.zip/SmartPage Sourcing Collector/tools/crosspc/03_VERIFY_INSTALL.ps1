﻿$ErrorActionPreference='Stop'
$Root=Join-Path $env:ProgramData 'SmartPageEx\SmartPage Sourcing Collector'
function Find-NormalChromePath{
  $candidates=New-Object System.Collections.Generic.List[string]
  foreach($key in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe','HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe')){try{$v=[string](Get-Item -LiteralPath $key -ErrorAction Stop).GetValue('');if($v){$candidates.Add($v)}}catch{}}
  foreach($candidate in @((Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'),(Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),$(if(${env:ProgramFiles(x86)}){Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'}else{$null}))){if($candidate){$candidates.Add([string]$candidate)}}
  foreach($candidate in $candidates){if($candidate -and(Test-Path -LiteralPath $candidate -PathType Leaf)){return [IO.Path]::GetFullPath($candidate)}}
  return $null
}
$Chrome=Find-NormalChromePath
$Base=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$Config=Join-Path $Base 'network-host-config.json'
$Manifest=Join-Path $Root 'manifest.json'
$Native=Join-Path $Base 'com.smartpage.spx_network_v7.json'
$Launcher=Join-Path $Base 'open-dedicated-window.ps1'
$FirstWing=Join-Path $Root 'tools\crosspc\01_FIRST_RUN_WING_SETUP.ps1'
$ok=$true
function Check([string]$Name,[bool]$Value){Write-Host ($Name+'='+$Value);if(-not$Value){$script:ok=$false}}
Check 'CollectorRoot' (Test-Path -LiteralPath $Root -PathType Container)
Check 'Manifest' (Test-Path -LiteralPath $Manifest -PathType Leaf)
Check 'NormalGoogleChrome' (-not[string]::IsNullOrWhiteSpace($Chrome))
Check 'NetworkHostConfig' (Test-Path -LiteralPath $Config -PathType Leaf)
Check 'NativeManifest' (Test-Path -LiteralPath $Native -PathType Leaf)
Check 'DedicatedLauncher' (Test-Path -LiteralPath $Launcher -PathType Leaf)
Check 'FirstWingSetup' (Test-Path -LiteralPath $FirstWing -PathType Leaf)
if(Test-Path -LiteralPath $Manifest){$m=Get-Content -LiteralPath $Manifest -Raw -Encoding UTF8|ConvertFrom-Json;Check 'ManifestVersionValid' (([string]$m.version) -match '^\d+\.\d+\.\d+$');Check 'ManifestVersionAligned' ([string]$m.version -eq [string]$m.version_name)}
if(Test-Path -LiteralPath $Config){$c=Get-Content -LiteralPath $Config -Raw -Encoding UTF8|ConvertFrom-Json;Check 'ExtensionId' ([string]$c.extensionId -eq 'olmpllofoggohefbdkgkjjnlanfnaocd');Check 'ExtensionRoot' ([IO.Path]::GetFullPath([string]$c.extensionRoot).TrimEnd('\') -eq [IO.Path]::GetFullPath($Root).TrimEnd('\'))}
if(Test-Path -LiteralPath $Launcher){$t=Get-Content -LiteralPath $Launcher -Raw -Encoding UTF8;Check 'NormalChromeLauncher' ($t -match 'NORMAL_CHROME_V1514');Check 'WingDirectPac' ($t -match 'SPX_WING_DEFAULT_NETWORK_PAC_V1');Check 'WingDirectLaunchMode' ($t -match "launchMode.*wing-direct" -or $t -match "wing-direct.*directDefaultNetwork") }
if(Test-Path -LiteralPath $FirstWing){$w=Get-Content -LiteralPath $FirstWing -Raw -Encoding UTF8;Check 'WingUsesInteractiveLauncher' ($w -match 'Request-InteractiveWindow' -and $w -match "LaunchMode 'wing-direct'");Check 'WingUsesDedicatedLauncherOnly' ($w -match 'Request-InteractiveWindow')}
try{$h=Invoke-RestMethod -UseBasicParsing -Uri 'http://127.0.0.1:30765/health' -TimeoutSec 3;Check 'NetworkHostHealth' ($h.ok -eq $true -or [int]$h.proxyPort -ge 30766)}catch{Check 'NetworkHostHealth' $false}

# v1.5.16 normal Chrome extension persistence / stale-launcher checks
try{
  $openScript=Join-Path $Root 'tools\crosspc\02_OPEN_COLLECTOR.ps1'
  $registerScript=Join-Path $Root 'tools\crosspc\08_REGISTER_COLLECTOR_NORMAL_CHROME.ps1'
  $refreshScript=Join-Path $Root 'tools\crosspc\09_REFRESH_NORMAL_CHROME_LAUNCHER.ps1'
  Check 'LauncherRefreshTool' (Test-Path -LiteralPath $refreshScript -PathType Leaf)
  if(Test-Path -LiteralPath $openScript){$o=Get-Content -LiteralPath $openScript -Raw -Encoding UTF8;Check 'NormalChromeNoDeadLoadExtension' ($o -notmatch '--load-extension=' -and $o -notmatch '--disable-extensions-except=')}
  if(Test-Path -LiteralPath $registerScript){$r=Get-Content -LiteralPath $registerScript -Raw -Encoding UTF8;Check 'DedicatedProfileRegistrationHelper' ($r -match 'register-direct' -and $r -match 'Test-Registered');Check 'RegisterRejectsStaleLauncherFlags' ($r -match '--load-extension' -and $r -match '--disable-extensions-except' -and $r -match 'Get-CimInstance Win32_Process')}
  if(Test-Path -LiteralPath $Launcher){$lt=Get-Content -LiteralPath $Launcher -Raw -Encoding UTF8;Check 'InstalledLauncherNoDeadFlags' ($lt -notmatch '--load-extension=' -and $lt -notmatch '--disable-extensions-except=')}
}catch{Check 'NormalChromePersistenceChecks' $false}

if($ok){Write-Host 'FINAL=CROSS_PC_VERIFY_PASS' -ForegroundColor Green;exit 0}else{Write-Host 'FINAL=CROSS_PC_VERIFY_FAIL' -ForegroundColor Red;exit 1}
