@echo off
chcp 65001 >nul
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\crosspc\08_REGISTER_COLLECTOR_NORMAL_CHROME.ps1" -BrowserFamily whale
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" pause
exit /b %RC%
