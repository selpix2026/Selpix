@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp001_REGISTER_COLLECTOR_COMPANION.ps1"
set RC=%ERRORLEVEL%
echo ExitCode=%RC%
pause
exit /b %RC%
