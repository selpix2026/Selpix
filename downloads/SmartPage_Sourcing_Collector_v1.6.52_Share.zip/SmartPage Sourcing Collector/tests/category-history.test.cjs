const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const {runtime,root,sourceFunction}=require('./helpers.cjs');
test('category suggestions retain product provenance without invented keyword metrics',()=>{
  const ctx=runtime();vm.runInContext(fs.readFileSync(root+'/src/lib/discovery.js','utf8'),ctx);
  const rows=ctx.SPX.discovery.categoryKeywordCandidates([{pid:'1',name:'스테인리스 보온 텀블러'},{pid:'2',name:'스테인리스 보온 텀블러'},{pid:'3',name:'휴대용 물병'}],{categoryPath:'주방 > 물병'});
  assert.ok(rows.length>0);assert.ok(rows.length<=2);
  assert.equal(rows[0].discovery_source,'category_product');assert.equal(rows[0].source_category_path,'주방 > 물병');
  assert.equal(rows[0].monthly_search_volume,undefined);assert.equal(rows[0].rank,undefined);
});
test('partial upload keeps failed and unattempted items selected',async()=>{
  const keys=Array.from({length:12},(_,i)=>'k'+i),requests=[];
  const ctx=vm.createContext({msg:async(type,payload)=>{requests.push(payload);return{results:[{key:'k0',ok:true},{key:'k1',ok:false,transient:true}]};}});
  vm.runInContext(sourceFunction('src/history/history.js','uploadVerifiedHistoryRows'),ctx);
  const result=await ctx.uploadVerifiedHistoryRows(keys);
  assert.equal(requests.length,1);assert.deepEqual(Array.from(result.succeeded),['k0']);
  assert.equal(result.deferred.length,11);assert.equal(result.unattempted,8);
});
async function database(){
  const fake=require('fake-indexeddb'),ctx=runtime({indexedDB:new fake.IDBFactory(),IDBKeyRange:fake.IDBKeyRange,structuredClone});
  vm.runInContext(fs.readFileSync(root+'/src/lib/db.js','utf8'),ctx);return ctx.SPX.db;
}
test('filtered all-selection returns only matching pending keys',async()=>{
  const db=await database();
  await db.saveAggregate({keyword:'텀블러',marketplace:'coupang',date:'2026-01-01',grade:'B',status:'pending'});
  await db.saveAggregate({keyword:'우산',marketplace:'coupang',date:'2026-01-01',grade:'B',status:'pending'});
  const result=await db.pendingHistoryKeysV1635(25001,'텀블러');
  assert.equal(result.keys.length,1);assert.ok(result.keys[0].includes('텀블러'));
});
test('retention cleanup preserves pending aggregates',async()=>{
  const db=await database();
  const pending=await db.saveAggregate({keyword:'텀블러',marketplace:'coupang',date:'2020-01-01',grade:'B',status:'pending'});
  await db.purge(90,30);assert.ok(await db.getAggregate(pending.k));
});
