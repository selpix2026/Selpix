﻿param(
  [string]$SourceRoot='',
  [switch]$Elevated,
  [switch]$Quiet
)
$ErrorActionPreference='Stop'
try{$utf8=New-Object Text.UTF8Encoding($false);[Console]::InputEncoding=$utf8;[Console]::OutputEncoding=$utf8;$OutputEncoding=$utf8}catch{}
$InstalledRoot=Join-Path $env:ProgramData 'SmartPageEx\SmartPage Sourcing Collector'
$SyncStatusBase=Join-Path $env:ProgramData 'SmartPageEx'
$SyncErrorPath=Join-Path $SyncStatusBase 'runtime-sync-last-error.txt'
trap {
  $detail=($_|Out-String).Trim()
  try{New-Item -ItemType Directory -Path $SyncStatusBase -Force|Out-Null;[IO.File]::WriteAllText($SyncErrorPath,$detail,(New-Object Text.UTF8Encoding($false)))}catch{}
  Write-Host $detail -ForegroundColor Red
  exit 1
}
Remove-Item -LiteralPath $SyncErrorPath -Force -ErrorAction SilentlyContinue
if([string]::IsNullOrWhiteSpace($SourceRoot)){$SourceRoot=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)}
$SourceRoot=[IO.Path]::GetFullPath($SourceRoot).TrimEnd('\')
$InstalledRoot=[IO.Path]::GetFullPath($InstalledRoot).TrimEnd('\')
function Test-Admin{$id=[Security.Principal.WindowsIdentity]::GetCurrent();$p=New-Object Security.Principal.WindowsPrincipal($id);return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}
function Same-Path([string]$A,[string]$B){try{return [string]::Equals([IO.Path]::GetFullPath($A).TrimEnd('\'),[IO.Path]::GetFullPath($B).TrimEnd('\'),[StringComparison]::OrdinalIgnoreCase)}catch{return $false}}
function Copy-Tree([string]$Source,[string]$Destination){New-Item -ItemType Directory -Path $Destination -Force|Out-Null;foreach($item in @(Get-ChildItem -LiteralPath $Source -Force -ErrorAction Stop)){Copy-Item -LiteralPath $item.FullName -Destination $Destination -Recurse -Force}}
# SPX_V160_SAME_VERSION_PACKAGE_REPAIR: manifest version can stay 1.6.2 while the installer scripts are repaired.
# Compare critical package files so a repaired 1.6.2 ZIP can overwrite an earlier broken 1.6.2 ProgramData copy.
function Get-FileShaSafe([string]$Path){try{if(Test-Path -LiteralPath $Path -PathType Leaf){return ([string](Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash).ToLowerInvariant()}}catch{};return ''}
function Test-CriticalPackageMismatch([string]$Source,[string]$Installed){
  $critical=@(
    'tools\crosspc\10_SYNC_CURRENT_PACKAGE_TO_INSTALLED_ROOT.ps1',
    'tools\crosspc\08_REGISTER_COLLECTOR_NORMAL_CHROME.ps1',
    'tools\network-host\install-network-host.ps1',
    'tools\network-host\SpxNetworkHost.cs',
    'tools\network-host\open-dedicated-window.ps1',
    'tools\network-host\network-worker.ps1',
    'src\lib\aggregate.js',
    'src\background\service-worker-core.js',
    'src\content\coupang-search.js',
    'src\options\options.js'
  )
  foreach($relative in $critical){
    $sourceFile=Join-Path $Source $relative;$installedFile=Join-Path $Installed $relative
    $sourceSha=Get-FileShaSafe $sourceFile;$installedSha=Get-FileShaSafe $installedFile
    if([string]::IsNullOrWhiteSpace($sourceSha) -or [string]::IsNullOrWhiteSpace($installedSha) -or $sourceSha-ne$installedSha){return $true}
  }
  return $false
}
$sourceManifest=Join-Path $SourceRoot 'manifest.json'
if(-not(Test-Path -LiteralPath $sourceManifest -PathType Leaf)){throw '현재 패키지 manifest.json을 찾지 못했습니다.'}
$sourceJson=Get-Content -LiteralPath $sourceManifest -Raw -Encoding UTF8|ConvertFrom-Json
$sourceVersion=[string]$sourceJson.version
if([string]::IsNullOrWhiteSpace($sourceVersion)){throw '현재 패키지 version을 확인하지 못했습니다.'}
if(-not(Test-Admin)){
  $args='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath.Replace('"','""')+'" -SourceRoot "'+$SourceRoot.Replace('"','""')+'" -Elevated'+$(if($Quiet){' -Quiet'}else{''})
  $proc=Start-Process "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Verb RunAs -ArgumentList $args -Wait -PassThru
  exit $proc.ExitCode
}
# Only the isolated SmartPage Chrome is stopped. Personal Chrome and user/server data stay untouched.
$profile='C:\SpxDedicatedProfile'
try{$targets=@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe' OR Name='whale.exe'" -ErrorAction SilentlyContinue|Where-Object{[string]$_.CommandLine -match '(?i)(?:^|\s)--user-data-dir=(?:"C:\\SpxDedicatedProfile(?:-Whale)?"|C:\\SpxDedicatedProfile(?:-Whale)?)(?:\s|$)'});foreach($proc in $targets){try{Stop-Process -Id ([int]$proc.ProcessId) -Force -ErrorAction SilentlyContinue}catch{}};if($targets.Count){Start-Sleep -Milliseconds 700}}catch{}
$needSync=(-not(Same-Path $SourceRoot $InstalledRoot))
$installedVersion=''
if($needSync -and (Test-Path -LiteralPath (Join-Path $InstalledRoot 'manifest.json') -PathType Leaf)){
  try{
    $installedJson=Get-Content -LiteralPath (Join-Path $InstalledRoot 'manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
    $installedVersion=[string]$installedJson.version
    $sourceV=$null;$installedV=$null
    try{$sourceV=[version]$sourceVersion}catch{}
    try{$installedV=[version]$installedVersion}catch{}
    if($null-ne$sourceV -and $null-ne$installedV){
      if($sourceV -lt $installedV){$needSync=$false;if(-not$Quiet){Write-Host ('더 최신 고정 설치본을 보존합니다 · package v'+$sourceVersion+' / installed v'+$installedVersion) -ForegroundColor DarkYellow}}
      elseif($sourceV -eq $installedV){
        $criticalMismatch=Test-CriticalPackageMismatch -Source $SourceRoot -Installed $InstalledRoot
        $needSync=$criticalMismatch
        if($criticalMismatch -and -not$Quiet){Write-Host ('동일 버전 v'+$sourceVersion+'이지만 설치 복구 파일이 달라 ProgramData를 다시 동기화합니다.') -ForegroundColor Yellow}
      }
      else{$needSync=$true}
    }elseif($installedVersion -eq $sourceVersion){$needSync=(Test-CriticalPackageMismatch -Source $SourceRoot -Installed $InstalledRoot)}
  }catch{$needSync=$true}
}
if($needSync){
  $backupBase=Join-Path $env:ProgramData 'SmartPageEx\CollectorSourceBackup';New-Item -ItemType Directory -Path $backupBase -Force|Out-Null
  if(Test-Path -LiteralPath $InstalledRoot){$backup=Join-Path $backupBase ('before-runtime-sync-v'+($sourceVersion -replace '[^0-9A-Za-z._-]','_')+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss'));Move-Item -LiteralPath $InstalledRoot -Destination $backup -Force;if(-not$Quiet){Write-Host ('기존 고정 설치본 백업: '+$backup) -ForegroundColor DarkYellow}}
  Copy-Tree -Source $SourceRoot -Destination $InstalledRoot
}
$installedManifest=Get-Content -LiteralPath (Join-Path $InstalledRoot 'manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
$finalInstalledVersion=[string]$installedManifest.version
$sourceCheck=$null;$installedCheck=$null;try{$sourceCheck=[version]$sourceVersion}catch{};try{$installedCheck=[version]$finalInstalledVersion}catch{}
if($null-ne$sourceCheck -and $null-ne$installedCheck){if($installedCheck -lt $sourceCheck){throw ('고정 설치본 버전 동기화 실패 · source '+$sourceVersion+' / installed '+$finalInstalledVersion)}}elseif($finalInstalledVersion -ne $sourceVersion){throw ('고정 설치본 버전 확인 실패 · source '+$sourceVersion+' / installed '+$finalInstalledVersion)}
# SPX_V160_NETWORKHOST_REFRESH: v1.6.2 changes selected-adapter routing inside NetworkHost itself.
# RUN_08 must therefore refresh the installed DLL when /health still reports an older build.
$expectedNetworkBuild='v3.0.45-v1651-coupang-only'
$networkBase=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$networkRestartRequiredFlag=Join-Path $networkBase 'v161-networkhost-restart-required.json'
$deferredTaskName='SmartPageEx Network Helper Deferred Upgrade'
$networkInstaller=Join-Path $InstalledRoot 'tools\network-host\install-network-host.ps1'
$needNetworkHostRefresh=$true
try{
  $health=Invoke-RestMethod -Uri 'http://127.0.0.1:30765/health' -Method Get -TimeoutSec 2 -ErrorAction Stop
  if($null-ne$health -and [string]$health.buildMarker -eq $expectedNetworkBuild -and $health.proxyReady -eq $true){$needNetworkHostRefresh=$false;Remove-Item -LiteralPath $networkRestartRequiredFlag -Force -ErrorAction SilentlyContinue}
}catch{}
if($needNetworkHostRefresh){
  if(-not(Test-Path -LiteralPath $networkInstaller -PathType Leaf)){throw 'v1.6.2 NetworkHost 갱신 도구를 찾지 못했습니다.'}
  if(-not$Quiet){Write-Host 'v1.6.2 NetworkHost 선택망 정책/사용량 계측을 설치합니다.' -ForegroundColor Cyan}
  $networkInstallStatus=Join-Path $env:TEMP 'SmartPageEx-network-install-status.txt'
  Remove-Item -LiteralPath $networkInstallStatus -Force -ErrorAction SilentlyContinue
  & "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $networkInstaller -ExtensionId 'olmpllofoggohefbdkgkjjnlanfnaocd' -ExtensionRootOverride $InstalledRoot -Elevated
  if($LASTEXITCODE -ne 0){
    $networkInstallDetail=''
    try{if(Test-Path -LiteralPath $networkInstallStatus -PathType Leaf){$networkInstallDetail=(Get-Content -LiteralPath $networkInstallStatus -Raw -ErrorAction Stop).Trim()}}catch{}
    if(-not[string]::IsNullOrWhiteSpace($networkInstallDetail)){Write-Host ("NetworkHost 갱신 실패 상세:`n"+$networkInstallDetail) -ForegroundColor Red}
    throw ('v1.6.2 NetworkHost 갱신 실패 · ExitCode='+$LASTEXITCODE+$(if([string]::IsNullOrWhiteSpace($networkInstallDetail)){''}else{' · 상세='+$networkInstallDetail}))
  }

  # SPX_V160_DEFERRED_UPGRADE_ACCEPT: install-network-host deliberately preserves a compatible live bridge
  # and stages the new helper for the next Windows restart. That is a successful safe-install state, not a RUN_08 failure.
  $networkReadyNow=$false
  try{
    $health=Invoke-RestMethod -Uri 'http://127.0.0.1:30765/health' -Method Get -TimeoutSec 3 -ErrorAction Stop
    if([string]$health.buildMarker -eq $expectedNetworkBuild -and $health.proxyReady -eq $true){$networkReadyNow=$true}
  }catch{}
  if($networkReadyNow){
    Remove-Item -LiteralPath $networkRestartRequiredFlag -Force -ErrorAction SilentlyContinue
  }else{
    $deferredReady=$false;$config=$null;$task=$null
    try{$config=Get-Content -LiteralPath (Join-Path $networkBase 'network-host-config.json') -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop}catch{}
    try{$task=Get-ScheduledTask -TaskName $deferredTaskName -ErrorAction SilentlyContinue}catch{}
    if($null-ne$config -and [string]$config.targetBuildMarker -eq $expectedNetworkBuild -and $config.upgradePending -eq $true -and $null-ne$task){$deferredReady=$true}
    if(-not$deferredReady){
      $liveMarker='';try{$liveMarker=[string]$health.buildMarker}catch{}
      throw ('v1.6.2 NetworkHost 갱신 후 현재 실행본/재시작 예약을 확인하지 못했습니다. live='+$liveMarker)
    }
    New-Item -ItemType Directory -Path $networkBase -Force|Out-Null
    $currentBuildMarker='';try{$currentBuildMarker=[string]$health.buildMarker}catch{}
    $flag=[ordered]@{restartRequired=$true;targetBuildMarker=$expectedNetworkBuild;currentBuildMarker=$currentBuildMarker;deferredTask=$deferredTaskName;createdAt=(Get-Date).ToUniversalTime().ToString('o')}
    [IO.File]::WriteAllText($networkRestartRequiredFlag,($flag|ConvertTo-Json -Depth 4),(New-Object Text.UTF8Encoding($false)))
    if(-not$Quiet){Write-Host 'NetworkHost v1.6.2 안전 업그레이드 예약 완료 · Windows 재시작 1회 후 활성화됩니다.' -ForegroundColor Yellow}
  }
}

$refresh=Join-Path $InstalledRoot 'tools\crosspc\09_REFRESH_NORMAL_CHROME_LAUNCHER.ps1'
if(-not(Test-Path -LiteralPath $refresh -PathType Leaf)){throw '동기화된 설치본에서 launcher 복구 도구를 찾지 못했습니다.'}
& "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $refresh -Elevated -Quiet
if($LASTEXITCODE -ne 0){throw ('전용창 launcher 동기화 실패 · ExitCode='+$LASTEXITCODE)}
if(-not$Quiet){Write-Host ('✅ 고정 설치 경로/전용창 launcher 정합 완료 · installed v'+$finalInstalledVersion) -ForegroundColor Green}
exit 0
