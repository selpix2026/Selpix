﻿param(
  [string]$ExtensionId = '',
  [string]$ExtensionRootOverride = '',
  [switch]$Elevated,
  [switch]$DeferredUpgrade
)

$ErrorActionPreference = 'Stop'
try {
  $utf8Console = New-Object System.Text.UTF8Encoding($false)
  [Console]::InputEncoding = $utf8Console
  [Console]::OutputEncoding = $utf8Console
  $OutputEncoding = $utf8Console
} catch { }
$NetworkTaskName = 'SmartPageEx Network Switch'
$BridgeTaskName = 'SmartPageEx Network Local Bridge'
$BrowserTaskName = 'SmartPageEx Open Dedicated Browser'
$IntegrationSettingsTaskName = 'SmartPageEx Open Integration Settings'
$RecoveryTaskName = 'SmartPageEx Network Bridge Recovery'
$DeferredUpgradeTaskName = 'SmartPageEx Network Helper Deferred Upgrade'
$OldBridgeServiceName = 'SmartPageExNetworkBridge'
$NativeHostName = 'com.smartpage.spx_network_v7'
$StatusPath = Join-Path $env:TEMP 'SmartPageEx-network-install-status.txt'
$KnownExtensionId = 'olmpllofoggohefbdkgkjjnlanfnaocd'
$PlatformToolsUrl = 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip'
$BridgeToken = 'spx-v7-8e3c0af4640b4a20a1d706a1fba5e6d7'
$ExpectedHelperVersion = '3.0.45'
$ExpectedBuildMarker = 'v3.0.45-v1651-coupang-only'
$PackageRelease = 'v4.2.01'
$PackageReleaseMarker = 'SmartPageEx-NetworkHost-Package=v4.2.01'
$BridgeMutexName = 'Global\SmartPageExNetworkBridgeV33'
$DeferredExecutionMutexName = 'Global\SmartPageExNetworkDeferredUpgradeV426'
$DeferredStatusBaseDir = Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$DeferredStatusJsonPath = Join-Path $DeferredStatusBaseDir 'deferred-upgrade-status.json'
$DeferredStatusTextPath = Join-Path $DeferredStatusBaseDir 'deferred-upgrade-status.txt'
$DeferredStatusWriteErrorPath = Join-Path $DeferredStatusBaseDir 'deferred-upgrade-status-write-error.txt'
$ExpectedHelperSourceSha = '20f555e05d9a606806c22415cc092677534b4e10151d95f3e47be007824774bb'
$ExpectedStartScriptSha = '5df8836f9f49f627afb4c3a5be5bf87753516e6a3370eb779b1cf5da54dd4327'
$ExpectedLauncherSha = 'ae5dfdcbe18aba16a7857c7afc0da83cc1a8dcf3e5a96f8dd204d9f83d109c55'
$script:BridgeInstallMutex = $null
$script:BridgeInstallMutexOwned = $false
$script:DeferredExecutionMutex = $null
$script:DeferredExecutionMutexOwned = $false
$script:DeferredAttemptId = if($DeferredUpgrade){[Guid]::NewGuid().ToString('N')}else{''}
$script:DeferredStartedAt = if($DeferredUpgrade){(Get-Date).ToUniversalTime().ToString('o')}else{''}
$script:DeferredPhase = if($DeferredUpgrade){'STARTING'}else{'NOT_DEFERRED'}
$script:DeferredStatusWriteError = $null
$script:DeferredCleanupError = $null
$script:NativeRegistrationTemporarilyRemoved = $false

function Write-InstallStatus([string]$Text) { try { [IO.File]::WriteAllText($StatusPath,$Text,(New-Object Text.UTF8Encoding($true))) } catch { } }

function Get-InstallerSha256([string]$Path){
  if(-not(Test-Path -LiteralPath $Path -PathType Leaf)){return $null}
  $sha=[Security.Cryptography.SHA256]::Create()
  try{
    $fs=New-Object IO.FileStream($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
    try{return ([BitConverter]::ToString($sha.ComputeHash($fs))).Replace('-','').ToLowerInvariant()}
    finally{$fs.Dispose()}
  }finally{$sha.Dispose()}
}

function Get-FileSha256Lower([string]$Path){
  return (Get-InstallerSha256 $Path)
}

function Install-NativeLauncherLockSafe{
  param(
    [Parameter(Mandatory=$true)][string]$SourcePath,
    [Parameter(Mandatory=$true)][string]$DestinationPath
  )
  if(-not(Test-Path -LiteralPath $SourcePath -PathType Leaf)){throw ('Native launcher source is missing: '+$SourcePath)}
  $sourceHash=Get-FileSha256Lower $SourcePath
  if([string]::IsNullOrWhiteSpace([string]$sourceHash)){throw ('Native launcher source SHA-256 could not be read: '+$SourcePath)}
  if($sourceHash-ne$ExpectedLauncherSha){throw ('Native launcher package SHA-256 mismatch. Expected '+$ExpectedLauncherSha+' but got '+$sourceHash+'.')}

  if(Test-Path -LiteralPath $DestinationPath -PathType Leaf){
    $existingHash=$null
    try{$existingHash=Get-FileSha256Lower $DestinationPath}catch{}
    if($existingHash-eq$sourceHash){
      # Existing native launcher is already identical. Reuse it even if a live process keeps the EXE file locked.
      Write-Host '기존 Native launcher가 현재 패키지와 동일하여 잠금 상태 그대로 안전 재사용합니다.' -ForegroundColor DarkGray
      return [pscustomobject]@{Path=$DestinationPath;Reused=$true;Sha256=$sourceHash}
    }
  }

  try{
    Copy-Item -LiteralPath $SourcePath -Destination $DestinationPath -Force -ErrorAction Stop
  }catch{
    # A race can lock the file between the first hash read and Copy-Item. If the installed bytes are already
    # identical, this is not an installation failure; the launcher is version-neutral and delegates to the
    # freshly installed run-network-host.ps1 + versioned helper DLL.
    $afterHash=$null
    try{$afterHash=Get-FileSha256Lower $DestinationPath}catch{}
    if($afterHash-eq$sourceHash){
      Write-Host 'Native launcher copy 경합이 있었지만 설치된 EXE가 이미 동일하여 재사용합니다.' -ForegroundColor DarkGray
      return [pscustomobject]@{Path=$DestinationPath;Reused=$true;Sha256=$sourceHash}
    }
    throw ('Native launcher replacement failed and installed EXE differs from this package. Close SmartPage helper processes or restart Windows once. '+$_.Exception.Message)
  }

  $installedHash=Get-FileSha256Lower $DestinationPath
  if($installedHash-ne$sourceHash){throw ('Native launcher post-copy SHA-256 mismatch. Expected '+$sourceHash+' but got '+[string]$installedHash+'.')}
  return [pscustomobject]@{Path=$DestinationPath;Reused=$false;Sha256=$installedHash}
}

function Write-DeferredStatusWriteError([string]$Text){
  $script:DeferredStatusWriteError=$Text
  $payload=('timestamp='+(Get-Date).ToUniversalTime().ToString('o')+"`r`n"+'attemptId='+$script:DeferredAttemptId+"`r`n"+'error='+$Text)
  try{
    New-Item -ItemType Directory -Path $DeferredStatusBaseDir -Force|Out-Null
    [IO.File]::WriteAllText($DeferredStatusWriteErrorPath,$payload,(New-Object Text.UTF8Encoding($true)))
  }catch{
    try{[IO.File]::WriteAllText((Join-Path $env:TEMP 'SmartPageEx-deferred-upgrade-status-write-error.txt'),$payload,(New-Object Text.UTF8Encoding($true)))}catch{}
  }
}

function Write-DeferredUpgradeStatus([string]$Status,[string]$Phase,[string]$ErrorText=''){
  if(-not$DeferredUpgrade){return}
  $script:DeferredPhase=$Phase
  $sourceDir=''
  try{$sourceDir=Split-Path -Parent $PSCommandPath}catch{}
  $installerSha=$null
  try{$installerSha=Get-InstallerSha256 $PSCommandPath}catch{}
  $now=(Get-Date).ToUniversalTime().ToString('o')
  $payload=[ordered]@{
    deferredUpgrade=$true
    status=$Status
    phase=$Phase
    startedAt=$script:DeferredStartedAt
    updatedAt=$now
    attemptId=$script:DeferredAttemptId
    sourceDir=$sourceDir
    installerPath=[string]$PSCommandPath
    installerSha=$installerSha
    targetHelperVersion=$ExpectedHelperVersion
    targetBuildMarker=$ExpectedBuildMarker
    extensionId=([string]$ExtensionId).Trim().ToLowerInvariant()
    extensionRootOverride=[string]$ExtensionRootOverride
    taskName=$DeferredUpgradeTaskName
    taskPreservedUntilSuccess=$true
    automaticRetry=$false
    error=$ErrorText
    statusWriteError=$script:DeferredStatusWriteError
    stagingCleanupError=$script:DeferredCleanupError
  }
  $text=@(
    'SmartPage Ex Deferred Upgrade durable status',
    ('status='+$Status),
    ('phase='+$Phase),
    ('startedAt='+$script:DeferredStartedAt),
    ('updatedAt='+$now),
    ('attemptId='+$script:DeferredAttemptId),
    ('sourceDir='+$sourceDir),
    ('installerPath='+[string]$PSCommandPath),
    ('installerSha='+[string]$installerSha),
    ('targetHelperVersion='+$ExpectedHelperVersion),
    ('targetBuildMarker='+$ExpectedBuildMarker),
    ('extensionId='+([string]$ExtensionId).Trim().ToLowerInvariant()),
    ('extensionRootOverride='+[string]$ExtensionRootOverride),
    ('taskName='+$DeferredUpgradeTaskName),
    'taskPreservedUntilSuccess=true',
    'automaticRetry=false',
    ('error='+$ErrorText),
    ('statusWriteError='+[string]$script:DeferredStatusWriteError),
    ('stagingCleanupError='+[string]$script:DeferredCleanupError)
  ) -join "`r`n"

  $errors=@()
  try{New-Item -ItemType Directory -Path $DeferredStatusBaseDir -Force|Out-Null}catch{$errors+=@('mkdir: '+$_.Exception.Message)}
  try{[IO.File]::WriteAllText($DeferredStatusJsonPath,($payload|ConvertTo-Json -Depth 6),(New-Object Text.UTF8Encoding($true)))}catch{$errors+=@('json: '+$_.Exception.Message)}
  try{[IO.File]::WriteAllText($DeferredStatusTextPath,$text,(New-Object Text.UTF8Encoding($true)))}catch{$errors+=@('txt: '+$_.Exception.Message)}
  if($errors.Count -gt 0){Write-DeferredStatusWriteError ($errors -join ' | ')}
}

function Release-DeferredExecutionMutex{
  if($null-ne$script:DeferredExecutionMutex){
    if($script:DeferredExecutionMutexOwned){try{$script:DeferredExecutionMutex.ReleaseMutex()}catch{}}
    try{$script:DeferredExecutionMutex.Dispose()}catch{}
  }
  $script:DeferredExecutionMutex=$null
  $script:DeferredExecutionMutexOwned=$false
}

function Initialize-DeferredUpgradeExecution{
  if(-not$DeferredUpgrade){return}
  $mutex=$null;$acquired=$false
  try{
    $mutex=[System.Threading.Mutex]::new($false,$DeferredExecutionMutexName)
    try{$acquired=$mutex.WaitOne(0)}catch [System.Threading.AbandonedMutexException]{$acquired=$true}
  }catch{
    Write-DeferredStatusWriteError ('Deferred execution mutex creation failed: '+$_.Exception.Message)
    throw
  }
  if(-not$acquired){
    try{$mutex.Dispose()}catch{}
    throw 'Another SmartPage Ex deferred upgrade execution is already active. Duplicate execution was blocked without retry.'
  }
  $script:DeferredExecutionMutex=$mutex
  $script:DeferredExecutionMutexOwned=$true
  Write-DeferredUpgradeStatus 'RUNNING' 'STARTED'

  $task=Get-ScheduledTask -TaskName $DeferredUpgradeTaskName -ErrorAction SilentlyContinue
  if($null-eq$task){
    Write-DeferredUpgradeStatus 'FAILED_REVIEW_REQUIRED' 'TASK_PRESERVE_CHECK' 'Deferred Upgrade task is missing while -DeferredUpgrade is running.'
    throw 'Deferred Upgrade task is missing while -DeferredUpgrade is running. Review required.'
  }
  try{
    Disable-ScheduledTask -TaskName $DeferredUpgradeTaskName -ErrorAction Stop|Out-Null
  }catch{
    Write-DeferredUpgradeStatus 'FAILED_REVIEW_REQUIRED' 'TASK_DISABLE' ('Unable to disable Deferred Upgrade task: '+$_.Exception.Message)
    throw
  }
  Write-DeferredUpgradeStatus 'RUNNING' 'TASK_PRESERVED_DISABLED'
}

function Set-DeferredUpgradePhase([string]$Phase){
  if($DeferredUpgrade){Write-DeferredUpgradeStatus 'RUNNING' $Phase}
}

trap {
  try{Release-BridgeInstallMutex}catch{}
  if($script:NativeRegistrationTemporarilyRemoved){try{if($user -and (Test-Path -LiteralPath $ManifestPath)){Register-NativeMessagingRegistration $user.Sid $ManifestPath}}catch{}}
  $detail = ($_ | Out-String).Trim()

  if($DeferredUpgrade){
    try{
      $task=Get-ScheduledTask -TaskName $DeferredUpgradeTaskName -ErrorAction SilentlyContinue
      if($null-ne$task){Disable-ScheduledTask -TaskName $DeferredUpgradeTaskName -ErrorAction SilentlyContinue|Out-Null}
    }catch{}
    Write-DeferredUpgradeStatus 'FAILED_REVIEW_REQUIRED' $script:DeferredPhase $detail
    $message = "SmartPage Ex deferred network helper upgrade failed. Review required.`r`n`r`n$detail"
    Write-InstallStatus $message
    try{Release-DeferredExecutionMutex}catch{}
  }else{
    $message = "SmartPage Ex network helper manual installation failed.`r`n`r`n$detail"
    Write-InstallStatus $message
  }

  Write-Host ''; Write-Host $message -ForegroundColor Red
  exit 1
}
function Test-Administrator {
  $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
  $principal=New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Test-LoopbackPort([int]$Port,[int]$TimeoutMilliseconds=700) {
  $client=New-Object Net.Sockets.TcpClient
  try{
    $result=$client.BeginConnect('127.0.0.1',$Port,$null,$null)
    if(-not$result.AsyncWaitHandle.WaitOne([Math]::Max(200,$TimeoutMilliseconds))){return $false}
    $client.EndConnect($result)
    return $true
  }catch{return $false}finally{try{$client.Close()}catch{}}
}


function Get-LocalBridgeStatus([int]$TimeoutSeconds=1){
  if(-not(Test-LoopbackPort 30765 180)){return $null}
  try{
    $body=@{command='status'}|ConvertTo-Json -Compress
    $response=Invoke-WebRequest -Uri ('http://127.0.0.1:30765/api?token='+$BridgeToken) -Method Post -ContentType 'text/plain; charset=UTF-8' -Body $body -TimeoutSec 1 -UseBasicParsing
    if(-not$response -or [string]::IsNullOrWhiteSpace([string]$response.Content)){return $null}
    return ([string]$response.Content|ConvertFrom-Json)
  }catch{return $null}
}

function Get-LocalBridgeHealth([int]$TimeoutSeconds=1){
  # Do not use Invoke-WebRequest for localhost liveness. Windows PowerShell 5.1 can
  # enter WinINET/proxy auto-detection even for 127.0.0.1 and falsely time out while
  # the bridge is already listening. Speak HTTP directly over TcpClient instead.
  if(-not(Test-LoopbackPort 30765 180)){return $null}
  $client=$null;$stream=$null;$buffer=$null
  try{
    $client=New-Object Net.Sockets.TcpClient
    $connect=$client.BeginConnect('127.0.0.1',30765,$null,$null)
    $waitMs=[Math]::Max(500,([Math]::Max(1,$TimeoutSeconds)*1000))
    if(-not$connect.AsyncWaitHandle.WaitOne($waitMs)){return $null}
    $client.EndConnect($connect)
    $client.NoDelay=$true
    $stream=$client.GetStream()
    $stream.ReadTimeout=$waitMs
    $stream.WriteTimeout=$waitMs
    $request="GET /health HTTP/1.1`r`nHost: 127.0.0.1:30765`r`nConnection: close`r`n`r`n"
    $requestBytes=[Text.Encoding]::ASCII.GetBytes($request)
    $stream.Write($requestBytes,0,$requestBytes.Length)
    $stream.Flush()
    $buffer=New-Object IO.MemoryStream
    $chunk=New-Object byte[] 4096
    while($true){
      try{$count=$stream.Read($chunk,0,$chunk.Length)}catch{break}
      if($count-le0){break}
      $buffer.Write($chunk,0,$count)
      if($buffer.Length-gt262144){return $null}
    }
    $raw=[Text.Encoding]::UTF8.GetString($buffer.ToArray())
    $split=$raw.IndexOf("`r`n`r`n",[StringComparison]::Ordinal)
    if($split-lt0){return $null}
    $header=$raw.Substring(0,$split)
    if($header-notmatch '^HTTP/1\.[01] 200\b'){return $null}
    $body=$raw.Substring($split+4).Trim()
    if([string]::IsNullOrWhiteSpace($body)){return $null}
    $health=($body|ConvertFrom-Json)
    if($null-eq$health){return $null}
    $bridgePort=0;try{$bridgePort=[int]$health.bridgePort}catch{}
    if($bridgePort-ne30765){return $null}
    if([string]$health.transport-ne'raw_loopback_http'){return $null}
    if([string]::IsNullOrWhiteSpace([string]$health.helperVersion)){return $null}
    return $health
  }catch{return $null}finally{
    try{if($buffer){$buffer.Dispose()}}catch{}
    try{if($stream){$stream.Dispose()}}catch{}
    try{if($client){$client.Close()}}catch{}
  }
}

function Invoke-LocalBridgeApi([hashtable]$Payload,[int]$TimeoutSeconds=2){
  if(-not(Test-LoopbackPort 30765 180)){return $null}
  $client=$null;$stream=$null;$buffer=$null
  try{
    $client=New-Object Net.Sockets.TcpClient
    $connect=$client.BeginConnect('127.0.0.1',30765,$null,$null)
    $waitMs=[Math]::Max(700,([Math]::Max(1,$TimeoutSeconds)*1000))
    if(-not$connect.AsyncWaitHandle.WaitOne($waitMs)){return $null}
    $client.EndConnect($connect);$client.NoDelay=$true
    $stream=$client.GetStream();$stream.ReadTimeout=$waitMs;$stream.WriteTimeout=$waitMs
    $body=($Payload|ConvertTo-Json -Compress -Depth 8)
    $bodyBytes=[Text.Encoding]::UTF8.GetBytes($body)
    $header="POST /api HTTP/1.1`r`nHost: 127.0.0.1:30765`r`nContent-Type: application/json; charset=utf-8`r`nX-SmartPageEx-Token: $BridgeToken`r`nContent-Length: $($bodyBytes.Length)`r`nConnection: close`r`n`r`n"
    $headerBytes=[Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($headerBytes,0,$headerBytes.Length);$stream.Write($bodyBytes,0,$bodyBytes.Length);$stream.Flush()
    $buffer=New-Object IO.MemoryStream;$chunk=New-Object byte[] 4096
    while($true){try{$count=$stream.Read($chunk,0,$chunk.Length)}catch{break};if($count-le0){break};$buffer.Write($chunk,0,$count);if($buffer.Length-gt1048576){return $null}}
    $raw=[Text.Encoding]::UTF8.GetString($buffer.ToArray());$split=$raw.IndexOf("`r`n`r`n",[StringComparison]::Ordinal)
    if($split-lt0){return $null};$head=$raw.Substring(0,$split);if($head-notmatch '^HTTP/1\.[01] 200\b'){return $null}
    $json=$raw.Substring($split+4).Trim();if([string]::IsNullOrWhiteSpace($json)){return $null};return ($json|ConvertFrom-Json)
  }catch{return $null}finally{try{if($buffer){$buffer.Dispose()}}catch{};try{if($stream){$stream.Dispose()}}catch{};try{if($client){$client.Close()}}catch{}}
}

function Get-NetstatListenerPids([int]$Port){
  $found=New-Object System.Collections.Generic.List[int]
  try{
    $lines=@(& "$env:SystemRoot\System32\netstat.exe" -ano -p tcp 2>$null)
    foreach($line in $lines){
      $m=[regex]::Match([string]$line,'^\s*TCP\s+(?:127\.0\.0\.1|0\.0\.0\.0|\[::1\]|\[::\]):'+[regex]::Escape([string]$Port)+'\s+\S+\s+LISTENING\s+(\d+)\s*$','IgnoreCase')
      if($m.Success){$pidValue=0;if([int]::TryParse($m.Groups[1].Value,[ref]$pidValue)-and$pidValue-gt0){$found.Add($pidValue)}}
    }
  }catch{}
  return @($found|Sort-Object -Unique)
}
function Get-LoopbackPortOwnerPids([int]$Port){
  $found=New-Object System.Collections.Generic.List[int]
  try{
    $rows=@(Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)
    if($rows.Count-eq0){$rows=@(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)}
    foreach($pidValue in @($rows|ForEach-Object{[int]$_.OwningProcess}|Where-Object{$_-gt0})){if(-not$found.Contains([int]$pidValue)){$found.Add([int]$pidValue)}}
  }catch{}
  foreach($pidValue in @(Get-NetstatListenerPids $Port)){if(-not$found.Contains([int]$pidValue)){$found.Add([int]$pidValue)}}
  return @($found|Sort-Object -Unique)
}

function Get-ExpectedHelperPortOwnerStatus{
  if([string]::IsNullOrWhiteSpace([string]$ExePath) -or -not(Test-Path -LiteralPath $ExePath)){return $null}
  $controlPids=@(Get-LoopbackPortOwnerPids 30765)
  if($controlPids.Count-eq0){return $null}

  # v4.0.42: SYSTEM으로 떠 있는 정상 helper는 관리자 PowerShell에서도 Win32_Process의
  # ExecutablePath/CommandLine이 비어 보일 수 있습니다. 이 경우 기존 코드는 건강한 브리지를
  # 재사용하지 못하고 PID 강제정리 경로로 들어가 설치가 오래 멈추는 문제가 있었습니다.
  # /health가 현재 기대 빌드이며, health PID가 30765와 실제 proxy LISTEN의 동일 소유자임을
  # 교차검증하면 프로세스 메타데이터 조회 실패와 무관하게 안전하게 기존 브리지를 재사용합니다.
  $live=Get-LocalBridgeHealth 1
  if($null-ne$live -and [string]$live.helperVersion -eq $ExpectedHelperVersion -and [string]$live.buildMarker -eq $ExpectedBuildMarker -and $live.proxyReady -eq $true){
    $livePid=0;$liveProxyPort=0
    try{$livePid=[int]$live.pid}catch{}
    try{$liveProxyPort=[int]$live.proxyPort}catch{}
    if($livePid-gt0 -and $controlPids -contains $livePid -and $liveProxyPort-ge30766 -and $liveProxyPort-le30769){
      $proxyPids=@(Get-LoopbackPortOwnerPids $liveProxyPort)
      if($proxyPids -contains $livePid){
        $ownerMetadataAvailable=$false
        try{
          $probe=Get-CimInstance Win32_Process -Filter ("ProcessId="+$livePid) -ErrorAction Stop
          $ownerMetadataAvailable=($null-ne$probe -and -not[string]::IsNullOrWhiteSpace([string]$probe.ExecutablePath))
        }catch{}
        if(-not$ownerMetadataAvailable){
          Write-Host ('PATCH14 정상 SYSTEM 브리지 health/listener 교차검증 성공 · PID '+$livePid+' 프로세스 메타데이터 조회가 제한되어도 재사용합니다.') -ForegroundColor Green
        }
        return [pscustomobject]@{
          ok=$true;helperVersion=[string]$live.helperVersion;buildMarker=[string]$live.buildMarker;
          bridgePort=30765;proxyPort=$liveProxyPort;proxyReady=$true;pid=$livePid;
          transport='verified_health_pid_and_control_proxy_listener';ownerVerified=$true
        }
      }
    }
  }

  $expectedPath='';try{$expectedPath=[IO.Path]::GetFullPath($ExePath)}catch{$expectedPath=[string]$ExePath}
  foreach($ownerPid in $controlPids){
    $proc=$null
    try{$proc=Get-CimInstance Win32_Process -Filter ("ProcessId="+$ownerPid) -ErrorAction Stop}catch{}
    if($null-eq$proc){continue}
    $actualPath=[string]$proc.ExecutablePath
    if([string]::IsNullOrWhiteSpace($actualPath)){continue}
    try{$actualPath=[IO.Path]::GetFullPath($actualPath)}catch{}
    if(-not[string]::Equals($actualPath,$expectedPath,[StringComparison]::OrdinalIgnoreCase)){continue}
    if([string]$proc.CommandLine -notlike '*--http-server*'){continue}
    foreach($proxyPort in @(30766,30767,30768,30769)){
      $proxyPids=@(Get-LoopbackPortOwnerPids $proxyPort)
      if($proxyPids -contains [int]$ownerPid){
        $live=Get-LocalBridgeHealth 1
        if($null-eq$live){continue}
        if([string]$live.helperVersion -ne $ExpectedHelperVersion -or [string]$live.buildMarker -ne $ExpectedBuildMarker){
          Write-Host ('실행 중 helper 버전 불일치 · 현재 '+[string]$live.helperVersion+' / '+[string]$live.buildMarker+' → 필요 '+$ExpectedHelperVersion+' / '+$ExpectedBuildMarker+' · 안전 재시작합니다.') -ForegroundColor Yellow
          return $null
        }
        return [pscustomobject]@{
          ok=$true;helperVersion=[string]$live.helperVersion;buildMarker=[string]$live.buildMarker;
          bridgePort=30765;proxyPort=$proxyPort;proxyReady=$true;pid=[int]$ownerPid;
          transport='verified_expected_exe_port_owner_and_live_build';ownerVerified=$true
        }
      }
    }
  }
  return $null
}

function Get-CompatibleSmartPageBridgeStatus{
  # v4.0.45: first prefer /health. Older 3.0.23 bridges can keep the TCP listeners alive
  # while their quick /health response is unavailable after a raw-client disconnect or SYSTEM
  # metadata isolation. In that case, do NOT assume the listener is foreign: corroborate the
  # same PID on control+proxy with SmartPage's own startup log before entering cleanup.
  $controlPids=@(Get-LoopbackPortOwnerPids 30765)
  if($controlPids.Count-eq0){return $null}
  $live=Get-LocalBridgeHealth 1
  if($null-ne$live -and $live.ok-eq$true -and $live.proxyReady-eq$true -and [string]$live.transport-eq'raw_loopback_http'){
    $livePid=0;$proxyPort=0
    try{$livePid=[int]$live.pid}catch{}
    try{$proxyPort=[int]$live.proxyPort}catch{}
    if(($livePid -gt 0) -and ($proxyPort -ge 30766) -and ($proxyPort -le 30769) -and ($controlPids -contains $livePid) -and (@(Get-LoopbackPortOwnerPids $proxyPort) -contains $livePid)){
      $versionText=[string]$live.helperVersion
      try{$version=[version]$versionText}catch{$version=$null}
      if($null-ne$version -and $version-gt[version]$ExpectedHelperVersion -and -not($versionText-eq$ExpectedHelperVersion -and [string]$live.buildMarker-eq$ExpectedBuildMarker)){
        return [pscustomobject]@{ok=$true;helperVersion=$versionText;buildMarker=[string]$live.buildMarker;bridgePort=30765;proxyPort=$proxyPort;proxyReady=$true;pid=$livePid;transport='compatible_legacy_health_listener_verified';ownerVerified=$true;upgradePending=$true}
      }
    }
  }

  # PATCH16 fallback for the exact orphan-listener state seen in the field:
  #   - Win32_Process/Get-Process metadata is unavailable
  #   - taskkill returns 128
  #   - 30765 + one proxy port are still LISTEN under the same PID
  #   - local-bridge.log records that same PID as SmartPage V23 with ProxyReady=True
  # This evidence is strong enough to preserve the current session and defer upgrade to reboot.
  $bridgeLog=Join-Path $InstallDir 'local-bridge.log'
  if(-not(Test-Path -LiteralPath $bridgeLog -PathType Leaf)){return $null}
  $tail=@()
  try{$tail=@(Get-Content -LiteralPath $bridgeLog -Encoding UTF8 -Tail 240 -ErrorAction Stop)}catch{return $null}
  if($tail.Count-eq0){return $null}
  foreach($ownerPid in $controlPids){
    foreach($candidateProxyPort in @(30766,30767,30768,30769)){
      if(@(Get-LoopbackPortOwnerPids $candidateProxyPort) -notcontains [int]$ownerPid){continue}
      $startupSeen=$false;$readySeen=$false;$loggedMarker='';$loggedVersion=''
      foreach($line in $tail){
        $lineText=[string]$line
        $startupMatch=[regex]::Match($lineText,('Bridge startup begin\. PID='+[regex]::Escape([string]$ownerPid)+'\s+BuildMarker=(?<marker>v(?<version>3\.0\.\d+)[^\s]*)'),'IgnoreCase')
        if($startupMatch.Success){$startupSeen=$true;$loggedMarker=[string]$startupMatch.Groups['marker'].Value;$loggedVersion=[string]$startupMatch.Groups['version'].Value}
        if($lineText -match ('Local bridge V33 started\. PID='+[regex]::Escape([string]$ownerPid)+'\s+Control=127\.0\.0\.1:30765\s+ProxyReady=True\s+ProxyPort='+[regex]::Escape([string]$candidateProxyPort))){$readySeen=$true}
      }
      if(-not($startupSeen-and$readySeen)){continue}
      try{$loggedVersionValue=[version]$loggedVersion}catch{continue}
      if($loggedVersionValue-le[version]$ExpectedHelperVersion){continue}
      if($loggedVersion-eq$ExpectedHelperVersion-and$loggedMarker-eq$ExpectedBuildMarker){continue}
      Write-Host ('PATCH16 SmartPage 로그/listener 교차검증 성공 · /health 응답이 없어도 PID '+$ownerPid+' · helper '+$loggedVersion+' / '+$loggedMarker+' · proxy '+$candidateProxyPort+'를 호환 브리지로 보호합니다.') -ForegroundColor Green
      return [pscustomobject]@{ok=$true;helperVersion=$loggedVersion;buildMarker=$loggedMarker;bridgePort=30765;proxyPort=$candidateProxyPort;proxyReady=$true;pid=[int]$ownerPid;transport='compatible_legacy_log_listener_verified';ownerVerified=$true;upgradePending=$true}
    }
  }
  return $null
}

function Test-SmartPageBridgeOwnerPid([int]$OwnerPid){
  if($OwnerPid-le0){return $false}
  try{
    $proc=Get-CimInstance Win32_Process -Filter ("ProcessId="+$OwnerPid) -ErrorAction Stop
    if($null-eq$proc){return $false}
    $identity=(([string]$proc.Name)+' '+([string]$proc.ExecutablePath)+' '+([string]$proc.CommandLine))
    return ($identity -match '(?i)(SpxNetworkHost|SmartPageEx|spx-collector.*network-host|network-host.*SmartPage)')
  }catch{
    try{return ([string](Get-Process -Id $OwnerPid -ErrorAction Stop).ProcessName -match '(?i)SpxNetworkHost')}catch{return $false}
  }
}

function Stop-ConfirmedSmartPageBridgeOnControlPort{
  if(-not(Test-LoopbackPort 30765 180)){return $true}
  $health=Get-LocalBridgeHealth 1
  $status=$null
  if($null-eq$health){$status=Get-LocalBridgeStatus 1}
  $ownerPids=@(Get-LoopbackPortOwnerPids 30765)
  if($ownerPids.Count-eq0){return $false}

  $confirmed=($null-ne$health)
  if(-not$confirmed -and $null-ne$status){
    $statusBridgePort=0;try{$statusBridgePort=[int]$status.bridgePort}catch{}
    $statusProxyPort=0;try{$statusProxyPort=[int]$status.proxyPort}catch{}
    if(-not[string]::IsNullOrWhiteSpace([string]$status.helperVersion) -and (($statusBridgePort-eq30765)-or($statusProxyPort-ge30766-and$statusProxyPort-le30769))){$confirmed=$true}
  }
  if(-not$confirmed){
    foreach($ownerPid in $ownerPids){if(Test-SmartPageBridgeOwnerPid $ownerPid){$confirmed=$true;break}}
  }
  if(-not$confirmed){return $false}

  $detectedVersion='legacy/unknown'
  if($null-ne$health -and -not[string]::IsNullOrWhiteSpace([string]$health.helperVersion)){$detectedVersion=[string]$health.helperVersion}
  elseif($null-ne$status -and -not[string]::IsNullOrWhiteSpace([string]$status.helperVersion)){$detectedVersion=[string]$status.helperVersion}
  Write-Host ('기존 SmartPage Ex 로컬 브리지 감지: helper '+$detectedVersion+' / PID '+($ownerPids-join ',')+'. 새 설치가 끝날 때까지 자동 재기동을 차단하고 종료합니다.') -ForegroundColor Yellow
  foreach($ownerPid in $ownerPids){
    try{Stop-Process -Id $ownerPid -Force -ErrorAction Stop}catch{
      try{& "$env:SystemRoot\System32\taskkill.exe" /PID $ownerPid /T /F 2>$null|Out-Null}catch{}
    }
  }
  for($i=0;$i-lt30;$i++){
    if(-not(Test-LoopbackPort 30765 120)){return $true}
    Start-Sleep -Milliseconds 120
  }
  return (-not(Test-LoopbackPort 30765 150))
}

function Release-BridgeInstallMutex{
  if($null-ne$script:BridgeInstallMutex){
    if($script:BridgeInstallMutexOwned){try{$script:BridgeInstallMutex.ReleaseMutex()}catch{}}
    try{$script:BridgeInstallMutex.Dispose()}catch{}
  }
  $script:BridgeInstallMutex=$null
  $script:BridgeInstallMutexOwned=$false
}

function Acquire-BridgeInstallMutex{
  Release-BridgeInstallMutex
  for($attempt=0;$attempt-lt24;$attempt++){
    $mutex=$null;$acquired=$false
    try{
      $mutex=[System.Threading.Mutex]::new($false,$BridgeMutexName)
      try{$acquired=$mutex.WaitOne(0)}catch [System.Threading.AbandonedMutexException]{$acquired=$true}
      if($acquired){
        $script:BridgeInstallMutex=$mutex
        $script:BridgeInstallMutexOwned=$true
        return $true
      }
    }catch{}
    if($null-ne$mutex -and -not$acquired){try{$mutex.Dispose()}catch{}}

    # Chrome Native Messaging 또는 이전 복구 작업이 설치 도중 helper를 다시 띄울 수 있습니다.
    # 이름/상태/실행경로로 SmartPage Ex임이 확인된 프로세스만 정리하고 다시 잠금을 시도합니다.
    Get-CimInstance Win32_Process -Filter "Name='SpxNetworkHost.exe'" -ErrorAction SilentlyContinue|ForEach-Object{try{Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue|Out-Null}catch{}}
    if(Test-LoopbackPort 30765 120){[void](Stop-ConfirmedSmartPageBridgeOnControlPort)}
    Start-Sleep -Milliseconds 150
  }
  return $false
}

function Assert-ControlPortAvailableForSmartPage{
  if(-not(Test-LoopbackPort 30765 180)){return}
  $health=Get-LocalBridgeHealth 1
  if($null-ne$health){
    if(Stop-ConfirmedSmartPageBridgeOnControlPort){return}
    throw ('기존 SmartPage Ex 로컬 브리지를 종료하지 못했습니다. '+(Get-LoopbackPortOwnerText 30765))
  }
  throw ('127.0.0.1:30765 포트를 다른 프로그램이 사용 중입니다. 임의 종료하지 않았습니다. '+(Get-LoopbackPortOwnerText 30765))
}

function Test-LocalBridgeStatusReady($Status){
  if($null -eq $Status){return $false}
  if([string]$Status.helperVersion -ne $ExpectedHelperVersion){return $false}
  if([string]$Status.buildMarker -ne $ExpectedBuildMarker){return $false}
  if($Status.proxyReady -ne $true){return $false}
  $proxyPort=0;try{$proxyPort=[int]$Status.proxyPort}catch{}
  if($proxyPort -le 0){return $false}
  return ((Test-LoopbackPort 30765 350) -and (Test-LoopbackPort $proxyPort 350))
}
function Wait-LocalBridgeStatus([int]$Attempts=48,[int]$DelayMilliseconds=250){
  $last=$null
  for($i=0;$i -lt [Math]::Max(1,$Attempts);$i++){
    # Startup readiness must use the lightweight /health endpoint.
    # The full status command can perform route/public-IP inspection and is not a liveness probe.
    $last=Get-LocalBridgeHealth 1
    if(Test-LocalBridgeStatusReady $last){return $last}
    Start-Sleep -Milliseconds ([Math]::Max(100,$DelayMilliseconds))
  }
  return $last
}
function Get-LoopbackPortOwnerText([int]$Port){
  try{
    $rows=@(Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)
    if($rows.Count -eq 0){$rows=@(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)}
    if($rows.Count -eq 0){return 'closed'}
    $parts=@()
    foreach($row in $rows){
      $pidValue=[int]$row.OwningProcess;$processName=''
      try{$processName=[string](Get-Process -Id $pidValue -ErrorAction Stop).ProcessName}catch{}
      $parts+=('LISTEN pid='+$pidValue+$(if($processName){' '+$processName}else{''}))
    }
    return ($parts-join ', ')
  }catch{return $(if(Test-LoopbackPort $Port 250){'LISTEN (owner unavailable)'}else{'closed'})}
}
function Get-BridgeFailureDetail{
  $parts=New-Object System.Collections.Generic.List[string]
  foreach($port in @(30765,30766,30767,30768,30769)){$parts.Add(('port '+$port+': '+(Get-LoopbackPortOwnerText $port)))}
  try{
    $taskInfo=Get-ScheduledTaskInfo -TaskName $BridgeTaskName -ErrorAction Stop
    $parts.Add(('task LastTaskResult='+[string]$taskInfo.LastTaskResult+' LastRunTime='+[string]$taskInfo.LastRunTime))
  }catch{$parts.Add(('task info unavailable: '+$_.Exception.Message))}
  try{
    $procs=@(Get-CimInstance Win32_Process -Filter "Name='SpxNetworkHost.exe'" -ErrorAction SilentlyContinue)
    $runtimeProcs=@(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue|Where-Object{([string]$_.CommandLine -like '*run-network-host.ps1*') -and ([string]$_.CommandLine -like '*-HttpServer*')})
    if($procs.Count){$parts.Add(('Native launcher PID(s)='+(@($procs|ForEach-Object{$_.ProcessId})-join ',')))}else{$parts.Add('Native launcher process=not running')}
    if($runtimeProcs.Count){$parts.Add(('PowerShell bridge PID(s)='+(@($runtimeProcs|ForEach-Object{$_.ProcessId})-join ',')))}else{$parts.Add('PowerShell bridge process=not running')}
  }catch{}
  try{
    $status=Get-LocalBridgeHealth 1
    if($null-eq$status){$status=Get-LocalBridgeStatus 2}
    if($null-ne$status){
      $parts.Add(('reported helperVersion='+[string]$status.helperVersion+' buildMarker='+[string]$status.buildMarker+' proxyPort='+[string]$status.proxyPort+' pid='+[string]$status.pid))
    }
  }catch{}
  $bridgeLog=Join-Path $InstallDir 'local-bridge.log'
  if(Test-Path -LiteralPath $bridgeLog){
    try{
      $tail=@(Get-Content -LiteralPath $bridgeLog -Encoding UTF8 -Tail 8 -ErrorAction Stop|ForEach-Object{([string]$_).Trim()}|Where-Object{$_})
      if($tail.Count){$parts.Add(('recent local-bridge.log: '+($tail-join ' | ')))}
    }catch{}
  }
  $stderrPath=Join-Path $InstallDir 'bridge-start.stderr.log'
  if(Test-Path -LiteralPath $stderrPath){
    try{$stderr=(Get-Content -LiteralPath $stderrPath -Encoding UTF8 -Raw -ErrorAction Stop).Trim();if($stderr){$parts.Add(('direct-start stderr: '+$stderr))}}catch{}
  }
  return ($parts-join '; ')
}

function Invoke-AdbCapture([string]$AdbPath,[string[]]$Arguments){
  # Windows PowerShell 5.1 can convert normal native stderr into NativeCommandError when
  # $ErrorActionPreference='Stop'. ADB writes daemon startup notices to stderr even on success.
  $savedPreference=$ErrorActionPreference
  try{
    $ErrorActionPreference='Continue'
    $lines=@(& $AdbPath @Arguments 2>&1|ForEach-Object{
      if($_ -is [System.Management.Automation.ErrorRecord]){
        if($_.Exception -and -not[string]::IsNullOrWhiteSpace([string]$_.Exception.Message)){[string]$_.Exception.Message}else{[string]$_}
      }else{[string]$_}
    })
    $exitCode=[int]$LASTEXITCODE
    return [pscustomobject]@{ExitCode=$exitCode;Lines=@($lines);Text=(($lines-join ' ').Trim())}
  }catch{
    return [pscustomobject]@{ExitCode=-1;Lines=@();Text=([string]$_.Exception.Message).Trim()}
  }finally{$ErrorActionPreference=$savedPreference}
}

function Start-AdbServerReliable([string]$AdbPath,[string]$LogDir){
  if(Test-LoopbackPort 5037 350){return [pscustomobject]@{Ready=$true;Mode='existing';Detail='ADB daemon already listening on 127.0.0.1:5037.'}}
  New-Item -ItemType Directory -Path $LogDir -Force|Out-Null

  $first=Invoke-AdbCapture $AdbPath @('start-server')
  for($i=0;$i -lt 20;$i++){if(Test-LoopbackPort 5037 250){return [pscustomobject]@{Ready=$true;Mode='start-server';Detail=$first.Text}};Start-Sleep -Milliseconds 250}

  # A stale adb.exe can survive a prior install. Stop it and retry once before nodaemon fallback.
  $kill=Invoke-AdbCapture $AdbPath @('kill-server')
  Start-Sleep -Milliseconds 350
  $second=Invoke-AdbCapture $AdbPath @('start-server')
  for($i=0;$i -lt 20;$i++){if(Test-LoopbackPort 5037 250){return [pscustomobject]@{Ready=$true;Mode='restart-server';Detail=$second.Text}};Start-Sleep -Milliseconds 250}

  $stdout=Join-Path $LogDir 'adb-server.stdout.log';$stderr=Join-Path $LogDir 'adb-server.stderr.log'
  Remove-Item -LiteralPath $stdout,$stderr -Force -ErrorAction SilentlyContinue
  $proc=Start-Process -FilePath $AdbPath -ArgumentList @('nodaemon','server') -WorkingDirectory (Split-Path -Parent $AdbPath) -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
  for($i=0;$i -lt 32;$i++){
    if(Test-LoopbackPort 5037 250){return [pscustomobject]@{Ready=$true;Mode='nodaemon';Detail='ADB daemon started with hidden nodaemon fallback.'}}
    if($proc.HasExited){break}
    Start-Sleep -Milliseconds 250
  }
  $parts=New-Object System.Collections.Generic.List[string]
  foreach($candidate in @($first.Text,$kill.Text,$second.Text)){if(-not[string]::IsNullOrWhiteSpace($candidate)){$parts.Add($candidate)}}
  foreach($log in @($stdout,$stderr)){if(Test-Path -LiteralPath $log){$value=(Get-Content -LiteralPath $log -Raw -ErrorAction SilentlyContinue).Trim();if($value){$parts.Add($value)}}}
  throw ('ADB daemon did not open 127.0.0.1:5037. '+(($parts-join ' | ').Trim()))
}

function Test-AdbExecutable([string]$Path){
  if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
  try{
    $output=@(& $Path version 2>&1|ForEach-Object{[string]$_})
    return ($LASTEXITCODE -eq 0 -and (($output -join ' ') -match 'Android Debug Bridge'))
  }catch{return $false}
}
function Copy-AdbRuntime([string]$SourceAdb,[string]$DestinationDir){
  $sourceDir=Split-Path -Parent ([IO.Path]::GetFullPath($SourceAdb))
  New-Item -ItemType Directory -Path $DestinationDir -Force|Out-Null
  foreach($item in Get-ChildItem -LiteralPath $sourceDir -Force -ErrorAction Stop){
    Copy-Item -LiteralPath $item.FullName -Destination $DestinationDir -Recurse -Force
  }
  return (Join-Path $DestinationDir 'adb.exe')
}
function Install-OrFindAdb([string]$InstallDir,[object]$InteractiveUser,[string]$SourceDir){
  $destination=Join-Path $InstallDir 'platform-tools'
  $destinationAdb=Join-Path $destination 'adb.exe'
  if (Test-AdbExecutable $destinationAdb) { return [pscustomobject]@{Ready=$true;Path=$destinationAdb;Source='existing-programdata';Downloaded=$false;Error=''} }
  $candidates=New-Object System.Collections.Generic.List[string]
  foreach($candidate in @(
    (Join-Path $SourceDir 'platform-tools\adb.exe'),
    (Join-Path $SourceDir 'adb.exe'),
    (Join-Path $InteractiveUser.ProfilePath 'AppData\Local\Android\Sdk\platform-tools\adb.exe'),
    (Join-Path $env:ProgramFiles 'Android\android-sdk\platform-tools\adb.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Android\android-sdk\platform-tools\adb.exe')
  )){if(-not[string]::IsNullOrWhiteSpace($candidate)){$candidates.Add($candidate)}}
  try { $command=Get-Command adb.exe -ErrorAction SilentlyContinue | Select-Object -First 1; if ($command -and $command.Source) { $candidates.Add([string]$command.Source) } } catch { }
  foreach($candidate in $candidates){
    if(Test-AdbExecutable $candidate){
      try{
        $copied=Copy-AdbRuntime $candidate $destination
        if(Test-AdbExecutable $copied){return [pscustomobject]@{Ready=$true;Path=$copied;Source=('copied:'+([IO.Path]::GetFullPath($candidate)));Downloaded=$false;Error=''}}
      }catch{}
    }
  }
  $tempRoot=Join-Path $env:TEMP ('spx-platform-tools-'+[Guid]::NewGuid().ToString('N'))
  $zipPath=Join-Path $tempRoot 'platform-tools.zip'
  try{
    New-Item -ItemType Directory -Path $tempRoot -Force|Out-Null
    try{[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12}catch{}
    Write-Host 'Google Android SDK Platform-Tools(ADB)가 없어 공식 파일을 다운로드합니다...' -ForegroundColor Yellow
    Invoke-WebRequest -Uri $PlatformToolsUrl -OutFile $zipPath -UseBasicParsing -TimeoutSec 90
    Expand-Archive -LiteralPath $zipPath -DestinationPath $tempRoot -Force
    $downloadedAdb=Join-Path $tempRoot 'platform-tools\adb.exe'
    if(-not(Test-AdbExecutable $downloadedAdb)){throw 'Downloaded adb.exe validation failed.'}
    if(Test-Path -LiteralPath $destination){Remove-Item -LiteralPath $destination -Recurse -Force -ErrorAction SilentlyContinue}
    Copy-Item -LiteralPath (Join-Path $tempRoot 'platform-tools') -Destination $destination -Recurse -Force
    if(-not(Test-AdbExecutable $destinationAdb)){throw 'Installed adb.exe validation failed.'}
    return [pscustomobject]@{Ready=$true;Path=$destinationAdb;Source=$PlatformToolsUrl;Downloaded=$true;Error=''}
  }catch{
    return [pscustomobject]@{Ready=$false;Path='';Source=$PlatformToolsUrl;Downloaded=$false;Error=([string]$_.Exception.Message).Trim()}
  }finally{Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue}
}
function Initialize-AdbSharedRuntime([object]$AdbInstall,[string]$InstallDir,[object]$InteractiveUser){
  $homeDir=Join-Path $InstallDir 'adb-home'
  $androidDir=Join-Path $homeDir '.android'
  $keyPath=Join-Path $androidDir 'adbkey'
  $publicKeyPath=$keyPath+'.pub'
  New-Item -ItemType Directory -Path $androidDir -Force|Out-Null
  $state='not-ready';$detail='ADB executable is unavailable.';$keySource='none'
  if(-not$AdbInstall.Ready){return [pscustomobject]@{Ready=$false;ServerReady=$false;ServerMode='none';KeysPath=$keyPath;DeviceState=$state;Detail=$detail;KeySource=$keySource;DeviceSerial='';DeviceModel=''}}

  # v3.0.8.11에서 파일이어야 할 adbkey 경로가 폴더로 생성된 경우를 자동 복구합니다.
  foreach($collision in @($keyPath,$publicKeyPath,(Join-Path $InstallDir 'adb-keys\adbkey'))){
    if(Test-Path -LiteralPath $collision -PathType Container){Remove-Item -LiteralPath $collision -Recurse -Force -ErrorAction SilentlyContinue}
  }

  if(Test-Path -LiteralPath $keyPath -PathType Leaf){$keySource='existing-dedicated-home'}

  # 이미 휴대폰에서 승인된 사용자 기본 ADB 키를 우선 복사해 새 RSA 승인창을 줄입니다.
  if(-not(Test-Path -LiteralPath $keyPath -PathType Leaf)){
    $keyCandidates=New-Object System.Collections.Generic.List[string]
    foreach($candidate in @(
      (Join-Path $InteractiveUser.ProfilePath '.android\adbkey'),
      (Join-Path $env:USERPROFILE '.android\adbkey'),
      (Join-Path $InstallDir 'adb-keys\adbkey')
    )){if(-not[string]::IsNullOrWhiteSpace($candidate)){$keyCandidates.Add($candidate)}}
    foreach($candidate in $keyCandidates){
      try{
        if((Test-Path -LiteralPath $candidate -PathType Leaf)-and((Get-Item -LiteralPath $candidate).Length-gt256)){
          Copy-Item -LiteralPath $candidate -Destination $keyPath -Force
          if(Test-Path -LiteralPath ($candidate+'.pub') -PathType Leaf){Copy-Item -LiteralPath ($candidate+'.pub') -Destination $publicKeyPath -Force}
          $keySource='copied:'+([IO.Path]::GetFullPath($candidate));break
        }
      }catch{}
    }
  }

  $oldEnv=@{}
  foreach($name in @('ADB_VENDOR_KEYS','ANDROID_USER_HOME','HOME','USERPROFILE','ADB_TRACE','ADB_SERVER_SOCKET','ANDROID_ADB_SERVER_ADDRESS','ANDROID_ADB_SERVER_PORT')){$oldEnv[$name]=[Environment]::GetEnvironmentVariable($name,'Process')}
  try{
    # ADB는 USERPROFILE\.android\adbkey를 기본 사용자 키로 사용합니다. SYSTEM 작업과 설치기가 같은 전용 홈을 사용합니다.
    $env:ANDROID_USER_HOME=$homeDir;$env:USERPROFILE=$homeDir;$env:HOME=$homeDir
    $env:ADB_VENDOR_KEYS=$keyPath
    $env:ADB_TRACE=$null;$env:ADB_SERVER_SOCKET=$null;$env:ANDROID_ADB_SERVER_ADDRESS=$null;$env:ANDROID_ADB_SERVER_PORT=$null

    if(-not(Test-Path -LiteralPath $keyPath -PathType Leaf)){
      $tempKey=Join-Path $androidDir ('adbkey-'+[Guid]::NewGuid().ToString('N')+'.tmp')
      $tempPub=$tempKey+'.pub'
      $keyResult=Invoke-AdbCapture $AdbInstall.Path @('keygen',$tempKey)
      $keyOutput=@($keyResult.Lines)
      $keyExit=[int]$keyResult.ExitCode
      $tempReady=(Test-Path -LiteralPath $tempKey -PathType Leaf)-and((Get-Item -LiteralPath $tempKey).Length-gt256)
      if($keyExit-ne0-or-not$tempReady){
        $kind=if(Test-Path -LiteralPath $tempKey -PathType Container){'temporary key path became a directory'}else{'temporary key file was not created'}
        throw ('ADB shared key generation failed (exit '+$keyExit+', '+$kind+'): '+(($keyOutput-join ' ').Trim()))
      }
      Move-Item -LiteralPath $tempKey -Destination $keyPath -Force
      if(Test-Path -LiteralPath $tempPub -PathType Leaf){Move-Item -LiteralPath $tempPub -Destination $publicKeyPath -Force}
      $keySource='generated-dedicated-home'
    }
    if(-not(Test-Path -LiteralPath $publicKeyPath -PathType Leaf)){
      $pubResult=Invoke-AdbCapture $AdbInstall.Path @('pubkey',$keyPath)
      $pubOutput=@($pubResult.Lines)
      if($pubResult.ExitCode-eq0-and$pubOutput.Count-gt0){[IO.File]::WriteAllText($publicKeyPath,(($pubOutput-join "`n").Trim()+"`n"),(New-Object Text.UTF8Encoding($false)))}
    }

    $server=Start-AdbServerReliable $AdbInstall.Path (Join-Path $InstallDir 'logs')
    if(-not$server.Ready){throw ('ADB server start failed: '+$server.Detail)}
    $devicesResult=Invoke-AdbCapture $AdbInstall.Path @('devices','-l')
    $devices=@($devicesResult.Lines)
    if($devicesResult.ExitCode-ne0){throw ('ADB device query failed: '+$devicesResult.Text)}
    $ready=@($devices|Where-Object{$_-match '^\S+\s+device(?:\s|$)'})
    $unauthorized=@($devices|Where-Object{$_-match '^\S+\s+unauthorized(?:\s|$)'})
    $offline=@($devices|Where-Object{$_-match '^\S+\s+offline(?:\s|$)'})
    $deviceSerial='';$deviceModel=''
    if($ready.Count-gt0){
      $state='device';$detail='ADB device ready.'
      $firstReady=[string]$ready[0]
      $parts=@($firstReady -split '\s+')
      if($parts.Count-gt0){$deviceSerial=[string]$parts[0]}
      if($firstReady -match '(?:^|\s)model:(\S+)'){$deviceModel=([string]$matches[1]).Replace('_','-')}
    }
    elseif($unauthorized.Count-gt0){$state='unauthorized';$detail='Unlock the phone and approve Always allow USB debugging from this computer.'}
    elseif($offline.Count-gt0){$state='offline';$detail='ADB device is offline. Reconnect the USB cable.'}
    else{$state='not-connected';$detail='No ADB device is connected. Enable Developer options and USB debugging.'}
    return [pscustomobject]@{Ready=$true;ServerReady=$true;ServerMode=([string]$server.Mode);KeysPath=$keyPath;DeviceState=$state;Detail=$detail;KeySource=$keySource;DeviceSerial=$deviceSerial;DeviceModel=$deviceModel}
  }catch{return [pscustomobject]@{Ready=$false;ServerReady=$false;ServerMode='failed';KeysPath=$keyPath;DeviceState='error';Detail=([string]$_.Exception.Message).Trim();KeySource=$keySource;DeviceSerial='';DeviceModel=''}}
  finally{
    foreach($name in $oldEnv.Keys){[Environment]::SetEnvironmentVariable($name,$oldEnv[$name],'Process')}
  }
}
function Get-InteractiveUserInfo {
  $name=''; try{$name=[string](Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName}catch{}
  if([string]::IsNullOrWhiteSpace($name)){$name=[Security.Principal.WindowsIdentity]::GetCurrent().Name}
  $sid=(New-Object Security.Principal.NTAccount($name)).Translate([Security.Principal.SecurityIdentifier]).Value
  $profile=Get-CimInstance Win32_UserProfile -ErrorAction SilentlyContinue|Where-Object{$_.SID -eq $sid}|Select-Object -First 1
  $profilePath=if($profile -and $profile.LocalPath){[string]$profile.LocalPath}else{$env:USERPROFILE}
  [pscustomobject]@{Name=$name;Sid=$sid;ProfilePath=$profilePath}
}

function Register-DedicatedBrowserWatcher([object]$InteractiveUser,[string]$LauncherPath){
  # PATCH8: /Run one-shot 작업은 일부 Windows 환경에서 "실행 요청 성공(0)"만 반환하고
  # 실제 interactive desktop 프로세스를 만들지 않는 경우가 있습니다. 전용창 요청은 아주 작은
  # 사용자 세션 watcher가 ProgramData 요청 파일만 감시하도록 되돌립니다. C# SYSTEM bridge는
  # 브라우저를 직접 띄우지 않으며, watcher가 현재 로그인 세션에서 Chrome을 엽니다.
  $readyPath=Join-Path $InstallDir 'dedicated-window-launcher.ready'
  $requestPath=Join-Path $InstallDir 'dedicated-window-request.json'
  $resultPath=Join-Path $InstallDir 'dedicated-window-result.json'
  Stop-ScheduledTask -TaskName $BrowserTaskName -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $readyPath -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $requestPath -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue

  $browserAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument ('-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$LauncherPath+'" -Watch') -WorkingDirectory $InstallDir
  $browserPrincipal=New-ScheduledTaskPrincipal -UserId $InteractiveUser.Sid -LogonType Interactive -RunLevel Limited
  $browserTrigger=New-ScheduledTaskTrigger -AtLogOn -User $InteractiveUser.Name
  $browserSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable
  Register-ScheduledTask -TaskName $BrowserTaskName -Action $browserAction -Trigger $browserTrigger -Principal $browserPrincipal -Settings $browserSettings -Force|Out-Null
  Start-ScheduledTask -TaskName $BrowserTaskName -ErrorAction Stop

  $ready=$null
  for($i=0;$i-lt30;$i++){
    Start-Sleep -Milliseconds 200
    if(Test-Path -LiteralPath $readyPath){
      try{$ready=Get-Content -LiteralPath $readyPath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop}catch{$ready=$null}
      if($null-ne$ready -and [int]$ready.pid -gt0){break}
    }
  }
  if($null-eq$ready -or [int]$ready.pid -le0){
    $taskInfoText=''
    try{$taskInfo=Get-ScheduledTaskInfo -TaskName $BrowserTaskName -ErrorAction Stop;$taskInfoText=' LastTaskResult='+[string]$taskInfo.LastTaskResult+' LastRunTime='+[string]$taskInfo.LastRunTime}catch{}
    throw ('전용창 interactive launcher watcher를 현재 사용자 세션에서 시작하지 못했습니다.'+$taskInfoText)
  }
  Write-Host ('전용창 interactive launcher 준비 완료 · PID '+[string]$ready.pid+' · User '+[string]$ready.user+' · Session '+[string]$ready.sessionId) -ForegroundColor Green
  return $ready
}
function Find-SmartPageExtensionRoot([string]$StartPath){
  if([string]::IsNullOrWhiteSpace($StartPath)){return ''}
  try{$current=Get-Item -LiteralPath $StartPath -ErrorAction Stop;if(-not $current.PSIsContainer){$current=$current.Directory}
    for($i=0;$i -lt 10 -and $null -ne $current;$i++){
      if((Test-Path (Join-Path $current.FullName 'manifest.json')) -and (Test-Path (Join-Path $current.FullName 'src\options\options.html'))){return [IO.Path]::GetFullPath($current.FullName)}
      $current=$current.Parent
    }}catch{}
  return ''
}
function Resolve-PreferenceExtensionPath([string]$PathValue,[string]$PreferencePath){
  if([string]::IsNullOrWhiteSpace($PathValue)){return ''}
  try{
    $candidate=[Environment]::ExpandEnvironmentVariables($PathValue.Trim().Trim('"'))
    if(-not[IO.Path]::IsPathRooted($candidate)){$candidate=Join-Path (Split-Path -Parent $PreferencePath) $candidate}
    return [IO.Path]::GetFullPath($candidate).TrimEnd('\')
  }catch{return ''}
}
function Find-LoadedSmartPageExtensionIds([string]$ProfilePath,[string]$ExtensionRoot){
  $found=New-Object System.Collections.Generic.List[string]
  if([string]::IsNullOrWhiteSpace($ProfilePath)-or[string]::IsNullOrWhiteSpace($ExtensionRoot)){return @()}
  $expected='';try{$expected=[IO.Path]::GetFullPath($ExtensionRoot).TrimEnd('\')}catch{return @()}
  $userData=Join-Path $ProfilePath 'AppData\Local\Google\Chrome\User Data'
  if(-not(Test-Path -LiteralPath $userData)){return @()}
  $profiles=@()
  $defaultProfile=Join-Path $userData 'Default';if(Test-Path -LiteralPath $defaultProfile){$profiles+=Get-Item -LiteralPath $defaultProfile}
  $profiles+=Get-ChildItem -LiteralPath $userData -Directory -ErrorAction SilentlyContinue|Where-Object{$_.Name-like'Profile *'}
  foreach($profile in $profiles){
    foreach($fileName in @('Secure Preferences','Preferences')){
      $preferencePath=Join-Path $profile.FullName $fileName
      if(-not(Test-Path -LiteralPath $preferencePath)){continue}
      try{
        $preference=Get-Content -LiteralPath $preferencePath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
        $settings=$preference.extensions.settings;if($null-eq$settings){continue}
        foreach($property in $settings.PSObject.Properties){
          $candidateId=([string]$property.Name).Trim().ToLowerInvariant()
          if($candidateId-notmatch'^[a-p]{32}$'){continue}
          $candidatePath=Resolve-PreferenceExtensionPath ([string]$property.Value.path) $preferencePath
          if(-not[string]::IsNullOrWhiteSpace($candidatePath)-and[string]::Equals($candidatePath,$expected,[StringComparison]::OrdinalIgnoreCase)){$found.Add($candidateId)}
        }
      }catch{}
    }
  }
  return @($found|Sort-Object -Unique)
}
function Add-UniqueExtensionId([System.Collections.Generic.List[string]]$Target,[string]$Value){
  $normalized=([string]$Value).Trim().ToLowerInvariant()
  if($normalized-match'^[a-p]{32}$'-and-not$Target.Contains($normalized)){$Target.Add($normalized)}
}
function Set-RegistryDefaultValue([Microsoft.Win32.RegistryHive]$Hive,[Microsoft.Win32.RegistryView]$View,[string]$SubKey,[string]$Value){
  $base=$null;$key=$null
  try{$base=[Microsoft.Win32.RegistryKey]::OpenBaseKey($Hive,$View);$key=$base.CreateSubKey($SubKey,[Microsoft.Win32.RegistryKeyPermissionCheck]::ReadWriteSubTree);$key.SetValue('',$Value,[Microsoft.Win32.RegistryValueKind]::String)}
  finally{if($key){$key.Dispose()};if($base){$base.Dispose()}}
}

function Get-RegistryDefaultValue([Microsoft.Win32.RegistryHive]$Hive,[Microsoft.Win32.RegistryView]$View,[string]$SubKey){
  $base=$null;$key=$null
  try{
    $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey($Hive,$View)
    $key=$base.OpenSubKey($SubKey,$false)
    if($null-eq$key){return $null}
    return [string]$key.GetValue('',$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
  }catch{return $null}finally{if($key){$key.Dispose()};if($base){$base.Dispose()}}
}
function Test-NativeMessagingRegistration([string]$UserSid,[string]$Manifest){
  if([string]::IsNullOrWhiteSpace($Manifest)-or-not(Test-Path -LiteralPath $Manifest -PathType Leaf)){
    return [pscustomobject]@{ok=$false;matches=@();reason='manifest_missing'}
  }
  $expected=[IO.Path]::GetFullPath($Manifest)
  $matches=New-Object System.Collections.Generic.List[string]
  $views=@([Microsoft.Win32.RegistryView]::Registry32);if([Environment]::Is64BitOperatingSystem){$views+=[Microsoft.Win32.RegistryView]::Registry64}
  foreach($view in $views){
    $sub="Software\Google\Chrome\NativeMessagingHosts\$NativeHostName"
    $lm=Get-RegistryDefaultValue ([Microsoft.Win32.RegistryHive]::LocalMachine) $view $sub
    if(-not[string]::IsNullOrWhiteSpace($lm)){
      try{if([string]::Equals([IO.Path]::GetFullPath($lm),$expected,[StringComparison]::OrdinalIgnoreCase)){$matches.Add(('HKLM/'+$view))}}catch{}
    }
    if(-not[string]::IsNullOrWhiteSpace($UserSid)){
      $u=Get-RegistryDefaultValue ([Microsoft.Win32.RegistryHive]::Users) $view ("$UserSid\$sub")
      if(-not[string]::IsNullOrWhiteSpace($u)){
        try{if([string]::Equals([IO.Path]::GetFullPath($u),$expected,[StringComparison]::OrdinalIgnoreCase)){$matches.Add(('HKU/'+$view))}}catch{}
      }
    }
  }
  return [pscustomobject]@{ok=($matches.Count-gt0);matches=@($matches);reason=if($matches.Count-gt0){'ok'}else{'registry_mismatch'}}
}

function ConvertFrom-JsonWithLineComments([string]$Text){
  if([string]::IsNullOrWhiteSpace($Text)){return $null}
  $sb=New-Object Text.StringBuilder
  $inString=$false;$escaped=$false;$i=0
  while($i-lt$Text.Length){
    $c=$Text[$i]
    if($inString){
      [void]$sb.Append($c)
      if($escaped){$escaped=$false}
      elseif($c-eq'\'){$escaped=$true}
      elseif($c-eq'"'){$inString=$false}
      $i++;continue
    }
    if($c-eq'"'){$inString=$true;[void]$sb.Append($c);$i++;continue}
    if($c-eq'/'-and($i+1)-lt$Text.Length-and$Text[$i+1]-eq'/'){
      $i+=2
      while($i-lt$Text.Length-and$Text[$i]-ne"`r"-and$Text[$i]-ne"`n"){$i++}
      continue
    }
    [void]$sb.Append($c);$i++
  }
  return ($sb.ToString()|ConvertFrom-Json -ErrorAction Stop)
}

function Remove-RegistrySubKeyTree([Microsoft.Win32.RegistryHive]$Hive,[Microsoft.Win32.RegistryView]$View,[string]$SubKey){
  $base=$null
  try{$base=[Microsoft.Win32.RegistryKey]::OpenBaseKey($Hive,$View);$base.DeleteSubKeyTree($SubKey,$false)}catch{}finally{if($base){$base.Dispose()}}
}
function Remove-NativeMessagingRegistration([string]$UserSid){
  $regViews=@([Microsoft.Win32.RegistryView]::Registry32);if([Environment]::Is64BitOperatingSystem){$regViews+=[Microsoft.Win32.RegistryView]::Registry64}
  foreach($regView in $regViews){
    $sub="Software\Google\Chrome\NativeMessagingHosts\$NativeHostName"
    Remove-RegistrySubKeyTree ([Microsoft.Win32.RegistryHive]::LocalMachine) $regView $sub
    if(-not[string]::IsNullOrWhiteSpace($UserSid)){Remove-RegistrySubKeyTree ([Microsoft.Win32.RegistryHive]::Users) $regView ("$UserSid\$sub")}
  }
}
# SPX_V160_BOUNDED_STARTUP_CLEANUP
# Some Windows installations can leave ScheduledTasks/CIM providers waiting indefinitely.
# Best-effort legacy cleanup must never block the installer forever.
function Invoke-BoundedProcess([string]$FilePath,[string]$Arguments,[int]$TimeoutMs=3000){
  $proc=$null
  try{
    $psi=New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName=$FilePath
    $psi.Arguments=$Arguments
    $psi.UseShellExecute=$false
    $psi.CreateNoWindow=$true
    $psi.WindowStyle=[System.Diagnostics.ProcessWindowStyle]::Hidden
    $proc=New-Object System.Diagnostics.Process
    $proc.StartInfo=$psi
    if(-not$proc.Start()){return [pscustomobject]@{Started=$false;TimedOut=$false;ExitCode=$null}}
    if(-not$proc.WaitForExit([Math]::Max(500,$TimeoutMs))){
      try{$proc.Kill()}catch{}
      return [pscustomobject]@{Started=$true;TimedOut=$true;ExitCode=$null}
    }
    return [pscustomobject]@{Started=$true;TimedOut=$false;ExitCode=$proc.ExitCode}
  }catch{
    return [pscustomobject]@{Started=$false;TimedOut=$false;ExitCode=$null;Error=$_.Exception.Message}
  }finally{
    if($null-ne$proc){try{$proc.Dispose()}catch{}}
  }
}
function Remove-LegacyNetworkHostTasks{
  # Never enumerate the full Task Scheduler store on the critical install path.
  foreach($legacyTask in @('SmartPageEx Network Helper','SmartPageEx Network Host','SmartPageEx Network Bridge','SmartPageEx Network Helper Recovery')){
    [void](Invoke-BoundedProcess "$env:SystemRoot\System32\schtasks.exe" ('/End /TN "'+$legacyTask+'"') 1800)
    [void](Invoke-BoundedProcess "$env:SystemRoot\System32\schtasks.exe" ('/Delete /F /TN "'+$legacyTask+'"') 1800)
  }
}
function Remove-LegacyNetworkHostServices{
  # Old packages used one known service name. Avoid a broad Win32_Service CIM enumeration.
  [void](Invoke-BoundedProcess "$env:SystemRoot\System32\sc.exe" ('stop "'+$OldBridgeServiceName+'"') 2200)
  [void](Invoke-BoundedProcess "$env:SystemRoot\System32\sc.exe" ('delete "'+$OldBridgeServiceName+'"') 2200)
}
function Test-ProcessIdStillOwnsSmartPagePorts([int]$ProcessId){
  if($ProcessId-le0){return $false}
  $control=@(Get-LoopbackPortOwnerPids 30765)
  if($control -notcontains $ProcessId){return $false}
  foreach($pp in @(30766,30767,30768,30769)){if(@(Get-LoopbackPortOwnerPids $pp) -contains $ProcessId){return $true}}
  return $false
}
function Invoke-SystemTaskkillForPid([int]$ProcessId){
  if($ProcessId-le0 -or $ProcessId-eq$PID){return $false}
  $token=[guid]::NewGuid().ToString('N').Substring(0,10)
  $taskName=('SmartPageEx Port Cleanup '+$ProcessId+' '+$token)
  # v4.1.89: SYSTEM scheduled tasks must not depend on the interactive user's TEMP path.
  # Use a ProgramData directory visible to both the installer and SYSTEM.
  $cleanupDir=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33\cleanup'
  New-Item -ItemType Directory -Path $cleanupDir -Force|Out-Null
  $cleanupScript=Join-Path $cleanupDir ('SmartPageEx-port-cleanup-'+$token+'.ps1')
  $resultPath=Join-Path $cleanupDir ('SmartPageEx-port-cleanup-'+$token+'.json')
  $cleanupBody=@'
param([int]$TargetPid,[string]$ResultPath)
$ErrorActionPreference='SilentlyContinue'
function Get-ListeningPortsForPid([int]$PidValue){
  $ports=New-Object System.Collections.Generic.List[int]
  try{
    $lines=@(& "$env:SystemRoot\System32\netstat.exe" -ano -p tcp 2>$null)
    foreach($line in $lines){
      $m=[regex]::Match([string]$line,'^\s*TCP\s+\S+:(30765|30766|30767|30768|30769)\s+\S+\s+LISTENING\s+(\d+)\s*$','IgnoreCase')
      if($m.Success -and [int]$m.Groups[2].Value -eq $PidValue){$p=[int]$m.Groups[1].Value;if(-not$ports.Contains($p)){$ports.Add($p)}}
    }
  }catch{}
  return @($ports|Sort-Object)
}
$processName='';$processPath='';$commandLine='';$taskkillExit=$null;$cimTerminate=$false;$stopProcess=$false
try{$p=Get-CimInstance Win32_Process -Filter ("ProcessId="+$TargetPid) -ErrorAction SilentlyContinue;if($p){$processName=[string]$p.Name;$processPath=[string]$p.ExecutablePath;$commandLine=[string]$p.CommandLine}}catch{}
$before=@(Get-ListeningPortsForPid $TargetPid)
try{& "$env:SystemRoot\System32\taskkill.exe" /PID $TargetPid /T /F 2>$null|Out-Null;$taskkillExit=[int]$LASTEXITCODE}catch{$taskkillExit=-1}
for($i=0;$i-lt30;$i++){if(@(Get-ListeningPortsForPid $TargetPid).Count-eq0){break};Start-Sleep -Milliseconds 100}
if(@(Get-ListeningPortsForPid $TargetPid).Count-gt0){
  try{$p=Get-CimInstance Win32_Process -Filter ("ProcessId="+$TargetPid) -ErrorAction SilentlyContinue;if($p){$r=Invoke-CimMethod -InputObject $p -MethodName Terminate -ErrorAction SilentlyContinue;if($r -and [int]$r.ReturnValue -eq0){$cimTerminate=$true}}}catch{}
  for($i=0;$i-lt25;$i++){if(@(Get-ListeningPortsForPid $TargetPid).Count-eq0){break};Start-Sleep -Milliseconds 100}
}
if(@(Get-ListeningPortsForPid $TargetPid).Count-gt0){
  try{Stop-Process -Id $TargetPid -Force -ErrorAction SilentlyContinue;$stopProcess=$true}catch{}
  for($i=0;$i-lt25;$i++){if(@(Get-ListeningPortsForPid $TargetPid).Count-eq0){break};Start-Sleep -Milliseconds 100}
}
$after=@(Get-ListeningPortsForPid $TargetPid)
$result=[ordered]@{ok=($after.Count-eq0);pid=$TargetPid;processName=$processName;processPath=$processPath;commandLine=$commandLine;beforePorts=$before;afterPorts=$after;taskkillExit=$taskkillExit;cimTerminate=$cimTerminate;stopProcess=$stopProcess;completedAt=(Get-Date).ToUniversalTime().ToString('o')}
try{[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Compress -Depth 4),(New-Object Text.UTF8Encoding($false)))}catch{}
if($after.Count-eq0){exit 0}else{exit 1}
'@
  try{
    Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
    [IO.File]::WriteAllText($cleanupScript,$cleanupBody,(New-Object Text.UTF8Encoding($true)))
    $cleanupArgs=('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$cleanupScript+'" -TargetPid '+$ProcessId+' -ResultPath "'+$resultPath+'"')
    $action=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument $cleanupArgs -WorkingDirectory $cleanupDir
    $principal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 1)
    Register-ScheduledTask -TaskName $taskName -Action $action -Principal $principal -Settings $settings -Force -ErrorAction Stop|Out-Null
    Start-ScheduledTask -TaskName $taskName -ErrorAction Stop
    # Start-ScheduledTask is asynchronous. Keep the task until SYSTEM actually runs and reports completion.
    for($i=0;$i-lt200;$i++){
      if(Test-Path -LiteralPath $resultPath){break}
      if(-not(Test-ProcessIdStillOwnsSmartPagePorts $ProcessId)){break}
      Start-Sleep -Milliseconds 100
    }
    $result=$null
    if(Test-Path -LiteralPath $resultPath){try{$result=Get-Content -LiteralPath $resultPath -Raw -Encoding UTF8|ConvertFrom-Json}catch{}}
    $detail=''
    if($null-ne$result){
      $detail=('SYSTEM 포트 정리 결과 · PID '+$ProcessId+' · process='+$(if($result.processName){[string]$result.processName}else{'미확인'})+' · taskkillExit='+[string]$result.taskkillExit+' · before='+(@($result.beforePorts)-join ',')+' · after='+(@($result.afterPorts)-join ','))
      if($result.ok-eq$true){Write-Host $detail -ForegroundColor DarkGray}
    }else{
      $taskDetail=''
      try{$ti=Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction Stop;$taskDetail=(' LastTaskResult='+[string]$ti.LastTaskResult+' LastRunTime='+[string]$ti.LastRunTime)}catch{}
      $detail=('SYSTEM 포트 정리 결과 파일을 받지 못했습니다 · PID '+$ProcessId+'.'+$taskDetail)
    }
    # Port release, not task submission or the first netstat snapshot, is the success criterion.
    # Windows can keep a just-terminated SYSTEM listener in netstat briefly even after the process object disappears.
    for($i=0;$i-lt50;$i++){
      if(-not(Test-ProcessIdStillOwnsSmartPagePorts $ProcessId)){
        if($null-ne$result -and $result.ok-ne$true){Write-Host ('SYSTEM 포트 지연 해제 확인 · PID '+$ProcessId+' · 최종적으로 30765/프록시 포트가 닫혔습니다.') -ForegroundColor DarkGray}
        return $true
      }
      Start-Sleep -Milliseconds 100
    }
    if(-not[string]::IsNullOrWhiteSpace($detail)){Write-Host $detail -ForegroundColor Yellow}
  }catch{
    Write-Host ('SYSTEM 포트 정리 실행 실패 · PID '+$ProcessId+' · '+$_.Exception.Message) -ForegroundColor Yellow
  }finally{
    try{Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue}catch{}
    try{Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue}catch{}
    try{Remove-Item -LiteralPath $cleanupScript,$resultPath -Force -ErrorAction SilentlyContinue}catch{}
  }
  return (-not(Test-ProcessIdStillOwnsSmartPagePorts $ProcessId))
}
function Stop-ProcessIdHard([int]$ProcessId){
  if($ProcessId-le0 -or $ProcessId-eq$PID){return $false}
  try{
    $proc=Get-CimInstance Win32_Process -Filter ("ProcessId="+$ProcessId) -ErrorAction SilentlyContinue
    if($null-ne$proc){try{Invoke-CimMethod -InputObject $proc -MethodName Terminate -ErrorAction SilentlyContinue|Out-Null}catch{}}
  }catch{}
  Start-Sleep -Milliseconds 120
  if(-not(Test-ProcessIdStillOwnsSmartPagePorts $ProcessId)){return $true}
  try{Stop-Process -Id $ProcessId -Force -ErrorAction SilentlyContinue}catch{}
  try{& "$env:SystemRoot\System32\taskkill.exe" /PID $ProcessId /T /F 2>$null|Out-Null}catch{}
  for($i=0;$i-lt12;$i++){Start-Sleep -Milliseconds 120;if(-not(Test-ProcessIdStillOwnsSmartPagePorts $ProcessId)){return $true}}
  # SYSTEM 시작 helper처럼 현재 관리자 PowerShell에서 프로세스 이름/경로 조회가 실패하는 경우에도
  # 30765+30766~30769 동일 PID라는 SmartPage 전용 포트 서명을 확인한 뒤 SYSTEM 일회성 작업으로 종료합니다.
  if(Test-ProcessIdStillOwnsSmartPagePorts $ProcessId){
    Write-Host ('SmartPage Ex 전용 포트 소유 PID '+$ProcessId+'가 일반 종료에 응답하지 않아 SYSTEM 권한으로 안전 정리합니다.') -ForegroundColor Yellow
    [void](Invoke-SystemTaskkillForPid $ProcessId)
  }
  return (-not(Test-ProcessIdStillOwnsSmartPagePorts $ProcessId))
}
function Invoke-SystemBroadSmartPagePortCleanup{
  $token=[guid]::NewGuid().ToString('N').Substring(0,10)
  $taskName=('SmartPageEx Broad Port Cleanup '+$token)
  $cleanupDir=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33\cleanup'
  New-Item -ItemType Directory -Path $cleanupDir -Force|Out-Null
  $cleanupScript=Join-Path $cleanupDir ('SmartPageEx-broad-port-cleanup-'+$token+'.ps1')
  $resultPath=Join-Path $cleanupDir ('SmartPageEx-broad-port-cleanup-'+$token+'.json')
  $cleanupBody=@'
param([string]$ResultPath)
$ErrorActionPreference='SilentlyContinue'
$stoppedTasks=@();$killed=@()
try{
  Get-ScheduledTask -ErrorAction SilentlyContinue|Where-Object{[string]$_.TaskName -like 'SmartPageEx*'}|ForEach-Object{
    try{Stop-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath -ErrorAction SilentlyContinue;$stoppedTasks+=([string]$_.TaskName)}catch{}
  }
}catch{}
try{& "$env:SystemRoot\System32\taskkill.exe" /IM SpxNetworkHost.exe /T /F 2>$null|Out-Null}catch{}
try{
  Get-CimInstance Win32_Process -ErrorAction SilentlyContinue|Where-Object{
    ([string]$_.Name -ieq 'SpxNetworkHost.exe') -or
    ([string]$_.ExecutablePath -match '(?i)SmartPageEx\\NetworkHost') -or
    ([string]$_.CommandLine -match '(?i)(SmartPageEx\\NetworkHost|SpxNetworkHost|network-switch-daemon|network-worker|start-network-host)')
  }|ForEach-Object{
    try{$pidValue=[int]$_.ProcessId;if($pidValue-gt4){$r=Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue;if($r -and [int]$r.ReturnValue -eq0){$killed+=$pidValue}}}catch{}
  }
}catch{}
Start-Sleep -Milliseconds 500
$owners=@()
try{
  $lines=@(& "$env:SystemRoot\System32\netstat.exe" -ano -p tcp 2>$null)
  foreach($line in $lines){
    $m=[regex]::Match([string]$line,'^\s*TCP\s+\S+:(30765|30766|30767|30768|30769)\s+\S+\s+LISTENING\s+(\d+)\s*$','IgnoreCase')
    if($m.Success){$owners+=([int]$m.Groups[2].Value)}
  }
}catch{}
$result=[ordered]@{ok=(@($owners|Sort-Object -Unique).Count-eq0);owners=@($owners|Sort-Object -Unique);stoppedTasks=@($stoppedTasks|Sort-Object -Unique);killed=@($killed|Sort-Object -Unique);completedAt=(Get-Date).ToUniversalTime().ToString('o')}
try{[IO.File]::WriteAllText($ResultPath,($result|ConvertTo-Json -Compress -Depth 4),(New-Object Text.UTF8Encoding($false)))}catch{}
if($result.ok){exit 0}else{exit 1}
'@
  try{
    Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
    [IO.File]::WriteAllText($cleanupScript,$cleanupBody,(New-Object Text.UTF8Encoding($true)))
    $cleanupArgs=('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$cleanupScript+'" -ResultPath "'+$resultPath+'"')
    $action=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument $cleanupArgs -WorkingDirectory $cleanupDir
    $principal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Seconds 40)
    Register-ScheduledTask -TaskName $taskName -Action $action -Principal $principal -Settings $settings -Force -ErrorAction Stop|Out-Null
    Start-ScheduledTask -TaskName $taskName -ErrorAction Stop
    for($i=0;$i-lt160;$i++){
      if(Test-Path -LiteralPath $resultPath){break}
      if(@(Get-LoopbackPortOwnerPids 30765).Count-eq0){break}
      Start-Sleep -Milliseconds 100
    }
    $result=$null
    if(Test-Path -LiteralPath $resultPath){try{$result=Get-Content -LiteralPath $resultPath -Raw -Encoding UTF8|ConvertFrom-Json}catch{}}
    for($i=0;$i-lt50;$i++){
      if(@(Get-LoopbackPortOwnerPids 30765).Count-eq0){Start-Sleep -Milliseconds 250;if(@(Get-LoopbackPortOwnerPids 30765).Count-eq0){return $true}}
      Start-Sleep -Milliseconds 100
    }
    if($null-ne$result){Write-Host ('SYSTEM 전체 Helper 정리 결과 · 남은 PID '+(@($result.owners)-join ',')+' · 종료 PID '+(@($result.killed)-join ',')) -ForegroundColor Yellow}
  }catch{
    Write-Host ('SYSTEM 전체 Helper 정리 실행 실패 · '+$_.Exception.Message) -ForegroundColor Yellow
  }finally{
    try{Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue}catch{}
    try{Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue}catch{}
    try{Remove-Item -LiteralPath $cleanupScript,$resultPath -Force -ErrorAction SilentlyContinue}catch{}
  }
  return (@(Get-LoopbackPortOwnerPids 30765).Count-eq0)
}
function Clear-SmartPageDedicatedLoopbackPorts{
  # Installer cleanup must be bounded. Never run the same SYSTEM kill loop for minutes.
  # 1) each observed PID gets one hard cleanup attempt; 2) one broad SYSTEM cleanup; 3) fail with diagnostics.
  $attempted=@{}
  for($round=0;$round-lt8;$round++){
    $control=@(Get-LoopbackPortOwnerPids 30765|Sort-Object -Unique)
    $proxyMap=@{}
    foreach($pp in @(30766,30767,30768,30769)){$proxyMap[$pp]=@(Get-LoopbackPortOwnerPids $pp)}
    if($control.Count-eq0){
      Start-Sleep -Milliseconds 250
      if(@(Get-LoopbackPortOwnerPids 30765).Count-eq0){Start-Sleep -Milliseconds 250;if(@(Get-LoopbackPortOwnerPids 30765).Count-eq0){return $true}}
      continue
    }
    $didAttempt=$false
    foreach($ownerPid in $control){
      $ownsProxy=$false
      foreach($pp in @(30766,30767,30768,30769)){if($proxyMap[$pp] -contains [int]$ownerPid){$ownsProxy=$true;break}}
      if(($ownsProxy -or (Test-SmartPageBridgeOwnerPid $ownerPid)) -and -not $attempted.ContainsKey([string]$ownerPid)){
        $attempted[[string]$ownerPid]=$true
        $didAttempt=$true
        [void](Stop-ProcessIdHard $ownerPid)
      }
    }
    if(@(Get-LoopbackPortOwnerPids 30765).Count-eq0){Start-Sleep -Milliseconds 300;if(@(Get-LoopbackPortOwnerPids 30765).Count-eq0){return $true}}
    if(-not$didAttempt){break}
    Start-Sleep -Milliseconds 250
  }
  if(@(Get-LoopbackPortOwnerPids 30765).Count-gt0){
    Write-Host ('PID별 정리 후에도 전용 포트가 남아 SYSTEM 전체 Helper 정리를 1회만 실행합니다. '+(Get-LoopbackPortOwnerText 30765)) -ForegroundColor Yellow
    [void](Invoke-SystemBroadSmartPagePortCleanup)
  }
  if(@(Get-LoopbackPortOwnerPids 30765).Count-eq0){Start-Sleep -Milliseconds 300;if(@(Get-LoopbackPortOwnerPids 30765).Count-eq0){return $true}}
  Write-Host ('전용 포트 정리를 제한시간 내 완료하지 못했습니다. 동일 PID 정리를 반복하지 않고 설치를 중단합니다. '+(Get-LoopbackPortOwnerText 30765)) -ForegroundColor Red
  return $false
}
function Get-ReadyProxyPort{
  foreach($pp in @(30766,30767,30768,30769)){if(Test-LoopbackPort $pp 120){return [int]$pp}}
  return 0
}
function Wait-BridgePorts([int]$Attempts=50,[int]$DelayMs=150){
  for($i=0;$i-lt$Attempts;$i++){
    if(Test-LoopbackPort 30765 120){$pp=Get-ReadyProxyPort;if($pp-ge30766){return [int]$pp}}
    Start-Sleep -Milliseconds $DelayMs
  }
  return 0
}
function Register-NativeMessagingRegistration([string]$UserSid,[string]$Manifest){
  $regViews=@([Microsoft.Win32.RegistryView]::Registry32);if([Environment]::Is64BitOperatingSystem){$regViews+=[Microsoft.Win32.RegistryView]::Registry64}
  foreach($regView in $regViews){
    $sub="Software\Google\Chrome\NativeMessagingHosts\$NativeHostName"
    Set-RegistryDefaultValue ([Microsoft.Win32.RegistryHive]::LocalMachine) $regView $sub $Manifest
    if(-not[string]::IsNullOrWhiteSpace($UserSid)){Set-RegistryDefaultValue ([Microsoft.Win32.RegistryHive]::Users) $regView ("$UserSid\$sub") $Manifest}
  }
}
function Stop-AndRemoveTask([string]$TaskName){
  # ScheduledTasks provider can hang on damaged task stores, so use bounded schtasks.exe calls.
  $endResult=Invoke-BoundedProcess "$env:SystemRoot\System32\schtasks.exe" ('/End /TN "'+$TaskName+'"') 2200
  if($endResult.TimedOut){Write-Host ('예약 작업 종료 제한시간 초과 · '+$TaskName+' · 계속 진행합니다.') -ForegroundColor Yellow}
  if($TaskName-eq$BridgeTaskName){
    for($i=0;$i-lt30;$i++){if(-not(Test-LoopbackPort 30765 100)){break};Start-Sleep -Milliseconds 100}
  }
  $deleteResult=Invoke-BoundedProcess "$env:SystemRoot\System32\schtasks.exe" ('/Delete /F /TN "'+$TaskName+'"') 2200
  if($deleteResult.TimedOut){Write-Host ('예약 작업 삭제 제한시간 초과 · '+$TaskName+' · 포트 기반 정리로 계속 진행합니다.') -ForegroundColor Yellow}
}
function Grant-ScheduledTaskReadExecute([string]$TaskName,[string]$UserSid){
  try{
    $service=New-Object -ComObject 'Schedule.Service';$service.Connect()
    $folder=$service.GetFolder('\');$task=$folder.GetTask($TaskName)
    $sddl=('D:P(A;;FA;;;SY)(A;;FA;;;BA)(A;;GRGX;;;{0})' -f $UserSid)
    $task.SetSecurityDescriptor($sddl,0)
    return $true
  }catch{Write-Warning ("예약 작업 실행 권한 부여 실패: {0}" -f $_.Exception.Message);return $false}
}
function Restore-StoredNetworkMetrics([string]$StatePath){
  if(-not(Test-Path -LiteralPath $StatePath)){return}
  try{
    $state=Get-Content -LiteralPath $StatePath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
    if($null-eq$state-or-not$state.applied){Remove-Item -LiteralPath $StatePath -Force -ErrorAction SilentlyContinue;return}
    $changes=@()
    if($null-ne$state.changes){$changes=@($state.changes)}
    elseif($null-ne$state.interfaceIndex){$changes=@([pscustomobject]@{interfaceIndex=[int]$state.interfaceIndex;originalAutomaticMetric=[string]$state.originalAutomaticMetric;originalInterfaceMetric=[int]$state.originalInterfaceMetric})}
    foreach($change in $changes){
      $index=[int]$change.interfaceIndex;if($index-le0){continue}
      $iface=Get-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $index -ErrorAction SilentlyContinue|Select-Object -First 1
      if($null-eq$iface){continue}
      $auto=[string]$change.originalAutomaticMetric
      if($auto-match'Enabled|True' -or [string]::IsNullOrWhiteSpace($auto)){
        Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $index -AutomaticMetric Enabled -ErrorAction SilentlyContinue
      }else{
        Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $index -AutomaticMetric Disabled -InterfaceMetric ([Math]::Max(1,[int]$change.originalInterfaceMetric)) -ErrorAction SilentlyContinue
      }
    }
  }catch{}finally{Remove-Item -LiteralPath $StatePath -Force -ErrorAction SilentlyContinue}
}

function Assert-DeferredTargetInstallComplete{
  if(-not$DeferredUpgrade){return $null}
  Set-DeferredUpgradePhase 'VERIFY_TARGET_RUNTIME'

  $installedSource=Join-Path $InstallDir 'SpxNetworkHost.cs'
  $installedStart=Join-Path $InstallDir 'start-network-host.ps1'
  if((Get-InstallerSha256 $installedSource) -ne $ExpectedHelperSourceSha){throw 'Deferred target verification failed: installed SpxNetworkHost.cs SHA mismatch.'}
  if((Get-InstallerSha256 $installedStart) -ne $ExpectedStartScriptSha){throw 'Deferred target verification failed: installed start-network-host.ps1 SHA mismatch.'}
  if(-not(Test-Path -LiteralPath $ExePath -PathType Leaf)){throw 'Deferred target verification failed: SpxNetworkHost.exe missing.'}
  if(-not(Test-Path -LiteralPath $DllPath -PathType Leaf)){throw ('Deferred target verification failed: versioned helper DLL missing: '+$DllFileName)}

  if(-not(Test-Path -LiteralPath $ConfigPath -PathType Leaf)){throw 'Deferred target verification failed: config missing.'}
  $finalConfig=[IO.File]::ReadAllText($ConfigPath,[Text.Encoding]::UTF8)|ConvertFrom-Json -ErrorAction Stop
  if([string]$finalConfig.helperVersion -ne $ExpectedHelperVersion){throw ('Deferred target verification failed: config HelperVersion='+[string]$finalConfig.helperVersion)}
  if([string]$finalConfig.buildMarker -ne $ExpectedBuildMarker){throw ('Deferred target verification failed: config BuildMarker='+[string]$finalConfig.buildMarker)}
  if($finalConfig.upgradePending -eq $true){throw 'Deferred target verification failed: config upgradePending is still true.'}

  $health=$null
  for($attempt=0;$attempt-lt6;$attempt++){
    if($attempt -gt 0){Start-Sleep -Milliseconds 300}
    $health=Get-LocalBridgeHealth 2
    if($null-ne$health){break}
  }
  if($null-eq$health){throw 'Deferred target verification failed: /health HTTP 200 target response unavailable.'}
  if([string]$health.helperVersion -ne $ExpectedHelperVersion){throw ('Deferred target verification failed: /health HelperVersion='+[string]$health.helperVersion)}
  if([string]$health.buildMarker -ne $ExpectedBuildMarker){throw ('Deferred target verification failed: /health BuildMarker='+[string]$health.buildMarker)}
  if($health.proxyReady -ne $true){throw 'Deferred target verification failed: /health proxyReady is not true.'}

  $healthPid=0;$healthProxy=0
  try{$healthPid=[int]$health.pid}catch{}
  try{$healthProxy=[int]$health.proxyPort}catch{}
  if($healthPid -le 0){throw 'Deferred target verification failed: /health PID invalid.'}
  if($healthProxy -lt 30766 -or $healthProxy -gt 30769){throw ('Deferred target verification failed: /health proxyPort='+$healthProxy)}

  $controlOwners=@(Get-LoopbackPortOwnerPids 30765)
  $proxyOwners=@(Get-LoopbackPortOwnerPids $healthProxy)
  if($controlOwners.Count -ne 1 -or [int]$controlOwners[0] -ne $healthPid){throw ('Deferred target verification failed: 30765 owner does not equal health PID '+$healthPid+'. owners='+($controlOwners -join ','))}
  if($proxyOwners.Count -ne 1 -or [int]$proxyOwners[0] -ne $healthPid){throw ('Deferred target verification failed: proxy owner does not equal health PID '+$healthPid+'. owners='+($proxyOwners -join ','))}

  foreach($requiredTaskName in @($BridgeTaskName,$RecoveryTaskName,$NetworkTaskName,$BrowserTaskName)){
    if($null-eq(Get-ScheduledTask -TaskName $requiredTaskName -ErrorAction SilentlyContinue)){throw ('Deferred target verification failed: required task missing '+$requiredTaskName)}
  }

  Write-DeferredUpgradeStatus 'TARGET_VERIFIED' 'TARGET_VERIFIED'
  return [pscustomobject]@{helperVersion=[string]$health.helperVersion;buildMarker=[string]$health.buildMarker;pid=$healthPid;proxyPort=$healthProxy}
}

function Complete-DeferredUpgradeLifecycle{
  if(-not$DeferredUpgrade){return $null}
  $verification=Assert-DeferredTargetInstallComplete

  Set-DeferredUpgradePhase 'FINALIZE_DEFERRED_TASK'
  $task=Get-ScheduledTask -TaskName $DeferredUpgradeTaskName -ErrorAction SilentlyContinue
  if($null-ne$task){
    Unregister-ScheduledTask -TaskName $DeferredUpgradeTaskName -Confirm:$false -ErrorAction Stop
  }
  if($null-ne(Get-ScheduledTask -TaskName $DeferredUpgradeTaskName -ErrorAction SilentlyContinue)){
    throw 'Deferred target verification passed but Deferred Upgrade task could not be removed.'
  }

  # Cleanup is permitted only after target verification. The currently executing staged
  # directory is intentionally retained as forensic evidence because deleting the running
  # script tree can be non-deterministic on Windows PowerShell 5.1. Other stale deferred
  # staging directories can be removed now.
  Set-DeferredUpgradePhase 'CLEANUP_STAGING'
  try{
    $sourceDirNormalized=''
    try{$sourceDirNormalized=[IO.Path]::GetFullPath($SourceDir).TrimEnd('\')}catch{}
    foreach($candidate in @((Join-Path $InstallDir 'deferred-upgrade-v3026'),(Join-Path $InstallDir 'deferred-upgrade-v4183-orphan-port'))){
      $candidateNormalized=''
      try{$candidateNormalized=[IO.Path]::GetFullPath($candidate).TrimEnd('\')}catch{}
      if(-not[string]::IsNullOrWhiteSpace($candidateNormalized) -and (Test-Path -LiteralPath $candidate -PathType Container)){
        if(-not[string]::Equals($candidateNormalized,$sourceDirNormalized,[StringComparison]::OrdinalIgnoreCase)){
          Remove-Item -LiteralPath $candidate -Recurse -Force -ErrorAction Stop
        }
      }
    }
  }catch{$script:DeferredCleanupError=$_.Exception.Message}

  Write-DeferredUpgradeStatus 'SUCCESS' 'COMPLETE'
  try{Release-DeferredExecutionMutex}catch{}
  return $verification
}


Remove-Item -LiteralPath $StatusPath -Force -ErrorAction SilentlyContinue
$RequestedExtensionId=([string]$ExtensionId).Trim().ToLowerInvariant()
if(-not[string]::IsNullOrWhiteSpace($RequestedExtensionId)-and$RequestedExtensionId-notmatch'^[a-p]{32}$'){throw 'Invalid Chrome extension ID.'}
if(-not (Test-Administrator)){
  $quoted='"'+$PSCommandPath.Replace('"','""')+'"'
  $args="-NoProfile -ExecutionPolicy Bypass -File $quoted -Elevated"
  if(-not[string]::IsNullOrWhiteSpace($RequestedExtensionId)){$args+=' -ExtensionId "'+$RequestedExtensionId+'"'}
  if(-not[string]::IsNullOrWhiteSpace($ExtensionRootOverride)){$args+=' -ExtensionRootOverride "'+([string]$ExtensionRootOverride).Replace('"','""')+'"'}
  if($DeferredUpgrade){$args+=' -DeferredUpgrade'}
  $p=Start-Process "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Verb RunAs -ArgumentList $args -Wait -PassThru
  exit $p.ExitCode
}
if($DeferredUpgrade){Initialize-DeferredUpgradeExecution}
Set-DeferredUpgradePhase 'PREFLIGHT'
$user=Get-InteractiveUserInfo
$SourceDir=Split-Path -Parent $PSCommandPath
$PackageMarkerPath=Join-Path $SourceDir 'PACKAGE_RELEASE.txt'
if(-not(Test-Path -LiteralPath $PackageMarkerPath -PathType Leaf)){
  throw ('Network Host package marker is missing. Expected '+$PackageRelease+'. Delete or rename the old spx-collector folder and extract the ZIP again.')
}
$PackageMarkerText=([IO.File]::ReadAllText($PackageMarkerPath,[Text.Encoding]::ASCII)).Trim()
if($PackageMarkerText-ne$PackageReleaseMarker){
  throw ('Network Host package files are mixed. Expected '+$PackageRelease+' but marker was "'+$PackageMarkerText+'". Delete or rename the old spx-collector folder and extract the ZIP again.')
}
$SourceCsPath=Join-Path $SourceDir 'SpxNetworkHost.cs'
$PackageLauncherPath=Join-Path $SourceDir 'SpxNetworkHostLauncher.exe'
if(-not(Test-Path -LiteralPath $SourceCsPath -PathType Leaf)){throw ('Missing file: '+$SourceCsPath)}
if(-not(Test-Path -LiteralPath $PackageLauncherPath -PathType Leaf)){throw ('Missing native launcher: '+$PackageLauncherPath)}
try{$launcherBytes=[IO.File]::ReadAllBytes($PackageLauncherPath);if($launcherBytes.Length-lt65536-or$launcherBytes[0]-ne0x4D-or$launcherBytes[1]-ne0x5A){throw 'invalid PE header'}}catch{throw ('Native launcher package validation failed: '+$_.Exception.Message)}
$packageLauncherSha=Get-FileSha256Lower $PackageLauncherPath
if($packageLauncherSha-ne$ExpectedLauncherSha){throw ('Native launcher package SHA-256 mismatch. Expected '+$ExpectedLauncherSha+' but got '+[string]$packageLauncherSha+'.')}
$SourceCsText=[IO.File]::ReadAllText($SourceCsPath,[Text.Encoding]::UTF8)
if($SourceCsText-match '[^\x00-\x7F]'){
  $firstNonAscii=-1
  for($i=0;$i-lt$SourceCsText.Length;$i++){if([int][char]$SourceCsText[$i]-gt127){$firstNonAscii=$i;break}}
  throw ('This is not the '+$PackageRelease+' ASCII-safe helper source. Source SpxNetworkHost.cs contains non-ASCII data at character '+$firstNonAscii+'. Delete or rename the old spx-collector folder and extract the ZIP again.')
}
Write-Host ('Package preflight OK: '+$PackageRelease+' / SpxNetworkHost.cs ASCII-safe') -ForegroundColor DarkGray
$InstallDir=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$PreviousInstallDir=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV31'
$DedicatedProfileDir='C:\SpxDedicatedProfile'
$ExePath=Join-Path $InstallDir 'SpxNetworkHost.exe'
# SPX_V160_DLL_LOCK_SAFE_SLOT: never compile over a DLL that an older PowerShell-hosted helper may still map.
$DllSlotToken=[Guid]::NewGuid().ToString('N').Substring(0,12)
$DllFileName=('SpxNetworkHost.v3037.'+$DllSlotToken+'.dll')
$DllPath=Join-Path $InstallDir $DllFileName
$LegacyDllPath=Join-Path $InstallDir 'SpxNetworkHost.dll'
$RuntimeHostPath=Join-Path $InstallDir 'run-network-host.ps1'
$LauncherSourcePath=Join-Path $SourceDir 'SpxNetworkHostLauncher.exe'
$ManifestPath=Join-Path $InstallDir ($NativeHostName+'.json')
$ConfigPath=Join-Path $InstallDir 'network-host-config.json'
$IntegrationSecretsPath=Join-Path $InstallDir 'integration-secrets.json'
$ProxyStatePath=Join-Path $InstallDir 'coupang-window-proxy.json'
# SPX_V160_PRESERVE_SELECTED_PROXY_STATE: RUN_08 upgrades must not erase the already-selected
# tethering adapter. The proxy sockets remain fail-closed because every Coupang connection is
# explicitly bound to the saved adapter; OpenCoupangWindow re-verifies isolation/connectivity.
$previousProxyState=$null
try{
  if(Test-Path -LiteralPath $ProxyStatePath -PathType Leaf){
    $candidateProxyState=Get-Content -LiteralPath $ProxyStatePath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
    if($candidateProxyState.enabled -eq $true -and
       (-not[string]::IsNullOrWhiteSpace([string]$candidateProxyState.adapterName) -or -not[string]::IsNullOrWhiteSpace([string]$candidateProxyState.adapterId))){
      $previousProxyState=$candidateProxyState
      Write-Host ('기존 전용망 선택 보존 준비 · '+[string]$candidateProxyState.adapterName+' / '+[string]$candidateProxyState.ipv4Address) -ForegroundColor DarkGray
    }
  }
}catch{Write-Host ('기존 전용망 선택 상태 읽기 건너뜀 · '+$_.Exception.Message) -ForegroundColor DarkYellow}
$LegacyInstallDir=Join-Path $env:ProgramData 'SmartPageEx\NetworkHost'
# v4.1.65: failed older auto-start tasks are removed, but an unkillable 29765/29766
# listener is never allowed to block the fresh V33 install on 30765/30766.
foreach($legacyTaskName in @('SmartPageEx Network Local Bridge V24','SmartPageEx Network Local Bridge User Fallback V24','SmartPageEx Network Bridge Recovery V24')){
  try{Stop-ScheduledTask -TaskName $legacyTaskName -ErrorAction SilentlyContinue}catch{}
  try{Unregister-ScheduledTask -TaskName $legacyTaskName -Confirm:$false -ErrorAction SilentlyContinue}catch{}
}
try{Get-CimInstance Win32_Process -Filter "Name='SpxNetworkHost_v3030.exe'" -ErrorAction SilentlyContinue|ForEach-Object{try{Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue|Out-Null}catch{}}}catch{}

$ExtensionRoot=''
if(-not[string]::IsNullOrWhiteSpace($ExtensionRootOverride)){
  try{$candidateRoot=[IO.Path]::GetFullPath([string]$ExtensionRootOverride);if(Test-Path -LiteralPath $candidateRoot -PathType Container){$ExtensionRoot=$candidateRoot}}catch{}
}
if([string]::IsNullOrWhiteSpace($ExtensionRoot)){$ExtensionRoot=Find-SmartPageExtensionRoot $SourceDir}
$DetectedExtensionIds=@(Find-LoadedSmartPageExtensionIds $user.ProfilePath $ExtensionRoot)
$AllowedExtensionIds=New-Object System.Collections.Generic.List[string]
Add-UniqueExtensionId $AllowedExtensionIds $RequestedExtensionId
foreach($candidateId in $DetectedExtensionIds){Add-UniqueExtensionId $AllowedExtensionIds $candidateId}
$PrimaryExtensionId=if(-not[string]::IsNullOrWhiteSpace($RequestedExtensionId)){$RequestedExtensionId}elseif($DetectedExtensionIds.Count-gt 0){[string]$DetectedExtensionIds[0]}else{''}
if([string]::IsNullOrWhiteSpace($PrimaryExtensionId)){
  # v3.0.8.5: Windows PowerShell 5.1 인코딩과 C# Add-Type 컴파일을 먼저 안정화합니다.
  # Chrome이 완전히 종료됐거나 새 폴더로 덮어써 Preferences 경로가 아직 갱신되지
  # 않은 경우에도 설치를 중단하지 않습니다. 로컬 브리지는 확장 ID와 무관하게 동작하고,
  # Native Messaging 백업에는 기존 고정 ID를 우선 허용합니다.
  $PrimaryExtensionId=$KnownExtensionId
  Add-UniqueExtensionId $AllowedExtensionIds $PrimaryExtensionId
  Write-Host '';Write-Host '현재 확장 ID 자동 탐지는 생략되었습니다. 로컬 브리지 우선 방식으로 설치를 계속합니다.' -ForegroundColor Yellow
}
# 이전 설치 경로에서 쓰던 ID도 함께 허용해 기존 Chrome 프로필을 보존합니다.
Add-UniqueExtensionId $AllowedExtensionIds $KnownExtensionId
$AllowedOrigins=@($AllowedExtensionIds|ForEach-Object{"chrome-extension://$_/"})

# PATCH7: 재부팅/로그온으로 이미 정상 SYSTEM 브리지가 떠 있다면 그것이 정상 상태입니다.
# running SpxNetworkHost.exe는 절대 종료/재기동하지 않습니다.
# 다만 PATCH6의 조기 성공 경로에서 누락됐던 보조 스크립트/예약작업/ACL/config를 현재 ZIP 기준으로
# 다시 동기화하여 전용창 실행과 network-command-queue-v3083 처리 경로를 복구합니다.
$existingBridge=Get-ExpectedHelperPortOwnerStatus
# PATCH11: 같은 빌드라도 stale 모바일-reset mutex/state가 남아 있으면 실행 중 helper를 재사용하지 않습니다.
# helper 재시작은 Global\SmartPageExMobileNetworkResetV1 커널 mutex까지 확실히 해제하는 유일한 안전 경로입니다.
if($null-ne$existingBridge){
  try{
    $mobileStatus=Invoke-LocalBridgeApi @{command='mobile_reset_status'} 2
    if($null-ne$mobileStatus -and $mobileStatus.running -eq $true){
      $phase=[string]$mobileStatus.phase
      $started=[datetime]::MinValue;try{$started=[datetime]::Parse([string]$mobileStatus.startedAt).ToUniversalTime()}catch{}
      $ageSec=if($started-ne[datetime]::MinValue){((Get-Date).ToUniversalTime()-$started).TotalSeconds}else{999999}
      if([string]::IsNullOrWhiteSpace($phase) -and $ageSec-gt30){
        Write-Host ('단계정보 없는 stale 모바일 네트워크 복구 잠금 감지('+[Math]::Round($ageSec)+'초) · helper를 안전 재시작합니다.') -ForegroundColor Yellow
        $existingBridge=$null
      }
    }
  }catch{}
}
$compatibleBridge=$null
if($null-eq$existingBridge){$compatibleBridge=Get-CompatibleSmartPageBridgeStatus}
if($null-ne$compatibleBridge){
  if($DeferredUpgrade){
    throw ('Deferred upgrade still detected a compatible live bridge after restart. No automatic requeue is allowed. '+(Get-BridgeFailureDetail))
  }
  $legacyPid=0;$legacyProxyPort=0
  try{$legacyPid=[int]$compatibleBridge.pid}catch{}
  try{$legacyProxyPort=[int]$compatibleBridge.proxyPort}catch{}
  Write-Host ($PackageRelease+' 호환 브리지 보호모드 · 현재 helper '+[string]$compatibleBridge.helperVersion+' / '+[string]$compatibleBridge.buildMarker+' · PID '+$legacyPid+'가 30765/'+$legacyProxyPort+'에서 정상 응답 중입니다.') -ForegroundColor Yellow
  Write-Host ('이 PID를 강제 종료하지 않습니다. 현재 세션은 살리고 다음 Windows 재시작 뒤 대상 Helper '+$ExpectedHelperVersion+' 정합 복구를 자동 실행합니다.') -ForegroundColor Yellow

  New-Item -ItemType Directory -Path $InstallDir -Force|Out-Null
  New-Item -ItemType Directory -Path $DedicatedProfileDir -Force|Out-Null
  foreach($name in @('SpxNetworkHost.cs','SpxNetworkHostLauncher.exe','run-network-host.ps1','network-worker.ps1','network-switch-daemon.ps1','reset-mobile-network.ps1','open-dedicated-window.ps1','start-network-host.ps1','stop-network-host.ps1')){
    $source=Join-Path $SourceDir $name
    if(-not(Test-Path -LiteralPath $source -PathType Leaf)){throw "Missing support file: $source"}
    Copy-Item -LiteralPath $source -Destination (Join-Path $InstallDir $name) -Force
  }
  & "$env:SystemRoot\System32\icacls.exe" $InstallDir /inheritance:e /grant ('*S-1-5-18:(OI)(CI)F') ('*S-1-5-32-544:(OI)(CI)F') ('*'+$user.Sid+':(OI)(CI)M') /T /C|Out-Null
  & "$env:SystemRoot\System32\icacls.exe" $DedicatedProfileDir /inheritance:e /grant ('*S-1-5-18:(OI)(CI)F') ('*S-1-5-32-544:(OI)(CI)F') ('*'+$user.Sid+':(OI)(CI)M') /T /C|Out-Null

  if(-not(Test-Path -LiteralPath $IntegrationSecretsPath -PathType Leaf)){
    $integrationTemplate=[ordered]@{supabaseUrl='';serviceKey='';naverApiKey='';naverSecretKey='';naverCustomerId='';naverDataLabHubClientId='';naverDataLabHubClientSecret='';naverDataLabLegacyClientId='';naverDataLabLegacyClientSecret='';geminiApiKey='';openaiApiKey=''}
    [IO.File]::WriteAllText($IntegrationSecretsPath,($integrationTemplate|ConvertTo-Json -Depth 3),(New-Object Text.UTF8Encoding($false)))
  }
  & "$env:SystemRoot\System32\icacls.exe" $IntegrationSecretsPath /inheritance:r /grant:r ('*S-1-5-18:F') ('*S-1-5-32-544:F') ('*'+$user.Sid+':M') /C|Out-Null

  $compatConfig=[ordered]@{}
  try{if(Test-Path -LiteralPath $ConfigPath -PathType Leaf){$oldConfig=Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop;foreach($prop in @($oldConfig.PSObject.Properties)){$compatConfig[[string]$prop.Name]=$prop.Value}}}catch{}
  $compatConfig['extensionRoot']=$ExtensionRoot;$compatConfig['extensionRootFound']=(-not[string]::IsNullOrWhiteSpace($ExtensionRoot))
  $compatConfig['extensionId']=$PrimaryExtensionId;$compatConfig['extensionIds']=@($AllowedExtensionIds);$compatConfig['detectedExtensionIds']=$DetectedExtensionIds;$compatConfig['allowedOrigins']=$AllowedOrigins
  $compatConfig['bridgePort']=30765;$compatConfig['proxyPort']=$legacyProxyPort;$compatConfig['dedicatedProfileDir']=$DedicatedProfileDir
  $compatConfig['interactiveUser']=$user.Name;$compatConfig['interactiveUserSid']=$user.Sid;$compatConfig['interactiveProfile']=$user.ProfilePath
  $compatConfig['helperVersion']=[string]$compatibleBridge.helperVersion;$compatConfig['buildMarker']=[string]$compatibleBridge.buildMarker
  $compatConfig['targetHelperVersion']=$ExpectedHelperVersion;$compatConfig['targetBuildMarker']=$ExpectedBuildMarker;$compatConfig['upgradePending']=$true
  $compatConfig['startupMode']='compatibility_bridge_until_reboot';$compatConfig['automaticStart']=$true;$compatConfig['watchdog']=$false;$compatConfig['updatedAt']=(Get-Date).ToUniversalTime().ToString('o')
  [IO.File]::WriteAllText($ConfigPath,($compatConfig|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))

  # v4.0.42 can remove these independent support tasks before its port-cleanup failure. Restore them now.
  $networkRunnerPath=Join-Path $InstallDir 'network-switch-daemon.ps1'
  $networkAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$networkRunnerPath+'"') -WorkingDirectory $InstallDir
  $networkPrincipal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  $networkSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 3)
  Register-ScheduledTask -TaskName $NetworkTaskName -Action $networkAction -Principal $networkPrincipal -Settings $networkSettings -Force|Out-Null
  $taskPermissionGranted=Grant-ScheduledTaskReadExecute $NetworkTaskName $user.Sid
  $launcherPath=Join-Path $InstallDir 'open-dedicated-window.ps1'
  $browserWatcher=Register-DedicatedBrowserWatcher $user $launcherPath
  $integrationSettingsAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\notepad.exe" -Argument ('"'+$IntegrationSecretsPath+'"') -WorkingDirectory $InstallDir
  $integrationSettingsPrincipal=New-ScheduledTaskPrincipal -UserId $user.Name -LogonType Interactive -RunLevel Limited
  $integrationSettingsTaskSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 30)
  Register-ScheduledTask -TaskName $IntegrationSettingsTaskName -Action $integrationSettingsAction -Principal $integrationSettingsPrincipal -Settings $integrationSettingsTaskSettings -Force|Out-Null

  if(Test-Path -LiteralPath $ExePath -PathType Leaf){
    $nativeCompat=[ordered]@{name=$NativeHostName;description='SmartPage Ex selected-network helper - compatibility bridge retained until reboot';path=$ExePath;type='stdio';allowed_origins=$AllowedOrigins}
    [IO.File]::WriteAllText($ManifestPath,($nativeCompat|ConvertTo-Json -Depth 6),(New-Object Text.UTF8Encoding($false)))
    Register-NativeMessagingRegistration $user.Sid $ManifestPath
  }

  # Do not stop the live process. Only prevent the old definitions from respawning it on the next boot.
  foreach($taskName in @($BridgeTaskName,$RecoveryTaskName)){try{Disable-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue|Out-Null}catch{}}

  # Copy a self-contained installer snapshot to ProgramData so the upgrade does not depend on the ZIP staying on D:.
  $deferredDir=Join-Path $InstallDir 'deferred-upgrade-v3026'
  New-Item -ItemType Directory -Path $deferredDir -Force|Out-Null
  foreach($name in @('PACKAGE_RELEASE.txt','install-network-host.ps1','SpxNetworkHost.cs','SpxNetworkHostLauncher.exe','run-network-host.ps1','network-worker.ps1','network-switch-daemon.ps1','reset-mobile-network.ps1','open-dedicated-window.ps1','start-network-host.ps1','stop-network-host.ps1')){
    $source=Join-Path $SourceDir $name
    if(-not(Test-Path -LiteralPath $source -PathType Leaf)){throw "Missing deferred upgrade file: $source"}
    Copy-Item -LiteralPath $source -Destination (Join-Path $deferredDir $name) -Force
  }
  $deferredInstaller=Join-Path $deferredDir 'install-network-host.ps1'
  $deferredArgs=('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$deferredInstaller+'" -Elevated -DeferredUpgrade -ExtensionId "'+$PrimaryExtensionId+'"');if(-not[string]::IsNullOrWhiteSpace($ExtensionRoot)){$deferredArgs+=' -ExtensionRootOverride "'+$ExtensionRoot.Replace('"','""')+'"'}
  $deferredAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument $deferredArgs -WorkingDirectory $deferredDir
  $deferredTrigger=New-ScheduledTaskTrigger -AtLogOn -User $user.Name
  $deferredPrincipal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  $deferredSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -StartWhenAvailable
  Register-ScheduledTask -TaskName $DeferredUpgradeTaskName -Action $deferredAction -Trigger $deferredTrigger -Principal $deferredPrincipal -Settings $deferredSettings -Force|Out-Null

  $compatMessage=@"
SmartPage Ex network helper compatibility repair completed.

Current bridge retained            : True
Current helper                     : $([string]$compatibleBridge.helperVersion) / $([string]$compatibleBridge.buildMarker)
Current PID                        : $legacyPid
Control / proxy                    : 127.0.0.1:30765 / 127.0.0.1:$legacyProxyPort
Target helper                      : $ExpectedHelperVersion / $ExpectedBuildMarker
Forced SYSTEM termination          : Skipped by design
Independent support tasks          : Repaired
Deferred upgrade                   : Registered for next Windows restart + user logon
Windows restart required           : True
Result                             : SUCCESS_WITH_RESTART_REQUIRED

Do not repeat install-network-host.cmd in a loop. Restart Windows once. After logon the staged installer upgrades the helper automatically.
"@
  Write-InstallStatus $compatMessage
  Write-Host ''
  Write-Host '기존 브리지를 억지로 종료하지 않고 설치 실패를 복구했습니다.' -ForegroundColor Green
  Write-Host ('Windows를 한 번 재시작하면 로그인 후 대상 Network Helper '+$ExpectedHelperVersion+' 정합 복구가 자동 실행됩니다.') -ForegroundColor Yellow
  Write-Host '재시작 전까지는 현재 호환 브리지가 계속 동작합니다. install-network-host.cmd를 반복 실행하지 마세요.' -ForegroundColor DarkGray
  Write-Host ''
  Write-Host $compatMessage -ForegroundColor Green
  exit 0
}

if($null-ne$existingBridge){
  $existingPid=0;try{$existingPid=[int]$existingBridge.pid}catch{}
  $existingProxyPort=0;try{$existingProxyPort=[int]$existingBridge.proxyPort}catch{}
  if($existingPid-gt0 -and $existingProxyPort-ge30766 -and $existingProxyPort-le30769){
    Write-Host 'PATCH7 기존 정상 브리지 감지 · 실행 중 helper는 재시작하지 않고 보조 작업만 복구합니다.' -ForegroundColor Green
    New-Item -ItemType Directory -Path $InstallDir -Force|Out-Null
    New-Item -ItemType Directory -Path $DedicatedProfileDir -Force|Out-Null

    # 실행 중 EXE/SpxNetworkHost.cs는 건드리지 않습니다. helper와 독립적인 지원 스크립트만 현재 ZIP에서 갱신합니다.
    foreach($name in @('network-worker.ps1','network-switch-daemon.ps1','reset-mobile-network.ps1','open-dedicated-window.ps1','start-network-host.ps1','stop-network-host.ps1')){
      $source=Join-Path $SourceDir $name
      if(-not(Test-Path -LiteralPath $source -PathType Leaf)){throw "Missing support file: $source"}
      Copy-Item -LiteralPath $source -Destination (Join-Path $InstallDir $name) -Force
    }

    # PATCH10 stale mobile reset cleanup: old support scripts could leave an adb.exe/PowerShell call
    # waiting without a timeout while the helper mutex stayed locked. Only processes older than 120s
    # are considered stale. First request airplane-mode OFF with the newly copied script, then terminate
    # only the stale reset script process so the running helper can release/retry safely.
    try{
      $staleCutoff=(Get-Date).AddSeconds(-150)
      $installedResetScriptVersion=''
      try{
        $resetStatePath=Join-Path $InstallDir 'mobile-reset-state.json'
        if(Test-Path -LiteralPath $resetStatePath -PathType Leaf){
          $resetState=Get-Content -LiteralPath $resetStatePath -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop
          $installedResetScriptVersion=[string]$resetState.scriptVersion
        }
      }catch{}
      $legacyResetState=([string]$installedResetScriptVersion -ne '3.0.19.0')
      $staleReset=@(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue|Where-Object{
        ($_.Name -ieq 'powershell.exe' -or $_.Name -ieq 'pwsh.exe') -and
        [string]$_.CommandLine -match [regex]::Escape($InstallDir) -and
        [string]$_.CommandLine -match 'reset-mobile-network\.ps1' -and
        ($legacyResetState -or ($_.CreationDate -and ([datetime]$_.CreationDate) -lt $staleCutoff))
      })
      if($staleReset.Count -gt 0){
        Write-Host ('구형 또는 150초 이상 멈춘 모바일 네트워크 복구 프로세스 '+$staleReset.Count+'개 감지 · 비행기 모드 안전 OFF 후 정리합니다.') -ForegroundColor Yellow
        $resetScript=Join-Path $InstallDir 'reset-mobile-network.ps1'
        try{
          $safeOff=Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$resetScript,'-ForceDisableOnly') -WindowStyle Hidden -PassThru
          if($safeOff){[void]$safeOff.WaitForExit(30000)}
        }catch{}
        foreach($proc in $staleReset){try{Invoke-CimMethod -InputObject $proc -MethodName Terminate -ErrorAction SilentlyContinue|Out-Null}catch{}}
        Start-Sleep -Milliseconds 800
      }
    }catch{}

    # PATCH5/6 도중 남을 수 있는 오래된 interactive launcher 프로세스를 종료합니다.
    Stop-ScheduledTask -TaskName $BrowserTaskName -ErrorAction SilentlyContinue
    $installPattern=[regex]::Escape($InstallDir)
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue|Where-Object{
      $_.ProcessId-ne$PID -and
      [string]$_.CommandLine-match$installPattern -and
      [string]$_.CommandLine-match'open-dedicated-window\.ps1'
    }|ForEach-Object{try{Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue|Out-Null}catch{}}
    Start-Sleep -Milliseconds 250

    # 과거 요청/결과 ACK가 새 전용창 요청을 가로막지 않도록 launcher IPC 파일만 초기화합니다.
    foreach($stale in @('dedicated-window-request.json','dedicated-window-result.json','dedicated-window-ready.json')){
      Remove-Item -LiteralPath (Join-Path $InstallDir $stale) -Force -ErrorAction SilentlyContinue
    }

    # 지원 스크립트와 launcher가 interactive user 권한으로 결과 파일을 쓸 수 있도록 ACL을 다시 보장합니다.
    & "$env:SystemRoot\System32\icacls.exe" $InstallDir /inheritance:e /grant ('*S-1-5-18:(OI)(CI)F') ('*S-1-5-32-544:(OI)(CI)F') ('*'+$user.Sid+':(OI)(CI)M') /T /C|Out-Null
    & "$env:SystemRoot\System32\icacls.exe" $DedicatedProfileDir /inheritance:e /grant ('*S-1-5-18:(OI)(CI)F') ('*S-1-5-32-544:(OI)(CI)F') ('*'+$user.Sid+':(OI)(CI)M') /T /C|Out-Null

    # config를 현재 확장 폴더/ID/interactive user에 맞춰 갱신합니다.
    $reuseConfigMap=[ordered]@{}
    try{
      if(Test-Path -LiteralPath $ConfigPath -PathType Leaf){
        $oldConfig=Get-Content -LiteralPath $ConfigPath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
        foreach($prop in @($oldConfig.PSObject.Properties)){$reuseConfigMap[[string]$prop.Name]=$prop.Value}
      }
    }catch{}
    $reuseConfigMap['extensionRoot']=$ExtensionRoot
    $reuseConfigMap['extensionRootFound']=(-not[string]::IsNullOrWhiteSpace($ExtensionRoot))
    $reuseConfigMap['extensionId']=$PrimaryExtensionId
    $reuseConfigMap['extensionIds']=@($AllowedExtensionIds)
    $reuseConfigMap['detectedExtensionIds']=$DetectedExtensionIds
    $reuseConfigMap['allowedOrigins']=$AllowedOrigins
    $reuseConfigMap['bridgePort']=30765
    $reuseConfigMap['proxyPort']=$existingProxyPort
    $reuseConfigMap['dedicatedProfileDir']=$DedicatedProfileDir
    $reuseConfigMap['interactiveUser']=$user.Name
    $reuseConfigMap['interactiveUserSid']=$user.Sid
    $reuseConfigMap['interactiveProfile']=$user.ProfilePath
    $reuseConfigMap['helperVersion']=$ExpectedHelperVersion
    $reuseConfigMap['buildMarker']=$ExpectedBuildMarker
    $reuseConfigMap['upgradePending']=$false
    $reuseConfigMap['startupMode']='system_startup_logon_bridge'
    $reuseConfigMap['automaticStart']=$true
    $reuseConfigMap['watchdog']=$true
    $reuseConfigMap['supportPlane']='patch7-repaired'
    $reuseConfigMap['updatedAt']=(Get-Date).ToUniversalTime().ToString('o')
    [IO.File]::WriteAllText($ConfigPath,($reuseConfigMap|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))

    # Native Messaging manifest는 현재 확장 ID와 실행 중 ProgramData helper를 가리키도록 갱신합니다.
    $nativeReuse=[ordered]@{
      name=$NativeHostName
      description='SmartPage Ex selected-network helper - existing SYSTEM bridge reused; support plane repaired'
      path=$ExePath
      type='stdio'
      allowed_origins=$AllowedOrigins
    }
    [IO.File]::WriteAllText($ManifestPath,($nativeReuse|ConvertTo-Json -Depth 6),(New-Object Text.UTF8Encoding($false)))
    Register-NativeMessagingRegistration $user.Sid $ManifestPath

    # network-command-queue-v3083 단발 SYSTEM 작업을 현재 스크립트로 재등록합니다.
    foreach($staleName in @('network-switch-heartbeat.json','network-switch-heartbeat-v308.json','network-switch-heartbeat-v3081.json','network-command.json','network-result.json','network-command-v308.json','network-result-v308.json','network-command-v3081.json','network-result-v3081.json','network-command-v3082.json','network-result-v3082.json','network-command-v3083.json','network-result-v3083.json')){
      Remove-Item -LiteralPath (Join-Path $InstallDir $staleName) -Force -ErrorAction SilentlyContinue
    }
    foreach($staleDir in @('network-command-queue-v3081','network-processing-queue-v3081','network-result-queue-v3081','network-command-queue-v3082','network-processing-queue-v3082','network-result-queue-v3082','network-command-queue-v3083','network-processing-queue-v3083','network-result-queue-v3083')){
      Remove-Item -LiteralPath (Join-Path $InstallDir $staleDir) -Recurse -Force -ErrorAction SilentlyContinue
    }
    $networkRunnerPath=Join-Path $InstallDir 'network-switch-daemon.ps1'
    $networkAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$networkRunnerPath+'"') -WorkingDirectory $InstallDir
    $networkPrincipal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $networkSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 3)
    Register-ScheduledTask -TaskName $NetworkTaskName -Action $networkAction -Principal $networkPrincipal -Settings $networkSettings -Force|Out-Null
    $taskPermissionGranted=Grant-ScheduledTaskReadExecute $NetworkTaskName $user.Sid

    # PATCH8: 현재 로그인 사용자 세션에 작은 watcher를 하나 유지합니다.
    $launcherPath=Join-Path $InstallDir 'open-dedicated-window.ps1'
    $browserWatcher=Register-DedicatedBrowserWatcher $user $launcherPath

    # 연동 설정 편집기 작업도 현재 interactive user로 복원합니다.
    if(-not(Test-Path -LiteralPath $IntegrationSecretsPath -PathType Leaf)){
      $integrationTemplate=[ordered]@{
        supabaseUrl='';serviceKey='';naverApiKey='';naverSecretKey='';naverCustomerId='';
        naverDataLabHubClientId='';naverDataLabHubClientSecret='';
        naverDataLabLegacyClientId='';naverDataLabLegacyClientSecret='';
        geminiApiKey='';openaiApiKey=''
      }
      [IO.File]::WriteAllText($IntegrationSecretsPath,($integrationTemplate|ConvertTo-Json -Depth 3),(New-Object Text.UTF8Encoding($false)))
    }
    & "$env:SystemRoot\System32\icacls.exe" $IntegrationSecretsPath /inheritance:r /grant:r ('*S-1-5-18:F') ('*S-1-5-32-544:F') ('*'+$user.Sid+':M') /C|Out-Null
    $integrationSettingsAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\notepad.exe" -Argument ('"'+$IntegrationSecretsPath+'"') -WorkingDirectory $InstallDir
    $integrationSettingsPrincipal=New-ScheduledTaskPrincipal -UserId $user.Name -LogonType Interactive -RunLevel Limited
    $integrationSettingsTaskSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 30)
    Register-ScheduledTask -TaskName $IntegrationSettingsTaskName -Action $integrationSettingsAction -Principal $integrationSettingsPrincipal -Settings $integrationSettingsTaskSettings -Force|Out-Null

    # 1분 safety recovery 작업은 빠른 /health 응답과 실제 프록시 포트를 함께 확인하고, 응답불능일 때 기존 SYSTEM bridge 작업을 먼저 중지한 뒤 단일 재기동합니다.
    $bridgeLauncher=Join-Path $InstallDir 'start-network-host.ps1'
    $recoveryAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$bridgeLauncher+'" -Silent') -WorkingDirectory $InstallDir
    $recoveryPrincipal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $recoveryTrigger=New-ScheduledTaskTrigger -Once -At ((Get-Date).AddMinutes(1)) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration (New-TimeSpan -Days 3650)
    $recoverySettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 1) -StartWhenAvailable
    Register-ScheduledTask -TaskName $RecoveryTaskName -Action $recoveryAction -Trigger $recoveryTrigger -Principal $recoveryPrincipal -Settings $recoverySettings -Force|Out-Null
$recoveryTaskPermissionGranted=Grant-ScheduledTaskReadExecute $RecoveryTaskName $user.Sid
if(-not$recoveryTaskPermissionGranted){Write-Warning '현재 사용자에게 SYSTEM 브리지 복구 예약작업 실행 권한을 부여하지 못했습니다. 즉시복구가 제한될 수 있습니다.'}

    # PATCH8 watcher action/세션을 설치 시 즉시 검증합니다.
    $browserTaskCheck=Get-ScheduledTask -TaskName $BrowserTaskName -ErrorAction Stop
    $browserArgs=[string](($browserTaskCheck.Actions|Select-Object -First 1).Arguments)
    if($browserArgs -notmatch '(?i)(^|\s)-Watch(\s|$)'){throw 'Dedicated browser watcher task is not configured with -Watch.'}
    if($browserArgs -notmatch '(?i)open-dedicated-window\.ps1'){throw 'Dedicated browser task action does not point to open-dedicated-window.ps1.'}

    $taskState='not queried'
    try{
      $task=Get-ScheduledTask -TaskName $BridgeTaskName -ErrorAction Stop
      $taskState=[string]$task.State
    }catch{$taskState='not found (running bridge retained)'}

    $reuseMessage=@"
SmartPage Ex network helper installation/support repair completed.

Existing SYSTEM bridge reused     : True (no restart)
Process ID                        : $existingPid
Executable                        : $ExePath
Control port                      : 127.0.0.1:30765
Proxy port                        : 127.0.0.1:$existingProxyPort
Bridge scheduled task             : $taskState
Network command queue task        : refreshed (v3083 support scripts)
Dedicated browser launcher task   : refreshed (interactive PATCH8 watcher)
Integration settings task         : refreshed
Recovery task                     : refreshed
Extension root                    : $ExtensionRoot
Native Messaging                  : registration refreshed
Installer startup model           : PATCH7 reuse-existing + support-plane repair
Result                            : SUCCESS

The running SmartPage Ex bridge was not stopped or started again.
"@
    Write-InstallStatus $reuseMessage
    Write-Host ''
    Write-Host '기존 정상 SmartPage Ex 브리지는 그대로 유지했습니다.' -ForegroundColor Green
    Write-Host ('전용창/요청 큐 보조 작업 복구 완료 · PID '+$existingPid+' · 127.0.0.1:30765 + 127.0.0.1:'+$existingProxyPort) -ForegroundColor Green
    Write-Host 'Chrome Native Messaging·현재 확장 경로·전용창 interactive watcher를 모두 갱신했습니다.' -ForegroundColor DarkGray
    Write-Host ''
    Write-Host $reuseMessage -ForegroundColor Green
    if($DeferredUpgrade){
      $null=Complete-DeferredUpgradeLifecycle
    }else{
      try{Unregister-ScheduledTask -TaskName $DeferredUpgradeTaskName -Confirm:$false -ErrorAction SilentlyContinue}catch{}
    }
    exit 0
  }
}

Write-Host 'Installer startup model: V33 isolated install; fresh 30765 bank selected; old 29765 listener is ignored, clean install continues.' -ForegroundColor DarkGray

# v4.1.42: Native Messaging 등록은 설치 중 제거하지 않습니다.
# 이전 설치가 중간 실패해도 네이버 SearchAd/DataLab 기본망 통신까지 함께 끊기지 않게 하기 위한 안전 규칙입니다.
$script:NativeRegistrationTemporarilyRemoved=$false
Write-Host '기존 Chrome Native Messaging 등록을 유지한 채 새 Helper를 병렬 준비합니다.' -ForegroundColor DarkGray

# 이름이 바뀐 과거 작업/서비스까지 정리하되 어떤 Windows 관리 provider도 무기한 기다리지 않게 합니다.
Write-Host '[1/4] 예약 작업 정리 · 각 호출 최대 2.2초' -ForegroundColor DarkGray
Remove-LegacyNetworkHostTasks
foreach($task in @($BridgeTaskName,$BrowserTaskName,$IntegrationSettingsTaskName,$RecoveryTaskName,$NetworkTaskName)){Stop-AndRemoveTask $task}
Write-Host '[1/4] 예약 작업 정리 완료' -ForegroundColor DarkGray

Write-Host '[2/4] 레거시 서비스 정리 · 전체 서비스 열거 없이 알려진 서비스만 처리' -ForegroundColor DarkGray
Remove-LegacyNetworkHostServices
Write-Host '[2/4] 레거시 서비스 정리 완료' -ForegroundColor DarkGray

Write-Host '[3/4] Helper 실행 프로세스 정리 · 광범위 PowerShell CIM 열거 생략' -ForegroundColor DarkGray
foreach($launcherProc in @(Get-Process -Name 'SpxNetworkHost' -ErrorAction SilentlyContinue)){
  # Kill the native launcher process tree first. Its child PowerShell process is the one that maps SpxNetworkHost.dll.
  [void](Invoke-BoundedProcess "$env:SystemRoot\System32\taskkill.exe" ('/PID '+[string]$launcherProc.Id+' /T /F') 2200)
  try{Stop-Process -Id $launcherProc.Id -Force -ErrorAction SilentlyContinue}catch{}
}
# A stale child can already be detached from the launcher/ports. The versioned DLL slot below guarantees such a stale mapping cannot block this install.
Start-Sleep -Milliseconds 250
Write-Host '[3/4] Helper 실행 프로세스 정리 완료' -ForegroundColor DarkGray

Write-Host '[4/4] 전용 포트 30765/30766~30769 상태 확인 및 제한시간 정리' -ForegroundColor DarkGray

# v4.0.18: 3.0.22 이하가 사용하던 18765/18766~18769 포트 뱅크는 새 helper에서 사용하지 않습니다.
# Process/CIM 객체가 사라졌는데 TCP LISTEN PID만 남는 Windows 비정상 점유가 있어도 새 설치를 막지 않습니다.
$legacyControlOwners=@(Get-LoopbackPortOwnerPids 18765)
$legacyProxyOwners=New-Object System.Collections.Generic.List[int]
foreach($legacyPort in @(18766,18767,18768,18769)){
  foreach($legacyPid in @(Get-LoopbackPortOwnerPids $legacyPort)){
    if(-not$legacyProxyOwners.Contains([int]$legacyPid)){$legacyProxyOwners.Add([int]$legacyPid)}
  }
}
if($legacyControlOwners.Count-gt0){
  $legacyShared=@($legacyControlOwners|Where-Object{$legacyProxyOwners -contains [int]$_})
  Write-Host ('구버전 브리지 포트 18765/18766~18769 잔여 LISTEN 감지 · PID '+(($legacyControlOwners|Sort-Object -Unique)-join ',')+'. v4.1.65는 30765/30766~30769 독립 포트 뱅크로 이주하여 이 점유를 안전하게 우회합니다.') -ForegroundColor Yellow
  if($legacyShared.Count-gt0){Write-Host '구버전 예약작업/서비스는 제거했으므로 해당 잔여 프로세스는 Windows 재부팅 후 다시 기동되지 않습니다.' -ForegroundColor DarkGray}
}

# v4.1.65: v4.1.64 and earlier used 29765/29766~29769. A field machine retained
# those listeners under a SYSTEM PID that taskkill/CIM could no longer identify.
# The V33 helper deliberately does not wait for or reuse that bank.
$previousControlOwners=@(Get-LoopbackPortOwnerPids 29765)
$previousProxyOwners=New-Object System.Collections.Generic.List[int]
foreach($previousPort in @(29766,29767,29768,29769)){
  foreach($previousPid in @(Get-LoopbackPortOwnerPids $previousPort)){
    if(-not$previousProxyOwners.Contains([int]$previousPid)){$previousProxyOwners.Add([int]$previousPid)}
  }
}
if($previousControlOwners.Count-gt0){
  $previousShared=@($previousControlOwners|Where-Object{$previousProxyOwners -contains [int]$_})
  Write-Host ('이전 Helper 포트 29765/29766~29769 잔여 LISTEN 감지 · PID '+(($previousControlOwners|Sort-Object -Unique)-join ',')+'. v4.2.01는 30765/30766~30769 V33 포트 뱅크를 사용하므로 설치를 계속합니다.') -ForegroundColor Yellow
  if($previousShared.Count-gt0){Write-Host '이전 예약작업/서비스는 제거했으며, 고아 listener는 다음 Windows 재부팅 때 사라져도 새 Helper에는 영향이 없습니다.' -ForegroundColor DarkGray}
}

# SmartPage Ex 새 전용 포트 쌍을 잡고 남아 있는 고아 프로세스를 정리합니다.
if(-not(Clear-SmartPageDedicatedLoopbackPorts)){
  if($DeferredUpgrade){
    throw ('Deferred upgrade could not clear the SmartPage dedicated loopback ports after restart. No automatic requeue is allowed. '+(Get-BridgeFailureDetail))
  }
  # v4.1.89: Windows가 LISTEN PID를 보고하지만 SYSTEM taskkill/CIM에서도 해당 프로세스를
  # 찾지 못하는 고아 TCP 소유권 상태에서는 같은 kill 루프를 반복하지 않습니다. 현재 설치를
  # 실패로 끝내면 Bridge/Recovery 작업도 사라져 다음 로그인까지 더 악화될 수 있으므로,
  # ProgramData에 완전한 설치 스냅샷을 남기고 다음 재부팅+로그온에서 1회 자동 복구합니다.
  $orphanDetail=Get-BridgeFailureDetail
  Write-Host ('30765 고아 LISTEN을 현재 Windows 세션에서 해제하지 못했습니다. 재부팅 1회 자동복구를 등록합니다. '+$orphanDetail) -ForegroundColor Yellow
  $deferredDir=Join-Path $InstallDir 'deferred-upgrade-v4183-orphan-port'
  New-Item -ItemType Directory -Path $deferredDir -Force|Out-Null
  foreach($name in @('PACKAGE_RELEASE.txt','install-network-host.ps1','SpxNetworkHost.cs','SpxNetworkHostLauncher.exe','run-network-host.ps1','network-worker.ps1','network-switch-daemon.ps1','reset-mobile-network.ps1','open-dedicated-window.ps1','start-network-host.ps1','stop-network-host.ps1')){
    $source=Join-Path $SourceDir $name
    if(-not(Test-Path -LiteralPath $source -PathType Leaf)){throw ('Missing deferred orphan recovery file: '+$source)}
    Copy-Item -LiteralPath $source -Destination (Join-Path $deferredDir $name) -Force
  }
  $deferredInstaller=Join-Path $deferredDir 'install-network-host.ps1'
  $deferredArgs=('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$deferredInstaller+'" -Elevated -DeferredUpgrade -ExtensionId "'+$PrimaryExtensionId+'"')
  if(-not[string]::IsNullOrWhiteSpace($ExtensionRoot)){$deferredArgs+=' -ExtensionRootOverride "'+$ExtensionRoot.Replace('"','""')+'"'}
  $deferredAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument $deferredArgs -WorkingDirectory $deferredDir
  $deferredTrigger=New-ScheduledTaskTrigger -AtLogOn -User $user.Name
  $deferredPrincipal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
  $deferredSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -StartWhenAvailable
  Register-ScheduledTask -TaskName $DeferredUpgradeTaskName -Action $deferredAction -Trigger $deferredTrigger -Principal $deferredPrincipal -Settings $deferredSettings -Force|Out-Null
  $message=@"
SmartPage Ex network helper deferred orphan-port recovery registered.

Package                            : $PackageRelease
Control ports                      : 30765 / 30766-30769
Current orphan listener            : $orphanDetail
Deferred installer                 : $deferredInstaller
Automatic recovery                 : next Windows restart + user logon
Result                             : SUCCESS_WITH_RESTART_REQUIRED

Do not repeat install-network-host.cmd. Restart Windows once; the staged SYSTEM installer will finish automatically after logon.
"@
  Write-InstallStatus $message
  Write-Host '';Write-Host '설치 파일/복구 작업을 ProgramData에 안전하게 예약했습니다.' -ForegroundColor Green
  Write-Host '현재 고아 포트는 Windows 재부팅이 필요합니다. 재부팅 후 로그인하면 설치가 자동으로 마무리됩니다.' -ForegroundColor Yellow
  exit 0
}
if(@(Get-LoopbackPortOwnerPids 30765).Count-gt0){throw ('설치 전 127.0.0.1:30765가 아직 LISTEN 중입니다. '+(Get-BridgeFailureDetail))}
Write-Host '[4/4] 전용 포트 정리 완료' -ForegroundColor DarkGray

Set-DeferredUpgradePhase 'TARGET_INSTALL_PREPARE'
# helper의 전역 Mutex와 같은 이름을 설치기가 잠시 잡아 설치 중 다른 현재 helper의 기동도 차단합니다.
if(-not(Acquire-BridgeInstallMutex)){
  throw ('설치 중 SmartPage Ex 브리지 기동 잠금을 확보하지 못했습니다. '+(Get-BridgeFailureDetail))
}
Write-Host '설치 중 로컬 브리지 자동 재기동 차단 잠금을 확보했습니다.' -ForegroundColor DarkGray

# 구버전 작업이 완전히 멈춘 뒤 저장된 원본 메트릭을 복원합니다.
Restore-StoredNetworkMetrics (Join-Path $InstallDir 'selected-route-guard.json')
Restore-StoredNetworkMetrics (Join-Path $InstallDir 'system-route-pin.json')
Restore-StoredNetworkMetrics (Join-Path $PreviousInstallDir 'selected-route-guard.json')
Restore-StoredNetworkMetrics (Join-Path $PreviousInstallDir 'system-route-pin.json')
try{
  foreach($name in @('SmartPageExNetworkHelper','SmartPageExNetworkBridge')){Remove-ItemProperty -Path "Registry::HKEY_USERS\$($user.Sid)\Software\Microsoft\Windows\CurrentVersion\Run" -Name $name -Force -ErrorAction SilentlyContinue}
  Remove-Item -LiteralPath (Join-Path $user.ProfilePath 'AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\SmartPageEx Network Bridge.lnk') -Force -ErrorAction SilentlyContinue
}catch{}
Start-Sleep -Milliseconds 500

New-Item -ItemType Directory -Path $InstallDir -Force|Out-Null
# v4.1.65: preserve credentials/protected settings and ADB identity from V31 without
# touching its locked EXE or old loopback ports. Older NetworkHost is a secondary source.
$MigrationSources=@($PreviousInstallDir,$LegacyInstallDir)
foreach($migrationSource in $MigrationSources){
  foreach($legacyName in @('integration-secrets.json','dedicated-profile-settings.dpapi','dedicated-profile-settings-machine.dpapi','manager-layout-v30823.json')){
    $legacyPath=Join-Path $migrationSource $legacyName
    $freshPath=Join-Path $InstallDir $legacyName
    if((-not(Test-Path -LiteralPath $freshPath -PathType Leaf)) -and (Test-Path -LiteralPath $legacyPath -PathType Leaf)){
      try{Copy-Item -LiteralPath $legacyPath -Destination $freshPath -Force}catch{}
    }
  }
  foreach($legacyDirectoryName in @('platform-tools','adb-home','adb-keys')){
    $legacyDirectory=Join-Path $migrationSource $legacyDirectoryName
    $freshDirectory=Join-Path $InstallDir $legacyDirectoryName
    if((-not(Test-Path -LiteralPath $freshDirectory)) -and (Test-Path -LiteralPath $legacyDirectory -PathType Container)){
      try{Copy-Item -LiteralPath $legacyDirectory -Destination $freshDirectory -Recurse -Force}catch{}
    }
  }
}

# A blank/new V33 integration-secrets.json must not hide working credentials from V31.
# Merge only missing values. Never overwrite a non-empty value in the current V33 file.
foreach($migrationSource in $MigrationSources){
  $legacyIntegrationPath=Join-Path $migrationSource 'integration-secrets.json'
  if(-not((Test-Path -LiteralPath $IntegrationSecretsPath -PathType Leaf) -and (Test-Path -LiteralPath $legacyIntegrationPath -PathType Leaf))){continue}
  try{
    $freshJson=ConvertFrom-JsonWithLineComments (Get-Content -LiteralPath $IntegrationSecretsPath -Raw -Encoding UTF8)
    $legacyJson=ConvertFrom-JsonWithLineComments (Get-Content -LiteralPath $legacyIntegrationPath -Raw -Encoding UTF8)
    $freshTarget=if($freshJson.PSObject.Properties.Name -contains 'settings' -and $freshJson.settings){$freshJson.settings}else{$freshJson}
    $legacyTarget=if($legacyJson.PSObject.Properties.Name -contains 'settings' -and $legacyJson.settings){$legacyJson.settings}else{$legacyJson}
    $integrationKeys=@('supabaseUrl','serviceKey','naverApiKey','naverSecretKey','naverCustomerId','naverDataLabHubClientId','naverDataLabHubClientSecret','naverDataLabLegacyClientId','naverDataLabLegacyClientSecret','geminiApiKey','openaiApiKey')
    $mergedCount=0
    foreach($keyName in $integrationKeys){
      $freshProp=$freshTarget.PSObject.Properties[$keyName]
      $legacyProp=$legacyTarget.PSObject.Properties[$keyName]
      $freshValue=if($freshProp){[string]$freshProp.Value}else{''}
      $legacyValue=if($legacyProp){[string]$legacyProp.Value}else{''}
      if([string]::IsNullOrWhiteSpace($freshValue) -and -not [string]::IsNullOrWhiteSpace($legacyValue)){
        $freshTarget | Add-Member -NotePropertyName $keyName -NotePropertyValue $legacyValue -Force
        $mergedCount++
      }
    }
    if($mergedCount -gt 0){
      $jsonText=$freshJson | ConvertTo-Json -Depth 12
      [IO.File]::WriteAllText($IntegrationSecretsPath,$jsonText,(New-Object Text.UTF8Encoding($false)))
      Write-Host ('기존 NetworkHost 연동 인증정보 '+$mergedCount+'개를 '+$migrationSource+'에서 비파괴 복원했습니다.') -ForegroundColor Green
    }
  }catch{
    Write-Warning '기존 integration-secrets.json이 표준 JSON/주석형 JSON으로 해석되지 않아 자동 병합을 건너뜁니다. 기존 파일은 삭제하거나 덮어쓰지 않았습니다.'
  }
}
New-Item -ItemType Directory -Path $DedicatedProfileDir -Force|Out-Null
foreach($name in @('SpxNetworkHost.cs','SpxNetworkHostLauncher.exe','run-network-host.ps1','network-worker.ps1','network-switch-daemon.ps1','reset-mobile-network.ps1','open-dedicated-window.ps1','start-network-host.ps1','stop-network-host.ps1')){
  $source=Join-Path $SourceDir $name
  if(-not(Test-Path $source)){throw "Missing file: $source"}
  $destination=Join-Path $InstallDir $name
  if($name-eq'SpxNetworkHost.cs'){
    # PATCH18: always rewrite the already-verified package source as pure ASCII.
    [IO.File]::WriteAllText($destination,$SourceCsText,[Text.Encoding]::ASCII)
  }else{
    Copy-Item -LiteralPath $source -Destination $destination -Force
  }
}
$adbInstall=Install-OrFindAdb $InstallDir $user $SourceDir
$adbRuntime=Initialize-AdbSharedRuntime $adbInstall $InstallDir $user
if(-not$adbInstall.Ready){Write-Warning ('ADB 자동 설치 실패: '+$adbInstall.Error)}
elseif($adbRuntime.DeviceState-eq'unauthorized'){Write-Host '휴대폰 잠금을 해제하고 USB 디버깅 허용 창에서 이 컴퓨터를 항상 허용하세요.' -ForegroundColor Yellow}
elseif($adbRuntime.DeviceState-ne'device'){Write-Host ('ADB 상태: '+$adbRuntime.DeviceState+' / '+$adbRuntime.Detail+' · 설치 자체에는 영향 없음 · 휴대폰 연결 불필요') -ForegroundColor DarkGray}
if(Test-Path $ExePath){Remove-Item $ExePath -Force -ErrorAction SilentlyContinue}
if(Test-Path $DllPath){Remove-Item $DllPath -Force -ErrorAction SilentlyContinue}
# Do not remove/overwrite $LegacyDllPath here. An old PowerShell runtime can keep it mapped even after ports close.
foreach($staleLog in @('local-bridge.log','bridge-start.stdout.log','bridge-start.stderr.log')){
  Remove-Item -LiteralPath (Join-Path $InstallDir $staleLog) -Force -ErrorAction SilentlyContinue
}
$sourceCodePath=Join-Path $InstallDir 'SpxNetworkHost.cs'
$sourceCode=[System.IO.File]::ReadAllText($sourceCodePath,[System.Text.Encoding]::UTF8)
# v4.1.89: keep the C# helper as a DLL loaded by Windows PowerShell. The native x64 launcher
# is a plain PE executable and does not require the .NET CLR shim to start.
if($sourceCode -match '[^\x00-\x7F]'){throw 'SpxNetworkHost.cs must be ASCII-safe before Add-Type compilation.'}
$controlBindIndex=$sourceCode.IndexOf('controlListener.Start(128);')
$proxyStartIndex=$sourceCode.IndexOf('StartProxyServer();')
if($controlBindIndex-lt0-or$proxyStartIndex-lt0-or$controlBindIndex-ge$proxyStartIndex){
  throw 'SpxNetworkHost.cs is not the current v3.0.45 selected-network connectivity helper source. Overwrite install-network-host.ps1, SpxNetworkHost.cs and the native launcher from the same release before installing.'
}
if($sourceCode.IndexOf($ExpectedBuildMarker)-lt0){
  throw ('SpxNetworkHost.cs build marker mismatch. Expected '+$ExpectedBuildMarker+'.')
}
if(-not(Test-Path -LiteralPath $LauncherSourcePath -PathType Leaf)){throw ('Missing native launcher: '+$LauncherSourcePath)}
if(-not(Test-Path -LiteralPath (Join-Path $SourceDir 'run-network-host.ps1') -PathType Leaf)){throw 'Missing run-network-host.ps1.'}
Write-Host ('Helper source verified: '+$ExpectedBuildMarker) -ForegroundColor DarkGray
Write-Host 'Installer startup model: native x64 launcher + PowerShell-hosted helper DLL' -ForegroundColor DarkGray
Add-Type -TypeDefinition $sourceCode -Language CSharp -ReferencedAssemblies @('System.dll','System.Core.dll','System.Security.dll','System.Web.Extensions.dll','System.Windows.Forms.dll') -OutputAssembly $DllPath -OutputType Library -IgnoreWarnings
if(-not(Test-Path $DllPath)){throw ('Versioned helper DLL was not created: '+$DllFileName)}
$launcherInstall=Install-NativeLauncherLockSafe -SourcePath $LauncherSourcePath -DestinationPath $ExePath
Copy-Item -LiteralPath (Join-Path $SourceDir 'run-network-host.ps1') -Destination $RuntimeHostPath -Force
if(-not(Test-Path $ExePath)){throw 'Native SpxNetworkHost.exe launcher was not installed.'}
& "$env:SystemRoot\System32\icacls.exe" $InstallDir /inheritance:e /grant ('*S-1-5-18:(OI)(CI)F') ('*S-1-5-32-544:(OI)(CI)F') ('*'+$user.Sid+':(OI)(CI)M') /T /C|Out-Null
& "$env:SystemRoot\System32\icacls.exe" $DedicatedProfileDir /inheritance:e /grant ('*S-1-5-18:(OI)(CI)F') ('*S-1-5-32-544:(OI)(CI)F') ('*'+$user.Sid+':(OI)(CI)M') /T /C|Out-Null

# One editable credential source file outside the extension folder. Keep an existing file exactly as-is
# across reinstalls; only create a blank template on the first install. The file ACL is restricted to
# SYSTEM, local Administrators and the current interactive user.
if(-not(Test-Path -LiteralPath $IntegrationSecretsPath -PathType Leaf)){
  $integrationTemplate=[ordered]@{
    supabaseUrl='';serviceKey='';naverApiKey='';naverSecretKey='';naverCustomerId='';
    naverDataLabHubClientId='';naverDataLabHubClientSecret='';
    naverDataLabLegacyClientId='';naverDataLabLegacyClientSecret='';
    geminiApiKey='';openaiApiKey=''
  }
  [IO.File]::WriteAllText($IntegrationSecretsPath,($integrationTemplate|ConvertTo-Json -Depth 3),(New-Object Text.UTF8Encoding($false)))
}
& "$env:SystemRoot\System32\icacls.exe" $IntegrationSecretsPath /inheritance:r /grant:r ('*S-1-5-18:F') ('*S-1-5-32-544:F') ('*'+$user.Sid+':M') /C|Out-Null

$native=[ordered]@{name=$NativeHostName;description='SmartPage Ex selected-network helper - manual on demand';path=$ExePath;type='stdio';allowed_origins=$AllowedOrigins}
[IO.File]::WriteAllText($ManifestPath,($native|ConvertTo-Json -Depth 6),(New-Object Text.UTF8Encoding($false)))
$config=[ordered]@{extensionRoot=$ExtensionRoot;extensionRootFound=(-not[string]::IsNullOrWhiteSpace($ExtensionRoot));extensionId=$PrimaryExtensionId;extensionIds=@($AllowedExtensionIds);detectedExtensionIds=$DetectedExtensionIds;allowedOrigins=$AllowedOrigins;bridgePort=30765;proxyPort=30766;dedicatedProfileDir=$DedicatedProfileDir;interactiveUser=$user.Name;interactiveUserSid=$user.Sid;interactiveProfile=$user.ProfilePath;adbSerial=([string]$adbRuntime.DeviceSerial);adbDeviceModel=([string]$adbRuntime.DeviceModel);adbPath=([string]$adbInstall.Path);adbVendorKeysPath=([string]$adbRuntime.KeysPath);adbReady=($adbInstall.Ready-and$adbRuntime.ServerReady);adbServerReady=($adbRuntime.ServerReady-eq$true);adbServerMode=([string]$adbRuntime.ServerMode);adbMobileRecoveryReady=([string]$adbRuntime.DeviceState-eq'device');adbDeviceState=([string]$adbRuntime.DeviceState);adbInstallSource=([string]$adbInstall.Source);helperDll=$DllFileName;connectivityResetOnly=$true;routingTableMode='selected_socket_bind_only_no_default_route_mutation';routingDaemonMode='system_on_demand_one_shot';helperVersion=$ExpectedHelperVersion;buildMarker=$ExpectedBuildMarker;startupMode='system_startup_logon_bridge';automaticStart=$true;watchdog=$true;updatedAt=(Get-Date).ToUniversalTime().ToString('o')}
[IO.File]::WriteAllText($ConfigPath,($config|ConvertTo-Json -Depth 6),(New-Object Text.UTF8Encoding($false)))
# v4.1.42: Native Messaging is registered immediately after the fresh executable/manifest are ready.
# Naver API requests use this stdio path and do not require the local HTTP bridge to be listening.
Register-NativeMessagingRegistration $user.Sid $ManifestPath
$nativeEarly=Test-NativeMessagingRegistration $user.Sid $ManifestPath
if(-not$nativeEarly.ok){throw 'Chrome Native Messaging early registration verification failed.'}
Write-Host '네이버 기본망용 Native Messaging 등록을 먼저 완료했습니다. 이후 전용창 브리지를 별도 기동합니다.' -ForegroundColor Green

# Windows 어댑터 메트릭 변경은 관리자 권한이 필요합니다. v3.0.8.5에서도 라우팅 변경용 데몬은 로그인 내내
# 실행되는 데몬을 사용하지 않습니다. Chrome이 고정/해제 요청 파일을 만든 뒤 SYSTEM 권한의
# 단발 예약 작업을 호출하며, 큐가 비면 약 2초 뒤 완전히 종료됩니다.
$networkRunnerPath=Join-Path $InstallDir 'network-switch-daemon.ps1'
foreach($staleName in @('network-switch-heartbeat.json','network-switch-heartbeat-v308.json','network-switch-heartbeat-v3081.json','network-command.json','network-result.json','network-command-v308.json','network-result-v308.json','network-command-v3081.json','network-result-v3081.json','network-command-v3082.json','network-result-v3082.json','network-command-v3083.json','network-result-v3083.json')){
  Remove-Item -LiteralPath (Join-Path $InstallDir $staleName) -Force -ErrorAction SilentlyContinue
}
foreach($staleDir in @('network-command-queue-v3081','network-processing-queue-v3081','network-result-queue-v3081','network-command-queue-v3082','network-processing-queue-v3082','network-result-queue-v3082','network-command-queue-v3083','network-processing-queue-v3083','network-result-queue-v3083')){
  Remove-Item -LiteralPath (Join-Path $InstallDir $staleDir) -Recurse -Force -ErrorAction SilentlyContinue
}
$networkAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$networkRunnerPath+'"') -WorkingDirectory $InstallDir
$networkPrincipal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$networkSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 3)
Register-ScheduledTask -TaskName $NetworkTaskName -Action $networkAction -Principal $networkPrincipal -Settings $networkSettings -Force|Out-Null
$taskPermissionGranted=Grant-ScheduledTaskReadExecute $NetworkTaskName $user.Sid

# 전용창과 C# 로컬 프록시가 쿠팡 트래픽만 선택망으로 보냅니다. 위 관리자 작업은
# 선택망이 Windows 기본 경로가 되는 데이터 누수 상황만 교정하는 안전 가드입니다.
# PATCH8: browser launcher는 현재 로그인 사용자 세션의 watcher로 등록합니다.
$launcherPath=Join-Path $InstallDir 'open-dedicated-window.ps1'
$browserWatcher=Register-DedicatedBrowserWatcher $user $launcherPath

# The settings editor runs in the interactive user's desktop even though the local bridge itself runs as SYSTEM.
$integrationSettingsAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\notepad.exe" -Argument ('"'+$IntegrationSecretsPath+'"') -WorkingDirectory $InstallDir
$integrationSettingsPrincipal=New-ScheduledTaskPrincipal -UserId $user.Name -LogonType Interactive -RunLevel Limited
$integrationSettingsTaskSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 30)
Register-ScheduledTask -TaskName $IntegrationSettingsTaskName -Action $integrationSettingsAction -Principal $integrationSettingsPrincipal -Settings $integrationSettingsTaskSettings -Force|Out-Null

# v3.0.8.5: 로컬 제어 브리지와 쿠팡 전용 프록시는 사용자 계정의 대화형 예약 작업에
# 의존하지 않고 SYSTEM 작업으로 부팅/로그온 때 시작합니다. 이렇게 하면 현재 확장 ID가
# 평상시 명령은 127.0.0.1 로컬 브리지로 처리합니다. Native manifest는 브리지가 꺼졌을 때 ensure_bridge 복구 신호에만 사용합니다.
$bridgeLauncher=Join-Path $InstallDir 'start-network-host.ps1'
$bridgeAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument ('-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$RuntimeHostPath+'" -HttpServer') -WorkingDirectory $InstallDir
$bridgeTriggers=@()
$bridgeTriggers+=New-ScheduledTaskTrigger -AtStartup
$bridgeTriggers+=New-ScheduledTaskTrigger -AtLogOn
$bridgePrincipal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$bridgeSettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 5 -RestartInterval (New-TimeSpan -Minutes 1)
Register-ScheduledTask -TaskName $BridgeTaskName -Action $bridgeAction -Trigger $bridgeTriggers -Principal $bridgePrincipal -Settings $bridgeSettings -Force|Out-Null
$bridgeTaskPermissionGranted=Grant-ScheduledTaskReadExecute $BridgeTaskName $user.Sid
if(-not$bridgeTaskPermissionGranted){Write-Warning '현재 사용자에게 SYSTEM 로컬 브리지 예약작업 실행 권한을 부여하지 못했습니다. Native Messaging 즉시복구가 제한될 수 있습니다.'}

# 복구 예약 작업은 새 브리지 검증이 끝난 뒤 등록합니다. 설치 중 중복 시작 경쟁을 막습니다.

# 설치 격리 상태에서 SYSTEM 브리지를 정확히 한 번만 시작합니다.
# Native Messaging은 이미 새 Helper에 등록되어 있지만, 새 Helper의 ensure_bridge 외에는 30765 브리지 시작과 충돌하지 않습니다.
Release-BridgeInstallMutex
Start-Sleep -Milliseconds 120
if(-not(Clear-SmartPageDedicatedLoopbackPorts)){throw ('SYSTEM 브리지 시작 직전 전용 포트 정리에 실패했습니다. '+(Get-BridgeFailureDetail))}
if(@(Get-LoopbackPortOwnerPids 30765).Count-gt0){throw ('SYSTEM 브리지 시작 직전 30765가 다시 LISTEN 상태가 되었습니다. '+(Get-BridgeFailureDetail))}

Set-DeferredUpgradePhase 'START_TARGET_RUNTIME'
Write-Host 'SYSTEM 로컬 브리지를 단일 기동합니다.' -ForegroundColor DarkGray
Start-ScheduledTask -TaskName $BridgeTaskName -ErrorAction Stop
$runningProxyPort=Wait-BridgePorts 60 150
$bridgeReady=(($runningProxyPort-ge30766)-and($runningProxyPort-le30769)-and(Test-LoopbackPort 30765 120))
if(-not$bridgeReady){
  throw ('Local bridge single-start port verification failed. No duplicate retry was attempted. '+(Get-BridgeFailureDetail))
}

# v3.0.12의 안정적인 설치 판정 원칙: 설치 성공은 전용 제어/프록시 포트가 실제 LISTEN인지로 결정합니다.
# /health는 진단 정보일 뿐 재기동/실패 판정에 사용하지 않습니다.
$bridgeStatus=Get-LocalBridgeHealth 1
$runningHelperVersion=$ExpectedHelperVersion
if($null-ne$bridgeStatus -and -not[string]::IsNullOrWhiteSpace([string]$bridgeStatus.helperVersion)){$runningHelperVersion=[string]$bridgeStatus.helperVersion}
if($null-ne$bridgeStatus){
  $reportedProxy=0;try{$reportedProxy=[int]$bridgeStatus.proxyPort}catch{}
  if($reportedProxy-ge30766-and$reportedProxy-le30769){$runningProxyPort=$reportedProxy}
}

# 전용창 브리지 검증 후 같은 Native Messaging 등록을 한 번 더 readback 확인합니다.
Register-NativeMessagingRegistration $user.Sid $ManifestPath
$script:NativeRegistrationTemporarilyRemoved=$false
Write-Host 'Chrome Native Messaging 등록을 현재 helper로 복원했습니다.' -ForegroundColor DarkGray


if($runningProxyPort -lt 30766 -or $runningProxyPort -gt 30769){throw 'Local bridge did not open a valid SmartPage Ex proxy port.'}
$config.proxyPort=$runningProxyPort;$config.helperVersion=$ExpectedHelperVersion;$config.buildMarker=$ExpectedBuildMarker
if($config.PSObject.Properties.Name -contains 'upgradePending'){$config.upgradePending=$false}
$config.updatedAt=(Get-Date).ToUniversalTime().ToString('o')
[IO.File]::WriteAllText($ConfigPath,($config|ConvertTo-Json -Depth 6),(New-Object Text.UTF8Encoding($false)))

# 새 브리지의 helperVersion/buildMarker/실제 proxyPort 검증이 끝난 뒤에만 1분 health 기반 단일 복구 작업을 등록합니다.
$recoveryAction=New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+$bridgeLauncher+'" -Silent') -WorkingDirectory $InstallDir
$recoveryPrincipal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$recoveryTrigger=New-ScheduledTaskTrigger -Once -At ((Get-Date).AddMinutes(1)) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration (New-TimeSpan -Days 3650)
$recoverySettings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 1) -StartWhenAvailable
Register-ScheduledTask -TaskName $RecoveryTaskName -Action $recoveryAction -Trigger $recoveryTrigger -Principal $recoveryPrincipal -Settings $recoverySettings -Force|Out-Null
$recoveryTaskPermissionGranted=Grant-ScheduledTaskReadExecute $RecoveryTaskName $user.Sid
if(-not$recoveryTaskPermissionGranted){Write-Warning '현재 사용자에게 SYSTEM 브리지 복구 예약작업 실행 권한을 부여하지 못했습니다. Native Messaging 직접 브리지 복구는 계속 사용할 수 있습니다.'}

# v4.1.89: a successful installer must leave every task that the Native helper invokes.
# The field failure showed schtasks /Run returning "file not found" after reboot because the
# bridge/recovery definitions were absent. Fail installation here instead of reporting success
# with a task set that cannot support selected-network routing.
foreach($requiredTaskName in @($BridgeTaskName,$RecoveryTaskName,$NetworkTaskName,$BrowserTaskName)){
  $requiredTask=Get-ScheduledTask -TaskName $requiredTaskName -ErrorAction SilentlyContinue
  if($null-eq$requiredTask){throw ('필수 Network Host 예약작업 등록 검증 실패: '+$requiredTaskName)}
}
Write-Host '필수 Network Host 예약작업 4개 등록 확인 완료.' -ForegroundColor DarkGray

# 설치 과정에서도 Windows 라우팅 테이블은 건드리지 않고 런타임 상태만 system으로 초기화합니다.
@{ok=$true;mode='system';selectedAdapterId='';selectedAdapterName='';routingTableChanged=$false;updatedAt=(Get-Date).ToUniversalTime().ToString('o')}|ConvertTo-Json -Compress|Set-Content (Join-Path $InstallDir 'network-runtime.json') -Encoding UTF8
if($null-ne$previousProxyState){
  $preservedProxy=[ordered]@{
    enabled=$true
    adapterId=[string]$previousProxyState.adapterId
    adapterName=[string]$previousProxyState.adapterName
    adapterDescription=[string]$previousProxyState.adapterDescription
    ipv4Address=[string]$previousProxyState.ipv4Address
    interfaceIndex=$previousProxyState.interfaceIndex
    selectedNetworkReady=$false
    selectedNetworkDnsReady=$false
    selectedNetworkDnsMode=''
    selectedNetworkCoupangTcpReady=$false
    selectedNetworkCheckedAt=''
    selectedNetworkError=''
    publicIp=[string]$previousProxyState.publicIp
    publicIpLastKnown=[string]$previousProxyState.publicIpLastKnown
    publicIpLastKnownAt=[string]$previousProxyState.publicIpLastKnownAt
    updatedAt=(Get-Date).ToUniversalTime().ToString('o')
  }
  $preservedProxy|ConvertTo-Json -Compress|Set-Content $ProxyStatePath -Encoding UTF8
  Write-Host ('기존 전용망 선택 보존 완료 · '+[string]$previousProxyState.adapterName) -ForegroundColor Green
}else{
  @{enabled=$false;updatedAt=(Get-Date).ToUniversalTime().ToString('o')}|ConvertTo-Json -Compress|Set-Content $ProxyStatePath -Encoding UTF8
}

$message=@"
SmartPage Ex network helper manual installation completed.
Current extension ID           : $PrimaryExtensionId
Allowed extension ID(s)        : $($AllowedExtensionIds -join ', ')
Chrome profile auto-detection  : $($DetectedExtensionIds.Count -gt 0)
Automatic startup/logon bridge: True (SYSTEM hidden single instance)`r`nLocal bridge auto-recovery    : True (Chrome on-demand + SYSTEM hidden 1-minute safety check)
Administrator route runner    : Installed (SYSTEM, starts only per request)
Task run permission granted    : $taskPermissionGranted
Persistent routing process    : None (local control bridge only stays running)
Visible terminal repetition    : Removed
Adapter/status lookup          : Local bridge primary; Native Messaging only for emergency bridge restart
Selected-network proxy         : SYSTEM bridge verified on control 30765 + proxy $runningProxyPort; selected adapter activates only after selection
Dedicated browser launcher     : Lightweight interactive watcher (500 ms request-file wait)
Integration settings source    : $IntegrationSecretsPath
Integration settings editor    : Interactive Notepad task
Windows default route guarded : Pinned base adapter stays preferred; selected tethering is demoted for dedicated mode
Route command transport        : Per-request queue to one-shot SYSTEM task (auto exit when empty)
Windows routing change scope   : System base and selected-adapter metrics only; each restored on clear
Local bridge verification      : $bridgeReady
Local bridge helper version    : $runningHelperVersion`r`nLocal bridge proxy port        : $runningProxyPort
Extension source root          : $ExtensionRoot
ADB executable ready           : $($adbInstall.Ready)
ADB executable path            : $([string]$adbInstall.Path)
ADB shared key path            : $([string]$adbRuntime.KeysPath)
ADB shared key source          : $([string]$adbRuntime.KeySource)
ADB daemon port 5037 ready     : $($adbRuntime.ServerReady)
ADB daemon start mode          : $([string]$adbRuntime.ServerMode)
ADB mobile recovery ready      : $([string]$adbRuntime.DeviceState-eq'device')
ADB device state               : $([string]$adbRuntime.DeviceState)
ADB device detail              : $([string]$adbRuntime.Detail)
Dedicated Chrome profile       : $DedicatedProfileDir
"@
if($DeferredUpgrade){
  $null=Complete-DeferredUpgradeLifecycle
}else{
  try{Unregister-ScheduledTask -TaskName $DeferredUpgradeTaskName -Confirm:$false -ErrorAction SilentlyContinue}catch{}
}
Write-InstallStatus $message
Write-Host '';Write-Host $message -ForegroundColor Green
exit 0
