const SPX_POPUP_BUILD_VERSION='1.6.50';
const $=(id)=>document.getElementById(id);
const send=(m)=>new Promise((resolve)=>{try{chrome.runtime.sendMessage(m,(r)=>resolve(chrome.runtime.lastError?null:r));}catch(_){resolve(null);}});
async function load(){
  $('version').textContent='v'+chrome.runtime.getManifest().version;
  const net=await send({type:'SPX_NETWORK_STATUS'});const nd=net?.data||{};
  $('network').textContent=net?.ok?(String(nd.mode||nd.configuredMode||'system')==='window'?'선택망 준비':'기본망'):'확인 필요';
  const wing=await send({type:'SPX_WING_VIEW_STATE'});const wd=wing?.data||{};
  $('wing').textContent=wing?.ok?`${wd.status||'idle'} · 대기 ${Number(wd.pending_count||0)}`:'확인 필요';
}
$('openCoupang').addEventListener('click',()=>chrome.tabs.create({url:'https://www.coupang.com/search'}));
$('openOptions').addEventListener('click',()=>chrome.runtime.openOptionsPage());
$('openDedicated').addEventListener('click',async()=>{
  $('msg').textContent='선택망 전용창 준비 중...';const saved=await chrome.storage.local.get('settings');const s=saved?.settings||{};const id=String(s.collectionNetworkAdapterId||'').trim(),name=String(s.collectionNetworkAdapterName||'').trim();
  if(!id){$('msg').textContent='설정에서 전용 수집 어댑터를 먼저 선택·적용하세요.';return;}
  const r=await send({type:'SPX_NETWORK_OPEN_COUPANG_WINDOW',adapterId:id,adapterName:name,startUrl:'https://www.coupang.com/np/search?q=%EC%83%81%ED%92%88&channel=user'});
  $('msg').textContent=r?.ok?'전용창 실행 요청 완료':('전용창 실행 실패 · '+String(r?.error||'네트워크 보조도구 확인'));
});
load().catch(()=>{});
