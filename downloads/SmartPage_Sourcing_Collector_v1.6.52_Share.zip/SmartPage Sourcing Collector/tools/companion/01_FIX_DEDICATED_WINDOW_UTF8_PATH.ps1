﻿$ErrorActionPreference = 'Stop'
$ExpectedId = 'olmpllofoggohefbdkgkjjnlanfnaocd'
$ManagerId = 'cikfdcalhneenfppkcplacnheaecfnai'
$ExpectedCollectorRoot = 'D:\01. Work In Process\쿠팡 수집기\SmartPage Sourcing Collector'
$ActualCollectorRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Root = $ExpectedCollectorRoot
$InstallDir = Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$ConfigPath = Join-Path $InstallDir 'network-host-config.json'
$NativeManifestPath = Join-Path $InstallDir 'com.smartpage.spx_network_v7.json'
$LauncherPath = Join-Path $InstallDir 'open-dedicated-window.ps1'
$ReadyPath = Join-Path $InstallDir 'dedicated-window-launcher.ready'
$LauncherLogPath = Join-Path $InstallDir 'dedicated-window-launch.log'
$TaskName = 'SmartPageEx Open Dedicated Browser'
$RuntimeDir = Join-Path $Root 'runtime'
$DiagnosticPath = Join-Path $RuntimeDir 'DEDICATED_WINDOW_FIX5_DIAGNOSTIC.txt'

function Read-Utf8Text([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
  return [IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8)
}
function Read-Utf8Json([string]$Path) {
  $text = Read-Utf8Text $Path
  if ($null -eq $text) { return $null }
  return ($text | ConvertFrom-Json -ErrorAction Stop)
}
function Write-Utf8Bom([string]$Path, [string]$Text) {
  [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding($true)))
}
function Write-Utf8NoBom([string]$Path, [string]$Text) {
  [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding($false)))
}
function Add-Unique($Values, [string]$Value) {
  $list = @($Values)
  if ($list -notcontains $Value) { $list += $Value }
  return @($list | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | Select-Object -Unique)
}
function Set-Prop($Object, [string]$Name, $Value) {
  if ($null -eq $Object.PSObject.Properties[$Name]) {
    $Object | Add-Member -NotePropertyName $Name -NotePropertyValue $Value
  } else {
    $Object.$Name = $Value
  }
}
function Eq-Path([string]$A, [string]$B) {
  try {
    return ([IO.Path]::GetFullPath($A).TrimEnd([char]'\') -eq [IO.Path]::GetFullPath($B).TrimEnd([char]'\'))
  } catch { return $false }
}
if (-not (Eq-Path $ActualCollectorRoot $ExpectedCollectorRoot)) {
  throw ('Collector 경로가 고정 경로와 다릅니다. 현재=' + $ActualCollectorRoot + ' / 필요=' + $ExpectedCollectorRoot)
}

function Get-ManifestId([string]$Path) {
  $manifest = Read-Utf8Json $Path
  $bytes = [Convert]::FromBase64String([string]$manifest.key)
  $sha = [Security.Cryptography.SHA256]::Create()
  try { $hash = $sha.ComputeHash($bytes) } finally { $sha.Dispose() }
  $builder = New-Object Text.StringBuilder
  for ($i = 0; $i -lt 16; $i++) {
    [void]$builder.Append([char]([int][char]'a' + (($hash[$i] -shr 4) -band 15)))
    [void]$builder.Append([char]([int][char]'a' + ($hash[$i] -band 15)))
  }
  return $builder.ToString()
}
function Get-WatcherProcesses {
  $rows = @()
  try {
    $rows = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object {
      $cmd = [string]$_.CommandLine
      -not [string]::IsNullOrWhiteSpace($cmd) -and
      $cmd.IndexOf($LauncherPath, [StringComparison]::OrdinalIgnoreCase) -ge 0 -and
      $cmd -match '(?i)(?:^|\s)-Watch(?:\s|$)'
    })
  } catch { $rows = @() }
  return @($rows)
}
function Wait-TaskNotRunning([int]$TimeoutMs) {
  $deadline = (Get-Date).AddMilliseconds($TimeoutMs)
  do {
    try {
      $state = [string](Get-ScheduledTask -TaskName $TaskName -ErrorAction Stop).State
      if ($state -ne 'Running') { return $true }
    } catch { return $true }
    Start-Sleep -Milliseconds 250
  } while ((Get-Date) -lt $deadline)
  return $false
}
function Stop-LauncherWatcherOnly {
  Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
  if (Wait-TaskNotRunning 5000) { return }

  # Fallback: stop ONLY the exact interactive watcher PowerShell process.
  $watchers = @(Get-WatcherProcesses)
  foreach ($p in $watchers) {
    try { Stop-Process -Id ([int]$p.ProcessId) -Force -ErrorAction Stop } catch { }
  }
  if (-not (Wait-TaskNotRunning 5000)) {
    $ids = @((Get-WatcherProcesses) | ForEach-Object { [string]$_.ProcessId }) -join ','
    throw ('Dedicated launcher watcher would not stop. WatcherPIDs=' + $ids)
  }
}
function Test-LauncherSyntax([string]$Path) {
  $tokens = $null
  $errors = $null
  [void][System.Management.Automation.Language.Parser]::ParseFile($Path, [ref]$tokens, [ref]$errors)
  if ($null -ne $errors -and @($errors).Count -gt 0) {
    $messages = @($errors | ForEach-Object { $_.Message }) -join ' | '
    throw ('Launcher PowerShell syntax check failed: ' + $messages)
  }
}
function Start-And-WaitLauncherReady([int]$TimeoutSeconds) {
  if (Test-Path -LiteralPath $ReadyPath -PathType Leaf) {
    Remove-Item -LiteralPath $ReadyPath -Force -ErrorAction SilentlyContinue
  }
  Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop
  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  do {
    Start-Sleep -Milliseconds 250
    if (Test-Path -LiteralPath $ReadyPath -PathType Leaf) {
      try {
        $ready = Read-Utf8Json $ReadyPath
        if ($null -ne $ready -and $ready.ready -eq $true) { return $ready }
      } catch { }
    }
  } while ((Get-Date) -lt $deadline)
  return $null
}
function Write-FailureDiagnostic([string]$Reason) {
  try {
    New-Item -ItemType Directory -Path $RuntimeDir -Force | Out-Null
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('SmartPage Sourcing Collector dedicated-window FIX5 diagnostic')
    $lines.Add('CapturedAt=' + (Get-Date).ToString('o'))
    $lines.Add('Reason=' + $Reason)
    try {
      $t = Get-ScheduledTask -TaskName $TaskName -ErrorAction Stop
      $ti = Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction Stop
      $lines.Add('TaskState=' + [string]$t.State)
      $lines.Add('TaskLastResult=' + [string]$ti.LastTaskResult)
      $lines.Add('TaskLastRunTime=' + [string]$ti.LastRunTime)
    } catch { $lines.Add('TaskReadError=' + $_.Exception.Message) }
    $watchers = @(Get-WatcherProcesses)
    $lines.Add('WatcherProcessCount=' + $watchers.Count)
    foreach ($p in $watchers) { $lines.Add('WatcherPID=' + [string]$p.ProcessId + ' CommandLine=' + [string]$p.CommandLine) }
    $lines.Add('ReadyExists=' + (Test-Path -LiteralPath $ReadyPath -PathType Leaf))
    if (Test-Path -LiteralPath $LauncherLogPath -PathType Leaf) {
      $lines.Add('--- dedicated-window-launch.log tail ---')
      try { @(Get-Content -LiteralPath $LauncherLogPath -Tail 30 -ErrorAction Stop) | ForEach-Object { $lines.Add([string]$_) } } catch { }
    }
    [IO.File]::WriteAllLines($DiagnosticPath, $lines, (New-Object Text.UTF8Encoding($true)))
  } catch { }
}

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  throw '관리자 권한이 필요합니다. RUN_01_DEDICATED_WINDOW_UTF8_FIX.cmd를 우클릭하여 관리자 권한으로 실행하세요.'
}

$ManifestPath = Join-Path $Root 'manifest.json'
foreach ($path in @($ManifestPath, $ConfigPath, $NativeManifestPath, $LauncherPath)) {
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw ('필수 파일을 찾지 못했습니다: ' + $path) }
}
$manifest = Read-Utf8Json $ManifestPath
if ([string]$manifest.name -ne 'SmartPage Sourcing Collector') { throw '현재 폴더가 SmartPage Sourcing Collector가 아닙니다.' }
if ([string]$manifest.version -ne '1.0.4') { throw ('Collector 버전이 1.0.4가 아닙니다: ' + [string]$manifest.version) }
$actualId = Get-ManifestId $ManifestPath
if ($actualId -ne $ExpectedId) { throw ('Collector 확장 ID가 예상과 다릅니다: ' + $actualId) }

$task = Get-ScheduledTask -TaskName $TaskName -ErrorAction Stop
$taskAction = @($task.Actions)[0]
if (-not ([string]$taskAction.Arguments).Contains($LauncherPath)) { throw '예약 작업이 NetworkHostV33 launcher를 가리키지 않습니다. STOP.' }

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupDir = Join-Path $InstallDir ('collector-utf8-path-fix5-backup\' + $stamp)
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
foreach ($path in @($ConfigPath, $NativeManifestPath, $LauncherPath)) {
  Copy-Item -LiteralPath $path -Destination (Join-Path $backupDir ([IO.Path]::GetFileName($path))) -Force
}

try {
  $config = Read-Utf8Json $ConfigPath
  $collectorOrigin = 'chrome-extension://' + $ExpectedId + '/'
  $managerOrigin = 'chrome-extension://' + $ManagerId + '/'

  $ids = Add-Unique @($config.extensionIds) $ExpectedId
  $ids = Add-Unique $ids $ManagerId
  Set-Prop $config 'extensionIds' $ids

  $origins = @($config.allowedOrigins)
  $origins = Add-Unique $origins $collectorOrigin
  $origins = Add-Unique $origins $managerOrigin
  Set-Prop $config 'allowedOrigins' $origins
  Set-Prop $config 'extensionRoot' ([IO.Path]::GetFullPath($Root))
  Set-Prop $config 'extensionRootFound' $true
  Set-Prop $config 'extensionId' $ExpectedId
  Write-Utf8Bom $ConfigPath ($config | ConvertTo-Json -Depth 30)

  $nativeManifest = Read-Utf8Json $NativeManifestPath
  $nativeOrigins = @($nativeManifest.allowed_origins)
  $nativeOrigins = Add-Unique $nativeOrigins $collectorOrigin
  $nativeOrigins = Add-Unique $nativeOrigins $managerOrigin
  Set-Prop $nativeManifest 'allowed_origins' $nativeOrigins
  Write-Utf8NoBom $NativeManifestPath ($nativeManifest | ConvertTo-Json -Depth 20)

  # PowerShell 5.1-safe patch of ONLY RequestPath JSON read.
  $launcher = Read-Utf8Text $LauncherPath
  $explicitUtf8Pattern = '\[IO\.File\]::ReadAllText\(\$RequestPath\s*,\s*\[Text\.Encoding\]::UTF8\)'
  if ($launcher -notmatch $explicitUtf8Pattern) {
    $requestPattern = '(?im)^(?<indent>[ \t]*)\$request\s*=\s*Get-Content\s+-LiteralPath\s+\$RequestPath\s+-Raw(?:\s+-ErrorAction\s+Stop)?\s*\|\s*ConvertFrom-Json(?:\s+-ErrorAction\s+Stop)?\s*$'
    $match = [Text.RegularExpressions.Regex]::Match($launcher, $requestPattern)
    if (-not $match.Success) { throw 'Launcher RequestPath JSON read line was not found. STOP before launcher write.' }
    $indent = $match.Groups['indent'].Value
    $replacement = $indent + '# SPX_UTF8_REQUEST_READER_V103_FIX5' + "`r`n" + $indent + '$request = ([IO.File]::ReadAllText($RequestPath,[Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop)'
    $launcher = $launcher.Substring(0, $match.Index) + $replacement + $launcher.Substring($match.Index + $match.Length)
  } elseif ($launcher -notmatch 'SPX_UTF8_REQUEST_READER_V103_FIX5') {
    $utf8LinePattern = '(?im)^(?<indent>[ \t]*)\$request\s*=\s*\(\[IO\.File\]::ReadAllText\(\$RequestPath\s*,\s*\[Text\.Encoding\]::UTF8\).*?$'
    $match2 = [Text.RegularExpressions.Regex]::Match($launcher, $utf8LinePattern)
    if ($match2.Success) {
      $indent2 = $match2.Groups['indent'].Value
      $replacement2 = $indent2 + '# SPX_UTF8_REQUEST_READER_V103_FIX5' + "`r`n" + $match2.Value
      $launcher = $launcher.Substring(0, $match2.Index) + $replacement2 + $launcher.Substring($match2.Index + $match2.Length)
    }
  }
  if ($launcher -notmatch $explicitUtf8Pattern) { throw 'Launcher request JSON is still not explicit UTF-8.' }
  Write-Utf8Bom $LauncherPath $launcher
  Test-LauncherSyntax $LauncherPath

  # FIX5: wait for the old task instance to actually stop before starting a new watcher.
  Stop-LauncherWatcherOnly
  $ready = Start-And-WaitLauncherReady 15
  if ($null -eq $ready) {
    $t = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    $ti = Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction SilentlyContinue
    $watcherIds = @((Get-WatcherProcesses) | ForEach-Object { [string]$_.ProcessId }) -join ','
    $reason = 'Interactive launcher watcher did not create a fresh ready file after verified stop/start. TaskState=' + [string]$t.State + '; LastResult=' + [string]$ti.LastTaskResult + '; WatcherPIDs=' + $watcherIds
    Write-FailureDiagnostic $reason
    throw $reason
  }

  $verifyConfig = Read-Utf8Json $ConfigPath
  $verifyNative = Read-Utf8Json $NativeManifestPath
  $verifyLauncher = Read-Utf8Text $LauncherPath
  if (-not (Eq-Path ([string]$verifyConfig.extensionRoot) $Root)) { throw 'Post verify: NetworkHost Collector root mismatch.' }
  if ([string]$verifyConfig.extensionId -ne $ExpectedId) { throw 'Post verify: NetworkHost active extensionId is not Collector.' }
  if (-not (@($verifyConfig.extensionIds) -contains $ExpectedId)) { throw 'Post verify: Collector ID missing from config.' }
  if (-not (@($verifyConfig.allowedOrigins) -contains $collectorOrigin)) { throw 'Post verify: Collector origin missing from config.' }
  if (-not (@($verifyNative.allowed_origins) -contains $collectorOrigin)) { throw 'Post verify: Collector origin missing from native manifest.' }
  if ($verifyLauncher -notmatch $explicitUtf8Pattern) { throw 'Post verify: launcher explicit UTF-8 request reader missing.' }
}
catch {
  $failure = $_.Exception.Message
  Write-FailureDiagnostic $failure
  try { Stop-LauncherWatcherOnly } catch {}
  try { Copy-Item -LiteralPath (Join-Path $backupDir 'network-host-config.json') -Destination $ConfigPath -Force } catch {}
  try { Copy-Item -LiteralPath (Join-Path $backupDir 'com.smartpage.spx_network_v7.json') -Destination $NativeManifestPath -Force } catch {}
  try { Copy-Item -LiteralPath (Join-Path $backupDir 'open-dedicated-window.ps1') -Destination $LauncherPath -Force } catch {}
  try {
    Test-LauncherSyntax $LauncherPath
    $null = Start-And-WaitLauncherReady 10
  } catch {}
  throw ('UTF-8/path FIX5 rolled back: ' + $failure + ' Diagnostic=' + $DiagnosticPath)
}

Write-Host ('BACKUP=' + $backupDir)
Write-Host ('COLLECTOR_ROOT=' + $Root)
Write-Host 'CONFIG_ACTIVE_EXTENSION=COLLECTOR'
Write-Host 'CONFIG_JSON_UTF8_BOM=YES'
Write-Host 'LAUNCHER_REQUEST_READER=UTF8_EXPLICIT_FIX5'
Write-Host 'LAUNCHER_WATCHER_RESTARTED=YES'
Write-Host 'CHROME_STOP=0 CHROME_FORCE_KILL=0 NETWORKHOST_RESTART=0 ROUTE_CHANGE=0 ADAPTER_CHANGE=0'
Write-Host 'FINAL=DEDICATED_WINDOW_UTF8_PATH_FIX5_PASS'
