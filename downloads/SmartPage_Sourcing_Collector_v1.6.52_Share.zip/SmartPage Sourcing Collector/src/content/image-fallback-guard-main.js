/* SmartPage Sourcing Collector v1.2.2
 * MAIN-world Coupang remote-placeholder guard.
 * Purpose: stop Coupang's repeated remote fallback assignment before it becomes
 * another HTTP request while image-download OFF is active.
 *
 * Invariants:
 * - normal product image URLs are never rewritten here;
 * - no MutationObserver / polling / onerror handler is installed;
 * - known remote placeholder URLs are localized to an in-memory 1x1 GIF once;
 * - image ON leaves native setters untouched in behavior.
 */
(()=>{
  'use strict';
  const MODE_ATTR='data-spx-image-download-mode';
  const MARK_ATTR='data-spx-placeholder-localized';
  const ORIGINAL_ATTR='data-spx-placeholder-original';
  const LOCAL_PIXEL='data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==';
  const PLACEHOLDER_RE=/(?:^|[\/_-])no[_-]?img(?:[\/_-]|\.|$)|no[_-]?image|image[_-]?(?:ready|prepar|pending)|placeholder/i;
  const root=()=>document.documentElement;
  const active=()=>root()?.getAttribute(MODE_ATTR)==='block';
  const text=(value)=>String(value??'').trim();
  const isRemote=(value)=>/^https?:\/\//i.test(text(value));
  const isPlaceholder=(value)=>isRemote(value)&&PLACEHOLDER_RE.test(text(value));
  const nativeSetAttribute=Element.prototype.setAttribute;
  const nativeGetAttribute=Element.prototype.getAttribute;
  const mark=(node,original)=>{
    try{
      if(nativeGetAttribute.call(node,MARK_ATTR)!=='1')nativeSetAttribute.call(node,MARK_ATTR,'1');
      if(original&&!nativeGetAttribute.call(node,ORIGINAL_ATTR))nativeSetAttribute.call(node,ORIGINAL_ATTR,text(original).slice(0,500));
    }catch(_){ }
  };
  const localize=(node,value)=>{
    if(!active()||!isPlaceholder(value))return null;
    mark(node,value);
    return LOCAL_PIXEL;
  };
  const patchProperty=(proto,name)=>{
    try{
      const desc=Object.getOwnPropertyDescriptor(proto,name);
      if(!desc||typeof desc.set!=='function'||typeof desc.get!=='function'||desc.set.__spxV118===true)return;
      const nativeSet=desc.set,nativeGet=desc.get;
      const wrapped=function(value){
        const localized=localize(this,value);
        if(localized!==null){
          try{if(nativeGet.call(this)===localized)return;}catch(_){ }
          return nativeSet.call(this,localized);
        }
        return nativeSet.call(this,value);
      };
      Object.defineProperty(wrapped,'__spxV118',{value:true});
      Object.defineProperty(proto,name,{...desc,get:nativeGet,set:wrapped});
    }catch(_){ }
  };
  patchProperty(HTMLImageElement.prototype,'src');
  patchProperty(HTMLImageElement.prototype,'srcset');
  if(typeof HTMLSourceElement!=='undefined')patchProperty(HTMLSourceElement.prototype,'srcset');

  try{
    const native=Element.prototype.setAttribute;
    if(native.__spxV118!==true){
      const wrapped=function(name,value){
        const attr=String(name||'').toLowerCase();
        const imageLike=this instanceof HTMLImageElement || (typeof HTMLSourceElement!=='undefined'&&this instanceof HTMLSourceElement);
        if(imageLike&&(attr==='src'||attr==='srcset')){
          const localized=localize(this,value);
          if(localized!==null){
            try{if(nativeGetAttribute.call(this,attr)===localized)return;}catch(_){ }
            return native.call(this,name,localized);
          }
        }
        return native.call(this,name,value);
      };
      Object.defineProperty(wrapped,'__spxV118',{value:true});
      Element.prototype.setAttribute=wrapped;
    }
  }catch(_){ }
  try{
    const nativeNs=Element.prototype.setAttributeNS;
    if(typeof nativeNs==='function'&&nativeNs.__spxV118!==true){
      const wrappedNs=function(namespace,name,value){
        const attr=String(name||'').toLowerCase();
        const imageLike=this instanceof HTMLImageElement || (typeof HTMLSourceElement!=='undefined'&&this instanceof HTMLSourceElement);
        if(imageLike&&(attr==='src'||attr==='srcset')){
          const localized=localize(this,value);
          if(localized!==null){
            try{if(nativeGetAttribute.call(this,attr)===localized)return;}catch(_){ }
            return nativeNs.call(this,namespace,name,localized);
          }
        }
        return nativeNs.call(this,namespace,name,value);
      };
      Object.defineProperty(wrappedNs,'__spxV118',{value:true});
      Element.prototype.setAttributeNS=wrappedNs;
    }
  }catch(_){ }
  /* A page lazy-loader may clear src and immediately restore the same remote
     placeholder. Once SmartPage localized that placeholder, suppress only that
     clear/reassign cycle while image-download OFF is active. Normal product
     images are never marked and therefore keep native removeAttribute behavior. */
  try{
    const nativeRemove=Element.prototype.removeAttribute;
    if(typeof nativeRemove==='function'&&nativeRemove.__spxV118!==true){
      const wrappedRemove=function(name){
        const attr=String(name||'').toLowerCase();
        const imageLike=this instanceof HTMLImageElement || (typeof HTMLSourceElement!=='undefined'&&this instanceof HTMLSourceElement);
        if(active()&&imageLike&&(attr==='src'||attr==='srcset')&&nativeGetAttribute.call(this,MARK_ATTR)==='1')return;
        return nativeRemove.call(this,name);
      };
      Object.defineProperty(wrappedRemove,'__spxV118',{value:true});
      Element.prototype.removeAttribute=wrappedRemove;
    }
  }catch(_){ }
})();
