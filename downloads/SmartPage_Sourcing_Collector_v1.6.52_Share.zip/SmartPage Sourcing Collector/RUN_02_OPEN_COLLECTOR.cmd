@echo off
chcp 65001 >nul
setlocal
set "PS=%~dp0tools\crosspc\02_OPEN_COLLECTOR.ps1"
if not exist "%PS%" (
  echo [ERROR] Collector launcher PowerShell file not found.
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS%"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" pause
exit /b %RC%
