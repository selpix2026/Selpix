﻿$ErrorActionPreference='Stop'
$Base='C:\ProgramData\SmartPageEx\NetworkHostV33'
$Launcher=Join-Path $Base 'open-dedicated-window.ps1'
$Marker='SPX_WING_DEFAULT_NETWORK_PAC_V1'

function Fail([string]$Message){
  Write-Host ('FINAL=FAIL · '+$Message) -ForegroundColor Red
  exit 1
}

if(-not (Test-Path -LiteralPath $Launcher)){ Fail "launcher not found: $Launcher" }

$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$backupDir=Join-Path $Base ('wing-default-network-backup\'+$stamp)
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
Copy-Item -LiteralPath $Launcher -Destination (Join-Path $backupDir 'open-dedicated-window.ps1') -Force

$text=Get-Content -LiteralPath $Launcher -Raw -Encoding UTF8

if($text -notmatch [regex]::Escape($Marker)){
  $lines=@($text -split "`r?`n")
  $out=New-Object System.Collections.Generic.List[string]
  $inserted=$false
  $replaced=$false

  foreach($line in $lines){
    if(-not $inserted -and $line -match '^\s*\$argumentParts\s*=\s*@\('){
      $indent=([regex]::Match($line,'^\s*')).Value
      $out.Add($indent+'# '+$Marker)
      $out.Add($indent+"`$spxWingDirectPacPath = Join-Path `$PSScriptRoot 'coupang-proxy-wing-direct.pac'")
      $out.Add($indent+'$spxWingDirectPac = @"')
      $out.Add("function FindProxyForURL(url, host) {")
      $out.Add("  host = (host || '').toLowerCase();")
      $out.Add("  if (host === 'wing.coupang.com' || dnsDomainIs(host, '.wing.coupang.com') ||")
      $out.Add("      host === 'xauth.coupang.com' || host === 'auth.coupang.com' ||")
      $out.Add("      host === 'login.coupang.com' || host === 'idp.coupang.com' || host === 'idpp.coupang.com') return 'DIRECT';")
      $out.Add("  if (host === 'localhost' || host === '127.0.0.1' || host === '::1' ||")
      $out.Add("      host === 'supabase.co' || dnsDomainIs(host, '.supabase.co') ||")
      $out.Add("      host === 'supabase.in' || dnsDomainIs(host, '.supabase.in') ||")
      $out.Add("      host === 'naver.com' || dnsDomainIs(host, '.naver.com') ||")
      $out.Add("      host === 'naver.net' || dnsDomainIs(host, '.naver.net') ||")
      $out.Add("      host === 'api.openai.com' || dnsDomainIs(host, '.openai.com') ||")
      $out.Add("      host === 'generativelanguage.googleapis.com' || dnsDomainIs(host, '.googleapis.com') ||")
      $out.Add("      host === 'smartpage-ai.vercel.app' || dnsDomainIs(host, '.vercel.app')) return 'DIRECT';")
      $out.Add("  if (host === 'coupang.com' || dnsDomainIs(host, '.coupang.com') ||")
      $out.Add("      host === 'coupangcdn.com' || dnsDomainIs(host, '.coupangcdn.com') ||")
      $out.Add("      host === 'coupangcdn.net' || dnsDomainIs(host, '.coupangcdn.net') ||")
      $out.Add("      host === 'coupangstatic.com' || dnsDomainIs(host, '.coupangstatic.com') ||")
      $out.Add("      host === 'coupang.net' || dnsDomainIs(host, '.coupang.net'))")
      $out.Add("    return 'PROXY 127.0.0.1:`$proxyPort';")
      $out.Add("  return 'DIRECT';")
      $out.Add("}")
      $out.Add('"@')
      $out.Add($indent+'[IO.File]::WriteAllText($spxWingDirectPacPath,$spxWingDirectPac,(New-Object System.Text.UTF8Encoding($false)))')
      $out.Add($indent+"`$spxWingDirectPacUrl = 'file:///' + (`$spxWingDirectPacPath -replace '\\','/')")
      $out.Add('')
      $inserted=$true
    }

    if($line -match '--proxy-pac-url='){
      $indent=([regex]::Match($line,'^\s*')).Value
      $out.Add($indent+"'--proxy-pac-url=' + (Quote-Argument `$spxWingDirectPacUrl),")
      $replaced=$true
    }else{
      $out.Add($line)
    }
  }

  if(-not $inserted){ Fail '$argumentParts block not found; original restored from backup is available.' }
  if(-not $replaced){ Fail '--proxy-pac-url line not found; original restored from backup is available.' }

  $newText=[string]::Join("`r`n",$out)
  [IO.File]::WriteAllText($Launcher,$newText,(New-Object System.Text.UTF8Encoding($true)))
}else{
  Write-Host 'PATCH_ALREADY_PRESENT=YES'
}

# Static verification only; no Chrome/NetworkHost restart.
$verify=Get-Content -LiteralPath $Launcher -Raw -Encoding UTF8
if($verify -notmatch [regex]::Escape($Marker)){ Fail 'marker verification failed' }
if($verify -notmatch "wing\.coupang\.com"){ Fail 'WING DIRECT rule verification failed' }
if($verify -notmatch "coupang-proxy-wing-direct\.pac"){ Fail 'custom PAC path verification failed' }
if($verify -notmatch "PROXY 127\.0\.0\.1:\`\$proxyPort"){ Fail 'selected tether proxy rule verification failed' }

Write-Host ('BACKUP='+$backupDir)
Write-Host 'WING_MAIN_HOST=WINDOWS_DEFAULT_NETWORK_DIRECT'
Write-Host 'WING_AUTH_HOSTS=WINDOWS_DEFAULT_NETWORK_DIRECT'
Write-Host 'COUPANG_SHOPPING=SELECTED_TETHER_PROXY'
Write-Host 'COUPANG_SHARED_CDN=SELECTED_TETHER_PROXY'
Write-Host 'NAVER=WINDOWS_DEFAULT_NETWORK_DIRECT'
Write-Host 'SUPABASE=WINDOWS_DEFAULT_NETWORK_DIRECT'
Write-Host 'CHROME_STOP=0 NETWORKHOST_RESTART=0 ROUTE_CHANGE=0 ADAPTER_CHANGE=0'
Write-Host 'NOTE=현재 열려 있는 전용창은 기존 PAC를 계속 사용합니다. 적용 후 전용창만 닫았다 다시 여세요.'
Write-Host 'FINAL=WING_DEFAULT_NETWORK_PATCH_PASS'
