const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {parseHTML,DOMParser}=require('linkedom');
const root=path.resolve(__dirname,'..');
function runtime(overrides={}){
  const {window,document}=parseHTML('<html><body></body></html>');
  const ctx=vm.createContext({console,URL,URLSearchParams,AbortController,setTimeout,clearTimeout,TextEncoder,TextDecoder,
    window,document,DOMParser,Node:window.Node,location:new URL('https://www.coupang.com/np/search?q=텀블러'),
    chrome:{storage:{local:{get:async()=>({}),set:async()=>{},remove:async()=>{}},onChanged:{addListener:()=>{}}},runtime:{getManifest:()=>({version:'1.6.52'})}},
    fetch:async()=>{throw new Error('Unexpected network in local test');},...overrides});
  for(const file of ['src/lib/util.js','src/lib/aggregate.js','src/content/coupang-parser.js'])vm.runInContext(fs.readFileSync(path.join(root,file),'utf8'),ctx,{filename:file});
  ctx.SPX.util.getSettings=async()=>({humanDelayEnabled:false});
  return ctx;
}
const relatedHtml=label=>`<html><body><h1>원본 텀블러</h1><section><h2>${label}</h2><ul>
  <li class="search-product"><a href="/vp/products/2?itemId=20&vendorItemId=200" title="보온 텀블러"><span class="price-value">12,000원</span><span class="rating-total-count">(30)</span></a></li>
  <li class="search-product"><a href="/vp/products/3?itemId=30&vendorItemId=300" title="휴대 텀블러"><span class="price-value">13,000원</span><span class="rating-total-count">(40)</span></a></li>
  </ul></section></body></html>`;
function detailHtml(pid=2,name='보온 텀블러'){
  return `<html><head><link rel="canonical" href="https://www.coupang.com/vp/products/${pid}"></head><body>
    <h1 class="prod-buy-header__title">${name}</h1><span class="total-price"><strong>12,000원</strong></span>
    <span class="count">30개 상품평</span><span>판매자: 좋은상점</span><span>일반배송</span><span>한 달 300명 구매</span>
    </body></html>`;
}
function sourceFunction(file,name){
  const source=fs.readFileSync(path.join(root,file),'utf8');
  const tree=require('acorn').parse(source,{ecmaVersion:'latest'});let found;
  function walk(node){if(!node||typeof node!=='object')return;if(node.type==='FunctionDeclaration'&&node.id?.name===name)found=source.slice(node.start,node.end);for(const value of Object.values(node)){if(Array.isArray(value))value.forEach(walk);else if(value&&typeof value==='object')walk(value);}}
  walk(tree);if(!found)throw new Error(`Function missing: ${name}`);return found;
}
module.exports={runtime,relatedHtml,detailHtml,root,sourceFunction};
