@echo off
chcp 65001 >nul
setlocal
set "PS=%~dp0tools\crosspc\09_REFRESH_NORMAL_CHROME_LAUNCHER.ps1"
if not exist "%PS%" (
  echo [ERROR] Normal Chrome launcher repair PowerShell file not found.
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS%"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo [ERROR] Normal Chrome launcher refresh failed. Check the message above.
if "%RC%"=="0" echo [OK] Normal Chrome launcher refresh completed.
pause
exit /b %RC%
