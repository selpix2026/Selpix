/* coupang-search.js — 쿠팡 검색화면 오버레이 + 자동 키워드 대기열 수집 */
(function () {
  if (globalThis.__SPX_COUPANG_SEARCH_301__) {
    // v1.6.41: 중복 콘텐츠 주입으로 사용자의 마지막 접기 상태를 변경하지 않습니다.
    return;
  }
  globalThis.__SPX_COUPANG_SEARCH_301__ = true;
  const FORCE_SIDEBAR_MODE = globalThis.__SPX_FORCE_SIDEBAR__ === true;
  const SPX = globalThis.SPX;
  const { fmt, currentKeyword: urlCurrentKeyword, getSettings, sleep } = SPX.util;
  const jitterMs=(min,max)=>{const lo=Math.max(0,Math.round(Number(min)||0)),hi=Math.max(lo,Math.round(Number(max)||lo));return lo+Math.floor(Math.random()*(hi-lo+1));};
  const AUTO_KEY = 'spxAutomation';
  const SPX_CONTENT_BUILD_VERSION='1.6.54';
  // 사이드바 표시 상태는 현재 URL/수집 작업과 무관한 확장프로그램 설정입니다.
  // Chrome local 저장소에 보존하여 F5/키워드 전환/새 쿠팡 탭에서도 유지합니다.
  const SPX_SIDEBAR_COLLAPSED_KEY_V1632='spxSidebarCollapsedV1632';
  let sidebarCollapsedV1632=false;
  let sidebarCollapsedReadyV1632=false;
  let sidebarCollapsedRevisionV1632=0;
  function renderSidebarCollapsedV1632(){
    const overlay=document.getElementById('spx-overlay');
    if(!overlay)return;
    overlay.classList.toggle('spx-collapsed',sidebarCollapsedV1632);
    const button=overlay.querySelector('#spx-fold');
    if(button){
      const label=sidebarCollapsedV1632?'사이드바 펼치기':'사이드바 접기';
      button.setAttribute('aria-label',label);
      button.setAttribute('aria-expanded',sidebarCollapsedV1632?'false':'true');
      button.dataset.spxTip=label;
    }
    // 새로고침 때 펼쳐졌다가 바로 접히는 화면 깜빡임을 방지합니다.
    if(sidebarCollapsedReadyV1632)overlay.style.visibility='';
  }
  function setSidebarCollapsedV1632(collapsed,{persist=true}={}){
    sidebarCollapsedRevisionV1632++;
    sidebarCollapsedV1632=collapsed===true;
    sidebarCollapsedReadyV1632=true;
    renderSidebarCollapsedV1632();
    if(persist)void chrome.storage.local.set({[SPX_SIDEBAR_COLLAPSED_KEY_V1632]:sidebarCollapsedV1632}).catch(()=>{});
  }
  void chrome.storage.local.get(SPX_SIDEBAR_COLLAPSED_KEY_V1632).then(stored=>{
    // 사용자가 복원 중 S를 먼저 누른 경우 뒤늦은 읽기값으로 덮지 않습니다.
    if(sidebarCollapsedRevisionV1632===0)sidebarCollapsedV1632=stored?.[SPX_SIDEBAR_COLLAPSED_KEY_V1632]===true;
  }).catch(()=>{}).finally(()=>{
    sidebarCollapsedReadyV1632=true;
    renderSidebarCollapsedV1632();
  });
  function cleanNetworkDisplayTextV10155(value,fallback='Windows 기본 인터넷'){
    const text=String(value??'').replace(/\s+/g,' ').trim();
    if(!text)return fallback;
    const replacements=(text.match(/\uFFFD/g)||[]).length;
    if(replacements>0||text.includes('�')||/���|����|癤풱|곸꽭|섏씠吏|뺤옣|꾨줈|洹몃옩/.test(text))return fallback;
    return text;
  }
  const SPX_RUNTIME_ALIGNMENT_REPAIR_KEY='spxRuntimeAlignmentRepairV30817';
  const SPX_MANUAL_IP_RUNTIME_REPAIR_KEY='spxManualIpRuntimeRepairV3085';
  const SPX_DEDICATED_NETWORK_TAB_KEY = 'spxDedicatedSelectedNetworkTabV306';
  const SPX_DEDICATED_NETWORK_PROFILE_KEY = 'spxDedicatedSelectedNetworkProfileV3077';
  const SPX_DEDICATED_COLLECTION_PAYLOAD_KEY='spxDedicatedCollectionPayloadV306';
  const SPX_DEDICATED_COLLECTION_STARTED_KEY='spxDedicatedCollectionStartedV306';
  const SPX_KEYWORD_TRANSITION_KEY='spxKeywordTransitionV3089';
  const SPX_STATUS_LOG_HEIGHT_KEY='spxSidebarStatusLogHeightV30814';
  const SPX_STATUS_LOG_MIN_HEIGHT=52;
  const SPX_STATUS_LOG_DEFAULT_HEIGHT=110;
  const SIDEBAR_WING_VIEW_METRIC_KEY='spxWinnerViewMetricSidecarV426';
  const SIDEBAR_WING_VIEW_QUEUE_KEY='spxWingViewQueueV426';
  let statusLogHeight=SPX_STATUS_LOG_DEFAULT_HEIGHT;
  let statusLogHeightSaveTimer=0;
  let recoveryCountdownTimer=null,recoveryCountdownPollTimer=null,recoveryCountdownBusy=false,recoveryCountdownStartedAt=0,recoveryCountdownSnapshot=null,recoveryCountdownLastSecondV1518=null,manualIpChangePending=false,lastRecoveryLogFamily='',recoveryUiOwner=false; /* SPX_RECOVERY_LOCAL_CLOCK_V1518 */
  let dedicatedCollectionPayload=null;
  function normalizeVisibleKeyword(value){return String(value||'').normalize('NFKC').replace(/\s+/g,' ').trim();}
  function canonicalVisibleKeyword(value){return SPX.util?.canonicalKeyword?.(value)||normalizeVisibleKeyword(value).toLowerCase().replace(/\s+/g,'');}
  function readKeywordTransitionMarker(){
    try{
      const raw=sessionStorage.getItem(SPX_KEYWORD_TRANSITION_KEY);if(!raw)return null;
      const marker=JSON.parse(raw);const maxAge=Number(marker?.readyAt||0)>0?6*60*60*1000:45000;
      if(!marker||Date.now()-Number(marker.readyAt||marker.startedAt||0)>maxAge){sessionStorage.removeItem(SPX_KEYWORD_TRANSITION_KEY);return null;}
      return marker;
    }catch(_){return null;}
  }
  function currentKeyword(){
    const urlKeyword=normalizeVisibleKeyword(urlCurrentKeyword?.());
    const marker=readKeywordTransitionMarker();
    if(!marker?.keyword)return urlKeyword;
    const target=normalizeVisibleKeyword(marker.keyword),targetKey=canonicalVisibleKeyword(target);
    const input=document.querySelector?.('#headerSearchKeyword, form[action*="/np/search"] input[name="q"], input[name="q"]');
    const inputKeyword=normalizeVisibleKeyword(input?.value||'');
    if(targetKey&&canonicalVisibleKeyword(urlKeyword)===targetKey)return target;
    if(targetKey&&canonicalVisibleKeyword(inputKeyword)===targetKey&&Number(marker.readyAt||0)>0)return target;
    const resultChanged=typeof searchResultSignature==='function'&&String(marker.beforeSignature||'')!==searchResultSignature();
    if(targetKey&&canonicalVisibleKeyword(inputKeyword)===targetKey&&resultChanged)return target;
    return urlKeyword;
  }
  function decodeBase64UrlJson(value){
    try{const base=String(value||'').replace(/-/g,'+').replace(/_/g,'/');const padded=base+'='.repeat((4-base.length%4)%4);const binary=atob(padded),bytes=Uint8Array.from(binary,(char)=>char.charCodeAt(0));return JSON.parse(new TextDecoder().decode(bytes));}catch(_){return null;}
  }
  function encodeBase64UrlJsonV10156(value){
    try{const bytes=new TextEncoder().encode(JSON.stringify(value));let binary='';for(const byte of bytes)binary+=String.fromCharCode(byte);return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}catch(_){return '';}
  }
  function initializeDedicatedNetworkTabMarker(){
    let dedicated=false;
    try{
      const raw=String(location.hash||'').replace(/^#/,'');const params=new URLSearchParams(raw);
      if(params.has('spx-selected-network')){
        sessionStorage.setItem(SPX_DEDICATED_NETWORK_TAB_KEY,'1');dedicated=true;params.delete('spx-selected-network');
        chrome.storage.local.set({[SPX_DEDICATED_NETWORK_PROFILE_KEY]:{enabled:true,markedAt:Date.now(),profileScope:'dedicated'}}).catch(()=>{});
      }
      else dedicated=sessionStorage.getItem(SPX_DEDICATED_NETWORK_TAB_KEY)==='1';
      if(params.has('spx-collect')){
        const payload=decodeBase64UrlJson(params.get('spx-collect'));
        if(payload&&(payload?.rows?.length||payload?.kind)){dedicatedCollectionPayload=payload;sessionStorage.setItem(SPX_DEDICATED_COLLECTION_PAYLOAD_KEY,JSON.stringify(payload));}
        params.delete('spx-collect');
      }else{
        const saved=sessionStorage.getItem(SPX_DEDICATED_COLLECTION_PAYLOAD_KEY);if(saved)try{dedicatedCollectionPayload=JSON.parse(saved);}catch(_){ }
      }
      const next=params.toString();history.replaceState(history.state,'',location.pathname+location.search+(next?`#${next}`:''));
    }catch(_){ }
    return dedicated;
  }
  let IS_SELECTED_NETWORK_DEDICATED_TAB = initializeDedicatedNetworkTabMarker();
  function setLowBandwidthVisualModeV10156(enabled){try{document.documentElement?.classList.toggle('spx-low-bandwidth-collection',enabled===true);}catch(_){}return enabled===true;}
  async function syncLowBandwidthVisualModeV10156(){try{const response=await SPX.util.sendMessage({type:'SPX_LOW_BANDWIDTH_TAB_STATUS'});setLowBandwidthVisualModeV10156(response?.ok===true&&response?.data?.active===true);}catch(_){}}
  setTimeout(()=>syncLowBandwidthVisualModeV10156(),0);

  async function restoreDedicatedNetworkProfileMarker(){
    try{
      const stored=await chrome.storage.local.get(SPX_DEDICATED_NETWORK_PROFILE_KEY);
      if(stored?.[SPX_DEDICATED_NETWORK_PROFILE_KEY]?.enabled===true){
        IS_SELECTED_NETWORK_DEDICATED_TAB=true;
        sessionStorage.setItem(SPX_DEDICATED_NETWORK_TAB_KEY,'1');
      }
      if(IS_SELECTED_NETWORK_DEDICATED_TAB)await SPX.util.sendMessage({type:'SPX_DEDICATED_PROFILE_HYDRATE',onlyWhenMissing:true}).catch(()=>null);
    }catch(_){ }
    return IS_SELECTED_NETWORK_DEDICATED_TAB;
  }
  let state = { keyword: '', lockedKeyword: '', detected: 0, agg: null, key: null, raw: [], busy: false, autoStarting: false, autoStarted: false, candidates: [], adminOverrideUploaded:false };
  let uiRepairTimer = null;
  let lifecycleTimer = null;
  let lifecyclePageDirtyV10157 = true;
  let lifecycleLastSignatureV10157 = '';
  let navigationTimer = null;
  let pendingNavigation = null;
  let autoRunTimer = null;
  let automationKickTimer = null;
  let automationKickRunId = '';
  let automationContextFailureCount = 0;
  let keywordTransitionPromise = null;
  let keywordTransitionTarget = '';
  let keywordTransitionRunId = '';
  let keywordTransitionSerial = 0;
  let bootRetryTimer = null;
  let automationEpoch = 0;
  let activeRunId = null;
  /* [v2.6.2] 마지막 페이지 저장 응답을 기다리는 동안 service-worker가 먼저
     running=false(manual_complete)를 저장하면 storage.onChanged가 현재 task를 취소해
     최종 분석 결과 렌더링이 유실될 수 있습니다. 응답 처리 완료 전까지 같은 runId의
     정상 완료 상태는 중단 신호가 아니라 '최종 결과 전달 중'으로 보류합니다. */
  let pendingPageSaveResponse = null;
  let recentlyRenderedCompletion = { runId:'', at:0 };
  let lastUrl = location.href;
  let lifecycleObserver = null;
  let storageChangeHandler = null;
  let runtimeStopHandler = null;
  let contextInvalidated = false;
  let activeCollectionSettingsOverride = null;
  let localManualScanActive = false;
  let localManualAbortRequested = false;
  let localManualCompletedKeyword = '';
  /* v4.1.1: 쿠팡 차단 복구가 상세상품 fetch 중 발생하면 검색결과 문서는 그대로 살아 있을 수 있습니다.
     현재 페이지 카드 파싱본을 메모리에만 잠시 보존해 새 IP 확인 뒤 같은 문서에서 이어서 상세확인·저장을 재개합니다.
     문서 자체가 차단화면으로 교체된 경우에는 이 메모리 체크포인트를 사용하지 않고 현재 페이지만 1회 다시 요청합니다. */
  let networkRecoveryPageSnapshot = null;
  let networkRecoverySoftResumeRequested = false;
  /* v4.0.97: 사이드바의 추가 페이지 체크는 사용자가 직접 바꾼 값이 현재 탭에서 최우선입니다.
     전용 프로필 설정 hydrate가 같은 순간 실행돼도 화면과 이번 실행 스냅샷을 되돌리지 않습니다. */
  let sidebarExtraPageSessionOverride = null;
  let sidebarExtraPagePersistPromise = Promise.resolve();
  /* 연속 탐색은 runId 생성 전에 네이버 후보를 먼저 확인합니다. 이 시작 구간도 실행 상태로
     취급해야 사용자가 사이드바의 ■ 버튼으로 즉시 취소할 수 있습니다. */
  let sourcingStartPending = false;
  let sourcingStartCancelRequested = false;
  const SIDEBAR_PROFILE_KEY = 'spxSidebarCollectionProfilesV228';
  const COLLECTION_PROFILE_KEY = 'spxSelectedCollectionProfileV273';
  const STEP_ANALYZE_KEY = 'spxStepAnalyzeAfterNavigationV273';
  let activeCollectionProfile = 'lite';
  const NEXT_NAVIGATION_DELAY_DEFAULT = Object.freeze({ min: 180, max: 420 });
  let nextNavigationDelayRange = { ...NEXT_NAVIGATION_DELAY_DEFAULT };
  let nextNavigationDelayPersistTimer = null;
  const RECENT_HISTORY_CLEAR_KEY_V101510='spxRecentCollectionHistoryClearedAtV101510';
  let persistentHistoryResetAtV101510=0;
  let persistentHistoryResetReadyV101510=Promise.resolve(0);
  try{persistentHistoryResetReadyV101510=chrome.storage.local.get(RECENT_HISTORY_CLEAR_KEY_V101510).then((stored)=>{persistentHistoryResetAtV101510=Math.max(0,Number(stored?.[RECENT_HISTORY_CLEAR_KEY_V101510])||0);return persistentHistoryResetAtV101510;}).catch(()=>persistentHistoryResetAtV101510);}catch(_){}
  let tabSessionStats = { discovered:0, processed:0, excluded:0, failed:0, belowCriteria:0, uploadPending:0, uploadHeld:0, uploadPendingDb:null, uploadPendingAttentionDb:null, uploaded:0, automationRunning:false, automationStartedAt:0, automationElapsedMs:0, runtimeDisplayMode:'auto',runtimeManualBaseMs:0, historyResetAt:0, runProcessed:null, runSaved:null, runRequeued:null, runExcluded:null, runFailed:null, runSkipped:null, runUploadPending:null, runUploadHeld:null, runUploaded:null };
  let tabSessionTicker = null;
  const MANUAL_PROFILE_DEFAULT = {
    /* v3.0.8.26: Lite/Pro 최대 페이지는 각각 독립 저장합니다. 체크 해제는 해당 프로필만 1페이지 고정입니다. */
    enabled:{
      maxPages:true, targetOrganic:true, maxProducts:true, lowReview:true,
      winnerMonthlySales:true, winnerReviewMin:true, winnerReviewMax:true, winnerRecentReview:true,
      detailRecommendations:true
    },
    maxPagesPerKeyword:1, sourceDataTargetOrganic:60, sourceDataMaxProducts:200, lowReviewSampleSize:4,
    winnerMonthlySalesMin:200, winnerReviewMin:10, winnerReviewMax:1500, winnerRecentReviewMin:1,
    collectDetailRecommendations:true
  };

  /* [v2.2.5] 쿠팡 홈 검색창이 가끔 component= 빈 파라미터가 붙은 주소를 만들고 본문을
     하얗게 남기는 사례가 확인됐다. 같은 탭에서 한 번만 표준 검색주소로 정리하며, 반복
     새로고침은 절대 하지 않는다. */
  /* v2.4.1: Next는 검색창 입력 + 실제 검색버튼 1회 클릭만 수행합니다.
     자동 URL 교정은 중복 이동을 만들 수 있어 실행하지 않습니다. */
  // if (normalizeMalformedSearchUrlOnce()) return;

  const $ = (id) => document.getElementById(id);


  const REQUIRED_UI_IDS = [
    'spx-overlay', 'spx-status', 'spx-mode-badge', 'spx-stop-summary-modal', 'spx-stop-summary-open', 'spx-pending-upload-now', 'spx-skip-keyword', 'spx-change-ip', 'spx-exclude-keyword', 'spx-step-once', 'spx-settings-modal', 'spx-network-toggle', 'spx-airplane-toggle', 'spx-memory-cleanup', 'spx-clear-browsing', 'spx-live-log', 'spx-count', 'spx-kwlabel', 'spx-scan', 'spx-run-toggle',
    'spx-auto', 'spx-auto-text', 'spx-auto-runtime', 'spx-next-now', 'spx-discovered', 'spx-discovered-list', 'spx-prog', 'spx-pfill', 'spx-ptxt',
    'spx-ptime', 'spx-body', 'spx-auto-upload', 'spx-upload', 'spx-admin-override-upload', 'spx-dbinfo', 'spx-tooltip',
  ];

  function contextEndError() {
    const error = SPX.util.contextInvalidatedError?.() || new Error('Extension context invalidated');
    error.spxContextInvalidated = true;
    return error;
  }

  function clearReloadNoticeV1518(){
    const existing=document.getElementById('spx-extension-update-notice');
    if(existing)existing.remove();
  }

  function showReloadNotice(detail='') {
    const mount = () => {
      const existing=document.getElementById('spx-extension-update-notice');
      if(existing){const text=existing.querySelector('[data-spx-runtime-text]');if(text&&detail)text.textContent=`SmartPage Sourcing Collector 새 버전 적용 대기 · ${detail} · 이 쿠팡 탭만 새로고침하세요.`;return;}
      const host = document.body || document.documentElement;
      if (!host) return;
      const box = document.createElement('div');
      box.id = 'spx-extension-update-notice';
      box.setAttribute('role', 'alert');
      box.style.cssText = 'position:fixed;z-index:2147483647;left:50%;top:18px;transform:translateX(-50%);display:flex;align-items:center;gap:12px;max-width:760px;padding:13px 16px;border-radius:10px;background:#171a21;color:#f4f6fb;border:1px solid #f2b03d;box-shadow:0 10px 35px rgba(0,0,0,.45);font:600 14px/1.45 -apple-system,BlinkMacSystemFont,Segoe UI,Malgun Gothic,sans-serif';
      const text = document.createElement('span');
      text.dataset.spxRuntimeText='1';
      text.textContent = detail ? `SmartPage Sourcing Collector 새 버전 적용 대기 · ${detail} · 이 쿠팡 탭만 새로고침하세요.` : 'SmartPage Sourcing Collector가 업데이트되었습니다. 이 쿠팡 탭을 새로고침하면 새 버전이 적용됩니다.';
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = '이 탭 새로고침';
      button.style.cssText = 'flex:none;border:0;border-radius:7px;background:#f2b03d;color:#1a1200;padding:8px 11px;font:800 12px/1 -apple-system,BlinkMacSystemFont,Segoe UI,Malgun Gothic,sans-serif;cursor:pointer';
      button.addEventListener('click', () => location.reload());
      box.append(text, button);
      host.appendChild(box);
    };
    if (document.body || document.documentElement) mount();
    else document.addEventListener('DOMContentLoaded', mount, { once: true });
  }

  function shutdownInvalidatedContext() {
    if (contextInvalidated) return;
    contextInvalidated = true;
    automationEpoch += 1;
    clearNavigationTimer();
    clearAutoRunTimer();
    clearAutomationKickWatchdog();
    if (bootRetryTimer) clearTimeout(bootRetryTimer);
    bootRetryTimer = null;
    if (uiRepairTimer) clearTimeout(uiRepairTimer);
    uiRepairTimer = null;
    if (lifecycleTimer) clearInterval(lifecycleTimer);
    lifecycleTimer = null;
    stopRecoveryCountdownMonitorV1518();
    if (tabSessionTicker) clearInterval(tabSessionTicker);
    tabSessionTicker = null;
    try { lifecycleObserver?.disconnect(); } catch (_) {}
    lifecycleObserver = null;
    try {
      if (storageChangeHandler && globalThis.chrome?.storage?.onChanged) {
        globalThis.chrome.storage.onChanged.removeListener(storageChangeHandler);
      }
    } catch (_) {}
    storageChangeHandler = null;
    try {
      if (runtimeStopHandler && globalThis.chrome?.runtime?.onMessage) {
        globalThis.chrome.runtime.onMessage.removeListener(runtimeStopHandler);
      }
    } catch (_) {}
    runtimeStopHandler = null;
    state.busy = false;
    state.autoStarting = false;
    state.autoStarted = false;
    activeRunId = null;
    showReloadNotice();
  }

  function legacyNativeRuntimeError(value){
    return /sendNativeMessage.*(?:is not a function|undefined)|(?:알 수 없는 요청|unknown request).*SPX_NETWORK/i.test(String(value?.error||value?.message||value||''));
  }
  function repairExtensionRuntime(reason='확장 런타임 버전 불일치'){
    /* v1.5.29: 자동 location.reload()는 하지 않습니다. manifest/service-worker가 실제로 다르거나
       content context가 폐기된 경우에만 사용자가 현재 탭을 1회 새로고침하도록 안내합니다. */
    showReloadNotice(reason);
    return false;
  }
  async function ensureRuntimeBuildAligned({repair=true}={}){
    let lastReason='';let lastError=null;let lastRuntimeBuild='';let lastManifestVersion='';
    const startedAt=Date.now();
    const maxWaitMs=8000;
    let attempt=0;
    while(Date.now()-startedAt<maxWaitMs){
      if(!SPX.util.runtimeAlive?.()){
        if(repair)showReloadNotice(`콘텐츠 ${SPX_CONTENT_BUILD_VERSION} · 확장 context 종료`);
        return false;
      }
      try{
        const response=await SPX.util.sendMessage({type:'SPX_RUNTIME_INFO'});
        const runtimeBuild=String(response?.data?.runtimeBuild||response?.data?.serviceWorkerBuild||'').trim();
        const manifestVersion=String(chrome.runtime?.getManifest?.().version||'').trim();
        lastRuntimeBuild=runtimeBuild;lastManifestVersion=manifestVersion;
        const extensionId=String(response?.data?.extensionId||chrome.runtime?.id||'').trim();
        if(response?.ok===true&&runtimeBuild===SPX_CONTENT_BUILD_VERSION&&manifestVersion===SPX_CONTENT_BUILD_VERSION){
          clearReloadNoticeV1518();
          return true;
        }
        lastReason=`콘텐츠 ${SPX_CONTENT_BUILD_VERSION} · 서비스워커 ${runtimeBuild||'시작 대기'} · manifest ${manifestVersion||'확인 불가'} · ID ${extensionId||'확인 불가'}`;
        /* v1.5.29: 검은 업데이트 배너는 실제 버전 불일치에만 사용합니다.
           같은 manifest에서 MV3 Service Worker가 늦게 깨거나 응답 채널만 닫힌 것은 업데이트가 아닙니다. */
        if(manifestVersion&&manifestVersion!==SPX_CONTENT_BUILD_VERSION)break;
        if(runtimeBuild&&runtimeBuild!==SPX_CONTENT_BUILD_VERSION)break;
      }catch(error){
        lastError=error;
        if(SPX.util.isContextInvalidatedError?.(error)||!SPX.util.runtimeAlive?.()){
          if(repair)showReloadNotice(`콘텐츠 ${SPX_CONTENT_BUILD_VERSION} · 확장 context 종료`);
          return false;
        }
        if(!SPX.util.isTransientRuntimeMessageError?.(error))lastReason=String(error?.message||error||'서비스워커 응답 오류');
        else lastReason=`콘텐츠 ${SPX_CONTENT_BUILD_VERSION} · 서비스워커 재연결 대기 · manifest ${String(chrome.runtime?.getManifest?.().version||'확인 불가')}`;
      }
      attempt+=1;
      await new Promise((resolve)=>setTimeout(resolve,Math.min(1200,180+attempt*140)));
    }
    const manifestVersion=lastManifestVersion||String(chrome.runtime?.getManifest?.().version||'').trim();
    const actualMismatch=(manifestVersion&&manifestVersion!==SPX_CONTENT_BUILD_VERSION)||(lastRuntimeBuild&&lastRuntimeBuild!==SPX_CONTENT_BUILD_VERSION);
    if(actualMismatch){
      const reason=lastReason||(lastError?.message||String(lastError||'확장 버전 불일치'));
      if(repair)repairExtensionRuntime(reason);else showReloadNotice(reason);
      return false;
    }
    /* SPX_V1526_TRANSIENT_RUNTIME_NO_RELOAD: 동일 manifest에서 Service Worker가 잠깐 응답하지 않아도
       새 버전 안내를 띄우지 않습니다. 이후 실제 작업 메시지가 Service Worker를 다시 깨웁니다. */
    clearReloadNoticeV1518();
    return true;
  }
  async function runtimeMessage(message) {
    if (contextInvalidated) throw contextEndError();
    try {
      if (!SPX.util.runtimeAlive?.()) throw contextEndError();
      const response=await SPX.util.sendMessage(message);
      if(message?.type!=='SPX_RUNTIME_INFO'&&response?.ok===false&&legacyNativeRuntimeError(response)){
        if(repairExtensionRuntime(response?.error||response?.message||'구버전 Native Messaging 호출')){
          const repaired=new Error('구버전 서비스워커를 감지해 확장 런타임을 다시 시작했습니다. 페이지가 새로고침된 뒤 다시 실행하세요.');
          repaired.code='SPX_RUNTIME_RESTARTING';throw repaired;
        }
      }
      return response;
    } catch (error) {
      if(legacyNativeRuntimeError(error)&&repairExtensionRuntime(error?.message||String(error))){
        const repaired=new Error('구버전 서비스워커를 감지해 확장 런타임을 다시 시작했습니다. 페이지가 새로고침된 뒤 다시 실행하세요.');
        repaired.code='SPX_RUNTIME_RESTARTING';throw repaired;
      }
      if (error?.spxContextInvalidated || SPX.util.isContextInvalidatedError?.(error) || !SPX.util.runtimeAlive?.()) {
        shutdownInvalidatedContext();
        throw contextEndError();
      }
      /* v1.5.22: Service Worker가 살아 있는 상태의 포트/수신자 경합은 업데이트로 오인하지 않습니다.
         호출자는 원래 작업 오류로 처리하고, 다음 호출에서 정상적으로 다시 연결할 수 있습니다. */
      if(SPX.util.isTransientRuntimeMessageError?.(error)&&SPX.util.runtimeAlive?.())throw error;
      throw error;
    }
  }

  function isUnknownRuntimeRequest(response,type){
    const message=String(response?.error||response?.message||'');
    return response?.ok===false&&new RegExp(`(?:알 수 없는 요청|unknown request)\\s*:\\s*${String(type||'').replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}`,'i').test(message);
  }
  function repairStaleDedicatedRuntime(){
    const now=Date.now();let prior=0;
    try{prior=Number(sessionStorage.getItem(SPX_MANUAL_IP_RUNTIME_REPAIR_KEY)||0);}catch(_){ }
    if(prior&&now-prior<60000)return false;
    try{sessionStorage.setItem(SPX_MANUAL_IP_RUNTIME_REPAIR_KEY,String(now));}catch(_){ }
    try{
      const currentUrl=location.href;
      /* 전용 프로필에 오래된 콘텐츠 문서가 남은 경우에도 확장 전체를 다시 시작하지 않고
         현재 전용 쿠팡 탭만 한 번 다시 읽습니다. */
      setTimeout(()=>location.replace(currentUrl),80);
      return true;
    }catch(_){return false;}
  }
  async function requestManualIpChange(payload){
    let response=await runtimeMessage({...payload,type:'SPX_NETWORK_MANUAL_IP_CHANGE'});
    if(isUnknownRuntimeRequest(response,'SPX_NETWORK_MANUAL_IP_CHANGE')){
      response=await runtimeMessage({...payload,type:'SPX_MANUAL_IP_CHANGE'});
    }
    if(isUnknownRuntimeRequest(response,'SPX_MANUAL_IP_CHANGE')){
      const repaired=repairStaleDedicatedRuntime();
      const error=new Error(repaired
        ?`전용창 확장 런타임이 이전 버전입니다. 이 탭을 한 번 새로고침한 뒤 IP↻를 눌러주세요.`
        :'전용창 확장 런타임이 아직 이전 버전입니다. 전용창을 완전히 닫고 설정에서 다시 연 뒤 IP↻를 눌러주세요.');
      error.code='SPX_STALE_EXTENSION_RUNTIME';throw error;
    }
    return response;
  }

  function setRecoveryActionLockV111(active){
    const locked=active===true;
    const scan=getUiElement('spx-scan',{repair:false});
    const next=getUiElement('spx-step-once',{repair:false});
    if(scan){
      /* v1.0.13: 버튼 깜빡임은 자동 클릭 신호가 아닙니다.
         네트워크 복구 중에는 starting 애니메이션을 완전히 끄고 정적인 '복구 중'으로 표시합니다. */
      scan.classList.remove('starting');
      if(locked){
        scan.dataset.originalText=scan.dataset.originalText||'키워드 분석';
        scan.textContent='복구 중';
        scan.disabled=true;
        scan.title='IP 변경 복구가 끝난 뒤 저장된 키워드/페이지에서 자동으로 수집을 이어갑니다.';
      }else{
        if(scan.textContent==='복구 중')scan.textContent=scan.dataset.originalText||'키워드 분석';
        scan.disabled=state.busy===true;
        if(scan.title==='IP 변경 복구가 끝난 뒤 저장된 키워드/페이지에서 자동으로 수집을 이어갑니다.')scan.title='';
      }
    }
    if(next)next.disabled=locked;
  }

  function formatRecoveryCountdown(ms){const total=Math.max(0,Math.ceil((Number(ms)||0)/1000)),m=Math.floor(total/60),s=total%60;return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;}
  function recoveryStepIndexV102(network={},status='',phase='',hostPhase=''){
    const p=String(phase||network?.phase||'').toLowerCase(),h=String(hostPhase||network?.hostPhase||'').toLowerCase(),st=String(status||network?.status||'').toLowerCase();
    // The current browser phase owns these steps. Old native telemetry must not
    // make a fresh request appear to skip stop / memory / site cleanup.
    const browserSteps={'request-accepted':0,'block-detected':0,stopped:1,'memory-cleanup':2,'site-cleanup':3,'airplane-prepare':4};
    if(Object.prototype.hasOwnProperty.call(browserSteps,p))return browserSteps[p];
    if(st==='completed'||st==='waiting-retry'||p==='normal-check'||p==='block-retry-wait')return 8;
    if(p==='page-refresh')return 7;
    if(p==='public-ip-check'||p==='ip-confirmed'||['public-ip-check','public-ip-confirmed','public-ip-unchanged'].includes(h))return 6;
    if(['reconnecting','windows-network-restoring'].includes(p)||['airplane-off','airplane-off-command','mobile-data-on','reconnecting','device-reconnect','tethering-check','device-restored','android-device-restored'].includes(h))return 5;
    if(p==='airplane-cycle'||['airplane-prepare','host-starting'].includes(p)||['airplane-on','mobile-data-off','device-ready','airplane-on-command'].includes(h))return 4;
    if(p==='request-accepted'||p==='block-detected')return 0;
    if(p==='site-cleanup')return 3;
    if(p==='memory-cleanup')return 2;
    if(p==='stopped')return 1;
    return 0;
  }
  function renderRecoveryStepperV102(network={},status='',phase='',hostPhase='',remainingMs=0){
    const steps=[
      ['🛑','차단 감지'],['⏸','멈춤'],['♻','1회'],['🧹','1회'],['✈',`ON ${Math.max(4,Math.min(300,Number(network?.airplaneHoldSeconds)||20))}초`],['✈','OFF'],['🌐','새 IP 확인'],['↻','F5 새로고침'],['✓','정상 확인']
    ];
    const active=Math.max(0,Math.min(steps.length-1,recoveryStepIndexV102(network,status,phase,hostPhase)));
    const holdLeft=Math.max(0,Number(network?.holdUntil||0)-Date.now());
    const renderRow=(rowSteps,offset)=>rowSteps.map(([icon,label],localIndex)=>{
      const i=offset+localIndex;
      let text=label;
      if(i===4&&active===4&&holdLeft>0)text=`ON ${Math.max(4,Math.min(300,Number(network?.airplaneHoldSeconds)||20))}초 · ${Math.max(1,Math.ceil(holdLeft/1000))}초`;
      const cls=i===active?'is-active':'is-off';
      const arrow=localIndex<rowSteps.length-1?'<span class="spx-recovery-arrow" aria-hidden="true">→</span>':'';
      return `<span class="spx-recovery-step ${cls}">${icon?`<span class="spx-recovery-step-icon">${esc(icon)}</span>`:''}<span class="spx-recovery-step-text">${esc(text)}</span></span>${arrow}`;
    }).join('');
    const firstRow=renderRow(steps.slice(0,5),0);
    const secondRow=renderRow(steps.slice(5),5);
    setHtml('spx-body',`<div class="spx-recovery-stepper" role="status" aria-live="polite"><div class="spx-recovery-row">${firstRow}</div><div class="spx-recovery-row">${secondRow}</div></div>`);
  }
  function clearRecoveryStepperV114(){
    const body=getUiElement('spx-body',{repair:false});
    if(body?.querySelector?.('.spx-recovery-stepper'))body.replaceChildren();
  }
  function renderRecoveryStoragePhaseV114(network={}){
    recoveryCountdownSnapshot={...(recoveryCountdownSnapshot||{}),networkRecovery:network,remainingMs:Math.max(0,Number(network?.holdUntil||0)-Date.now())};
    const status=String(network?.status||''),phase=String(network?.phase||''),hostPhase=String(network?.hostPhase||'');
    applyAirplaneRecoveryIndicatorV105(network,status,phase,hostPhase);
    if(status==='completed'){clearRecoveryStepperV114();return false;}
    if(!['resetting','finalizing'].includes(status))return false;
    recoveryUiOwner=true;ensureUi();setDisplay('spx-auto','flex');setSidebarCollecting(true);
    renderRecoveryStepperV102(network,status,phase,hostPhase,Math.max(0,Number(network?.holdUntil||0)-Date.now()));
    return true;
  }
  async function renderRecoveryCountdownOnce({autoStart=true}={}){
    if(recoveryCountdownBusy||contextInvalidated)return false;recoveryCountdownBusy=true;
    try{
      const response=await runtimeMessage({type:'SPX_GET_NETWORK_RECOVERY_STATE'}).catch(()=>null);
      /* SPX_RECOVERY_POLL_GAP_GUARD_V1518: MV3/Native 상태조회가 한두 번 늦거나 실패해도
         마지막 authoritative holdUntil snapshot을 빈 객체로 덮어쓰지 않습니다. 로컬 초시계는 계속 흐르고,
         다음 정상 poll이 오면 최신 상태로 다시 동기화합니다. */
      const hasFreshData=Boolean(response?.data&&typeof response.data==='object'&&response.data.networkRecovery&&typeof response.data.networkRecovery==='object');
      if(hasFreshData)recoveryCountdownSnapshot=response.data;
      const data=hasFreshData?response.data:(recoveryCountdownSnapshot&&typeof recoveryCountdownSnapshot==='object'?recoveryCountdownSnapshot:{});
      const network=data.networkRecovery&&typeof data.networkRecovery==='object'?data.networkRecovery:{};
      let status=String(network.status||''),phase=String(network.phase||''),hostPhase=String(network.hostPhase||'');
      /* 자동 복구는 AUTO_KEY의 실제 pause와 함께 있을 때만 화면 소유권을 가집니다.
         helper 상태만 뒤늦게 남은 경우 정상 수집 로그 위에 IP복구 문구를 반복 표시하지 않습니다. */
      if(['resetting','finalizing'].includes(status)&&network.manual!==true&&data.automationRecoveryPaused!==true){status='idle';phase='';hostPhase='';}
      applyAirplaneRecoveryIndicatorV105(network,status,phase,hostPhase);
      const remaining=Math.max(0,Number(data.remainingMs)||0),checkpoint=network.checkpoint&&typeof network.checkpoint==='object'?network.checkpoint:{};
      const keyword=String(checkpoint.keyword||currentKeyword()||'').trim(),page=Math.max(1,Number(checkpoint.page)||1);
      const locationLabel=keyword?` · ${keyword} ${page}페이지 보존`:'';
      const attempt=Math.max(1,Number(network.attempt)||1),maxAttempts=Math.max(attempt,Number(network.maxAttempts)||(network.manual===true?2:3));
      const ipButton=getUiElement('spx-change-ip',{repair:false});
      if(status==='waiting-retry'){
        const waitLeft=Math.max(0,Number(network.holdUntil||0)-Date.now());recoveryUiOwner=true;ensureUi();setDisplay('spx-auto','flex');setSidebarCollecting(true);setRecoveryActionLockV111(true);
        renderRecoveryStepperV102(network,status,phase||'block-retry-wait',hostPhase,waitLeft);
        const sec=Math.max(0,Math.ceil(waitLeft/1000));setText('spx-status','쿠팡 차단 지속 · 재복구 대기');setText('spx-auto-text',`차단 해제 대기 · ${sec}초 후에도 차단이면 [IP↻] 전체 복구단계를 같은 순서로 다시 실행${locationLabel}`);setProgress(0,`차단 지속 · ${sec}초 후 IP↻ 전체 재실행${locationLabel}`);renderFooterActivityV125R1();if(ipButton)ipButton.disabled=true;return waitLeft>0;
      }
      if(status==='failed'){
        setRecoveryActionLockV111(false);
        recoveryUiOwner=false;manualIpChangePending=false;recoveryCountdownStartedAt=0;ensureUi();setDisplay('spx-auto','flex');setSidebarCollecting(false);
        const lastError=String(network.lastError||network.phaseLabel||'공인 IP 변경을 확인하지 못했습니다.').trim();
        setText('spx-status','IP 변경 실패');setText('spx-auto-text',`${lastError}${locationLabel}`);
        setProgress(100,`IP 변경 실패 · ${lastError}${locationLabel}`);
        const inline=document.getElementById('spx-recovery-inline-countdown');if(inline)inline.textContent='IP 변경 실패';
        if(ipButton)ipButton.disabled=false;return false;
      }
      if(status==='completed'){
        setRecoveryActionLockV111(false);
        recoveryUiOwner=false;manualIpChangePending=false;recoveryCountdownStartedAt=0;ensureUi();setDisplay('spx-auto','flex');clearRecoveryStepperV114();
        const before=String(network.initialPublicIp||'이전 IP'),after=String(network.publicIp||'새 IP');
        /* v4.0.27: 쿠팡 차단 페이지를 그냥 열었을 뿐인 idle 상태는 실제 수집이 아닙니다.
           wasRunning+runId가 모두 있는 체크포인트만 재수집으로 표시/재개합니다. */
        const willResume=checkpoint?.wasRunning===true&&Boolean(String(checkpoint?.runId||''));
        setSidebarCollecting(willResume);
        setText('spx-status',willResume?'재수집':'수집 준비');
        setText('spx-auto-text',willResume?`IP 변경 확인 · ${before} → ${after}${locationLabel} · F5 정상 확인 완료 · 작업 재개`:`IP 변경 확인 · ${before} → ${after} · F5 정상 확인 완료 · 수집 준비`);
        setProgress(100,willResume?`차단 해제 확인 · 현재 페이지 작업 재개${locationLabel}`:`차단 해제 확인 · 수집 준비${locationLabel}`);
        const inline=document.getElementById('spx-recovery-inline-countdown');if(inline)inline.textContent=willResume?'IP 변경 완료 · 재수집':'IP 변경 완료 · 수집 준비';
        if(ipButton)ipButton.disabled=false;return false;
      }
      const startupGrace=manualIpChangePending&&recoveryCountdownStartedAt>0&&Date.now()-recoveryCountdownStartedAt<60000;
      if(status==='cancelled'){
        setRecoveryActionLockV111(false);
        /* v1.0.5: 새 수동 요청 직후 이전 reset 정리에서 잠깐 cancelled가 보일 수 있습니다.
           60초 startup grace 동안은 모니터를 종료하지 않고 다음 request-accepted/airplane-cycle 상태를 기다립니다. */
        if(startupGrace){recoveryUiOwner=true;if(ipButton)ipButton.disabled=true;return true;}
        recoveryUiOwner=false;manualIpChangePending=false;setSidebarCollecting(false);
        setText('spx-status','수집 대기');setText('spx-auto-text','수집 준비');
        setDisplay('spx-prog','none');
        if(ipButton)ipButton.disabled=false;return false;
      }
      const active=['resetting','finalizing'].includes(status)||remaining>0;
      if(ipButton)ipButton.disabled=active||startupGrace;
      if(!active){
        if(startupGrace){recoveryUiOwner=true;setRecoveryActionLockV111(true);return true;}
        setRecoveryActionLockV111(false);
        recoveryUiOwner=false;manualIpChangePending=false;if(ipButton)ipButton.disabled=false;return false;
      }
      setRecoveryActionLockV111(true);
      recoveryUiOwner=true;ensureUi();setDisplay('spx-auto','flex');setSidebarCollecting(true);renderFooterActivityV125R1();
      renderRecoveryStepperV102(network,status,phase,hostPhase,remaining);
      let headline='쿠팡 차단 감지',detail=`현재 쿠팡 탭·수집 작업 유지${locationLabel}`,timeLabel='';
      if(status==='resetting'){
        const holdLeft=Math.max(0,Number(network.holdUntil||0)-Date.now());
        if(phase==='block-detected'){
          headline='차단 감지';detail=`[IP↻] 동일 경로 1회 복구 시작${locationLabel}`;
        }else if(phase==='stopped'){
          headline='바로 중단';detail=`현재 수집 즉시 중단 완료${locationLabel}`;
        }else if(phase==='request-accepted'){
          headline='차단 감지';detail=`복구 요청 접수${locationLabel}`;
        }else if(phase==='memory-cleanup'){
          headline='♻ 1회';detail=`임시 리소스 정리 중${locationLabel}`;
        }else if(phase==='site-cleanup'){
          headline='🧹 1회';detail=`쿠팡 사이트 데이터 정리 중${locationLabel}`;
        }else if(phase==='airplane-prepare'||phase==='host-starting'){
          headline='✈ ON 준비';detail=`비행기 모드 ON 준비${locationLabel}`;
        }else if(phase==='airplane-cycle'&&holdLeft>0){
          headline=`✈ ON ${Math.max(4,Math.min(300,Number(network?.airplaneHoldSeconds)||20))}초`;timeLabel=formatRecoveryCountdown(holdLeft);detail=`${timeLabel} 남음${locationLabel}`;
        }else if(['reconnecting','windows-network-restoring'].includes(phase)){
          headline='OFF';detail=`비행기 모드 OFF · 네트워크 복구 확인 중${locationLabel}`;
        }else if(phase==='public-ip-check'){
          if(hostPhase==='public-ip-unchanged'&&attempt<maxAttempts){
            headline='IP 동일 · 재시도';detail=`공인 IP가 그대로여서 동일한 ${Math.max(4,Math.min(300,Number(network?.airplaneHoldSeconds)||20))}초 비행기모드 사이클을 다시 실행합니다 · ${attempt}/${maxAttempts}${locationLabel}`;
          }else{headline='새 IP 확인';detail=`선택망 공인 IP 확인 중${locationLabel}`;}
        }else if(phase==='ip-confirmed'){
          headline='새 IP 확인';detail=`${String(network.publicIp||'새 IP')} 확인 완료${locationLabel}`;

        }else{ 
          headline='비행기 모드 ON 준비';detail=`${String(network.phaseLabel||'비행기 모드 ON 명령 준비 중')}${locationLabel}`;
        }
      }else if(status==='finalizing'){
        if(phase==='page-refresh'){
          headline='페이지 새로고침 F5';detail=`현재 쿠팡 페이지를 그대로 새로고침 중${locationLabel}`;
        }else if(phase==='normal-check'){
          headline=network?.normalConfirmed===true?'정상 확인':'차단 확인';detail=network?.normalConfirmed===true?`차단 해제 확인 · 작업 재개${locationLabel}`:`차단 지속 여부 확인 중${locationLabel}`;
        }else{
          headline='복구 마무리';detail=`다음 단계 진행 중${locationLabel}`;
        }
      }
      setText('spx-status',headline);setText('spx-auto-text',detail);setProgress(0,`${headline} · ${detail}`,timeLabel||undefined);
      const inline=document.getElementById('spx-recovery-inline-countdown');if(inline)inline.textContent=timeLabel?`${headline} ${timeLabel}`:headline;
      return true;
    }finally{recoveryCountdownBusy=false;}
  }
  function renderRecoveryLocalClockV1518(){
    const data=recoveryCountdownSnapshot&&typeof recoveryCountdownSnapshot==='object'?recoveryCountdownSnapshot:{};
    const network=data.networkRecovery&&typeof data.networkRecovery==='object'?data.networkRecovery:{};
    const status=String(network.status||''),phase=String(network.phase||''),holdUntil=Number(network.holdUntil||0);
    if(status!=='resetting'||phase!=='airplane-cycle'||holdUntil<=0){recoveryCountdownLastSecondV1518=null;return;}
    const holdLeft=Math.max(0,holdUntil-Date.now()),sec=Math.max(0,Math.ceil(holdLeft/1000));
    if(recoveryCountdownLastSecondV1518===sec)return;
    recoveryCountdownLastSecondV1518=sec;
    const checkpoint=network.checkpoint&&typeof network.checkpoint==='object'?network.checkpoint:{};
    const keyword=String(checkpoint.keyword||currentKeyword()||'').trim(),page=Math.max(1,Number(checkpoint.page)||1);
    const locationLabel=keyword?` · ${keyword} ${page}페이지 보존`:'';
    const timeLabel=`${sec}초`;
    recoveryUiOwner=true;ensureUi();setDisplay('spx-auto','flex');setSidebarCollecting(true);setRecoveryActionLockV111(true);
    renderRecoveryStepperV102(network,status,phase,String(network.hostPhase||''),holdLeft);
    setText('spx-status',`✈ ON ${Math.max(4,Math.min(300,Number(network?.airplaneHoldSeconds)||20))}초`);
    setText('spx-auto-text',`${timeLabel} 남음${locationLabel}`);
    setProgress(0,`✈ ON ${Math.max(4,Math.min(300,Number(network?.airplaneHoldSeconds)||20))}초 · ${timeLabel} 남음${locationLabel}`,timeLabel);
    const inline=document.getElementById('spx-recovery-inline-countdown');if(inline)inline.textContent=`✈ ON ${Math.max(4,Math.min(300,Number(network?.airplaneHoldSeconds)||20))}초 ${timeLabel}`;
  }
  function stopRecoveryCountdownMonitorV1518(){
    if(recoveryCountdownTimer){clearInterval(recoveryCountdownTimer);recoveryCountdownTimer=null;}
    if(recoveryCountdownPollTimer){clearInterval(recoveryCountdownPollTimer);recoveryCountdownPollTimer=null;}
    recoveryCountdownStartedAt=0;recoveryCountdownSnapshot=null;recoveryCountdownLastSecondV1518=null;
  }
  function startRecoveryCountdownMonitor(){
    recoveryUiOwner=true;
    if(!recoveryCountdownStartedAt)recoveryCountdownStartedAt=Date.now();
    if(recoveryCountdownTimer||recoveryCountdownPollTimer)return;
    const poll=async()=>{
      const active=await renderRecoveryCountdownOnce({autoStart:false}).catch(()=>false);
      if(!active)stopRecoveryCountdownMonitorV1518();
    };
    poll();
    /* SPX_RECOVERY_LOCAL_CLOCK_V1518: Helper 상태 조회와 화면 초시계를 분리합니다.
       Native/SW 조회가 몇 초 늦어져도 cached holdUntil 기준 20→19→...→1초가 로컬에서 계속 갱신됩니다. */
    recoveryCountdownPollTimer=setInterval(poll,800);
    recoveryCountdownTimer=setInterval(renderRecoveryLocalClockV1518,250);
    renderRecoveryLocalClockV1518();
  }
  async function changePublicIpFromSidebar(){
    const button=getUiElement('spx-change-ip',{repair:false});
    if(button?.disabled)return;
    if(button)button.disabled=true;
    manualIpChangePending=true;
    ensureUi();setDisplay('spx-auto','flex');setSidebarCollecting(true);
    setText('spx-status','IP 변경 준비');
    setText('spx-auto-text','현재 쿠팡 탭과 수집 작업을 유지하고 비행기 모드·모바일 데이터 재연결과 새 공인 IP 확인을 시작합니다.');
    setProgress(0,'사용자 IP 변경 요청 · 현재 쿠팡 탭 유지 · 네트워크 복구 준비');
    startRecoveryCountdownMonitor();
    try{
      const response=await requestManualIpChange({
        source:'sidebar_button',
        keyword:currentKeyword(),
        page:Math.max(1,Number(new URL(location.href).searchParams.get('page'))||1),
        url:location.href,
      });
      if(!response?.ok)throw new Error(response?.error||'IP 변경을 시작하지 못했습니다.');
      /* runtime 응답 전 첫 poll이 idle/cancelled를 읽었더라도 실제 persisted 상태를 즉시 다시 그립니다. */
      startRecoveryCountdownMonitor();
      await renderRecoveryCountdownOnce({autoStart:false}).catch(()=>false);
      return response;
    }catch(error){
      manualIpChangePending=false;
      if(button?.isConnected)button.disabled=false;
      setSidebarCollecting(false);
      setText('spx-status','IP 변경 시작 실패');
      setText('spx-auto-text',error?.message||String(error));
      setProgress(0,`IP 변경 시작 실패 · ${error?.message||String(error)}`);
      throw error;
    }
  }



  function formatTabElapsed(ms){const total=Math.max(0,Math.floor((Number(ms)||0)/1000)),h=Math.floor(total/3600),m=Math.floor((total%3600)/60),sec=total%60;return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;}
  function currentTabElapsedMs(){const base=Math.max(0,Number(tabSessionStats.automationElapsedMs)||0);return tabSessionStats.automationRunning&&tabSessionStats.automationStartedAt?base+Math.max(0,Date.now()-Number(tabSessionStats.automationStartedAt)):base;}
  function footerRunCountsV129(){
    const s=tabSessionStats||{},shared=historyCumulativeCountsV1628||{};
    const num=(value,fallback=0)=>Number.isFinite(Number(value))?Math.max(0,Number(value)):Math.max(0,Number(fallback)||0);
    /* v1.3.1: 하단 진행상황은 run/키워드가 바뀌어도 0으로 되돌리지 않습니다.
       사용자가 최근수집내역 [초기화] 또는 최하단 [↻]을 누른 시점 이후의 누적값만 표시합니다. */
    return {
      processed:historyCumulativeCountsV1628?num(shared.completed,0)+num(shared.failed,0)+num(shared.below_criteria,0)+num(shared.excluded,0)+num(shared.skipped,0):num(s.processed,0),saved:0,requeued:0,excluded:historyCumulativeCountsV1628?num(shared.excluded,0):num(s.excluded,0),failed:historyCumulativeCountsV1628?num(shared.failed,0):num(s.failed,0),belowCriteria:historyCumulativeCountsV1628?num(shared.below_criteria,0):num(s.belowCriteria,0),skipped:historyCumulativeCountsV1628?num(shared.skipped,0):0,
      // Transport counters always come from the same authoritative local DB snapshot as the history window.
      // Tab-session uploadPending is a different scope and must NEVER be presented as cumulative local pending.
      pending:historyCumulativeCountsV1628?num(shared.pending):num(s.uploadPending,0),held:0,
      uploaded:historyCumulativeCountsV1628?num(shared.uploaded):(s.uploadedDb!=null&&Number.isFinite(Number(s.uploadedDb))?num(s.uploadedDb):num(s.uploaded,0)+num(s.uploadHeld,0)),
      globalPending:historyCumulativeCountsV1628?num(shared.pending):(s.uploadPendingDb!=null&&Number.isFinite(Number(s.uploadPendingDb))?num(s.uploadPendingDb):num(s.uploadPending,0)),
    };
  }
  function renderFooterActivityV125R1(){
    const button=getUiElement('spx-upload',{repair:false});if(!button)return;
    const s=tabSessionStats||{},c=historyCumulativeCountsV1628;
    const authoritative=Boolean(c&&Number.isFinite(Number(c.uploaded))&&Number.isFinite(Number(c.pending)));
    const pending=authoritative?Math.max(0,Number(c.pending)):null,uploaded=authoritative?Math.max(0,Number(c.uploaded)):null;
    // v1.6.41: bottom action and independent history window MUST display identical transport scope.
    // Do not fall back to tab-session counts (e.g. 9/48) while waiting for IndexedDB (e.g. 252/41).
    button.title=authoritative?'이 PC의 확장프로그램 로컬 DB 기준 누적 업로드/대기 · 최근 수집내역 독립 창과 같은 집계 · 서버 실시간 검증값 아님':'로컬 DB 누적 집계를 확인하는 중입니다. 수집/업로드 작업은 변경하지 않습니다.';
    if(recoveryUiOwner){button.disabled=true;button.textContent=authoritative?`쿠팡 차단 복구 중 · 업로드 ${fmt(uploaded)} · 로컬 대기 ${fmt(pending)}`:'쿠팡 차단 복구 중 · 집계 확인 중';return;}
    if(s.automationRunning===true){button.disabled=true;button.textContent=authoritative?`수집 중 · 업로드 ${fmt(uploaded)} · 로컬 대기 ${fmt(pending)}`:'수집 중 · 로컬 집계 확인 중';return;}
    if(!state.agg){if(!authoritative){button.disabled=true;button.textContent='로컬 집계 확인 중';}else if(pending>0){button.disabled=true;button.textContent=`로컬 대기 ${fmt(pending)}건`;}else if(uploaded>0){button.disabled=true;button.textContent=`업로드 ${fmt(uploaded)}건`;}else{button.disabled=true;button.textContent='먼저 분석하세요';}}
  }
  function renderTabSessionStats(){
    const s=tabSessionStats||{},run=footerRunCountsV129();
    const info=getUiElement('spx-dbinfo',{repair:false});
    /* v1.3.1: 하단 집계는 최근수집내역과 같은 '이번 실행' 범위를 사용합니다.
       발견 후보(unique discovery)는 위의 발견 목록에서 이미 별도 표시하므로, 하단은 처리 건수로 명확히 구분합니다. */
    const infoText=historyCumulativeCountsV1628?`전체 ${fmt(run.processed)} · 제외 ${fmt(run.excluded)} · 실패 ${fmt(run.failed)} · 미달 ${fmt(run.belowCriteria)} · 로컬 대기 ${fmt(run.globalPending)} · 업로드 ${fmt(run.uploaded)}`:'로컬 DB 누적 집계 확인 중';
    if(info&&info.textContent!==infoText)info.textContent=infoText;
    const pendingButton=getUiElement('spx-pending-upload-now',{repair:false});
    if(pendingButton){const pendingDb=run.globalPending,title=`전체 로컬 서버 업로드 대기 ${fmt(pendingDb)}건 · 현재 탭 누적 대기 ${fmt(run.pending)}건 · 상품 재수집 없이 서버로 전송`,aria=`전체 업로드 대기 ${fmt(pendingDb)}건 서버로 전송`;if(pendingButton.title!==title)pendingButton.title=title;if(pendingButton.getAttribute('aria-label')!==aria)pendingButton.setAttribute('aria-label',aria);if(pendingButton.classList.contains('spx-has-pending')!==(pendingDb>0))pendingButton.classList.toggle('spx-has-pending',pendingDb>0);}
    const historyOpen=getUiElement('spx-stop-summary-open',{repair:false});if(historyOpen&&(run.processed>0||run.globalPending>0)&&historyOpen.hidden)historyOpen.hidden=false;
    const timer=getUiElement('spx-auto-runtime',{repair:false});
    renderFooterActivityV125R1();
    if(timer){
      const manual=s.runtimeDisplayMode==='manual',total=currentTabElapsedMs(),base=Math.max(0,Number(s.runtimeManualBaseMs)||0);
      const modeButton=timer.querySelector('#spx-runtime-mode'),valueButton=timer.querySelector('#spx-runtime-value');
      if(modeButton){const mode=manual?'수동':'자동';if(modeButton.textContent!==mode)modeButton.textContent=mode;modeButton.title=manual?'자동 누적시간으로 돌아가기 (실제 타이머 계속 진행)':'수동 표시시간으로 전환 (실제 타이머 계속 진행)';}
      if(valueButton){const value=formatTabElapsed(manual?Math.max(0,total-base):total);if(valueButton.textContent!==value)valueButton.textContent=value;valueButton.title=manual?'수동 표시시간만 0으로 초기화 · 원래 자동 누적시간은 보존':'자동 탐색 누적시간 · 초기화하려면 최근 수집내역의 초기화 버튼을 사용하세요';}
      timer.title=s.automationRunning?'현재 탭 자동 탐색 실행 중 · 표시 모드 전환은 수집에 영향을 주지 않습니다.':'현재 탭 자동 탐색 누적시간';
    }
  }
  let transferCountsLastRequestV1631=0,transferCountsInFlightV1631=false,transferCountsRecheckV1634=false;
  async function refreshTransferCountsV1631(force=false){
    if(contextInvalidated)return false;
    // A committed DB revision during a running fetch must not disappear: replay once afterwards.
    if(transferCountsInFlightV1631){if(force)transferCountsRecheckV1634=true;return false;}
    if(!force&&Date.now()-transferCountsLastRequestV1631<8000)return false;
    transferCountsLastRequestV1631=Date.now();transferCountsInFlightV1631=true;
    try{
      const response=await runtimeMessage({type:'SPX_HISTORY_COUNTS_V1631'});
      if(response?.ok!==true||!response.data)return false;
      const {uploaded,pending}=response.data;
      if(!Number.isFinite(Number(uploaded))||!Number.isFinite(Number(pending)))return false;
      tabSessionStats.uploadedDb=Math.max(0,Number(uploaded));
      tabSessionStats.uploadPendingDb=Math.max(0,Number(pending));
      historyCumulativeCountsV1628={...response.data,uploaded:tabSessionStats.uploadedDb,pending:tabSessionStats.uploadPendingDb};
      renderTabSessionStats();applyHistoryCumulativeCountsV1628();return true;
    }catch(error){console.debug('[SPX] 로컬 집계 갱신 보류',error?.message||error);return false;}
    finally{
      transferCountsInFlightV1631=false;
      if(transferCountsRecheckV1634&&!contextInvalidated){
        transferCountsRecheckV1634=false;
        setTimeout(()=>{if(!contextInvalidated)void refreshTransferCountsV1631(true);},280);
      }
    }
  }
  setInterval(()=>{if(!contextInvalidated&&getUiElement('spx-overlay',{repair:false}))void refreshTransferCountsV1631();},10000);
  /* IndexedDB has no native cross-extension-view change event; a small revision
     token is raised after a committed local write. Both windows requery the same DB. */
  let transferCountsEventTimerV1634=0;
  try{globalThis.chrome?.storage?.onChanged?.addListener((changes,area)=>{
    if(area!=='local'||!changes?.spxLocalCollectionRevisionV1633)return;
    clearTimeout(transferCountsEventTimerV1634);
    transferCountsEventTimerV1634=setTimeout(()=>{if(!contextInvalidated)void refreshTransferCountsV1631(true);},320);
  });}catch(_){}

  async function refreshTabSessionStats(){
    try{const response=await runtimeMessage({type:'SPX_TAB_SESSION_STATS_GET'});if(response?.ok&&response.data){tabSessionStats={...tabSessionStats,...response.data};renderTabSessionStats();ensureTabSessionTicker();}return tabSessionStats;}catch(_){renderTabSessionStats();ensureTabSessionTicker();return tabSessionStats;}
  }
  async function recordTabSessionEvent(kind,delta={},options={}){
    const eventId=String(options.eventId||`${kind}:${state.lockedKeyword||state.keyword||currentKeyword()||'-'}:${Date.now()}`);
    try{const response=await runtimeMessage({type:'SPX_TAB_SESSION_STATS_EVENT',eventId,delta,discoveredKeywords:Array.isArray(options.discoveredKeywords)?options.discoveredKeywords:[]});if(response?.ok&&response.data){tabSessionStats={...tabSessionStats,...response.data};renderTabSessionStats();}return response;}catch(_){return null;}
  }
  async function resetTabSessionCounters(){
    try{
      /* v1.3.1 사용자 확정 계약: 최하단 ↻도 최근수집내역 [초기화]와 같은 경계를 사용합니다.
         초기화 이전 표시기록/누적카운트는 다시 불러오지 않고 이후 수집분만 새로 누적합니다.
         실제 raw/aggregate/outbox/payload는 안전을 위해 삭제하지 않습니다. */
      const response=await runtimeMessage({type:'SPX_CLEAR_RECENT_COLLECTION_HISTORY_V101510'});
      if(response?.ok&&response.data){
        tabSessionStats={...tabSessionStats,...response.data};
        persistentHistoryResetAtV101510=Math.max(persistentHistoryResetAtV101510,Number(response?.data?.historyResetAt)||Date.now());
        currentAutomationSummary=null;
        closeAutomationStopSummary();
        const historyOpen=getUiElement('spx-stop-summary-open',{repair:false});if(historyOpen)historyOpen.hidden=true;
        const historyList=getUiElement('spx-stop-history-list',{repair:false});if(historyList)historyList.replaceChildren();
        setText('spx-stop-count-success','0');setText('spx-stop-count-requeued','0');setText('spx-stop-count-below-criteria','0');setText('spx-stop-count-excluded','0');setText('spx-stop-count-skipped','0');setText('spx-stop-count-failed','0');
        setText('spx-history-uploaded-count','0');setText('spx-history-pending-count','0');
        renderTabSessionStats();
        setText('spx-status','수집내역 초기화 완료');
      }
      return response;
    }catch(_){return null;}
  }
  async function setTabAutomationTimer(action){
    try{const response=await runtimeMessage({type:'SPX_TAB_AUTOMATION_TIMER',action});if(response?.ok&&response.data){tabSessionStats={...tabSessionStats,...response.data};renderTabSessionStats();ensureTabSessionTicker();}return response;}catch(_){return null;}
  }
  function ensureTabSessionTicker(){
    if(contextInvalidated||tabSessionStats.automationRunning!==true){if(tabSessionTicker){clearInterval(tabSessionTicker);tabSessionTicker=null;}return;}
    if(tabSessionTicker)return;
    tabSessionTicker=setInterval(()=>{if(contextInvalidated||tabSessionStats.automationRunning!==true){clearInterval(tabSessionTicker);tabSessionTicker=null;return;}renderTabSessionStats();},1000);
  }

  async function safeGetSettings() {
    try {
      const base = await getSettings();
      const merged = activeCollectionSettingsOverride ? { ...base, ...activeCollectionSettingsOverride } : base;
      SPX.parserSettings = merged;
      return merged;
    }
    catch (error) {
      if (error?.spxContextInvalidated || SPX.util.isContextInvalidatedError?.(error) || !SPX.util.runtimeAlive?.()) {
        shutdownInvalidatedContext();
        throw contextEndError();
      }
      throw error;
    }
  }

  function hasCompleteUi() {
    return REQUIRED_UI_IDS.every((id) => Boolean($(id)));
  }

  let overlayTooltipTarget = null;
  function hideOverlayTooltip() {
    const tooltip = $('spx-tooltip');
    overlayTooltipTarget = null;
    if (!tooltip) return;
    tooltip.hidden = true;
    tooltip.classList.remove('visible');
    tooltip.style.visibility = '';
  }

  function positionOverlayTooltip(target = overlayTooltipTarget) {
    const tooltip = $('spx-tooltip');
    if (!tooltip || !target || tooltip.hidden || !document.contains(target)) return;
    const margin = 10;
    tooltip.style.left = `${margin}px`;
    tooltip.style.top = `${margin}px`;
    tooltip.style.visibility = 'hidden';
    const targetRect = target.getBoundingClientRect();
    const tipRect = tooltip.getBoundingClientRect();
    let placement = 'left';
    let left = targetRect.left - tipRect.width - 12;
    if (left < margin) {
      left = Math.min(window.innerWidth - tipRect.width - margin, targetRect.right + 12);
      placement = 'right';
    }
    let top = targetRect.top + targetRect.height / 2 - tipRect.height / 2;
    top = Math.max(margin, Math.min(window.innerHeight - tipRect.height - margin, top));
    tooltip.dataset.placement = placement;
    tooltip.style.left = `${Math.round(left)}px`;
    tooltip.style.top = `${Math.round(top)}px`;
    tooltip.style.visibility = 'visible';
  }

  function showOverlayTooltip(target) {
    const tooltip = $('spx-tooltip');
    const text = target?.dataset?.spxTip;
    if (!tooltip || !text) return;
    overlayTooltipTarget = target;
    tooltip.textContent = text;
    tooltip.hidden = false;
    tooltip.classList.add('visible');
    requestAnimationFrame(() => positionOverlayTooltip(target));
  }

  function overlayTooltipSuppressed(node) {
    /* 일반 키워드·체크박스 말풍선은 계속 막되, 전용망 상태 아이콘만 예외로 허용합니다.
       이 아이콘은 선택 어댑터와 실제 외부 공인 IP를 확인하는 안전 표시이므로 반드시 보여야 합니다. */
    if(node?.closest?.('.spx-network-check, .spx-keyword-toggle'))return false;
    return !!node?.matches?.('input[type="checkbox"],input[type="radio"],.spx-discovered-word,.spx-discovered-copy,[data-keyword]') ||
      !!node?.closest?.('label:has(input[type="checkbox"]),label:has(input[type="radio"]),.spx-discovered-keyword');
  }
  function promoteOverlayTitles(root) {
    const nodes = [];
    if (root?.nodeType === 1 && (root.hasAttribute?.('title') || root.hasAttribute?.('data-tip'))) nodes.push(root);
    root?.querySelectorAll?.('[title],[data-tip]').forEach((node) => nodes.push(node));
    for (const node of nodes) {
      if (overlayTooltipSuppressed(node)) { node.removeAttribute('title'); node.removeAttribute('data-tip'); node.removeAttribute('data-spx-tip'); delete node.dataset.spxTip; continue; }
      const text = node.getAttribute('title') || node.getAttribute('data-tip');
      if (text) node.dataset.spxTip = text;
      node.removeAttribute('title');
      node.removeAttribute('data-tip');
    }
  }

  function bindOverlayTooltips(root) {
    if (!root || root.dataset.spxTooltipBound === '1') return;
    root.dataset.spxTooltipBound = '1';
    promoteOverlayTitles(root);
    root.addEventListener('pointerover', (event) => {
      if (overlayTooltipSuppressed(event.target)) return;
      const target = event.target.closest?.('[data-spx-tip]');
      if (target && root.contains(target) && !overlayTooltipSuppressed(target)) showOverlayTooltip(target);
    });
    root.addEventListener('pointerout', (event) => {
      const target = event.target.closest?.('[data-spx-tip]');
      if (target && !target.contains(event.relatedTarget)) hideOverlayTooltip();
    });
    root.addEventListener('focusin', (event) => {
      if (overlayTooltipSuppressed(event.target)) return;
      const target = event.target.closest?.('[data-spx-tip]');
      if (target && root.contains(target) && !overlayTooltipSuppressed(target)) showOverlayTooltip(target);
    });
    root.addEventListener('focusout', hideOverlayTooltip);
    root.addEventListener('scroll', hideOverlayTooltip, true);
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        if (record.type === 'attributes') promoteOverlayTitles(record.target);
        else for (const node of record.addedNodes) if (node.nodeType === 1) promoteOverlayTitles(node);
      }
    });
    observer.observe(root, { subtree:true, childList:true, attributes:true, attributeFilter:['title'] });
  }

  function removeStaleUi() {
    $('spx-overlay')?.remove();
    $('spx-tab')?.remove();
  }

  function isCoupangSearchLandingV103(){
    try{
      return /(^|\.)coupang\.com$/i.test(location.hostname)
        && (location.pathname==='/search'||location.pathname==='/np/search');
    }catch(_){return false;}
  }
  function sidebarContextAvailableV103(){
    return Boolean(currentKeyword()||state.lockedKeyword||state.keyword||pendingNavigation?.transition?.keyword||pendingNavigation?.keyword||FORCE_SIDEBAR_MODE||isCoupangSearchLandingV103());
  }
  function uiKeywordContext(){
    const keyword=String(currentKeyword()||state.lockedKeyword||state.keyword||pendingNavigation?.transition?.keyword||pendingNavigation?.keyword||'').trim();
    if(keyword)return keyword;
    if(FORCE_SIDEBAR_MODE)return '사이드바 실행 대기';
    return isCoupangSearchLandingV103()?'쿠팡 검색 대기':'';
  }

  let lastShownStopSummaryId = '';
  let currentAutomationSummary = null;
  let pendingUploadSelectionKeysV10154=new Set();
  let pendingUploadListRowsV10154=[];
  let pendingSelectedUploadBusyV10154=false;
  let recentHistorySearchTermV117='';
  let recentHistoryUploadFilterV125R1='all';
  let recentHistoryStatusFilterV126='all';
  let pendingUploadResultTextV117='';
  let historyUploadStatusRefreshAtV10154=0;
  /* v1.6.28: 누적 집계는 로컬 IndexedDB의 실제 uploaded / pending 인덱스 수를
     사용합니다. 이번 실행 runHistory 건수와 혼합하지 않고 기존 대기목록 조회 응답을 재사용합니다.
     서버 요청 또는 전체 aggregate JSON 로드는 추가하지 않습니다. */
  let historyCumulativeCountsV1628=null;
  function applyHistoryCumulativeCountsV1628(){
    const counts=historyCumulativeCountsV1628;if(!counts)return false;
    const uploaded=Math.max(0,Number(counts.uploaded)||0),pending=Math.max(0,Number(counts.pending)||0);
    setText('spx-stop-count-success',fmt(uploaded+pending));
    setText('spx-history-uploaded-count',fmt(uploaded));
    setText('spx-history-pending-count',fmt(pending));
    return true;
  }
  let recentHistoryPendingRefreshAtV124=0;
  let recentHistoryExportBusyV138=false;
  const STOP_SUMMARY_SHOWN_SESSION_KEY = 'spxStopSummaryShownId';
  function stopSummaryIdentity(summary = {}) {
    if (summary?.id) return String(summary.id);
    return [summary?.runId||'run',summary?.stoppedAt||0,summary?.reason||'',summary?.processedCount||0,summary?.savedCount||0,summary?.requeuedCount||0,summary?.excludedCount||0,summary?.failedCount||0].join('|');
  }
  const STOP_SUMMARY_SHOWN_STORAGE_KEY = 'spxStopSummaryShownIdV293';
  const STOP_SUMMARY_RESTORE_MAX_AGE_MS = 15 * 60 * 1000;
  function readShownStopSummaryId() {
    try { return String(sessionStorage.getItem(STOP_SUMMARY_SHOWN_SESSION_KEY) || ''); }
    catch (_) { return ''; }
  }
  function rememberShownStopSummaryId(id) {
    lastShownStopSummaryId = String(id || '');
    try {
      if (lastShownStopSummaryId) sessionStorage.setItem(STOP_SUMMARY_SHOWN_SESSION_KEY, lastShownStopSummaryId);
    } catch (_) {}
    // 한 번 확인한 중단 이력은 Chrome을 다시 실행해도 다시 자동으로 열리지 않도록 기록합니다.
    try {
      if (lastShownStopSummaryId) chrome.storage.local.set({ [STOP_SUMMARY_SHOWN_STORAGE_KEY]: lastShownStopSummaryId }).catch(() => {});
    } catch (_) {}
  }
  function formatStopDuration(ms) {
    const totalSec = Math.max(0, Math.round(Number(ms || 0) / 1000));
    const hours = Math.floor(totalSec / 3600);
    const minutes = Math.floor((totalSec % 3600) / 60);
    const seconds = totalSec % 60;
    return [hours ? `${hours}시간` : '', minutes ? `${minutes}분` : '', `${seconds}초`].filter(Boolean).join(' ');
  }
  function stopStatusLabel(status) {
    return ({
      saved:'수집완료',
      requeued:'자료부족',
      below_criteria:'기준미달',
      excluded:'제외',
      failed:'실패·기술오류',
      skipped:'건너뜀',
      server_skipped:'건너뜀',
      deferred:'후순위',
    })[String(status || '')] || '처리';
  }
  function collectionHistoryResetAt(){return Math.max(persistentHistoryResetAtV101510,Math.max(0,Number(tabSessionStats?.historyResetAt)||0));}
  function visibleCollectionHistory(history=[]){
    const resetAt=collectionHistoryResetAt();
    const rows=Array.isArray(history)?history:[];
    if(!resetAt)return rows;
    return rows.filter((item)=>Math.max(0,Number(item?.at)||0)>resetAt);
  }
  /* v1.2.4 — 수집 중 최근수집내역 실시간 표시.
     spxAutomation.runHistory는 키워드 완료 시점마다 Local storage에 즉시 누적되지만,
     이전 버전에는 이를 최근수집내역 summary로 바꾸는 함수가 누락되어 최종 정지/완료 후에만
     lastRunSummary가 보이는 회귀가 있었습니다. 서버 조회 없이 현재 Local automation state만 사용합니다. */
  function liveAutomationSummaryFromState(state={}){
    if(!state||typeof state!=='object'||state.running!==true)return null;
    const history=Array.isArray(state.runHistory)?state.runHistory.slice():[];
    const count=(status)=>history.filter((row)=>String(row?.status||'')===status).length;
    const startedAt=Math.max(0,Number(state.startedAt)||0);
    const now=Date.now();
    const currentKeyword=String(state.currentKeyword||'').trim();
    const summary={
      id:`live:${String(state.runId||'run')}`,
      runId:String(state.runId||''),
      runLabel:String(state.runLabel||(state.mode==='full'?'연속 탐색':'수집')),
      mode:String(state.mode||'guided'),
      workScope:String(state.workScope||'discovery'),
      collectionProfile:String(state.collectionProfile||'lite'),
      live:true,
      reason:'수집 진행 중',
      startedAt:startedAt||null,
      stoppedAt:now,
      durationMs:startedAt?Math.max(0,now-startedAt):0,
      processedCount:Math.max(history.length,Math.max(0,Number(state.processed)||0)),
      savedCount:Math.max(count('saved'),Math.max(0,Number(state.savedCount)||0)),
      requeuedCount:Math.max(count('requeued'),Math.max(0,Number(state.requeuedCount)||0)),
      belowCriteriaCount:count('below_criteria'),
      excludedCount:Math.max(count('excluded'),Math.max(0,Number(state.excludedCount)||0)),
      failedCount:Math.max(count('failed'),Math.max(0,Number(state.failedCount)||0)),
      skippedCount:count('skipped')+count('server_skipped'),
      deferredCount:count('deferred'),
      collectedProductCount:Math.max(0,Number(state.collectedProductCount)||0),
      currentKeyword:currentKeyword||null,
      interruptedKeyword:null,
      history,
      explicitSelectionOnly:state.explicitSelectionOnly===true,
      directSequentialList:state.directSequentialList===true,
      autoPopup:false,
      _historyVisibleActivity:history.length>0,
    };
    return normalizeAutomationSummaryForHistoryReset(summary);
  }

  function normalizeAutomationSummaryForHistoryReset(summary={}){
    if(!summary||typeof summary!=='object')return summary;
    const resetAt=collectionHistoryResetAt();
    if(!resetAt)return summary;
    const history=visibleCollectionHistory(summary.history);
    const stoppedAt=Math.max(0,Number(summary.stoppedAt)||0);
    const interruptedKeyword=stoppedAt>resetAt?String(summary.interruptedKeyword||'').trim():'';
    const count=(status)=>history.filter((row)=>String(row?.status||'')===status).length;
    const skippedCount=count('skipped')+count('server_skipped');
    const collectedProductCount=history.reduce((sum,row)=>sum+Math.max(0,Number(row?.productCount)||0),0);
    return {...summary,
      history,
      interruptedKeyword:interruptedKeyword||null,
      processedCount:history.length,
      savedCount:count('saved'),requeuedCount:count('requeued'),belowCriteriaCount:count('below_criteria'),excludedCount:count('excluded'),failedCount:count('failed'),
      skippedCount,deferredCount:count('deferred'),collectedProductCount,
      startedAt:Math.max(Number(summary.startedAt)||0,resetAt),
      durationMs:Math.max(0,(stoppedAt||Date.now())-Math.max(Number(summary.startedAt)||0,resetAt)),
      _historyVisibleActivity:history.length>0||Boolean(interruptedKeyword)
    };
  }
  async function restoreCollectedSidebarHistoryItem(item={}) {
    const keyword=String(item?.keyword||'').trim();if(!keyword)return false;
    const localOnly=item?.localOnly===true,runKey=String(item?.runKey||'').trim(),aggregateKey=String(item?.aggregateKey||'').trim();
    /* v4.1.22: 현재 수집을 멈추지 않고 이미 저장된 과거 키워드 1건만 읽어 사이드바 폼에 미리보기합니다. 수집 task/state는 건드리지 않습니다. */
    setText('spx-status',`${keyword} 저장된 수집내역 불러오는 중...`);
    try{
      const response=await SPX.util.sendMessage({type:'SPX_SIDEBAR_COLLECTION_RESTORE',keyword,marketplace:'coupang',localOnly,runKey,aggregateKey});
      if(!response?.ok||!response?.data)throw new Error(response?.error||'저장된 수집내역을 찾지 못했습니다.');
      const aggregate=response.data;
      renderAgg(aggregate,[]);
      if(tabSessionStats.automationRunning!==true)state.agg=aggregate;
      ;
      closeAutomationStopSummary();
      setText('spx-status',`수집 내역 · ${aggregate.keyword||keyword}`);
      setText('spx-auto-text',`${aggregate.keyword||keyword} · ${response.source==='server'?'서버 DB':'로컬 DB'}에 저장된 마지막 수집 내용을 다시 표시했습니다.`);
      return true;
    }catch(error){setText('spx-status',`${keyword} 수집내역 불러오기 실패 · ${String(error?.message||error)}`);return false;}
  }
  function isHistoryTransportBearingV165(status=''){return String(status||'')==='saved';}
  function inferHistoryUploadStateV136(item={}) {
    if(!isHistoryTransportBearingV165(item?.status))return '';
    const reason=String(item?.reason||'').replace(/\s+/g,' ').trim();
    if(/서버\s*업로드\s*완료[\s·-]*보완\s*대기|서버\s*업로드\s*완료/.test(reason))return 'uploaded';
    if(/서버\s*업로드\s*완료/.test(reason))return 'uploaded';
    if(/업로드\s*대기|서버\s*(?:직행\s*)?업로드.*(?:실패|초과)|서버\s*연결.*(?:실패|지연)/.test(reason))return 'pending';
    return 'local';
  }
  function historyReasonBaseV136(value='') {
    const text=String(value||'').replace(/\s+/g,' ').trim();
    if(!text)return '처리 완료';
    /* 현재 업로드 상태를 뒤에 단 하나만 붙일 수 있도록 과거 전송상태/오류 꼬리를 제거합니다.
       예: '분석 완료 · 업로드 대기 · Error: ...' -> '분석 완료' */
    const stripped=text
      .replace(/\s*·\s*서버\s*업로드\s*완료(?:\s*·\s*보완\s*대기.*)?$/,'')
      .replace(/\s*·\s*업로드\s*대기(?:\s*·.*)?$/,'')
      .trim();
    return stripped||'분석 완료';
  }
  function historyReasonForStateV136(baseText='',stateValue='local',local=null) {
    const original=String(baseText||'').replace(/\s+/g,' ').trim();
    const base=historyReasonBaseV136(original);
    const supplementReason=String(local?.recollect_reason||local?.upload_repair_hold_reason||'').trim();
    if(stateValue==='uploaded')return `${base} · 서버 업로드 완료`;
        if(stateValue==='pending'){
      const errorTail=original.match(/(?:업로드\s*대기\s*·\s*)?(Error:\s*.*|서버\s*(?:직행\s*)?업로드.*(?:실패|초과).*)$/i)?.[1]||'';
      return `${base} · 서버 업로드 대기${errorTail?` · ${errorTail}`:''}`;
    }
    return base;
  }

  function renderStopSummaryHistory(summary) {
    summary=normalizeAutomationSummaryForHistoryReset(summary||{});
    const list = getUiElement('spx-stop-history-list', { repair:false });
    if (!list) return;
    const rows = Array.isArray(summary?.history) ? summary.history : [];
    const provisionalUpload={uploaded:0,pending:0};
    const fragment = document.createDocumentFragment();
    if (summary?.interruptedKeyword) {
      const row = document.createElement('div');
      row.className = 'spx-stop-history-row interrupted';
      row.dataset.historyKeyword=String(summary.interruptedKeyword||'');row.dataset.historyStatus='interrupted';row.dataset.historyIndex='-1';
      const badge = document.createElement('button'); badge.type='button';badge.className = 'spx-stop-history-badge interrupted'; badge.textContent = '중단';badge.title='클릭하여 이 키워드의 저장된 수집 내용을 사이드바에 다시 표시';badge.addEventListener('click',(event)=>{event.preventDefault();event.stopPropagation();void restoreCollectedSidebarHistoryItem({keyword:summary.interruptedKeyword,status:'interrupted'});});
      const keyword = document.createElement('b'); keyword.textContent = summary.interruptedKeyword;
      const reason = document.createElement('small'); reason.textContent = '중단 시 처리 중이던 키워드';
      row.append(badge, keyword, reason); fragment.appendChild(row);
    }
    for (const [historyIndex,item] of rows.entries()) {
      const row = document.createElement('div');
      const itemStatus=String(item?.status||''),itemKeyword=String(item?.keyword||'-');
      row.className = `spx-stop-history-row ${itemStatus}`;row.dataset.historyKeyword=itemKeyword;row.dataset.historyStatus=itemStatus;row.dataset.historyIndex=String(historyIndex);
      const badge = document.createElement('button');badge.type='button';
      badge.className = `spx-stop-history-badge ${itemStatus}`;
      badge.textContent = stopStatusLabel(itemStatus);badge.title='클릭하여 저장된 수집 내용을 사이드바에 다시 표시';
      if(isHistoryTransportBearingV165(itemStatus)){
        badge.dataset.historyUploadBadge='1';
        const provisionalState=inferHistoryUploadStateV136(item);
        row.dataset.historyUploadState=provisionalState;
        if(provisionalState==='uploaded'){badge.textContent='서버 업로드';badge.classList.add('upload-uploaded');provisionalUpload.uploaded++;}
        else if(provisionalState==='pending'){badge.textContent='업로드 대기';badge.classList.add('upload-pending');provisionalUpload.pending++;}
              }
      badge.addEventListener('click',(event)=>{event.preventDefault();event.stopPropagation();void restoreCollectedSidebarHistoryItem(item);});
      const keyword = document.createElement('b'); keyword.textContent = itemKeyword;
      const details = [];
      const collectedAt=formatHistoryDateTimeV117(item?.at,item?.date||item?.collected_at||item?.collected_on||'');
      if(collectedAt)details.push(`수집 ${collectedAt}`);
      if (item?.grade) details.push(String(item.grade));
      else if(String(item?.evaluationOutcome||'')==='below_criteria'||itemStatus==='below_criteria'){
        const indexState=String(item?.belowCriteriaIndexStatus||'');
        const indexLabel=indexState==='saved'?' · 색인 저장':indexState==='queued'?' · 색인 대기':indexState==='failed'?' · 색인 실패':'';
        details.push(`기준미달${Number.isFinite(Number(item?.gradeScore))?` · ${Number(item.gradeScore)}점`:''}${indexLabel}`);
      }
      else if(Number.isFinite(Number(item?.gradeScore))) details.push(`${Number(item.gradeScore)}점`);
      if (Number(item?.productCount) > 0) details.push(`상품 ${Number(item.productCount).toLocaleString('ko-KR')}개`);
      const keywordElapsed=Number(item?.durationMs);
      if(item?.durationMs!=null&&Number.isFinite(keywordElapsed)&&keywordElapsed>=0)details.push(`소요 ${(keywordElapsed/1000).toFixed(1)}초`);
      if (item?.reason) details.push(`${itemStatus==='excluded'?'제외 사유: ':''}${String(item.reason)}`);
      const reason = document.createElement('small'); reason.textContent = details.join(' · ') || '처리 완료';reason.dataset.baseText=reason.textContent;
      if(isHistoryTransportBearingV165(itemStatus))reason.textContent=historyReasonForStateV136(reason.dataset.baseText,String(row.dataset.historyUploadState||'local'),null);
      row.append(badge, keyword, reason); fragment.appendChild(row);
    }
    if (!fragment.childNodes.length) {
      const empty = document.createElement('div');
      empty.className = 'spx-stop-history-empty';
      empty.textContent = '현재 표시 가능한 키워드 상세 이력이 없습니다.';
      fragment.appendChild(empty);
    }
    list.replaceChildren(fragment);
    /* v1.3.7: async authoritative 조회 전에도 runHistory 자체가 명확히 pending/uploaded/held를 말하면
       배지와 상단 카운터를 즉시 같은 상태로 보여줍니다. 이후 Local DB authoritative 조회가 최종 교정합니다. */
    setText('spx-history-uploaded-count',fmt(provisionalUpload.uploaded));
    setText('spx-history-pending-count',fmt(provisionalUpload.pending));
    applyHistoryCumulativeCountsV1628();
        tabSessionStats.runUploaded=provisionalUpload.uploaded;tabSessionStats.runUploadPending=provisionalUpload.pending;tabSessionStats.runUploadHeld=0;renderTabSessionStats();
    applyRecentHistorySearchV117();
    const modal=getUiElement('spx-stop-summary-modal',{repair:false});if(modal&&!modal.hidden)void refreshHistoryUploadStatesV10154(summary);
  }

  function syncFooterRunSummaryV129(summary=currentAutomationSummary){
    const visible=summary&&typeof summary==='object'?normalizeAutomationSummaryForHistoryReset(summary):null;
    if(!visible){return false;}
    tabSessionStats.runProcessed=Math.max(0,Number(visible.processedCount)||0);
    tabSessionStats.runSaved=Math.max(0,Number(visible.savedCount)||0);
    tabSessionStats.runRequeued=Math.max(0,Number(visible.requeuedCount)||0);
    tabSessionStats.runBelowCriteria=Math.max(0,Number(visible.belowCriteriaCount)||0);
    tabSessionStats.runExcluded=Math.max(0,Number(visible.excludedCount)||0);
    tabSessionStats.runFailed=Math.max(0,Number(visible.failedCount)||0);
    tabSessionStats.runSkipped=Math.max(0,Number(visible.skippedCount)||0);
    renderTabSessionStats();
    return true;
  }
  let runUploadStateSyncSeqV129=0;
  let runUploadStateCacheV129={runId:'',byKeyword:new Map()};
  function runUploadStateCacheKeyV129(summary={}){
    return String(summary?.runId||summary?.id||summary?.startedAt||summary?.stoppedAt||'run');
  }
  async function loadRunUploadStateSummaryV129(summary=currentAutomationSummary,{force=false}={}){
    const rows=Array.isArray(summary?.history)?summary.history:[];
    const transportRows=rows.filter((item)=>isHistoryTransportBearingV165(item?.status));
    const keywords=[...new Set(transportRows.map((item)=>String(item?.keyword||'').trim()).filter(Boolean))];
    const result={uploaded:0,pending:0,held:0,local:0,byKeyword:new Map(),transportRows};
    if(!keywords.length)return result;
    const cacheKey=runUploadStateCacheKeyV129(summary);
    if(runUploadStateCacheV129.runId!==cacheKey)runUploadStateCacheV129={runId:cacheKey,byKeyword:new Map()};
    const cache=runUploadStateCacheV129.byKeyword;
    /* v1.3.1: 긴 실행(수백 키워드)에서 완료 때마다 전체 이력을 다시 조회하면 O(n²)로 느려집니다.
       신규 저장 키워드와 아직 pending인 키워드만 재확인하고, 강제 새로고침 때만 전체를 확인합니다.
       background API의 150개 제한도 넘지 않도록 100개씩 배치합니다. */
    const queryKeywords=keywords.filter((keyword)=>{
      if(force)return true;
      const cached=cache.get(keyword);
      /* v1.3.7: 첫 조회가 Local aggregate commit/업로드 ACK 경계보다 빨라 'local'로 보이면
         그 값을 terminal로 캐시하면 최근수집내역 배지가 계속 '수집저장'에 고정될 수 있습니다.
         local/pending은 미확정 상태이므로 다시 읽고, uploaded/held만 이벤트 무효화 전까지 캐시합니다. */
      return !cached||['local','pending'].includes(String(cached?.upload_state||'local'));
    });
    for(let i=0;i<queryKeywords.length;i+=100){
      const batch=queryKeywords.slice(i,i+100);
      const response=await runtimeMessage({type:'SPX_COLLECTION_UPLOAD_STATUS_V10154',keywords:batch});
      if(response?.ok!==true)throw new Error(response?.error||'최근 이력 업로드 상태 확인 실패');
      const returned=new Map((Array.isArray(response.data)?response.data:[]).map((row)=>[String(row?.keyword||''),row]));
      for(const keyword of batch)cache.set(keyword,returned.get(keyword)||{keyword,upload_state:'local'});
    }
    result.byKeyword=new Map(keywords.map((keyword)=>[keyword,cache.get(keyword)||{keyword,upload_state:'local'}]));
    for(const item of transportRows){
      const local=result.byKeyword.get(String(item?.keyword||''))||null,stateValue=String(local?.upload_state||'local');
      if(stateValue==='uploaded')result.uploaded++;
      else if(stateValue==='pending')result.pending++;
      else if(stateValue==='held')result.uploaded++;
      else result.local++;
    }
    return result;
  }
  async function syncFooterRunUploadStatesV129(summary=currentAutomationSummary,{force=false}={}){
    const seq=++runUploadStateSyncSeqV129;
    try{
      const result=await loadRunUploadStateSummaryV129(summary,{force});if(seq!==runUploadStateSyncSeqV129)return null;
      tabSessionStats.runUploaded=result.uploaded;tabSessionStats.runUploadPending=result.pending;tabSessionStats.runUploadHeld=0;renderTabSessionStats();return result;
    }catch(_){return null;}
  }

  async function refreshHistoryUploadStatesV10154(summary=currentAutomationSummary,{force=false}={}){
    const now=Date.now();if(!force&&now-historyUploadStatusRefreshAtV10154<1500)return;historyUploadStatusRefreshAtV10154=now;
    const rows=Array.isArray(summary?.history)?summary.history:[];
    const keywords=[...new Set(rows.filter((item)=>isHistoryTransportBearingV165(item?.status)).map((item)=>String(item?.keyword||'').trim()).filter(Boolean))];
    if(!keywords.length){setText('spx-history-uploaded-count','0');setText('spx-history-pending-count','0');tabSessionStats.runUploaded=0;tabSessionStats.runUploadPending=0;tabSessionStats.runUploadHeld=0;syncFooterRunSummaryV129(summary);renderTabSessionStats();applyHistoryCumulativeCountsV1628();return;}
    try{
      const result=await loadRunUploadStateSummaryV129(summary,{force}),byKeyword=result.byKeyword;
      document.querySelectorAll('#spx-stop-history-list .spx-stop-history-row').forEach((node)=>{
        if(!isHistoryTransportBearingV165(node.dataset.historyStatus))return;
        const keyword=String(node.dataset.historyKeyword||''),local=byKeyword.get(keyword)||null,stateValue=String(local?.upload_state||'local');
        node.dataset.historyUploadState=stateValue;
        const badge=node.querySelector('[data-history-upload-badge]'),reason=node.querySelector('small');
        if(stateValue==='uploaded'||stateValue==='held'){
          if(badge){badge.textContent='서버 업로드';badge.classList.add('upload-uploaded');badge.classList.remove('upload-pending');}
        }else if(stateValue==='pending'){
          if(badge){badge.textContent='업로드 대기';badge.classList.add('upload-pending');badge.classList.remove('upload-uploaded');}
        }else if(badge){badge.textContent='수집완료';badge.classList.remove('upload-uploaded','upload-pending');}
        if(reason){
          const base=String(reason.dataset.baseText||reason.textContent||'처리 완료');
          reason.textContent=historyReasonForStateV136(base,stateValue,local);
        }
      });
      setText('spx-history-uploaded-count',fmt(result.uploaded));setText('spx-history-pending-count',fmt(result.pending));
      tabSessionStats.runUploaded=result.uploaded;tabSessionStats.runUploadPending=result.pending;tabSessionStats.runUploadHeld=0;syncFooterRunSummaryV129(summary);renderTabSessionStats();applyHistoryCumulativeCountsV1628();applyRecentHistorySearchV117();
    }catch(_){/* 최근 수집내역 표시 보강 실패는 수집 자체를 방해하지 않음 */}
  }

  function formatHistoryDateTimeV117(value,fallbackDate=''){
    const rawValue=String(value??'').trim();
    const numeric=Number(value)||0;
    const parsed=!numeric&&rawValue?Date.parse(rawValue):NaN;
    const d=numeric>0?new Date(numeric):(Number.isFinite(parsed)?new Date(parsed):null);
    if(d&&!Number.isNaN(d.getTime())){
      const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');
      const hh=String(d.getHours()).padStart(2,'0'),mm=String(d.getMinutes()).padStart(2,'0');
      return `${y}-${m}-${day} ${hh}:${mm}`;
    }
    const raw=String(fallbackDate||'').trim();
    return raw?raw.slice(0,16).replace('T',' '):'';
  }
  function normalizeRecentHistorySearchV117(value){return String(value||'').normalize('NFKC').toLowerCase().replace(/\s+/g,' ').trim();}
  function expandRecentHistoryDetailsV126(){
    const details=getUiElement('spx-stop-history-details',{repair:false}),button=getUiElement('spx-stop-history-toggle',{repair:false});
    if(details)details.hidden=false;
    if(button){button.textContent='키워드 이력 접기 ▴';button.setAttribute('aria-expanded','true');}
  }
  function syncRecentHistoryFilterButtonsV126(){
    document.querySelectorAll('.spx-history-upload-state-summary [data-upload-filter]').forEach((node)=>{const active=node.dataset.uploadFilter===recentHistoryUploadFilterV125R1;node.classList.toggle('is-active',active);node.setAttribute('aria-pressed',active?'true':'false');});
    document.querySelectorAll('.spx-stop-summary-counts [data-history-filter]').forEach((node)=>{const active=node.dataset.historyFilter===recentHistoryStatusFilterV126;node.classList.toggle('is-active',active);node.setAttribute('aria-pressed',active?'true':'false');});
  }
  function setRecentHistoryStatusFilterV126(value='all'){
    const next=['saved','requeued','below_criteria','excluded','skipped','failed'].includes(String(value||''))?String(value):'all';
    recentHistoryStatusFilterV126=recentHistoryStatusFilterV126===next&&next!=='all'?'all':next;
    if(recentHistoryStatusFilterV126!=='all')recentHistoryUploadFilterV125R1='all';
    syncRecentHistoryFilterButtonsV126();
    if(recentHistoryStatusFilterV126!=='all')expandRecentHistoryDetailsV126();
    applyRecentHistorySearchV117();
  }
  async function setRecentHistoryUploadFilterV125R1(value='all'){
    const next=['uploaded','pending'].includes(String(value||''))?String(value):'all';
    recentHistoryUploadFilterV125R1=recentHistoryUploadFilterV125R1===next&&next!=='all'?'all':next;
    if(recentHistoryUploadFilterV125R1!=='all')recentHistoryStatusFilterV126='all';
    syncRecentHistoryFilterButtonsV126();
    if(recentHistoryUploadFilterV125R1!=='all'){
      expandRecentHistoryDetailsV126();
      /* v1.4.5: 상단 서버업로드/업로드대기 배지를 누르는 순간 현재 Local transport 상태를 강제 갱신합니다.
         과거 provisional reason만으로 필터링되어 목록이 비어 보이던 현상을 막습니다. */
      await refreshHistoryUploadStatesV10154(currentAutomationSummary,{force:true}).catch(()=>null);
    }
    applyRecentHistorySearchV117();
  }
  function applyRecentHistorySearchV117(){
    const term=normalizeRecentHistorySearchV117(recentHistorySearchTermV117);
    if(term)expandRecentHistoryDetailsV126();
    let historyVisible=0,pendingVisible=0;
    document.querySelectorAll('#spx-stop-history-list .spx-stop-history-row').forEach((node)=>{
      const historyStatus=String(node.dataset.historyStatus||''),hay=normalizeRecentHistorySearchV117(`${node.dataset.historyKeyword||''} ${historyStatus} ${node.textContent||''}`);
      const searchOk=!term||hay.includes(term),uploadState=String(node.dataset.historyUploadState||'');
      const uploadFilterOk=recentHistoryUploadFilterV125R1==='all'||uploadState===recentHistoryUploadFilterV125R1;
      const statusFilterOk=recentHistoryStatusFilterV126==='all'||historyStatus===recentHistoryStatusFilterV126||(recentHistoryStatusFilterV126==='skipped'&&historyStatus==='server_skipped');
      const visible=searchOk&&uploadFilterOk&&statusFilterOk;node.hidden=!visible;if(visible)historyVisible++;
    });
    document.querySelectorAll('#spx-pending-select-list .spx-pending-select-row').forEach((node)=>{
      const hay=normalizeRecentHistorySearchV117(`${node.dataset.pendingKeyword||''} ${node.dataset.pendingMeta||''} ${node.textContent||''}`),pendingState=String(node.dataset.pendingState||'pending');
      const searchOk=!term||hay.includes(term);
      const filterOk=recentHistoryUploadFilterV125R1==='all'||(recentHistoryUploadFilterV125R1==='pending'&&pendingState==='pending');
      const visible=recentHistoryStatusFilterV126==='all'&&searchOk&&filterOk&&recentHistoryUploadFilterV125R1!=='uploaded';node.hidden=!visible;if(visible)pendingVisible++;
    });
    const pendingPanel=document.querySelector('#spx-overlay .spx-pending-select-panel');if(pendingPanel)pendingPanel.hidden=recentHistoryUploadFilterV125R1==='uploaded'||recentHistoryStatusFilterV126!=='all';
    const meta=getUiElement('spx-history-search-result',{repair:false});
    if(meta){
      const uploadLabel=({uploaded:'서버 업로드',pending:'서버 업로드 대기'})[recentHistoryUploadFilterV125R1]||'';
      const statusLabel=({saved:'수집완료',requeued:'자료부족',excluded:'기준미달 제외',skipped:'건너뜀',failed:'실패·기술오류'})[recentHistoryStatusFilterV126]||'';
      const filterLabel=statusLabel||uploadLabel;
      meta.textContent=[term?`검색 결과 · 수집내역 ${fmt(historyVisible)}건 · 업로드 대기 ${fmt(pendingVisible)}건`:'',filterLabel?`필터 · ${filterLabel}`:''].filter(Boolean).join(' · ');
    }
  }
  function setPendingUploadResultV117(text='',tone=''){
    pendingUploadResultTextV117=String(text||'');
    const el=getUiElement('spx-pending-upload-result',{repair:false});if(!el)return;
    el.textContent=pendingUploadResultTextV117;
    el.className=`spx-pending-upload-result${tone?` ${tone}`:''}`;
    el.hidden=!pendingUploadResultTextV117;
  }

  function updatePendingSelectionButtonV10154(){
    const processable=new Set(pendingUploadListRowsV10154.filter((row)=>row?.upload_selectable===true).map((row)=>String(row?.k||'')));
    for(const key of [...pendingUploadSelectionKeysV10154])if(!processable.has(key))pendingUploadSelectionKeysV10154.delete(key);
    const selected=pendingUploadSelectionKeysV10154.size,button=getUiElement('spx-pending-selected-upload',{repair:false});
    if(button){button.disabled=pendingSelectedUploadBusyV10154||pendingUploadBusyV10151||selected<=0;if(!pendingSelectedUploadBusyV10154)button.textContent=`선택 ${fmt(selected)}건 서버로 업로드`;}
    const jsonButton=getUiElement('spx-stop-summary-json',{repair:false});if(jsonButton){jsonButton.title=selected>0?`선택한 서버 업로드 대기 ${fmt(selected)}건을 full-fidelity Manager Upload v2 JSON으로 저장합니다.`:'현재 검색·필터 결과를 Manager Upload v2 JSON으로 저장합니다.';}
    const uploadable=pendingUploadListRowsV10154.filter((row)=>row?.upload_selectable===true).length,attention=Math.max(0,pendingUploadListRowsV10154.length-uploadable);setText('spx-pending-select-count',`서버 업로드 대기 ${fmt(uploadable)}건 · 선택 ${fmt(selected)}건`);
  }

  function renderPendingSelectionListV10154(rows=[]){
    pendingUploadListRowsV10154=(Array.isArray(rows)?rows:[]).slice().sort((a,b)=>(Number(b?.updatedAt)||0)-(Number(a?.updatedAt)||0));
    const list=getUiElement('spx-pending-select-list',{repair:false});if(!list)return;
    const valid=new Set(pendingUploadListRowsV10154.filter((row)=>row?.upload_selectable===true).map((row)=>String(row?.k||'')));
    for(const key of [...pendingUploadSelectionKeysV10154])if(!valid.has(key))pendingUploadSelectionKeysV10154.delete(key);
    const fragment=document.createDocumentFragment();
    for(const item of pendingUploadListRowsV10154){
      const key=String(item?.k||''),selectable=item?.upload_selectable===true;
      const label=document.createElement('label');label.className=`spx-pending-select-row${selectable?'':' held'}`;label.dataset.pendingKeyword=String(item?.keyword||'');label.dataset.pendingState=selectable?'pending':'held';
      const check=document.createElement('input');check.type='checkbox';check.checked=pendingUploadSelectionKeysV10154.has(key);check.disabled=!selectable;
      check.addEventListener('change',()=>{if(check.checked)pendingUploadSelectionKeysV10154.add(key);else pendingUploadSelectionKeysV10154.delete(key);updatePendingSelectionButtonV10154();});
      const body=document.createElement('span');body.className='spx-pending-select-main';
      const name=document.createElement('b');name.textContent=String(item?.keyword||'-');
      const meta=document.createElement('small');
      const collectedAt=formatHistoryDateTimeV117(item?.collectedAt||item?.updatedAt,item?.date||'');
      const bits=[collectedAt?`수집 ${collectedAt}`:'',item?.grade?`등급 ${item.grade}`:'',String(item?.selection_reason||'서버 업로드 대기'),item?.upload_repair_hold_reason?String(item.upload_repair_hold_reason):''].filter(Boolean);
      meta.textContent=bits.join(' · ');label.dataset.pendingMeta=meta.textContent;body.append(name,meta);label.append(check,body);fragment.appendChild(label);
    }
    if(!fragment.childNodes.length){const empty=document.createElement('div');empty.className='spx-stop-history-empty';empty.textContent='서버 업로드 대기 항목이 없습니다.';fragment.appendChild(empty);}
    list.replaceChildren(fragment);updatePendingSelectionButtonV10154();applyRecentHistorySearchV117();
  }

  async function refreshPendingSelectionListV10154(){
    try{
      const response=await runtimeMessage({type:'SPX_PENDING_UPLOAD_LIST_V10154',limit:5000});
      if(response?.ok!==true)throw new Error(response?.error||'업로드 대기 목록 확인 실패');
      const data=response?.data||{},rows=Array.isArray(data.rows)?data.rows:[];
      renderPendingSelectionListV10154(rows);
      /* v1.2.6 R3: 최근수집내역에서 확인한 authoritative 목록 수를 하단 카운터에도 즉시 반영합니다.
         서로 다른 비동기 조회 시점 때문에 '42 → 0 → 42'처럼 보이는 표시 흔들림을 막습니다. */
      tabSessionStats.uploadPendingAttentionDb=0;
      // The list query is for selection only; it must not overwrite counts returned by
      // SPX_HISTORY_COUNTS_V1631, particularly if older requests complete out-of-order.
      setText('spx-global-pending-total',historyCumulativeCountsV1628?`${fmt(historyCumulativeCountsV1628.pending)}건`:'로컬 집계 확인 중');
      void refreshTransferCountsV1631(true);
      return data;
    }catch(error){
      /* 조회 실패를 0건으로 표현하지 않습니다. 마지막 정상 목록/카운터를 그대로 유지합니다. */
      const message=`업로드 대기 목록 확인 실패 · 기존 표시 유지 · ${String(error?.message||error)}`;
      const count=getUiElement('spx-pending-select-count',{repair:false});if(count)count.textContent=message;setText('spx-global-pending-total',tabSessionStats.uploadPendingDb!=null&&Number.isFinite(Number(tabSessionStats.uploadPendingDb))?`${fmt(tabSessionStats.uploadPendingDb)}건 · 이전 확인값`:'확인 실패');
      return null;
    }
  }

  function selectAllPendingUploadsV10154(){
    for(const row of pendingUploadListRowsV10154)if(row?.upload_selectable===true&&row?.k)pendingUploadSelectionKeysV10154.add(String(row.k));
    renderPendingSelectionListV10154(pendingUploadListRowsV10154);
  }
  function invertPendingUploadSelectionV1613(){
    // Only selectable upload-pending rows change selection. Never modify actual stored data.
    const old=new Set(pendingUploadSelectionKeysV10154);
    for(const row of pendingUploadListRowsV10154){
      if(row?.upload_selectable!==true||!row?.k)continue;
      const key=String(row.k);
      if(old.has(key))pendingUploadSelectionKeysV10154.delete(key);
      else pendingUploadSelectionKeysV10154.add(key);
    }
    renderPendingSelectionListV10154(pendingUploadListRowsV10154);
  }
  function clearPendingUploadSelectionV10154(){pendingUploadSelectionKeysV10154.clear();renderPendingSelectionListV10154(pendingUploadListRowsV10154);}

  async function deleteLocalPendingAttentionV111(){
    if(pendingSelectedUploadBusyV10154||pendingUploadBusyV10151)return false;
    const attention=pendingUploadListRowsV10154.filter((row)=>row?.upload_selectable!==true).length;
    if(attention<=0){setText('spx-stop-summary-reason','정리할 비업로드 보류 항목이 없습니다.');return false;}
    const ok=window.confirm(`비업로드 보류 ${fmt(attention)}건을 로컬에서 정리합니다.\n\n서버 업로드 대기 항목은 삭제하지 않습니다.\n원천상품(raw), 전송대기(outbox), 서버 DB도 변경하지 않습니다.`);if(!ok)return false;
    try{
      const response=await runtimeMessage({type:'SPX_PENDING_ATTENTION_DELETE_LOCAL_V111'});if(response?.ok!==true)throw new Error(response?.error||'비업로드 보류 로컬 정리 실패');
      const data=response.data||{};pendingUploadSelectionKeysV10154.clear();
      setText('spx-stop-summary-reason',`비업로드 보류 로컬 ${fmt(data.deleted||0)}건 정리 · 서버 업로드 대기 ${fmt(data.uploadableAfter||0)}건 보존`);
      await refreshPendingSelectionListV10154();await refreshDbInfo().catch(()=>{});return true;
    }catch(error){setText('spx-stop-summary-reason',String(error?.message||error));return false;}
  }

  async function runSelectedPendingUploadsV10154(){
    if(pendingSelectedUploadBusyV10154||pendingUploadBusyV10151||!pendingUploadSelectionKeysV10154.size)return false;
    pendingSelectedUploadBusyV10154=true;
    const button=getUiElement('spx-pending-selected-upload',{repair:false}),total=pendingUploadSelectionKeysV10154.size;
    setPendingUploadResultV117(`선택 ${fmt(total)}건 서버 업로드 시작...`,'working');
    let completed=0,uploaded=0,alreadyServer=0,recoveryNeeded=0,sourceMissing=0,failed=0,transient=false;
    try{
      while(pendingUploadSelectionKeysV10154.size&&!contextInvalidated){
        const current=pendingUploadListRowsV10154.filter((row)=>pendingUploadSelectionKeysV10154.has(String(row?.k||''))&&row?.upload_selectable===true).slice(0,4).map((row)=>String(row.k));
        if(!current.length)break;
        if(button){button.disabled=true;button.textContent=`선택 업로드 ${fmt(completed)}/${fmt(total)}`;}
        setPendingUploadResultV117(`전송 중 ${fmt(completed)}/${fmt(total)} · 저장된 수집자료 바로 전송 중...`,'working');
        const response=await runtimeMessage({type:'SPX_PENDING_UPLOAD_REPAIR_SELECTED_BATCH',keys:current});
        if(response?.ok!==true)throw new Error(response?.error||'선택 업로드 실패');
        const results=Array.isArray(response?.data?.results)?response.data.results:[];if(!results.length)break;
        for(const result of results){
          completed++;
          if(result?.transient===true){transient=true;failed++;continue;}
          pendingUploadSelectionKeysV10154.delete(String(result?.key||''));
          const action=String(result?.action||result?.outcome||''),reason=String(result?.error||result?.reason||result?.holdReason||'');
          if(/로컬\s*원천상품\s*없음/i.test(reason))sourceMissing++;
          else if(result?.ok===true&&action==='upload')uploaded++;
          else if(result?.ok===true&&['ack_local','superseded','finalize'].includes(action))alreadyServer++;
          else if(result?.held===true)recoveryNeeded++;
          else if(result?.ok===true)uploaded++;else failed++;
        }
        await refreshPendingSelectionListV10154();
        if(transient)break;
        await new Promise((resolve)=>setTimeout(resolve,250));
      }
      await refreshDbInfo().catch(()=>{});await refreshHistoryUploadStatesV10154(currentAutomationSummary,{force:true}).catch(()=>{});
      if(transient){
        setClass('spx-dbstate','spx-err');setText('spx-dbstate',`● 서버 일시 장애 · 선택 처리 ${fmt(completed)}/${fmt(total)} · 남은 선택 보존`);
        setPendingUploadResultV117(`전송 미완료 · 처리 ${fmt(completed)}/${fmt(total)} · 서버 일시 장애 · 남은 선택은 그대로 보존했습니다.`,'error');
      }else{
        const transportComplete=failed===0&&recoveryNeeded===0&&sourceMissing===0&&completed>=total;
        const diagnostic=transportComplete?null:await readUploadDiagnosticV118();
        const failureHint=!transportComplete&&failed>0?friendlyUploadFailureV118('',diagnostic):'';
        const stage=!transportComplete?uploadDiagnosticStageLabelV118(diagnostic?.stage):'';
        setClass('spx-dbstate',transportComplete?'spx-ok':'spx-err');setText('spx-dbstate',`● 선택 업로드 처리 ${fmt(completed)}/${fmt(total)} · 서버 업로드 ${fmt(uploaded+alreadyServer)} · 업로드 실패 ${fmt(failed)} · 수동 확인 필요 ${fmt(recoveryNeeded)} · 원본 없음 ${fmt(sourceMissing)}${failureHint?` · ${failureHint}`:''}${stage?` · 단계: ${stage}`:''}`);
        const resultText=transportComplete
          ?`전송 완료 ✓ · 선택 ${fmt(total)}건 · 새 업로드 ${fmt(uploaded)}건 · 이미 서버 저장 ${fmt(alreadyServer)}건`
          :`전송 일부 미완료 · 처리 ${fmt(completed)}/${fmt(total)} · 서버 업로드 ${fmt(uploaded+alreadyServer)}건 · 실패 ${fmt(failed)}건 · 수동 확인 필요 ${fmt(recoveryNeeded)}건 · 원본 없음 ${fmt(sourceMissing)}건${failureHint?` · ${failureHint}`:''}`;
        setPendingUploadResultV117(resultText,transportComplete?'success':'error');
      }
      if(uploaded>0)await recordTabSessionEvent('pending-upload-selected',{uploaded,uploadPending:-uploaded},{eventId:`pending-upload-selected:${Date.now()}`}).catch(()=>{});
      return !transient&&failed===0;
    }catch(error){
      const diagnostic=await readUploadDiagnosticV118(),friendly=friendlyUploadFailureV118(error?.message||error,diagnostic),stage=uploadDiagnosticStageLabelV118(diagnostic?.stage);
      setClass('spx-dbstate','spx-err');setText('spx-dbstate',`● 선택 업로드 중단 · ${friendly}${stage?` · 단계: ${stage}`:''}`);
      setPendingUploadResultV117(`전송 실패 · ${friendly}${stage?` · 단계: ${stage}`:''}`,'error');return false;
    }finally{
      pendingSelectedUploadBusyV10154=false;await refreshPendingSelectionListV10154().catch(()=>{});updatePendingSelectionButtonV10154();
    }
  }

  async function deleteAllLocalPendingUploadsV117(){
    if(pendingSelectedUploadBusyV10154||pendingUploadBusyV10151){setText('spx-stop-summary-reason','업로드 대기 처리 중에는 로컬 대기자료를 삭제할 수 없습니다.');return false;}
    const count=pendingUploadListRowsV10154.filter((row)=>row?.upload_selectable===true).length;
    if(count<=0){setText('spx-stop-summary-reason','완전삭제할 로컬 서버 업로드 대기 수집내역이 없습니다.');return false;}
    const ok=window.confirm(`로컬 서버 업로드 대기 수집내역 ${fmt(count)}건을 완전삭제합니다.\n\n삭제 대상:\n· 로컬 업로드 대기 aggregate\n· 해당 수집일 원천상품(raw)\n· 해당 대기자료와 연결된 로컬 전송대기(outbox)\n\n서버에 이미 저장된 DB는 삭제하거나 변경하지 않습니다.\n\n필요하면 먼저 CSV/JSON으로 백업한 뒤 진행하세요.`);if(!ok)return false;
    try{
      setText('spx-stop-summary-reason',`로컬 업로드 대기 ${fmt(count)}건 완전삭제 중...`);
      const response=await runtimeMessage({type:'SPX_PENDING_UPLOAD_DELETE_ALL_LOCAL_V117'});
      if(response?.ok!==true)throw new Error(response?.error||'로컬 업로드 대기 완전삭제 실패');
      const data=response.data||{};pendingUploadSelectionKeysV10154.clear();
      setPendingUploadResultV117('');
      setText('spx-stop-summary-reason',`로컬 업로드 대기 완전삭제 완료 · 대기 ${fmt(data.aggregatesDeleted||0)}건 · 원천상품 ${fmt(data.rawDeleted||0)}건 · 전송대기 ${fmt(data.outboxDeleted||0)}건 · 서버 DB 영향 0`);
      await refreshPendingSelectionListV10154();await refreshHistoryUploadStatesV10154(currentAutomationSummary,{force:true}).catch(()=>{});await refreshDbInfo().catch(()=>{});return true;
    }catch(error){setText('spx-stop-summary-reason',`로컬 업로드 대기 삭제 실패 · ${String(error?.message||error)}`);return false;}
  }

  async function clearRecentCollectionHistoryV10154(){
    if(pendingSelectedUploadBusyV10154||pendingUploadBusyV10151){setText('spx-stop-summary-reason','업로드 처리 중에는 초기화할 수 없습니다.');return false;}
    const first=window.confirm('전체 로컬 수집내역과 모든 로컬 업로드/수집 대기열을 완전히 삭제합니다.\n\n삭제: 원천상품·집계·저장 번들·로컬 후보/큐·전송 대기(outbox)·최근 수집 기록.\n서버 DB, WING 전용 큐, IP 복구 및 계정 설정은 변경하지 않습니다.\n\n미업로드 원본은 복원할 수 없습니다. 진행 중인 수집을 먼저 중지하세요.\n\n계속하시겠습니까?');
    if(!first)return false;
    const second=window.confirm('최종 확인 (2/2)\n\n로컬 업로드 대기와 원천상품까지 영구 삭제합니다.\n서버에 아직 올라가지 않은 자료도 사라집니다.\n\n정말 모든 로컬 수집내역·대기열을 삭제하시겠습니까?');
    if(!second)return false;
    const resetButton=getUiElement('spx-history-reset',{repair:false});if(resetButton)resetButton.disabled=true;
    try{
      const response=await runtimeMessage({type:'SPX_RESET_ALL_LOCAL_COLLECTION_V1627'});
      if(response?.ok!==true)throw new Error(response?.error||'로컬 전체 초기화 실패');
      const d=response?.data||{};
      tabSessionStats={...tabSessionStats,processed:0,excluded:0,failed:0,belowCriteria:0,uploaded:0,uploadPending:0,uploadHeld:0,uploadPendingDb:0,uploadPendingAttentionDb:0,runProcessed:0,runSaved:0,runRequeued:0,runExcluded:0,runFailed:0,runSkipped:0,runUploadPending:0,runUploadHeld:0,runUploaded:0,automationElapsedMs:0,historyResetAt:Number(d.historyResetAt)||Date.now()};
      persistentHistoryResetAtV101510=Math.max(persistentHistoryResetAtV101510,Number(d.historyResetAt)||Date.now());
      currentAutomationSummary=null;pendingUploadListRowsV10154=[];pendingUploadSelectionKeysV10154.clear();
      runUploadStateCacheV129={runId:'',byKeyword:new Map()};
      for(const id of ['spx-stop-count-success','spx-stop-count-requeued','spx-stop-count-below-criteria','spx-stop-count-excluded','spx-stop-count-skipped','spx-stop-count-failed','spx-history-uploaded-count','spx-history-pending-count'])setText(id,'0');
      historyCumulativeCountsV1628=null;
      setText('spx-global-pending-total','0건');setText('spx-stop-summary-meta','처리 0개 · 상품 0개 · 0초');
      setText('spx-stop-summary-title','최근 수집내역');
      setText('spx-stop-summary-reason',`로컬 전체 초기화 완료 · 원천 ${fmt(d?.deleted?.raw||0)}건 · 집계 ${fmt(d?.deleted?.aggregates||0)}건 · 전송대기 ${fmt(d?.deleted?.sync_outbox||0)}건 · 서버 DB 변경 0`);
      const list=getUiElement('spx-stop-history-list',{repair:false});if(list)list.innerHTML='<div class="spx-stop-history-empty">로컬 수집내역과 업로드 대기열이 완전히 삭제되었습니다.</div>';
      renderPendingSelectionListV10154([]);renderTabSessionStats();
      await refreshPendingSelectionListV10154();await refreshDbInfo().catch(()=>{});
      return true;
    }catch(error){setText('spx-stop-summary-reason',`로컬 전체 초기화 실패 · ${String(error?.message||error)}`);return false;}
    finally{if(resetButton)resetButton.disabled=false;}
  }

  function safeDownloadPart(value) { return String(value||'').replace(/[\/:*?"<>|]+/g,'_').replace(/\s+/g,'_').slice(0,60) || '연속수집'; }
  function automationSummaryRows(summary={}) {
    summary=normalizeAutomationSummaryForHistoryReset(summary||{}); const rows=[];
    if(summary.interruptedKeyword)rows.push({status:'중단',keyword:summary.interruptedKeyword,collectedAt:formatHistoryDateTimeV117(summary.stoppedAt,''),grade:'',productCount:'',reason:'중단 시 처리 중이던 키워드'});
    for(const item of Array.isArray(summary.history)?summary.history:[])rows.push({status:stopStatusLabel(item.status),keyword:item.keyword||'',collectedAt:formatHistoryDateTimeV117(item?.at,item?.date||item?.collected_at||item?.collected_on||''),grade:item.grade||'',productCount:Number(item.productCount)||0,reason:item.reason||''});
    return rows;
  }
  function historyUploadStateLabelV133(value=''){
    return ({uploaded:'서버 업로드',pending:'서버 업로드 대기',held:'서버 업로드',local:'수집완료'})[String(value||'')]||'';
  }
  function recentHistoryFilterLabelV133(){
    const statusLabel=({saved:'수집완료',requeued:'자료부족',below_criteria:'미달',excluded:'제외',skipped:'건너뜀',failed:'실패기술오류'})[recentHistoryStatusFilterV126]||'';
    const uploadLabel=({uploaded:'서버업로드',pending:'서버업로드대기'})[recentHistoryUploadFilterV125R1]||'';
    const term=String(recentHistorySearchTermV117||'').trim();
    return [statusLabel||uploadLabel||'전체',term?`검색_${safeDownloadPart(term)}`:''].filter(Boolean).join('_');
  }
  function currentVisibleHistoryExportRowsV133(summary=currentAutomationSummary){
    summary=normalizeAutomationSummaryForHistoryReset(summary||{});
    const history=Array.isArray(summary?.history)?summary.history:[];
    const nodes=[...document.querySelectorAll('#spx-stop-history-list .spx-stop-history-row')].filter((node)=>node.hidden!==true);
    return nodes.map((node)=>{
      const index=Number(node.dataset.historyIndex),item=Number.isInteger(index)&&index>=0?history[index]:null;
      const status=String(item?.status||node.dataset.historyStatus||'').trim();
      const keyword=String(item?.keyword||node.dataset.historyKeyword||'').trim();
      const uploadState=String(node.dataset.historyUploadState||'').trim();
      const collectedAt=item?formatHistoryDateTimeV117(item?.at,item?.date||item?.collected_at||item?.collected_on||''):formatHistoryDateTimeV117(summary?.stoppedAt,'');
      const fallbackReason=String(node.querySelector?.('small')?.dataset?.baseText||node.querySelector?.('small')?.textContent||'').trim();
      const reason=String(item?.reason||fallbackReason||(status==='interrupted'?'중단 시 처리 중이던 키워드':'')).trim();
      const date=String(item?.date||item?.collected_at||item?.collected_on||collectedAt||'').slice(0,10);
      return {historyIndex:Number.isInteger(index)?index:-1,status,statusLabel:status==='interrupted'?'중단':stopStatusLabel(status),uploadState,uploadStateLabel:historyUploadStateLabelV133(uploadState),keyword,collectedAt,grade:String(item?.grade||''),productCount:Math.max(0,Number(item?.productCount)||0),durationMs:item?.durationMs==null?null:Number(item.durationMs),reason,date,runKey:String(item?.runKey||item?.collection_run_key||'').trim(),marketplace:'coupang'};
    }).filter((row)=>row.keyword);
  }
  function filteredHistoryCsvV133(rows=[]){
    const escCsv=(value)=>`"${String(value??'').replace(/"/g,'""')}"`;
    const header=['상태','업로드상태','키워드','수집일시','등급','상품수','소요(초)','사유'];
    const body=(Array.isArray(rows)?rows:[]).map((row)=>[row.statusLabel||stopStatusLabel(row.status),row.uploadStateLabel||historyUploadStateLabelV133(row.uploadState),row.keyword||'',row.collectedAt||'',row.grade||'',Math.max(0,Number(row.productCount)||0),row.durationMs==null||!Number.isFinite(Number(row.durationMs))?'':(Number(row.durationMs)/1000).toFixed(1),row.reason||'']);
    return '\ufeff'+[header,...body].map((row)=>row.map(escCsv).join(',')).join('\r\n');
  }
  async function loadFilteredHistoryExportPackageV133(displayRows=[]){
    const visibleRows=Array.isArray(displayRows)?displayRows:[];
    const descriptors=visibleRows.filter((row)=>['saved','requeued'].includes(String(row?.status||'')));
    const rows=[],errors=visibleRows.filter((row)=>!['saved','requeued'].includes(String(row?.status||''))).map((row)=>({keyword:String(row?.keyword||''),status:String(row?.status||''),error:`${row?.statusLabel||stopStatusLabel(row?.status)} 상태는 SmartPage Manager canonical 업로드 대상이 아닙니다.`}));
    const chunkSize=12;
    for(let offset=0;offset<descriptors.length;offset+=chunkSize){
      const chunk=descriptors.slice(offset,offset+chunkSize);
      setText('spx-stop-summary-reason',`JSON 준비 ${fmt(Math.min(offset+chunk.length,descriptors.length))}/${fmt(descriptors.length)} · 저장된 Local 수집자료 변환 중...`);
      const response=await runtimeMessage({type:'SPX_HISTORY_FILTER_EXPORT_PACKAGE_V133',rows:chunk});
      if(response?.ok!==true)throw new Error(response?.error||'현재 필터 Manager Upload v2 JSON 생성 실패');
      rows.push(...(Array.isArray(response?.data?.rows)?response.data.rows:[]));
      errors.push(...(Array.isArray(response?.data?.errors)?response.data.errors:[]));
      await new Promise((resolve)=>setTimeout(resolve,0));
    }
    return {
      schema:'smartpage-manager-upload-package-v2',
      collectorVersion:SPX_CONTENT_BUILD_VERSION,
      exportedAt:new Date().toISOString(),
      purpose:'SmartPage Manager file import → full-fidelity server restore/upload',
      contract:{metric:'metricPayload → keyword_metrics/current canonical publish',run:'runPayload → keyword_runs',snapshots:'sourceSnapshots → product_snapshots',winners:'winnerProducts → winner_products',state:'statePayload → spx_keyword_state',countParityRequired:true,serverMutationOnExport:false},
      exportMode:'durable-canonical-v1.5.22',
      serverRequestsDuringExport:0,
      hashMode:'deferred-on-import',
      filter:{historyStatus:recentHistoryStatusFilterV126,uploadState:recentHistoryUploadFilterV125R1,search:String(recentHistorySearchTermV117||'')},
      visibleCount:visibleRows.length,
      uploadableRequestedCount:descriptors.length,
      exportedCount:rows.length,
      unavailableCount:errors.length,
      displayRows:visibleRows,
      errors,
      rows
    };
  }
  function triggerTextDownloadV117(text,type,filename){
    const blob=new Blob([text],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
  }
  function triggerManagerJsonDownloadV138(pack={},filename='최근수집내역.json'){
    /* v1.3.8: 100~수백건 Manager Upload JSON을 pretty full-pack 문자열 하나로
       한 번에 만들지 않습니다. rows는 행 단위 Blob part로 작성해 메모리 피크와 저장 대기를 줄입니다. */
    const meta={...pack};const rows=Array.isArray(meta.rows)?meta.rows:[];delete meta.rows;
    const entries=Object.entries(meta),parts=['{'];
    entries.forEach(([key,value],index)=>{parts.push(`${index?',':''}${JSON.stringify(key)}:${JSON.stringify(value)}`);});
    parts.push(`${entries.length?',':''}"rows":[`);
    rows.forEach((row,index)=>{if(index)parts.push(',');parts.push(JSON.stringify(row));});
    parts.push(']}');
    const blob=new Blob(parts,{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);return blob.size;
  }
  async function loadSelectedPendingExportPackageV117(){
    const keys=[...pendingUploadSelectionKeysV10154].filter(Boolean);
    if(!keys.length)return null;
    const rows=[];const errors=[];const chunkSize=20;
    for(let offset=0;offset<keys.length;offset+=chunkSize){
      const chunk=keys.slice(offset,offset+chunkSize);
      setText('spx-stop-summary-reason',`선택 업로드 대기 JSON 준비 ${fmt(Math.min(offset+chunk.length,keys.length))}/${fmt(keys.length)} · durable bundle 읽는 중...`);
      const response=await runtimeMessage({type:'SPX_PENDING_UPLOAD_EXPORT_SELECTED_V117',keys:chunk});
      if(response?.ok!==true)throw new Error(response?.error||'선택 업로드 대기 내보내기 실패');
      rows.push(...(Array.isArray(response?.data?.rows)?response.data.rows:[]));
      errors.push(...(Array.isArray(response?.data?.errors)?response.data.errors:[]));
      await new Promise((resolve)=>setTimeout(resolve,0));
    }
    return {
      schema:'smartpage-manager-upload-package-v2',
      collectorVersion:SPX_CONTENT_BUILD_VERSION,
      exportedAt:new Date().toISOString(),
      purpose:'SmartPage Manager file import → full-fidelity server restore/upload',
      contract:{metric:'metricPayload → keyword_metrics/current canonical publish',run:'runPayload → keyword_runs',snapshots:'sourceSnapshots → product_snapshots',winners:'winnerProducts → winner_products',state:'statePayload → spx_keyword_state',countParityRequired:true,serverMutationOnExport:false},
      exportMode:'selected-pending-durable-canonical-v1.5.22',
      serverRequestsDuringExport:0,
      hashMode:'deferred-on-import',
      selectedCount:keys.length,
      exportedCount:rows.length,
      unavailableCount:errors.length,
      errors,
      rows
    };
  }
  async function downloadSelectedPendingJsonV153(){
    const keys=[...pendingUploadSelectionKeysV10154].filter(Boolean);
    if(!keys.length)throw new Error('선택된 서버 업로드 대기 항목이 없습니다.');
    const exportedAt=new Date().toISOString(),stamp=exportedAt.replace(/[:.]/g,'-'),chunkSize=20;
    const meta={schema:'smartpage-manager-upload-package-v2',collectorVersion:SPX_CONTENT_BUILD_VERSION,exportedAt,purpose:'SmartPage Manager file import → full-fidelity server restore/upload',contract:{metric:'metricPayload → keyword_metrics/current canonical publish',run:'runPayload → keyword_runs',snapshots:'sourceSnapshots → product_snapshots',winners:'winnerProducts → winner_products',state:'statePayload → spx_keyword_state',countParityRequired:true,serverMutationOnExport:false},exportMode:'selected-pending-durable-canonical-v1.5.22',serverRequestsDuringExport:0,hashMode:'deferred-on-import',selectedCount:keys.length};
    const parts=['{'];const entries=Object.entries(meta);entries.forEach(([key,value],index)=>parts.push(`${index?',':''}${JSON.stringify(key)}:${JSON.stringify(value)}`));parts.push(`${entries.length?',':''}"rows":[`);
    let exported=0,firstRow=true;const errors=[];
    for(let offset=0;offset<keys.length;offset+=chunkSize){
      const chunk=keys.slice(offset,offset+chunkSize);
      setText('spx-stop-summary-reason',`선택 업로드 대기 JSON 준비 ${fmt(Math.min(offset+chunk.length,keys.length))}/${fmt(keys.length)} · 파일 조각 작성 중...`);
      const response=await runtimeMessage({type:'SPX_PENDING_UPLOAD_EXPORT_SELECTED_V117',keys:chunk});
      if(response?.ok!==true)throw new Error(response?.error||'선택 업로드 대기 내보내기 실패');
      const batchRows=Array.isArray(response?.data?.rows)?response.data.rows:[],batchErrors=Array.isArray(response?.data?.errors)?response.data.errors:[];
      for(const row of batchRows){if(!firstRow)parts.push(',');parts.push(JSON.stringify(row));firstRow=false;exported++;}
      errors.push(...batchErrors);
      await new Promise((resolve)=>setTimeout(resolve,0));
    }
    parts.push(`],"exportedCount":${exported},"unavailableCount":${errors.length},"errors":${JSON.stringify(errors)}}`);
    const blob=new Blob(parts,{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a'),filename=`서버업로드대기_선택_${keys.length}건_${stamp}.json`;
    a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
    return{selectedCount:keys.length,exportedCount:exported,unavailableCount:errors.length,bytes:blob.size,filename};
  }
  async function downloadAutomationSummary(format='csv') {
    const summary=currentAutomationSummary;if(!summary)return;
    if(recentHistoryExportBusyV138){setText('spx-stop-summary-reason','최근수집내역 파일 저장이 이미 진행 중입니다. 완료될 때까지 기다려 주세요.');return;}
    recentHistoryExportBusyV138=true;
    const jsonButton=getUiElement('spx-stop-summary-json',{repair:false}),csvButton=getUiElement('spx-stop-summary-csv',{repair:false});
    if(jsonButton)jsonButton.disabled=true;if(csvButton)csvButton.disabled=true;
    try{
      /* v1.3.8: 저장 버튼은 '현재 화면에 이미 보이는 필터 결과'를 그대로 저장합니다.
         클릭 순간 업로드상태를 다시 전수조회하지 않아 100건 이상에서도 저장 시작이 즉시 보입니다. */
      applyRecentHistorySearchV117();
      /* v1.5.3: 선택 pending JSON은 상단 최근수집 필터 결과가 0건이어도 저장되어야 합니다.
         예: 최근수집 '서버 업로드 대기'=0건이지만 하단 Local pending=537건 선택 상태. */
      if(format==='json'&&pendingUploadSelectionKeysV10154.size>0){
        const saved=await downloadSelectedPendingJsonV153(),mb=(saved.bytes/1024/1024).toFixed(saved.bytes>=10*1024*1024?1:2);
        setText('spx-stop-summary-reason',`선택 업로드 대기 ${fmt(saved.selectedCount)}건 JSON 저장 시작 ✓ · Manager Upload v2 ${fmt(saved.exportedCount)}건 · 복구불가 ${fmt(saved.unavailableCount)}건 · ${mb}MB`);
        return;
      }
      const visibleRows=currentVisibleHistoryExportRowsV133(summary);
      if(!visibleRows.length)throw new Error('현재 검색·필터 결과에 저장할 항목이 없습니다.');
      const stamp=new Date().toISOString().replace(/[:.]/g,'-'),filterLabel=safeDownloadPart(recentHistoryFilterLabelV133()),base=`최근수집내역_${filterLabel}_${visibleRows.length}건_${stamp}`;
      if(format==='json'){
        setText('spx-stop-summary-reason',`현재 표시 ${fmt(visibleRows.length)}건 · JSON 저장 준비 0/${fmt(visibleRows.filter((row)=>['saved','requeued'].includes(String(row?.status||''))).length)}...`);
        const pack=await loadFilteredHistoryExportPackageV133(visibleRows);
        setText('spx-stop-summary-reason',`JSON 파일 작성 중 · ${fmt(pack.exportedCount)}건...`);
        await new Promise((resolve)=>setTimeout(resolve,0));
        const bytes=triggerManagerJsonDownloadV138(pack,`${base}.json`),mb=(bytes/1024/1024).toFixed(bytes>=10*1024*1024?1:2);
        setText('spx-stop-summary-reason',`현재 필터 ${fmt(pack.visibleCount)}건 JSON 저장 시작 ✓ · Manager Upload v2 ${fmt(pack.exportedCount)}건 · 업로드 불가/원본 부족 ${fmt(pack.unavailableCount)}건 · ${mb}MB`);
      }else{
        const text=filteredHistoryCsvV133(visibleRows);
        triggerTextDownloadV117(text,'text/csv;charset=utf-8',`${base}.csv`);
        setText('spx-stop-summary-reason',`현재 필터 ${fmt(visibleRows.length)}건 CSV 저장 완료 · Excel 확인용 요약`);
      }
    }catch(error){setText('spx-stop-summary-reason',`파일 저장 실패 · ${String(error?.message||error)}`);}
    finally{recentHistoryExportBusyV138=false;if(jsonButton)jsonButton.disabled=false;if(csvButton)csvButton.disabled=false;}
  }

  function showAutomationStopSummary(summary,{force=false}={}) {
    if (!summary || typeof summary !== 'object' || (!force && summary.autoPopup===false)) return;
    summary=normalizeAutomationSummaryForHistoryReset(summary);
    const summaryMode = String(summary.mode || '');
    const summaryLabel = String(summary.runLabel || '');
    /* 연속·로컬DB·대기열·지정키워드 실행은 완료/중단 뒤 실제 처리 결과와 사유를 다시 보여줍니다.
       화면표시는 runHistory 로컬 상태만 사용하며 Supabase를 추가 조회하지 않습니다. */
    const automated = summary.workScope !== 'manual' &&
      (['full','local','refresh'].includes(summaryMode) || /연속|대기열|로컬DB|지정키워드|선택 키워드 순차/.test(summaryLabel));
    const hasActivity = summary._historyVisibleActivity!==undefined?summary._historyVisibleActivity:(Number(summary.processedCount || 0) > 0 || Boolean(summary.interruptedKeyword) || (Array.isArray(summary.history) && summary.history.length > 0));
    if (!automated || !hasActivity) return;
    const id = stopSummaryIdentity(summary);
    if (!force && id && (lastShownStopSummaryId === id || readShownStopSummaryId() === id)) return;
    const modal = getUiElement('spx-stop-summary-modal', { repair:false });
    if (!modal) return;
    if(summary.live!==true)rememberShownStopSummaryId(id);currentAutomationSummary=summary;const historyOpen=getUiElement('spx-stop-summary-open',{repair:false});if(historyOpen)historyOpen.hidden=false;
    const isCompleted=/완료|종료/.test(String(summary.reason||''))&&!/중단/.test(String(summary.reason||''));
    setText('spx-stop-summary-title', summary.pendingPanelOnly===true?'서버 업로드 상태':`${summary.runLabel || '연속 수집'} ${summary.live===true?'진행 내역':(isCompleted?'결과':'중단 이력')}`);
    setText('spx-stop-summary-reason', summary.reason || '사용자 중단');
    setText('spx-stop-count-success', Number(summary.savedCount || 0).toLocaleString('ko-KR'));
    applyHistoryCumulativeCountsV1628();
    setText('spx-stop-count-requeued', Number(summary.requeuedCount || 0).toLocaleString('ko-KR'));
    setText('spx-stop-count-below-criteria', Number(summary.belowCriteriaCount || 0).toLocaleString('ko-KR'));
    setText('spx-stop-count-excluded', Number(summary.excludedCount || 0).toLocaleString('ko-KR'));
    setText('spx-stop-count-failed', Number(summary.failedCount || 0).toLocaleString('ko-KR'));
    setText('spx-stop-count-skipped', Number(summary.skippedCount || 0).toLocaleString('ko-KR'));
    const skippedCount=Number(summary.skippedCount||0), deferredCount=Number(summary.deferredCount||0);
    const extraCounts=[skippedCount?`건너뜀 ${skippedCount.toLocaleString('ko-KR')}`:'',deferredCount?`후순위 ${deferredCount.toLocaleString('ko-KR')}`:''].filter(Boolean);
    setText('spx-stop-summary-meta', `처리 ${Number(summary.processedCount || 0).toLocaleString('ko-KR')}개 · 상품 ${Number(summary.collectedProductCount || 0).toLocaleString('ko-KR')}개${summary.live===true&&summary.currentKeyword?` · 현재 ${summary.currentKeyword}`:''}${extraCounts.length?` · ${extraCounts.join(' · ')}`:''} · ${formatStopDuration(summary.durationMs)}`);
    const details = getUiElement('spx-stop-history-details', { repair:false });
    /* 완료 직후 수집/제외/실패 이유를 바로 확인할 수 있도록 기본 펼침. 이력은 runHistory 로컬 데이터만 사용합니다. */
    if (details) details.hidden = false;
    const toggle = getUiElement('spx-stop-history-toggle', { repair:false });
    if (toggle) { toggle.textContent = '키워드 이력 접기 ▴'; toggle.setAttribute('aria-expanded', 'true'); }
    renderStopSummaryHistory(summary);
    if(legacyHistoryFallbackV1631)modal.hidden = false;
    void refreshHistoryUploadStatesV10154(summary,{force:true});
    void refreshPendingSelectionListV10154();
  }
  let legacyHistoryFallbackV1631=false;
  async function openPersistentCollectionHistoryV1631(){
    try{
      const response=await runtimeMessage({type:'SPX_HISTORY_WINDOW_OPEN_V1631'});
      if(response?.ok===true)return true;
      console.warn('[SPX] 독립 최근수집내역 창 열기 실패',response?.error||'');
    }catch(error){console.warn('[SPX] 독립 최근수집내역 창 열기 실패',error?.message||error);}
    legacyHistoryFallbackV1631=true;return openLatestAutomationSummary(); // browser without popup-window capability
  }

  function openAutomationSummaryLoadingV111(){
    const modal=getUiElement('spx-stop-summary-modal',{repair:false});if(!modal)return false;
    modal.hidden=false;setText('spx-global-pending-total',tabSessionStats.uploadPendingDb!=null&&Number.isFinite(Number(tabSessionStats.uploadPendingDb))?`${fmt(tabSessionStats.uploadPendingDb)}건 · 재확인 중`:'확인 중');setText('spx-stop-summary-title','최근 수집내역');setText('spx-stop-summary-reason','최근 수집내역 불러오는 중...');
    setText('spx-stop-summary-meta','로컬 상태 확인 중...');
    const list=getUiElement('spx-stop-history-list',{repair:false});if(list)list.innerHTML='<div class="spx-stop-history-empty">최근 수집내역 불러오는 중...</div>';
    return true;
  }

  async function openLatestAutomationSummary() {
    openAutomationSummaryLoadingV111();
    await persistentHistoryResetReadyV101510.catch(()=>0);
    let summary=currentAutomationSummary;
    try{const stored=await chrome.storage.local.get(AUTO_KEY),automation=stored?.[AUTO_KEY]||{};if(automation.running===true)summary=liveAutomationSummaryFromState(automation)||summary;else if(!summary)summary=automation.lastRunSummary||null;}catch(_){}
    summary=summary?normalizeAutomationSummaryForHistoryReset(summary):null;
    const visible=summary&&(summary._historyVisibleActivity!==false)&&(Boolean(summary.interruptedKeyword)||(Array.isArray(summary.history)&&summary.history.length>0)||Number(summary.processedCount||0)>0);
    if(visible){showAutomationStopSummary(summary,{force:true});return true;}
    const pending=await refreshPendingSelectionListV10154().catch(()=>null);
    if(pending===null){setText('spx-stop-summary-title','최근 수집내역');setText('spx-stop-summary-reason','업로드 대기 상태를 확인하지 못했습니다. 기존 카운터를 유지합니다.');setText('spx-stop-summary-meta','로컬 DB 조회 실패 · 0건으로 처리하지 않음');return true;}
    if(Number(pending?.total||0)>0){
      summary={workScope:'automation',mode:'local',runLabel:'서버 업로드 상태',reason:`서버 업로드 대기 ${fmt(pending.selectable||0)}건`,pendingPanelOnly:true,processedCount:0,savedCount:0,requeuedCount:0,excludedCount:0,failedCount:0,skippedCount:0,collectedProductCount:0,durationMs:0,history:[],_historyVisibleActivity:true};
      currentAutomationSummary=summary;showAutomationStopSummary(summary,{force:true});return true;
    }
    setText('spx-stop-summary-title','최근 수집내역');setText('spx-stop-summary-reason','아직 저장된 수집 내역이 없습니다.');setText('spx-stop-summary-meta','처리 0개 · 상품 0개 · 0초');renderStopSummaryHistory({history:[]});return true;
  }

  function closeAutomationStopSummary() {
    legacyHistoryFallbackV1631=false;
    const modal = getUiElement('spx-stop-summary-modal', { repair:false });
    if (modal) modal.hidden = true;
  }
  function toggleAutomationStopHistory() {
    const details = getUiElement('spx-stop-history-details', { repair:false });
    const button = getUiElement('spx-stop-history-toggle', { repair:false });
    if (!details || !button) return;
    details.hidden = !details.hidden;
    button.textContent = details.hidden ? '키워드 이력 펼치기 ▾' : '키워드 이력 접기 ▴';
    button.setAttribute('aria-expanded', details.hidden ? 'false' : 'true');
  }
  async function restoreAutomationStopSummaryFromStorage() {
    if (contextInvalidated) return false;
    try {
      const stored = await chrome.storage.local.get([AUTO_KEY, STOP_SUMMARY_SHOWN_STORAGE_KEY]);
      const automation = stored?.[AUTO_KEY] || null;
      const summary = automation?.lastRunSummary || null;
      if (automation?.running !== false || !summary) return false;
      const id = stopSummaryIdentity(summary);
      const stoppedAt = Number(summary.stoppedAt || 0);
      const fresh = stoppedAt > 0 && Date.now() - stoppedAt <= STOP_SUMMARY_RESTORE_MAX_AGE_MS;
      const alreadyShown = id && String(stored?.[STOP_SUMMARY_SHOWN_STORAGE_KEY] || '') === id;
      // 실시간 메시지를 놓친 직후의 최근 중단만 복원합니다. 오래된 실행 이력은 새 브라우저 세션에서 자동 팝업으로 띄우지 않습니다.
      if (!fresh || alreadyShown) return false;
      showAutomationStopSummary(summary);
      return true;
    } catch (error) {
      if (!contextInvalidated) console.debug('[SPX] 중단 이력 복원 대기', error?.message || error);
    }
    return false;
  }

  function shell() {
    const host = document.body || document.documentElement;
    if (contextInvalidated || !host || !uiKeywordContext()) return false;
    if (hasCompleteUi()) return true;

    removeStaleUi();
    try {
      const el = document.createElement('aside');
      el.id = 'spx-overlay';
      el.innerHTML = `
      <div class="spx-head">
        <button class="spx-mark" id="spx-fold" type="button" data-tip="사이드바 접기" aria-label="사이드바 접기">S</button>
        <div class="spx-head-titles"><div class="spx-title">소싱 키워드 수집기</div><div class="spx-sub">v${SPX_CONTENT_BUILD_VERSION}</div></div>
        <div class="spx-head-actions">
          <button class="spx-icon-btn spx-primary-icon" id="spx-run-toggle" type="button" data-tip="진행 중인 수집을 멈춥니다." aria-label="수집 멈춤" hidden>■</button>
          <button class="spx-ip-plain" id="spx-change-ip" type="button" data-tip="현재 선택 네트워크의 공인 IP를 변경하고 네트워크 안정화 후 현재 수집 위치에서 자동 재개합니다." aria-label="IP 변경 및 네트워크 안정화">IP↻</button>
          <label class="spx-network-check" data-tip="클릭: 현재 쿠팡 URL을 선택 네트워크 전용 프로필 창에도 엽니다. 원래 탭과 다른 Chrome 탭은 닫히지 않고 기본 인터넷을 유지합니다."><input id="spx-network-toggle" type="checkbox" aria-label="현재 쿠팡 URL을 선택 네트워크 전용창에도 열기"><span class="spx-network-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><circle cx="5" cy="12" r="2.2"></circle><circle cx="19" cy="6" r="2.2"></circle><circle cx="19" cy="18" r="2.2"></circle><path d="M7 11.2 16.9 6.8M7 12.8l9.9 4.4"></path></svg></span></label>
          <button class="spx-icon-btn spx-airplane-toggle" id="spx-airplane-toggle" type="button" data-tip="휴대폰 비행기모드 상태 확인 · 클릭하여 ON/OFF 전환" aria-label="휴대폰 비행기모드 전환">✈</button>
          <button class="spx-icon-btn" id="spx-memory-cleanup" type="button" data-tip="수집기 임시 캐시·만료 메시지·사용이 끝난 대용량 참조를 해제합니다." aria-label="확장프로그램 메모리 정리">♻</button>
          <button class="spx-icon-btn" id="spx-clear-browsing" type="button" data-tip="coupang.com·www.coupang.com의 쿠키, HTTP 캐시, CacheStorage, IndexedDB, LocalStorage, ServiceWorker 등 전체 사이트 데이터를 강력 정리합니다. 다른 사이트, 확장프로그램, 프록시 설정과 네트워크 보조도구 연결은 건드리지 않습니다." aria-label="쿠팡 두 도메인 전체 사이트 데이터 강력 정리">🧹</button>
          <button class="spx-icon-btn spx-collection-settings-icon" id="spx-open-collection-settings" type="button" data-tip="수집 설정" aria-label="수집 설정"><svg viewBox="0 0 22 22" aria-hidden="true" focusable="false"><path class="spx-tune-line" d="M3 6h16M3 11h16M3 16h16"></path><circle class="spx-tune-knob k1" cx="8" cy="6" r="2"></circle><circle class="spx-tune-knob k2" cx="14" cy="11" r="2"></circle><circle class="spx-tune-knob k3" cx="10" cy="16" r="2"></circle></svg></button>
        </div>
      </div>
      <div class="spx-status-row">
        <div class="spx-live"><span class="spx-dot"></span><span id="spx-status">감지됨</span></div>
        <div class="spx-status-actions">
          <button class="spx-mode-badge" id="spx-mode-badge" type="button" data-tip="선택 상태를 확인하거나 변경합니다. 클릭하면 수집 실행 선택창이 열립니다.">선택상태</button>
          <button class="spx-skip-btn" id="spx-skip-keyword" type="button" data-tip="현재 분석을 중단하고 다음 키워드를 쿠팡에서 검색한 뒤 화면에서 멈춥니다.">다음 ⏭</button>
          <button class="spx-skip-btn spx-exclude-btn" id="spx-exclude-keyword" type="button">제외 ✕</button>
        </div>
      </div>
      <div class="spx-detect">
        <div class="spx-n" id="spx-count">0</div>
        <div class="spx-l">현재 화면 감지상품<br><button type="button" id="spx-kwlabel" class="spx-keyword-copy" aria-label="현재 키워드 복사" title="클릭하여 현재 키워드 복사">-</button></div>
        <div class="spx-analysis-actions"><button class="spx-btn" id="spx-scan">키워드 분석</button><button class="spx-btn" id="spx-category-candidates" type="button" hidden>카테고리 키워드 찾기</button><button class="spx-icon-btn spx-analysis-next" id="spx-step-once" type="button" data-tip="현재 분석을 중단하고 다음 키워드를 쿠팡에서 검색한 뒤 키워드 분석을 자동 시작합니다." aria-label="다음 키워드 검색 후 분석">⏭</button></div>
      </div>
      <div class="spx-auto" id="spx-auto" style="display:none">
        <span class="spx-auto-dot"></span><span id="spx-auto-text">자동 소싱 실행 중</span><span id="spx-auto-runtime" class="spx-auto-runtime"><button type="button" id="spx-runtime-mode" title="자동/수동 시간 표시 전환">자동</button><button type="button" id="spx-runtime-value" title="수동 모드에서 클릭하면 수동 표시시간만 초기화">00:00:00</button></span><button id="spx-next-now" class="spx-auto-next" type="button" hidden>Next</button>
      </div>
      <div class="spx-discovered-wrap" id="spx-discovered-wrap">
        <div class="spx-discovered-head" id="spx-discovered" title="현재 검색결과에서 발견한 다음 분석 후보">발견 0개 · 수집 후 표시</div>
        <div class="spx-discovered-list" id="spx-discovered-list" hidden></div>
      </div>
      <div class="spx-progress" id="spx-prog" style="display:none">
        <div class="spx-pbar"><div class="spx-pfill" id="spx-pfill"></div></div>
        <div class="spx-ptxt"><span id="spx-ptxt">대기</span><span id="spx-ptime"></span></div>
        <div class="spx-live-log" id="spx-live-log" aria-label="상태로그"></div>
        <div class="spx-log-resize-handle" id="spx-log-resize-handle" role="separator" aria-orientation="horizontal" aria-label="상태로그 높이 조절" tabindex="0" data-tip="위아래로 드래그하거나 방향키 ↑↓로 상태로그 높이를 조절합니다."><span></span></div>
      </div>
      <div class="spx-metrics" id="spx-body"></div>
      <div class="spx-foot">
        <div class="spx-foot-toggles">
          <label class="spx-auto-upload-toggle" data-tip="고속 수집 · 기존 안정 수집은 기본값으로 유지하며 체크 시 안전보존 후 업로드와 다음 키워드 병행 및 빠른 스크롤을 사용합니다.">
            <input id="spx-fast-upload-overlap-footer" type="checkbox"><span>고속</span>
          </label>
          <label class="spx-auto-upload-toggle" data-tip="체크하면 수집 완료 결과를 로컬DB에 먼저 쓰지 않고 서버DB로 바로 올립니다. 서버 저장이 실패할 때만 로컬DB에 안전 보관해 업로드 대기로 전환합니다. 해제하면 처음부터 로컬 업로드 대기로 저장합니다.">
            <input id="spx-auto-upload" type="checkbox"><span>자동 업로드</span>
          </label>
          <label class="spx-auto-upload-toggle spx-keyword-toggle" data-tip="키워드1 = 일반 판매자 상품 키워드 수집 · 검색 결과의 일반 판매자와 확인된 판매자샵 상품의 실제 상품명 원문을 조합 없이 발견키워드에 저장합니다. 자동 미수집 승격 없음.">
            <input id="spx-prompt-keyword-1" type="checkbox"><span>키워드1</span>
          </label>
          <label class="spx-auto-upload-toggle spx-keyword-toggle" data-tip="키워드2 = 현재 검색화면과 판매량순·최신순 1페이지의 원본 상품명을 발견키워드에 저장합니다. 두 정렬에서 겹치지 않는 상품은 기존 효자 기준으로 추가 검증합니다. 기본 검색 순위·표본은 유지하며 추천의 추천은 추적하지 않습니다.">
            <input id="spx-prompt-keyword-2" type="checkbox"><span>키워드2</span>
          </label>
          <label class="spx-auto-upload-toggle spx-auto-extra-page-toggle" data-tip="해제하면 수집 기준 설정의 최대 검색 페이지를 절대 상한으로 따릅니다. 켜면 기본 최대 N페이지까지 확인한 뒤에도 추가 분석 신호가 남은 키워드만 N+1부터 한 페이지씩 조건부로 추가 확인합니다.">
            <input id="spx-auto-extra-page" type="checkbox"><span>추가 수집</span>
          </label>
        </div>
        <div class="spx-foot-main-actions">
          <button class="spx-icon-btn spx-history-open-btn" id="spx-stop-summary-open" type="button" data-tip="최근 수집 내역을 엽니다. 이전 실행의 수집·건너뜀·제외·실패 이유를 새 수집 중에도 다시 확인할 수 있습니다." aria-label="최근 수집 내역 열기">▤</button>
          <button class="spx-icon-btn spx-history-open-btn spx-pending-upload-btn" id="spx-pending-upload-now" type="button" data-tip="로컬DB 업로드 대기를 서버 상태와 대조해 안전하게 정리·전송합니다." aria-label="업로드 대기 서버로 전송">⇧</button>
          <button class="spx-btn spx-foot-upload-btn" id="spx-upload" disabled>먼저 분석하세요</button>
        </div>
        <button class="spx-btn spx-admin-override-btn" id="spx-admin-override-upload" type="button" hidden disabled data-tip="현재 키워드가 기준 미달이어도 탈락 사유와 원래 등급을 보존한 채 서버 관리자 권한으로 통과 업로드합니다.">관리자 통과 · 서버 올리기</button>
        <div class="spx-dbline"><span id="spx-dbinfo">로컬 DB 확인 중</span><button id="spx-session-reset" class="spx-session-reset-btn" type="button" data-tip="이번 탭의 표시 카운터만 0으로 바꿉니다. 로컬 수집내역·업로드 대기를 영구 삭제하려면 [최근 수집내역] → [초기화]를 이용하세요." aria-label="수집 카운트와 수집내역 초기화">↻</button></div>
      </div>
      <div id="spx-settings-modal" class="spx-settings-backdrop" hidden>
        <section class="spx-settings-drawer" role="dialog" aria-modal="true" aria-labelledby="spx-settings-title">
          <div class="spx-settings-head"><div><b id="spx-settings-title">수집 기준 설정</b><span>하나의 수집 기준과 공통 실행 설정을 관리합니다.</span></div><button id="spx-settings-close" type="button" aria-label="닫기">×</button></div>
          <div class="spx-settings-tabs"><button type="button" class="active" data-spx-profile-tab="manual">수집</button><button type="button" data-spx-profile-tab="common">설정</button><button type="button" data-spx-profile-tab="network">네트워크 · 데이터 사용</button></div>
          <div class="spx-settings-body">
            <div class="spx-profile-panel active" data-spx-profile-panel="manual">
              <p class="spx-profile-note">현재 사용하는 단일 수집 기준입니다. 단건·연속·로컬DB·대기열 수집이 같은 기준을 사용합니다.</p>
              <fieldset><legend tabindex="0" data-tip="현재 페이지에서 얼마나 많은 상품을 확인하고 저장할지 정합니다. 체크를 끄면 최대 1페이지로 동작합니다.">수집 범위</legend>
                <label class="spx-setting-row" data-tip="수집에 사용할 기본 최대 검색 페이지입니다. 체크 해제 시 최대 1페이지입니다. 체크한 N페이지는 반드시 N페이지까지 수집한다는 뜻이 아니며, 수집조건을 충족하면 N 이전에도 즉시 완료합니다. 하단의 필요 키워드 추가 확인을 켜면 기본 최대 N까지 확인했는데도 추가 분석이 필요한 키워드만 N+1부터 한 페이지씩 더 확인합니다."><input class="spx-setting-use" data-mode="manual" data-key="maxPages" type="checkbox"><span>키워드 하나당 최대 검색 페이지</span><input data-mode="manual" data-field="maxPagesPerKeyword" type="number" min="1" max="50"><button type="button" data-reset-mode="manual" data-reset-field="maxPagesPerKeyword">↺</button></label>
                <label class="spx-setting-row" data-tip="광고를 뺀 자연노출 상품을 이 수량까지 확인합니다. 현재 페이지에 상품이 적으면 실제 수집량은 더 적을 수 있습니다."><input class="spx-setting-use" data-mode="manual" data-key="targetOrganic" type="checkbox"><span>광고 제외 상품 수집 목표</span><input data-mode="manual" data-field="sourceDataTargetOrganic" type="number" min="1" max="200"><button type="button" data-reset-mode="manual" data-reset-field="sourceDataTargetOrganic">↺</button></label>
                <label class="spx-setting-row" data-tip="한 키워드에서 로컬 DB에 보관할 상품 수의 상한입니다. 수집 중 발견한 상품이 많아도 이 값을 넘겨 저장하지 않습니다."><input class="spx-setting-use" data-mode="manual" data-key="maxProducts" type="checkbox"><span>키워드 하나당 저장할 최대 상품 수</span><input data-mode="manual" data-field="sourceDataMaxProducts" type="number" min="1" max="200"><button type="button" data-reset-mode="manual" data-reset-field="sourceDataMaxProducts">↺</button></label>
                <label class="spx-setting-row" data-tip="리뷰는 적지만 실제 구매가 많은 상품을 놓치지 않도록 상세페이지에서 추가 확인할 상품 수입니다."><input class="spx-setting-use" data-mode="manual" data-key="lowReview" type="checkbox"><span>리뷰 적은 상품 상세확인 수</span><input data-mode="manual" data-field="lowReviewSampleSize" type="number" min="0" max="20"><button type="button" data-reset-mode="manual" data-reset-field="lowReviewSampleSize">↺</button></label>
              </fieldset>
              <fieldset><legend tabindex="0" data-tip="상품 상세페이지 추천영역은 노출만으로 효자상품에 넣지 않습니다. 상품명·가격·리뷰·별점·배송유형을 상세페이지에서 다시 확인합니다.">상세 추천상품 추가 확인</legend>
                <label class="spx-setting-row spx-scroll-toggle" data-tip="처음 방문한 상품 상세의 추천상품을 한 번 추가 확인합니다. 추천 영역 이름과 관계없이 중복을 제거하고 기존 효자상품 기준으로 검증하며 상품명도 발견 키워드로 저장합니다. 추천상품 상세에서 또 추천을 따라가지는 않습니다."><input class="spx-setting-use" data-mode="manual" data-key="detailRecommendations" data-toggle-field="collectDetailRecommendations" type="checkbox"><span>상세페이지 추천상품도 추가 확인</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-mode="manual" data-reset-field="collectDetailRecommendations">↺</button></label>
              </fieldset>

              <fieldset><legend tabindex="0" data-tip="단건·연속·로컬DB·대기열 수집이 함께 사용하는 입력 설정입니다. 각 행에 마우스를 올리면 기능과 적용 범위를 확인할 수 있습니다.">수집입력</legend>
                              <label class="spx-setting-row spx-common-toggle" data-tip="현재 키워드와 상품명에서 다음 분석 후보를 찾습니다. 상품성이 낮은 정보성 키워드는 제외 기준을 적용합니다."><input data-common-field="autoDiscover" type="checkbox"><span>연관 키워드 자동 찾기</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="autoDiscover" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row spx-common-toggle" data-tip="ON이면 수집 완료 결과를 Supabase 서버DB에 바로 저장합니다. 서버 저장 실패 시에만 로컬DB에 안전 보관해 업로드 대기로 전환합니다. OFF이면 처음부터 로컬 업로드 대기에 저장합니다."><input data-common-field="autoUpload" type="checkbox"><span>자동 업로드</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="autoUpload" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row spx-common-toggle" data-tip="효자상품 판정에 필요한 상품명·가격·리뷰·별점·배송유형 등의 상세정보를 추가로 확인합니다."><input data-common-field="sourceDataCollection" type="checkbox"><span>효자상품용 상세 상품정보 수집</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="sourceDataCollection" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row spx-common-toggle" data-tip="현재 키워드에서 목표 자연노출 수와 판정 표본이 충분하면 불필요한 추가 탐색을 줄입니다."><input data-common-field="adaptiveFastCollect" type="checkbox"><span>목표 수량 충족 시 빠른 종료</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="adaptiveFastCollect" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row" data-tip="한 번의 연속 실행에서 처리할 키워드 수 상한입니다."><span>한 번 실행할 최대 키워드 수</span><input data-common-field="maxKeywordsPerRun" type="number" min="1" max="200"><button type="button" data-reset-common="maxKeywordsPerRun" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row" data-tip="등급과 경쟁 구조를 계산할 때 사용하는 자연노출 상품 표본 수입니다."><span>자연노출 분석 표본 수</span><input data-common-field="organicSampleSize" type="number" min="1" max="10000"><button type="button" data-reset-common="organicSampleSize" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row" data-tip="쿠팡에서 발견한 연관검색어는 넓게 발견키워드로 저장하고, 이 값은 실제 자동수집 대기열로 승격할 최대 수입니다."><span>키워드마다 자동수집할 발견키워드 수</span><input data-common-field="candidatesPerKeyword" type="number" min="0" max="100"><button type="button" data-reset-common="candidatesPerKeyword" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row" data-tip="상품명·부품·소모품·재질·크기·기능 등 구매 의도가 있는 키워드만 남기는 최소 점수입니다."><span>상품 관련 키워드 최소 점수</span><input data-common-field="minIntentScore" type="number" min="0" max="100"><button type="button" data-reset-common="minIntentScore" title="기본값으로 되돌리기">↺</button></label>
                            </fieldset>
              <fieldset><legend tabindex="0" data-tip="수집한 상품을 효자상품으로 인정할 기준입니다. 모든 수집 방식이 같은 값을 사용합니다.">효자상품 판정 기준</legend>
                              <label class="spx-setting-row" data-tip="월판매 추정치 또는 최근 28일 구매 수의 최소값입니다."><span>월판매·28일 구매 최소</span><input data-common-field="winnerMonthlySalesMin" type="number" min="1" max="100000"><button type="button" data-reset-common="winnerMonthlySalesMin" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row" data-tip="효자상품으로 인정할 누적 리뷰 하한입니다."><span>누적리뷰 최소</span><input data-common-field="winnerReviewMin" type="number" min="0" max="100000"><button type="button" data-reset-common="winnerReviewMin" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row" data-tip="효자상품으로 인정할 누적 리뷰 상한입니다."><span>누적리뷰 최대</span><input data-common-field="winnerReviewMax" type="number" min="1" max="1000000"><button type="button" data-reset-common="winnerReviewMax" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row" data-tip="최근에도 판매 흐름이 있는지 확인하는 최근 28일 리뷰 최소값입니다."><span>최근 28일 리뷰 최소</span><input data-common-field="winnerRecentReviewMin" type="number" min="0" max="100000"><button type="button" data-reset-common="winnerRecentReviewMin" title="기본값으로 되돌리기">↺</button></label>
                            </fieldset>
              <fieldset><legend tabindex="0" data-tip="재수집 알림과 서버 요청 사이의 대기 범위를 모든 수집 방식에 적용합니다.">재수집·요청 간격</legend>
                              <label class="spx-setting-row spx-common-toggle"><input data-common-field="autoWeeklyRecollectEnabled" type="checkbox"><span>재수집 필요 배지 자동 계산</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="autoWeeklyRecollectEnabled" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row"><span>재수집 알림 기준(일)</span><input data-common-field="autoWeeklyRecollectDays" type="number" min="3" max="30"><button type="button" data-reset-common="autoWeeklyRecollectDays" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row spx-common-toggle"><input data-common-field="humanDelayEnabled" type="checkbox"><span>서버 요청 사이 ms 범위 적용</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="humanDelayEnabled" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row"><span>일반 요청 대기(ms)</span><span class="spx-range-pair"><input data-common-field="humanDelayMinMs" type="number" min="0" max="120000"><span class="spx-range-separator">~</span><input data-common-field="humanDelayMaxMs" type="number" min="0" max="180000"></span><button type="button" data-reset-common="humanDelayMinMs" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row"><span>다음 페이지·키워드 대기(ms)</span><span class="spx-range-pair"><input data-common-field="nextNavigationDelayMinMs" type="number" min="0" max="120000"><span class="spx-range-separator">~</span><input data-common-field="nextNavigationDelayMaxMs" type="number" min="0" max="180000"></span><button type="button" data-reset-common="nextNavigationDelayMinMs" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row"><span>일시 오류 재시도 횟수</span><input data-common-field="humanRetryMax" type="number" min="0" max="5"><button type="button" data-reset-common="humanRetryMax" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row"><span>오류 재시도 대기(ms)</span><span class="spx-range-pair"><input data-common-field="humanRetryMinMs" type="number" min="1000" max="120000"><span class="spx-range-separator">~</span><input data-common-field="humanRetryMaxMs" type="number" min="1000" max="300000"></span><button type="button" data-reset-common="humanRetryMinMs" title="기본값으로 되돌리기">↺</button></label>
                              <label class="spx-setting-row" data-tip="수동 IP↻과 수집 중 차단 복구가 함께 사용하는 비행기 모드 유지시간입니다. 4~300초이며 내부 설정은 ms로 저장합니다."><span>비행기 모드 유지(초)</span><input data-common-field="airplaneHoldMs" type="number" min="4" max="300" step="1"><button type="button" data-reset-common="airplaneHoldMs" title="기본값 20초로 되돌리기">↺</button></label>
                            </fieldset>
              <fieldset><legend tabindex="0" data-tip="쿠팡 차단 복구의 🧹 캐시·사이트 데이터 정리 범위를 선택합니다.">차단 복구 · 쿠팡 캐시 데이터</legend>
                <label class="spx-setting-row spx-common-toggle" data-tip="체크하면 차단 복구의 🧹 단계에서 쿠팡 쇼핑 데이터와 함께 WING 로그인 데이터도 정리합니다. 체크 해제하면 쿠팡 쇼핑 캐시는 정리하지만 WING 로그인 쿠키와 wing.coupang.com 저장소는 보존합니다."><input data-common-field="blockRecoveryDeleteWingData" type="checkbox"><span>🧹 차단 복구 시 쿠팡 WING 로그인 데이터도 삭제</span><span class="spx-toggle-state">WING 포함</span><button type="button" data-reset-common="blockRecoveryDeleteWingData" title="기본값으로 되돌리기">↺</button></label>
                <p class="spx-profile-note">체크 해제 = 쿠팡 쇼핑 캐시는 정리 · WING 로그인은 보존</p>
              </fieldset>
            </div>
            <div class="spx-profile-panel" data-spx-profile-panel="common">
              <p class="spx-profile-note">설정 탭은 화면 로딩·자동 탐색·플랫폼 교차 실행처럼 수집 전반에 공통 적용되는 항목입니다.</p>
              
              <fieldset><legend tabindex="0" data-tip="동적 렌더링 페이지에서 상품 카드와 이미지가 누락되지 않도록 작은 이동을 부드럽게 나누고, 간헐적인 보정과 읽기 휴지기를 적용합니다.">동적 화면 로딩 및 스크롤 설정</legend>
                <label class="spx-setting-row spx-common-toggle" data-tip="쿠팡 상품 카드가 늦게 나타나는 구간을 자연스럽게 이동해 지연 로딩을 돕습니다. 보안확인이나 캡차를 우회하지 않습니다."><input data-common-field="autoScrollEnabled" type="checkbox"><span>페이지 로딩 자동스크롤 사용</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="autoScrollEnabled" title="기본값으로 되돌리기">↺</button></label>
                <label class="spx-setting-row spx-common-toggle" data-tip="각 스크롤마다 입력 범위 안에서 이동폭과 대기시간을 새로 선택합니다. 가속·감속, 오버스크롤 보정, 읽기 휴지기는 자동으로 섞입니다."><input data-common-field="autoScrollRandom" type="checkbox"><span>스크롤 범위 랜덤 적용</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="autoScrollRandom" title="기본값으로 되돌리기">↺</button></label>
                <label class="spx-setting-row" data-tip="한 번의 유기적 스크롤 목표 이동폭입니다. 브라우저 렌더링 부하를 낮추기 위한 권장 기본값은 150~450px입니다."><span>이동폭(px) 최소~최대</span><span class="spx-range-pair"><input data-common-field="scrollStepMin" type="number" min="80" max="1200"><span class="spx-range-separator">~</span><input data-common-field="scrollStepMax" type="number" min="80" max="1200"></span><button type="button" data-reset-common="scrollStepMin" title="기본값 150~450px로 되돌리기">↺</button></label>
                <label class="spx-setting-row" data-tip="스크롤 이동 후 DOM과 이미지가 렌더링될 시간을 확보합니다. 권장 기본값은 250~850ms이며 주기적으로 1.5~3.5초 읽기 휴지기가 추가됩니다."><span>대기시간(ms) 최소~최대</span><span class="spx-range-pair"><input data-common-field="scrollDelayMin" type="number" min="50" max="5000"><span class="spx-range-separator">~</span><input data-common-field="scrollDelayMax" type="number" min="50" max="5000"></span><button type="button" data-reset-common="scrollDelayMin" title="기본값 250~850ms로 되돌리기">↺</button></label>
                <label class="spx-setting-row spx-common-toggle" data-tip="해제하면 키워드 하나당 최대 검색 페이지 설정이 단건·지정·연속·재수집 등 모든 수집 실행의 절대 상한입니다. 체크하면 기본 최대 N페이지까지 같은 조기종료 조건으로 확인한 뒤에도 추가 분석 신호가 남은 키워드만 N+1부터 한 페이지씩 더 확인합니다. 고정 3페이지 제한은 사용하지 않습니다."><input data-common-field="autoExtraPageEnabled" type="checkbox"><span>추가 수집</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="autoExtraPageEnabled" title="기본값으로 되돌리기">↺</button></label>
                <label class="spx-setting-row" data-tip="검색결과 준비, DOM 확인, 페이지 합산·최종 저장 단계에서 새 활동 없이 기다릴 제한시간을 매번 이 범위 안에서 무작위로 선택합니다. 기본값은 90,000~120,000ms입니다."><span>페이지 로딩·합산 최대 대기시간(ms) 최소~최대</span><span class="spx-range-pair"><input data-common-field="pageLoadingMaxWaitMinMs" type="number" min="30000" max="900000" step="1000"><span class="spx-range-separator">~</span><input data-common-field="pageLoadingMaxWaitMaxMs" type="number" min="30000" max="900000" step="1000"></span><button type="button" data-reset-common="pageLoadingMaxWaitMinMs" title="기본값 90,000~120,000ms로 되돌리기">↺</button></label>
              </fieldset>
              
              <fieldset><legend tabindex="0" data-tip="키워드를 직접 입력하지 않아도 카테고리·계절 씨앗을 보충하며 연속 탐색하는 공통 설정입니다.">전체 자동 탐색</legend>
                <label class="spx-setting-row spx-common-toggle" data-tip="현재 월과 맞는 계절·장마·신학기 키워드를 일반 카테고리보다 먼저 탐색합니다."><input data-common-field="fullExploreSeasonBoost" type="checkbox"><span>계절·이벤트 키워드 우선</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="fullExploreSeasonBoost" title="기본값으로 되돌리기">↺</button></label>
                <label class="spx-setting-row spx-common-toggle" data-tip="대기열이 비면 다음 카테고리 씨앗을 자동으로 보충합니다."><input data-common-field="fullExploreAutoRefill" type="checkbox"><span>대기열 자동 보충</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="fullExploreAutoRefill" title="기본값으로 되돌리기">↺</button></label>
                <label class="spx-setting-row spx-common-toggle" data-tip="사용자가 중단할 때까지 회차 제한 없이 계속 탐색합니다."><input data-common-field="continuousExplore" type="checkbox"><span>연속 탐색</span><span class="spx-toggle-state">사용</span><button type="button" data-reset-common="continuousExplore" title="기본값으로 되돌리기">↺</button></label>
                <label class="spx-setting-row" data-tip="전체 자동 탐색을 시작할 때 준비하는 초기 키워드 수입니다."><span>시작 키워드 수</span><input data-common-field="fullExploreSeedCount" type="number" min="1" max="60"><button type="button" data-reset-common="fullExploreSeedCount" title="기본값으로 되돌리기">↺</button></label>
                <label class="spx-setting-row" data-tip="같은 씨앗을 다시 탐색하기 전에 기다리는 기간입니다."><span>같은 씨앗 재수집 유예일</span><input data-common-field="fullExploreCooldownDays" type="number" min="1" max="365"><button type="button" data-reset-common="fullExploreCooldownDays" title="기본값으로 되돌리기">↺</button></label>
                <label class="spx-setting-row" data-tip="한 회차에서 새 씨앗을 보충할 최대 횟수입니다."><span>회차당 자동 보충 횟수</span><input data-common-field="fullExploreMaxRefills" type="number" min="0" max="100"><button type="button" data-reset-common="fullExploreMaxRefills" title="기본값으로 되돌리기">↺</button></label>
                <label class="spx-setting-row" data-tip="처리할 새 후보가 없을 때 다시 확인하는 ms 범위입니다."><span>새 후보 재확인(ms)</span><span class="spx-range-pair"><input data-common-field="continuousRetryMinMs" type="number" min="1000" max="86400000"><span class="spx-range-separator">~</span><input data-common-field="continuousRetryMaxMs" type="number" min="1000" max="86400000"></span><button type="button" data-reset-common="continuousRetryMinMs" title="기본값으로 되돌리기">↺</button></label>
              </fieldset>
              

            </div>
            <div class="spx-profile-panel" data-spx-profile-panel="network">
              <p class="spx-profile-note">NetworkHost 3.0.34 경량모드입니다. 기본 네트워크는 Windows 기본 인터넷, 전용 네트워크는 선택한 NetworkHost 어댑터입니다. 쿠팡 검색과 상세는 같은 수집 프로필을 사용하므로 두 항목을 같은 네트워크로 맞춰야 합니다.</p>
              <fieldset class="spx-network-route-fieldset"><legend tabindex="0" data-tip="쿠팡 검색과 상세페이지의 수집 프로필을 선택합니다. NetworkHost 3.0.34에서는 두 항목이 같은 프로필을 사용하므로 동일한 네트워크를 선택해야 합니다.">쿠팡 수집 네트워크</legend>
                <div class="spx-network-route-actions"><button type="button" class="spx-btn mini" data-network-route-all="system">모두 기본 네트워크</button><button type="button" class="spx-btn mini" data-network-route-all="dedicated">모두 전용 네트워크</button><small>쿠팡 검색·상세·효자상품 경로에만 적용 · WING · Supabase · 일반 인터넷은 항상 Windows 기본 인터넷</small></div>
                <div class="spx-network-route-row"><span><b>쿠팡 실제 검색수집</b><small>/np/search</small></span><label><input type="radio" name="networkRouteCoupangSearch" data-network-route-field="networkRouteCoupangSearch" value="system"><i>기본 네트워크</i></label><label><input type="radio" name="networkRouteCoupangSearch" data-network-route-field="networkRouteCoupangSearch" value="dedicated"><i>전용 네트워크</i></label></div>
                <div class="spx-network-route-row"><span><b>쿠팡 상세페이지</b><small>/vp/products/...</small></span><label><input type="radio" name="networkRouteCoupangDetail" data-network-route-field="networkRouteCoupangDetail" value="system"><i>기본 네트워크</i></label><label><input type="radio" name="networkRouteCoupangDetail" data-network-route-field="networkRouteCoupangDetail" value="dedicated"><i>전용 네트워크</i></label></div>
              </fieldset>
              <fieldset class="spx-network-route-fieldset"><legend tabindex="0" data-tip="효자상품 N개 펼치기에서 실제 썸네일 이미지를 어느 네트워크로 내려받을지 선택합니다.">효자상품 이미지</legend>
                <div class="spx-network-route-row"><span><b>효자상품 썸네일</b><small>펼치기 시에만 지연 로드</small></span><label><input type="radio" name="winnerImageNetworkMode" data-winner-image-network-field="winnerImageNetworkMode" value="system"><i>기본 네트워크</i></label><label><input type="radio" name="winnerImageNetworkMode" data-winner-image-network-field="winnerImageNetworkMode" value="dedicated"><i>전용 네트워크</i></label></div>
              </fieldset>
              <fieldset class="spx-network-route-fieldset"><legend tabindex="0" data-tip="수집 단계·파서·판정은 바꾸지 않고 페이지/텍스트, 이미지·영상, 웹폰트의 데이터 사용 방식을 각각 선택합니다.">쿠팡 페이지 리소스</legend>
                <div class="spx-network-route-row"><span><b>페이지/텍스트 데이터</b><small>절약: Save-Data 요청 · HTML·JSON·JS·XHR은 수집 품질 때문에 유지</small></span><label><input type="radio" name="collectionPageDataMode" data-resource-mode-field="collectionPageDataMode" value="save"><i>절약</i></label><label><input type="radio" name="collectionPageDataMode" data-resource-mode-field="collectionPageDataMode" value="normal"><i>다운로드 함</i></label></div>
                <div class="spx-network-route-row"><span><b>이미지·영상</b><small>기본값: 다운로드 안 함</small></span><label><input type="radio" name="collectionMediaMode" data-resource-mode-field="collectionMediaMode" value="block"><i>다운로드 안 함</i></label><label><input type="radio" name="collectionMediaMode" data-resource-mode-field="collectionMediaMode" value="load"><i>다운로드 함</i></label></div>
                <div class="spx-network-route-row"><span><b>웹폰트</b><small>기본값: 다운로드 안 함</small></span><label><input type="radio" name="collectionFontMode" data-resource-mode-field="collectionFontMode" value="block"><i>다운로드 안 함</i></label><label><input type="radio" name="collectionFontMode" data-resource-mode-field="collectionFontMode" value="load"><i>다운로드 함</i></label></div>
              </fieldset>
              <p class="spx-profile-note spx-network-route-note"><b>페이지/텍스트 절약:</b> 상품명·가격·리뷰·배송정보 수집에 필요한 HTML/텍스트/JS/JSON/XHR/fetch는 차단하지 않습니다. 별도 재수집·반복 reload 없이 네트워크 리소스 정책만 적용합니다.</p>
              <p class="spx-profile-note spx-network-route-note"><b>기본 네트워크 고정:</b> 쿠팡 홈페이지 / · /search · WING · Supabase · 일반 인터넷. 전용 프로필에서는 이 트래픽을 30766 프록시 bypass(DIRECT)로 분리하고, 적용 확인에 실패하면 수집을 시작하지 않습니다.</p>
            </div>
            <p id="spx-settings-message">수집 기준과 설정값은 하나의 실행 기준으로 저장됩니다.</p>
          </div>
          <div class="spx-settings-actions"><button id="spx-settings-default" type="button">현재 탭 기본값</button><span></span><button id="spx-settings-cancel" type="button">취소</button><button id="spx-settings-save" type="button">저장</button></div>
        </section>
      </div>
      <div id="spx-sourcing-modal" class="spx-settings-backdrop" hidden>
        <section class="spx-settings-drawer spx-sourcing-drawer" role="dialog" aria-modal="true" aria-labelledby="spx-sourcing-title">
          <div class="spx-settings-head spx-sourcing-head">
            <div class="spx-sourcing-titleline"><b id="spx-sourcing-title">수집 실행</b><i aria-hidden="true">|</i><label class="spx-sourcing-auto-upload compact" data-tip="사이드바 하단과 같은 업로드 자동 설정입니다."><input id="spx-auto-upload-sourcing" type="checkbox"><span>자동 업로드</span></label><i aria-hidden="true">|</i><label class="spx-next-delay-inline" data-tip="연속 탐색의 다음 페이지·다음 키워드 이동 전 대기입니다. 최소~최대 사이에서 매번 새로운 ms 값을 사용하며 설정 화면과 동기화됩니다."><span>다음 대기</span><input id="spx-next-delay-min-ms" type="number" min="100" max="120000" step="10" value="180" aria-label="다음 대기 최소 밀리초"><em>~</em><input id="spx-next-delay-max-ms" type="number" min="100" max="180000" step="10" value="420" aria-label="다음 대기 최대 밀리초"><small>ms</small></label></div>
            <button id="spx-sourcing-close" type="button" aria-label="닫기">×</button>
          </div>
          <p class="spx-sourcing-help">단건·연속·로컬DB·대기열 실행 방식을 선택합니다. 모든 실행은 같은 수집 기준을 사용합니다.</p>
          <div class="spx-sourcing-mode-grid" role="tablist" aria-label="실행 방식">
            <button type="button" class="active" data-spx-sourcing-mode="guided">단건 분석</button>
            <button type="button" data-spx-sourcing-mode="full">연속 탐색</button>
            <button type="button" data-spx-sourcing-mode="local">로컬DB</button>
            <button type="button" data-spx-sourcing-mode="refresh">대기열 수집</button>
          </div>
          <div class="spx-settings-body spx-sourcing-body">
            <section class="spx-sourcing-panel active" data-spx-sourcing-panel="guided">
              <p class="spx-profile-note"><b>단건 분석</b>은 현재 쿠팡 검색 키워드를 우선 사용합니다. 다른 웹페이지에서 사이드바를 불렀다면 아래 입력 키워드로 현재 탭을 쿠팡 검색페이지로 이동해 바로 수집합니다.</p>
              <div class="spx-guided-inline-row">
                <label class="spx-sourcing-field spx-guided-keyword-field" data-tip="쿠팡 검색페이지가 아닌 곳에서 사이드바를 강제 호출했을 때 사용할 단건 분석 키워드입니다."><span>분석 키워드</span><input id="spx-guided-keyword" type="text" placeholder="예: 빗물 제거 스퀴지" autocomplete="off" spellcheck="false"></label>
                
                
              </div>
            </section>
            <section class="spx-sourcing-panel" data-spx-sourcing-panel="full">
              <p class="spx-profile-note"><b>연속 탐색</b>의 지정키워드는 단건 분석과 같은 수집 조건을 한 키워드씩 반복합니다. 한 키워드가 최종 실패해도 같은 항목을 무한 재수집하지 않고 다음 키워드로 이동합니다.</p>
              <div class="spx-exploration-config" aria-label="연속 탐색 기준">
                <b>연속 탐색 타겟 · 다중 선택</b>
                <div class="spx-exploration-targets">
                  
                  <label><input type="checkbox" data-spx-explore-target="seasonal">계절 키워드</label>
                  <label><input type="checkbox" data-spx-explore-target="category">선택 카테고리</label>
                </div>
                <div class="spx-wave-toggle-row"><label class="spx-keyword-mode-option"><input id="spx-sourcing-wave-enabled" type="checkbox"><span>키워드 파도타기</span></label><label class="spx-keyword-mode-option"><input id="spx-sourcing-specified-enabled" type="checkbox"><span>지정키워드</span></label><b id="spx-sourcing-seed-count">키워드 0개</b></div>
                <textarea id="spx-sourcing-seed-keyword" class="spx-wave-seeds" rows="3" placeholder="지정 키워드를 쉼표로 구분해 입력&#10;예: 화분 받침대, 화분 선반"></textarea>
                <div class="spx-season-options spx-explore-option" data-spx-explore-option="season"><span>계절 선택</span><div><label><input type="checkbox" data-spx-season="봄">봄</label><label><input type="checkbox" data-spx-season="여름">여름</label><label><input type="checkbox" data-spx-season="가을">가을</label><label><input type="checkbox" data-spx-season="겨울">겨울</label><label><input type="checkbox" data-spx-season="연중">연중</label><label><input type="checkbox" data-spx-season="복합">복합</label></div></div>
                <div class="spx-sourcing-category-wrap spx-explore-option" data-spx-explore-option="category">
                  <span>카테고리 <small>선택 없으면 전체</small></span>
                  <div class="spx-sourcing-category-grid">
                    <select id="spx-sourcing-category1" aria-label="1차 카테고리"><option value="">1차 전체</option></select>
                    <select id="spx-sourcing-category2" aria-label="2차 카테고리"><option value="">2차 전체</option></select>
                    <select id="spx-sourcing-category3" aria-label="3차 카테고리"><option value="">3차 전체</option></select>
                  </div>
                </div>
              </div>
            </section>
            <section class="spx-sourcing-panel" data-spx-sourcing-panel="local"><p class="spx-profile-note"><b>로컬DB</b>에 누적된 키워드를 현재 탭에서 순서대로 수집합니다.</p></section>
            <section class="spx-sourcing-panel" data-spx-sourcing-panel="refresh">
              <p class="spx-profile-note"><b>대기열 수집</b>은 발견 키워드·서버 재수집 대기열 중 선택한 목록을 단건 분석처럼 한 개씩 즉시 반복합니다. Collector는 보완/부족없음 상태를 자체 판정하지 않습니다.</p>
              <div class="spx-queue-bucket-choice" role="radiogroup" aria-label="대기열 종류">
                <label><input type="radio" name="spx-queue-bucket" value="discovered" checked><span>발견 키워드</span></label>
                <label><input type="radio" name="spx-queue-bucket" value="manager"><span>서버 재수집 대기열</span></label>
              </div>
              <div id="spx-manager-queue-panel" class="spx-manager-queue-panel" hidden>
                <div class="spx-manager-queue-head">
                  <b id="spx-manager-queue-count">서버 재수집 대기열 · 확인 전</b>
                  <button id="spx-manager-queue-refresh" type="button">새로고침</button>
                </div>
                <div id="spx-manager-queue-keywords" class="spx-manager-queue-keywords">서버 재수집 목록 확인 전</div>
                <div id="spx-manager-queue-failed" class="spx-manager-queue-failed">실패 0건</div>
              </div>
            </section>
          </div>
          <div id="spx-sourcing-saved-summary" class="spx-sourcing-saved-summary" role="status" aria-live="polite">
            <b>저장된 실행 설정</b>
            <span id="spx-sourcing-saved-summary-text">단건 분석 · 키워드 분석 클릭 시 현재 검색어 1개만 분석하고 멈춥니다.</span>
          </div>
          <div class="spx-settings-actions spx-sourcing-actions">
            <button id="spx-sourcing-reload" type="button">저장값 복원</button>
            <span></span>
            <div id="spx-server-upload-policy" class="spx-server-upload-policy compact" role="radiogroup" aria-label="서버 업로드 키워드 처리 방식" data-tip="서버에 등록된 키워드 중 관리상태 부족없음·누락 0건만 건너뛰는 방식입니다.">
              <label data-tip="서버 관리상태가 부족없음이고 누락 수량 0건으로 확인된 키워드만 건너뜁니다. 보완필요·갱신대기·기준미달은 건너뛰지 않습니다."><input type="radio" name="spx-server-uploaded-policy" value="skip" checked><span>부족항목 SKIP</span></label>
              <label data-tip="서버에 이미 있는 키워드도 다시 수집·분석해 기존 서버 행을 갱신합니다."><input type="radio" name="spx-server-uploaded-policy" value="reanalyze"><span>재수집</span></label>
            </div>
            <button id="spx-sourcing-cancel" type="button">취소</button>
            <button id="spx-sourcing-save" type="button">설정 저장</button>
          </div>
        </section>
      </div>
      <div id="spx-stop-summary-modal" class="spx-settings-backdrop spx-stop-summary-backdrop" hidden>
        <section class="spx-settings-drawer spx-stop-summary-drawer" role="dialog" aria-modal="true" aria-labelledby="spx-stop-summary-title">
          <div class="spx-settings-head"><div><b id="spx-stop-summary-title">연속 수집 중단 이력</b><span id="spx-stop-summary-reason">사용자 중단</span></div><button id="spx-stop-summary-close" type="button" aria-label="닫기">×</button></div>
          <div class="spx-stop-summary-body">
            <div class="spx-global-pending-scope" role="status" aria-live="polite"><span>로컬 전체 서버 업로드 대기 (사이드바와 동일)</span><b id="spx-global-pending-total">확인 중</b></div>
            <div class="spx-stop-summary-counts">
              <div class="success" role="button" tabindex="0" aria-pressed="false" data-history-filter="saved" title="클릭하면 현재 상세목록의 수집완료 항목만 표시 · 수집완료 총수는 서버 업로드+로컬 대기 누적"><span>수집완료</span><b id="spx-stop-count-success">0</b></div>
              <div class="requeued" role="button" tabindex="0" aria-pressed="false" data-history-filter="requeued" title="클릭하면 자료부족 항목만 표시"><span>자료부족</span><b id="spx-stop-count-requeued">0</b></div>
              <div class="below-criteria" role="button" tabindex="0" aria-pressed="false" data-history-filter="below_criteria" title="클릭하면 기준미달 항목만 표시"><span>미달</span><b id="spx-stop-count-below-criteria">0</b></div>
              <div class="excluded" role="button" tabindex="0" aria-pressed="false" data-history-filter="excluded" title="클릭하면 제외 항목만 표시"><span>제외</span><b id="spx-stop-count-excluded">0</b></div>
              <div class="skipped" role="button" tabindex="0" aria-pressed="false" data-history-filter="skipped" title="클릭하면 건너뜀 항목만 표시"><span>건너뜀</span><b id="spx-stop-count-skipped">0</b></div>
              <div class="failed" role="button" tabindex="0" aria-pressed="false" data-history-filter="failed" title="클릭하면 실패·기술오류 항목만 표시"><span>실패·기술오류</span><b id="spx-stop-count-failed">0</b></div>
            </div>
            <p id="spx-stop-summary-meta" class="spx-stop-summary-meta">처리 0개 · 상품 0개 · 0초</p>
            <div class="spx-history-search-wrap"><input id="spx-history-search" type="search" autocomplete="off" placeholder="수집된 내역 · 업로드 대기 검색"><span id="spx-history-search-result"></span></div>
            <div class="spx-history-upload-state-summary"><div class="uploaded" role="button" tabindex="0" aria-pressed="false" data-upload-filter="uploaded" title="클릭하면 서버 업로드 완료 항목만 표시"><span>서버 업로드</span><b id="spx-history-uploaded-count">0</b></div><div class="pending" role="button" tabindex="0" aria-pressed="false" data-upload-filter="pending" title="클릭하면 서버 업로드 대기 항목만 표시"><span>로컬 대기</span><b id="spx-history-pending-count">0</b></div></div>
            <button id="spx-stop-history-toggle" class="spx-stop-history-toggle" type="button" aria-expanded="false">키워드 이력 펼치기 ▾</button>
            <div id="spx-stop-history-details" class="spx-stop-history-details" hidden><div id="spx-stop-history-list" class="spx-stop-history-list"></div></div>
            <section class="spx-pending-select-panel" aria-labelledby="spx-pending-select-title">
              <div class="spx-pending-select-head"><div><b id="spx-pending-select-title">서버 업로드 대기</b><span id="spx-pending-select-count">0건</span></div><div><button id="spx-pending-select-all" type="button">전체 선택</button><button id="spx-pending-select-invert" type="button">선택반전</button><button id="spx-pending-select-none" type="button">선택 해제</button></div></div>
              <div id="spx-pending-select-list" class="spx-pending-select-list"><div class="spx-stop-history-empty">서버 업로드 대기 확인 중...</div></div>
              <button id="spx-pending-selected-upload" class="spx-pending-selected-upload" type="button" disabled>선택 0건 서버로 업로드</button>
              <div id="spx-pending-upload-result" class="spx-pending-upload-result" hidden></div>
            </section>
          </div>
          <div class="spx-stop-summary-actions"><button id="spx-history-reset" class="secondary danger" type="button" data-tip="수집을 중지한 뒤 전체 로컬 수집내역·원천상품·후속/업로드 대기열을 완전히 삭제합니다. 서버 저장 데이터·IP·WING 설정은 유지됩니다. 두 번 확인 후 실행합니다.">초기화</button><button id="spx-pending-delete-all-local" class="secondary danger strong" type="button" data-tip="서버에 아직 업로드되지 않은 로컬 업로드 대기 수집자료를 aggregate/raw/연결 outbox까지 완전삭제합니다. 서버 DB는 변경하지 않습니다.">대기만 삭제</button><button id="spx-stop-summary-csv" class="secondary" type="button" data-tip="현재 검색·필터 결과에 화면에 보이는 항목만 Excel 확인용 요약 CSV로 저장합니다.">CSV 저장</button><button id="spx-stop-summary-json" class="secondary" type="button" data-tip="현재 검색·필터 결과의 정상 수집건을 run_key별 durable canonical bundle로 SmartPage Manager Upload v2 JSON에 저장합니다. 서버 업로드 완료건도 full-fidelity 재등록 가능 · 서버 조회·업로드 0.">JSON 저장</button><button id="spx-stop-summary-confirm" type="button">확인</button></div>
        </section>
      </div>
      <div id="spx-tooltip" class="spx-tooltip" role="tooltip" hidden></div>`;
      // 화면 렌더링보다 저장된 접기 상태 복원을 먼저 적용해 깜빡임을 막습니다.
      if(!sidebarCollapsedReadyV1632)el.style.visibility='hidden';
      if(sidebarCollapsedV1632)el.classList.add('spx-collapsed');
      host.appendChild(el);
      renderSidebarCollapsedV1632();
      // 저장소 응답이 지연/거부되더라도 사이드바가 영구히 숨겨지지 않게 합니다.
      if(!sidebarCollapsedReadyV1632)setTimeout(()=>{if(el.isConnected&&el.style.visibility==='hidden')el.style.visibility='';},1500);
      bindOverlayTooltips(el);
      bindWinnerImageActivationV10157(el);
      bindStatusLogResizer(el);
      loadActiveCollectionProfile().catch(()=>{});
      Promise.all([persistentHistoryResetReadyV101510,chrome.storage.local.get(AUTO_KEY)]).then(([,stored])=>{const summary=stored?.[AUTO_KEY]?.lastRunSummary;if(!summary)return;const visible=normalizeAutomationSummaryForHistoryReset(summary);if(visible?._historyVisibleActivity!==false&&(Boolean(visible?.interruptedKeyword)||(Array.isArray(visible?.history)&&visible.history.length>0))){currentAutomationSummary=visible;syncFooterRunSummaryV129(visible);void syncFooterRunUploadStatesV129(visible,{force:true});}}).catch(()=>{});

      // 별도 '소싱 수집기' 펼침 탭은 생성하지 않습니다.
      // 접혀도 상단 S가 클릭 가능한 위치에 남아 동일 버튼으로 접고 펼칩니다.
      el.querySelector('#spx-fold')?.addEventListener('click', () => {
        setSidebarCollapsedV1632(!sidebarCollapsedV1632);
      });
      bindSidebarDialogFocus(el);
      el.querySelector('#spx-scan')?.addEventListener('click', () => runSelectedAnalysisAction().catch(()=>{}));
      el.querySelector('#spx-category-candidates')?.addEventListener('click',()=>prepareCategoryKeywordSelection().catch(error=>setText('spx-status',error?.message||String(error))));
      el.querySelector('#spx-run-toggle')?.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); toggleSidebarAutomation(); });
      const networkToggle=el.querySelector('#spx-network-toggle');
      const networkToggleLabel=networkToggle?.closest('.spx-network-check');
      networkToggleLabel?.addEventListener('click',(event)=>{
        if(event.ctrlKey!==true)return;
        event.preventDefault();
        event.stopPropagation();
        openSelectedNetworkDedicatedWindow().catch(()=>{});
      });
      networkToggleLabel?.addEventListener('mouseenter',async()=>{
        await syncSidebarNetworkToggle().catch(()=>{});
        if(networkToggleLabel.matches(':hover'))showOverlayTooltip(networkToggleLabel);
      });
      networkToggle?.addEventListener('change', (event) => toggleCollectionNetwork(event.target?.checked === true));
      const airplaneToggle=el.querySelector('#spx-airplane-toggle');
      airplaneToggle?.addEventListener('click',(event)=>{event.preventDefault();event.stopPropagation();togglePhoneAirplaneMode().catch(()=>{});});
      airplaneToggle?.addEventListener('mouseenter',()=>syncAirplaneModeButton().catch(()=>{}));
      setTimeout(()=>syncAirplaneModeButton().catch(()=>{}),250);
      el.querySelector('#spx-step-once')?.addEventListener('click', () => stepOneKeyword({analyzeAfterSearch:true}));
      el.querySelector('#spx-mode-badge')?.addEventListener('click', () => openSourcingModal());
      el.querySelector('#spx-sourcing-close')?.addEventListener('click', () => closeSourcingModal());
      el.querySelector('#spx-sourcing-cancel')?.addEventListener('click', () => closeSourcingModal());
      el.querySelector('#spx-sourcing-save')?.addEventListener('click', () => saveSidebarSourcingSelection().catch((error)=>setText('spx-sourcing-saved-summary-text',error?.message||String(error))));
      el.querySelector('#spx-sourcing-reload')?.addEventListener('click', () => restoreSidebarSourcingSelection());
      el.querySelector('#spx-sourcing-modal')?.addEventListener('click', (event) => { if (event.target === event.currentTarget) closeSourcingModal(); });
      el.querySelector('#spx-stop-summary-modal')?.addEventListener('click', (event) => { if (event.target === event.currentTarget) closeAutomationStopSummary(); });
      el.querySelector('#spx-stop-summary-close')?.addEventListener('click', closeAutomationStopSummary);
      el.querySelector('#spx-stop-summary-confirm')?.addEventListener('click', closeAutomationStopSummary);
      el.querySelector('#spx-stop-summary-open')?.addEventListener('click',()=>{void openPersistentCollectionHistoryV1631();});
      el.querySelector('#spx-pending-upload-now')?.addEventListener('click',()=>runLatestPendingUploadV10151());
      el.querySelector('#spx-session-reset')?.addEventListener('click',()=>resetTabSessionCounters());
      el.querySelector('#spx-history-reset')?.addEventListener('click',()=>clearRecentCollectionHistoryV10154());
      el.querySelector('#spx-pending-delete-all-local')?.addEventListener('click',()=>deleteAllLocalPendingUploadsV117());
      el.querySelector('#spx-stop-summary-csv')?.addEventListener('click',()=>void downloadAutomationSummary('csv'));
      el.querySelector('#spx-stop-summary-json')?.addEventListener('click',()=>void downloadAutomationSummary('json'));
      el.querySelector('#spx-history-search')?.addEventListener('input',(event)=>{recentHistorySearchTermV117=String(event.target?.value||'');applyRecentHistorySearchV117();});
      el.querySelectorAll('.spx-history-upload-state-summary [data-upload-filter]').forEach((node)=>{node.addEventListener('click',()=>{void setRecentHistoryUploadFilterV125R1(node.dataset.uploadFilter);});node.addEventListener('keydown',(event)=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();void setRecentHistoryUploadFilterV125R1(node.dataset.uploadFilter);}});});
      el.querySelectorAll('.spx-stop-summary-counts [data-history-filter]').forEach((node)=>{node.addEventListener('click',()=>setRecentHistoryStatusFilterV126(node.dataset.historyFilter));node.addEventListener('keydown',(event)=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();setRecentHistoryStatusFilterV126(node.dataset.historyFilter);}});});
      el.querySelector('#spx-stop-history-toggle')?.addEventListener('click', toggleAutomationStopHistory);
      el.querySelector('#spx-pending-select-all')?.addEventListener('click',()=>selectAllPendingUploadsV10154());
      el.querySelector('#spx-pending-select-invert')?.addEventListener('click',()=>invertPendingUploadSelectionV1613());
      el.querySelector('#spx-pending-select-none')?.addEventListener('click',()=>clearPendingUploadSelectionV10154());
      el.querySelector('#spx-pending-attention-delete')?.addEventListener('click',()=>deleteLocalPendingAttentionV111());
      el.querySelector('#spx-pending-selected-upload')?.addEventListener('click',()=>runSelectedPendingUploadsV10154());
      el.querySelectorAll('[data-spx-sourcing-mode]').forEach((button)=>button.addEventListener('click',()=>selectSidebarSourcingMode(button.dataset.spxSourcingMode,{persist:false,markDirty:true})));
      el.querySelector('#spx-sourcing-category1')?.addEventListener('change',()=>{syncSidebarSourcingCategories(2);markSourcingDraftDirty();});
      el.querySelector('#spx-sourcing-category2')?.addEventListener('change',()=>{syncSidebarSourcingCategories(3);markSourcingDraftDirty();});
      el.querySelectorAll('[data-spx-explore-target], [data-spx-season], input[name="spx-queue-bucket"], input[name="spx-server-uploaded-policy"], #spx-sourcing-wave-enabled, #spx-sourcing-specified-enabled').forEach((input)=>input.addEventListener('change',()=>{enforceSidebarKeywordMode(input.id);syncSidebarExplorationOptions();markSourcingDraftDirty();}));
      const managerQueueRefresh=getUiElement('spx-manager-queue-refresh',{repair:false});if(managerQueueRefresh)managerQueueRefresh.addEventListener('click',(event)=>{event.preventDefault();event.stopPropagation();refreshManagerQueuePreview({silent:false}).catch(()=>{});});
      ['spx-guided-keyword','spx-sourcing-seed-keyword','spx-sourcing-target-month','spx-sourcing-category1','spx-sourcing-category2','spx-sourcing-category3','spx-sourcing-seeds'].forEach((id)=>el.querySelector(`#${id}`)?.addEventListener('input',()=>{if(id==='spx-sourcing-target-month')syncSidebarTargetMonthInput();syncSidebarExplorationOptions();scheduleSidebarSourcingPersistence();}));
      el.querySelector('#spx-sourcing-target-month')?.addEventListener('blur',()=>{syncSidebarTargetMonthInput({normalize:true});markSourcingDraftDirty();});
      el.querySelector('#spx-open-collection-settings')?.addEventListener('click', () => openCollectionSettings());
      el.querySelector('#spx-memory-cleanup')?.addEventListener('click', () => cleanExtensionMemory());
      el.querySelector('#spx-clear-browsing')?.addEventListener('click', () => clearBrowsingRecordsPreserveLogin());
      el.querySelector('#spx-settings-close')?.addEventListener('click', () => closeCollectionSettings());
      el.querySelector('#spx-settings-cancel')?.addEventListener('click', () => closeCollectionSettings());
      el.querySelector('#spx-settings-save')?.addEventListener('click', () => saveCollectionSettings());
      el.querySelector('#spx-settings-modal')?.addEventListener('click', (event) => { if (event.target?.id === 'spx-settings-modal') closeCollectionSettings(); });
      el.querySelectorAll('[data-spx-profile-tab]').forEach((button) => button.addEventListener('click', () => switchCollectionSettingsTab(button.dataset.spxProfileTab)));
      el.querySelectorAll('[data-reset-mode][data-reset-field]').forEach((button) => button.addEventListener('click', () => resetCollectionSetting(button.dataset.resetMode, button.dataset.resetField)));el.querySelectorAll('[data-reset-common]').forEach((button)=>button.addEventListener('click',()=>resetCommonSetting(button.dataset.resetCommon)));
      el.querySelectorAll('.spx-setting-use[data-toggle-field], [data-common-field][type="checkbox"]').forEach((input)=>input.addEventListener('change',()=>syncCollectionToggleState(input)));
      el.querySelectorAll('.spx-setting-use[data-toggle-field], [data-common-field][type="checkbox"]').forEach((input)=>syncCollectionToggleState(input));
      el.querySelectorAll('.spx-setting-use[data-key="maxPages"]').forEach((input)=>input.addEventListener('change',()=>syncProfileMaxPagesControl(input)));
      el.querySelectorAll('[data-field="maxPagesPerKeyword"]').forEach((input)=>input.addEventListener('input',()=>{input.value=String(clampSetting(input.value,1,50,1));}));
      el.querySelector('#spx-settings-default')?.addEventListener('click', () => resetCollectionProfile(activeSettingsTab));
      el.querySelector('#spx-skip-keyword')?.addEventListener('click', () => stepOneKeyword({analyzeAfterSearch:false}));
      el.querySelector('#spx-change-ip')?.addEventListener('click', () => changePublicIpFromSidebar());
      el.querySelector('#spx-exclude-keyword')?.addEventListener('click', () => excludeCurrentKeyword());
      el.querySelector('#spx-kwlabel')?.addEventListener('click', async (event) => {
        const label=event.currentTarget;
        const keyword=String(currentKeyword()||state.lockedKeyword||state.keyword||'').replace(/\s+/g,' ').trim();
        if(!keyword)return;
        let copied=false;
        try{await navigator.clipboard.writeText(keyword);copied=true;}catch(_){
          const input=document.createElement('textarea');input.value=keyword;input.setAttribute('readonly','');input.style.position='fixed';input.style.opacity='0';document.body.appendChild(input);input.select();
          try{copied=document.execCommand('copy');}catch(__){copied=false;}input.remove();
        }
        label.classList.toggle('copied',copied);
        label.title=copied?`복사 완료: ${keyword}`:'클립보드 복사 실패';
        setTimeout(()=>{if(!label.isConnected)return;label.classList.remove('copied');label.title='클릭하여 현재 키워드 복사';},900);
      });
      el.querySelector('#spx-runtime-mode')?.addEventListener('click', async(event)=>{event.stopPropagation();await setTabAutomationTimer('toggle-display');});
      el.querySelector('#spx-runtime-value')?.addEventListener('click', async(event)=>{event.stopPropagation();if(tabSessionStats.runtimeDisplayMode==='manual')await setTabAutomationTimer('reset-manual-display');});
      el.querySelector('#spx-next-now')?.addEventListener('click', () => skipPendingNavigation());
      el.querySelector('#spx-upload')?.addEventListener('click', runUpload);
      // v1.6.41: WING 실측 신규 수집 방식 확정. 구 방식 선택 UI 제거.
      el.querySelector('#spx-admin-override-upload')?.addEventListener('click', runAdminOverrideUpload);
      for(const [id,key] of [['spx-prompt-keyword-1','keyword1'],['spx-prompt-keyword-2','keyword2']]){
        el.querySelector('#'+id)?.addEventListener('change', async(event)=>{
          const input=event.currentTarget,next=event.currentTarget.checked===true;
          input.disabled=true;
          try{
            const saved=await chrome.storage.local.get(SPX.promptKeywords.SETTINGS_KEY);
            const controls={...(saved[SPX.promptKeywords.SETTINGS_KEY]||{}),[key]:next};
            await chrome.storage.local.set({[SPX.promptKeywords.SETTINGS_KEY]:controls});
            input.checked=next;
          }catch(error){input.checked=!next;console.warn('[SPX keyword controls] save failed',error);}
          finally{input.disabled=false;}
        });
      }
      chrome.storage.local.get(SPX.promptKeywords.SETTINGS_KEY).then(saved=>{
        const controls=saved?.[SPX.promptKeywords.SETTINGS_KEY]||{};
        const first=el.querySelector('#spx-prompt-keyword-1'),second=el.querySelector('#spx-prompt-keyword-2');
        if(first)first.checked=controls.keyword1===true;
        if(second)second.checked=controls.keyword2===true;
      }).catch(()=>{});
      const fastFooter=el.querySelector('#spx-fast-upload-overlap-footer');
      fastFooter?.addEventListener('change',async(event)=>{
        const next=event.target.checked===true;fastFooter.disabled=true;
        try{await SPX.util.setSettings({fastUploadOverlapEnabled:next});}
        catch(error){fastFooter.checked=!next;console.warn('[SPX] 고속 설정 저장 실패',error);}
        finally{fastFooter.disabled=false;}
      });
      void safeGetSettings().then(settings=>{if(fastFooter)fastFooter.checked=settings?.fastUploadOverlapEnabled===true;}).catch(()=>{});
      el.querySelector('#spx-auto-upload')?.addEventListener('change', (event) => updateSidebarAutoUploadSetting(event.target?.checked === true));
      el.querySelector('#spx-auto-upload-sourcing')?.addEventListener('change', (event) => updateSidebarAutoUploadSetting(event.target?.checked === true));
      el.querySelector('#spx-auto-extra-page')?.addEventListener('change', (event) => {
        event.stopPropagation();
        const checked=event.target?.checked===true;
        sidebarExtraPageSessionOverride=checked;
        const common=document.querySelector('#spx-overlay [data-common-field="autoExtraPageEnabled"]');
        if(common){common.checked=checked;syncCollectionToggleState(common);}
        /* 저장/전용창 공유/현재 연속 실행 정책 갱신을 한 작업으로 묶습니다. 사용자가 곧바로
           [키워드 분석]을 눌러도 selectedCollectionProfileSettings()가 이 Promise를 먼저 기다립니다. */
        sidebarExtraPagePersistPromise=(async()=>{
          const response=await runtimeMessage({type:'SPX_UPDATE_EXTRA_PAGE_POLICY',enabled:checked,source:'sidebar'}).catch((error)=>({ok:false,error:error?.message||String(error)}));
          if(response?.ok!==true)await SPX.util.setSettings({autoExtraPageEnabled:checked});
          return response;
        })();
      });
      ['spx-next-delay-min-ms','spx-next-delay-max-ms'].forEach((id)=>{const input=el.querySelector(`#${id}`);input?.addEventListener('input',()=>scheduleNextNavigationDelayPersistence());input?.addEventListener('change',()=>saveNextNavigationDelayFromSidebar().catch(()=>{}));});
      bindDiscoveredListActions();
      syncSidebarAutoUploadSetting().catch(() => {});
      syncSidebarNetworkToggle().catch(() => {});
      loadCommittedSidebarSourcingSelection({apply:true}).catch(()=>{});
      refreshSidebarRunButton().catch(() => {});
    syncNextNavigationDelaySetting().catch(() => {});
      syncSidebarAutoExtraPageSetting().catch(()=>{});
      ;
      /* 중단 메시지가 페이지 이동·확장 재로드 시점과 겹쳐 런타임 메시지를 놓쳐도,
         서비스워커가 저장한 마지막 연속 수집 요약을 현재 탭에서 한 번 복원합니다. */
      /* [v2.2.2] 요청 반영: 쿠팡 검색창(페이지 어디서든)에서 Ctrl+Enter=[▶ 수집] 시작,
         ESC=[■ 멈춤]. shell()이 여러 번 실행돼도 리스너가 중복되지 않도록 document에
         플래그로 1회만 바인딩한다. */
      if (!document.__spxKeyboardShortcutsBound) {
        document.__spxKeyboardShortcutsBound = true;
        document.addEventListener('keydown', (e) => {
          const tag = String(e.target?.tagName || '').toLowerCase();
          const typing = ['input', 'select', 'textarea'].includes(tag) || e.target?.isContentEditable;
          if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
            e.preventDefault();
            toggleSidebarAutomation();
          } else if (e.key === 'Escape') {
            const stopSummaryModal=getUiElement('spx-stop-summary-modal',{repair:false});
            if(stopSummaryModal&&!stopSummaryModal.hidden){
              e.preventDefault();
              e.stopPropagation();
              closeAutomationStopSummary();
              return;
            }
            const sourcingModal=getUiElement('spx-sourcing-modal',{repair:false});
            if(sourcingModal&&!sourcingModal.hidden){
              e.preventDefault();
              e.stopPropagation();
              closeSourcingModal();
              return;
            }
            const settingsModal=getUiElement('spx-settings-modal',{repair:false});
            if(settingsModal&&!settingsModal.hidden){
              e.preventDefault();
              e.stopPropagation();
              closeCollectionSettings();
              return;
            }
            if(!typing)runtimeMessage({ type: 'SPX_QUEUE_STOP', reason: 'ESC 단축키' }).catch(() => {});
          }
        });
      }
      return hasCompleteUi();
    } catch (error) {
      console.info('[SPX] UI 생성 대기', error?.message || error);
      return false;
    }
  }

  function ensureUi() {
    if (contextInvalidated || !uiKeywordContext() || !(document.body || document.documentElement)) return false;
    if (!hasCompleteUi()) {
      const repaired = shell();
      if (repaired) {
        detect();
        if (!state.agg) renderIdle();
        refreshDbInfo();
      }
    }
    return hasCompleteUi();
  }

  async function waitForUi(timeoutMs = 10000, task = null, stableChecks = 2) {
    const started = Date.now();
    let consecutiveReady = 0;
    while (Date.now() - started < timeoutMs) {
      if (contextInvalidated || !SPX.util.runtimeAlive?.()) { shutdownInvalidatedContext(); return false; }
      if (task && !taskIsCurrent(task)) return false;
      if (ensureUi() && hasCompleteUi()) {
        consecutiveReady += 1;
        if (consecutiveReady >= Math.max(1, Number(stableChecks) || 1)) return true;
      } else {
        consecutiveReady = 0;
      }
      await automationAwareWait(SPX.util.randomInt?.(120,230)||160,activeRunId);
    }
    return false;
  }

  function getUiElement(id, { repair = true } = {}) {
    let el = $(id);
    if (!el && repair && uiKeywordContext() && (document.body || document.documentElement)) {
      ensureUi();
      el = $(id);
    }
    if (!el && repair) queueUiRepair();
    return el || null;
  }

  async function requireUi(timeoutMs = 10000, task = null) {
    const ready = await waitForUi(timeoutMs, task, 2);
    return Boolean(ready && hasCompleteUi());
  }

  function queueUiRepair(delayMs = null) {
    if (contextInvalidated) return;
    clearTimeout(uiRepairTimer);
    const delay = Math.max(80, Math.min(1500, Number.isFinite(Number(delayMs)) ? Number(delayMs) : jitterMs(90,190)));
    uiRepairTimer = setTimeout(() => {
      uiRepairTimer = null;
      if (!sidebarContextAvailableV103() || contextInvalidated) return;
      if (!hasCompleteUi() && !ensureUi()) queueUiRepair(jitterMs(Math.min(1500,Math.max(90,delay*1.45)),Math.min(1800,Math.max(160,delay*2.15))));
    }, delay);
  }

  function scheduleBootRetry(delayMs = null) {
    if (contextInvalidated) return;
    if (bootRetryTimer) clearTimeout(bootRetryTimer);
    bootRetryTimer = setTimeout(async () => {
      bootRetryTimer = null;
      if (contextInvalidated || !sidebarContextAvailableV103()) return;
      if (!(await waitForUi(5000))) {
        queueUiRepair(jitterMs(160,260));
        scheduleBootRetry(jitterMs(Math.min(3000,Math.max(620,(Number(delayMs)||800)*1.2)),Math.min(3600,Math.max(900,(Number(delayMs)||800)*1.8))));
        return;
      }
      detect();
      if (!state.agg) renderIdle();
      refreshDbInfo();
      scheduleAutoRun(jitterMs(420,680));
    }, Math.max(200, Number.isFinite(Number(delayMs)) ? Number(delayMs) : jitterMs(650,1050)));
  }

  function setText(id, value) {
    const el = getUiElement(id);
    if (!el) return false;
    const next=value==null?'':String(value);
    if(el.textContent===next)return true;
    el.textContent = next;
    return true;
  }

  function setHtml(id, value) {
    const el = getUiElement(id);
    if (!el) return false;
    const next=value==null?'':String(value);
    if(el.innerHTML===next)return true;
    el.innerHTML = next;
    if(id==='spx-body')queueMicrotask(()=>{const details=el.querySelector?.('details.spx-winner-list[open]');if(details)activateWinnerImagesV10157(details).catch(()=>{});});
    return true;
  }

  function setDisplay(id, value) {
    const el = getUiElement(id);
    if (!el) return false;
    const next=value==null?'':String(value);
    if(el.style.display===next)return true;
    el.style.display = next;
    return true;
  }

  function setStyle(id, property, value) {
    const el = getUiElement(id);
    if (!el?.style) return false;
    const next=value==null?'':String(value);
    if(el.style[property]===next)return true;
    el.style[property] = next;
    return true;
  }

  function setDisabled(id, value) {
    const el = getUiElement(id);
    if (!el) return false;
    const next=Boolean(value);
    if(el.disabled===next)return true;
    el.disabled = next;
    return true;
  }

  function setClass(id, value) {
    const el = getUiElement(id);
    if (!el) return false;
    const next=value==null?'':String(value);
    if(el.className===next)return true;
    el.className = next;
    return true;
  }


  const normKeyword = (value) => String(value || '').trim().replace(/\s+/g, ' ').toLowerCase();

  async function waitForServerSignal(kind='normal'){const settings=await safeGetSettings();return SPX.util?.humanDelay?.(settings,kind)||0;}

  let nextKeywordHintAt=0;
  let nextKeywordHintBusy=false;
  async function refreshNextKeywordHint(force=false){
    const now=Date.now();if(nextKeywordHintBusy||(!force&&now-nextKeywordHintAt<1600))return;
    nextKeywordHintBusy=true;nextKeywordHintAt=now;
    try{
      const response=await runtimeMessage({type:'SPX_PEEK_NEXT_KEYWORD',currentKeyword:currentKeyword(),sourceKeyword:currentKeyword()});
      const keyword=String(response?.nextKeyword||'').trim();
      const tip=keyword?`다음 키워드: ${keyword} · 클릭하면 현재 분석을 먼저 멈추고 바로 이동합니다.`:'다음 키워드가 없습니다. 발견·재수집을 확인하세요.';
      for(const id of ['spx-skip-keyword','spx-step-once']){
        const button=getUiElement(id,{repair:false});if(!button)continue;
        button.title=tip;button.dataset.spxTip=tip;button.setAttribute('aria-label',tip);
      }
      const waitButton=getUiElement('spx-next-now',{repair:false});
      if(waitButton&&keyword){waitButton.title=`대기 생략 · 다음 키워드: ${keyword}`;waitButton.dataset.spxTip=waitButton.title;}
    }catch(_){ }
    finally{nextKeywordHintBusy=false;}
  }

  function clearNavigationTimer() {
    if (navigationTimer) {
      clearTimeout(navigationTimer);
      clearInterval(navigationTimer);
    }
    navigationTimer = null;
    pendingNavigation = null;
    const button = document.getElementById('spx-next-now');
    if (button) button.hidden = true;
  }

  function writeKeywordTransitionMarker(keyword,runId,beforeSignature=''){
    const marker={keyword:normalizeVisibleKeyword(keyword),runId:String(runId||''),beforeSignature:String(beforeSignature||''),startedAt:Date.now()};
    try{sessionStorage.setItem(SPX_KEYWORD_TRANSITION_KEY,JSON.stringify(marker));}catch(_){}
    return marker;
  }
  function markKeywordTransitionReady(keyword,runId,signature=''){
    const prior=readKeywordTransitionMarker()||{};
    const marker={...prior,keyword:normalizeVisibleKeyword(keyword),runId:String(runId||prior.runId||''),readySignature:String(signature||searchResultSignature()),readyAt:Date.now(),startedAt:Number(prior.startedAt||Date.now())};
    try{sessionStorage.setItem(SPX_KEYWORD_TRANSITION_KEY,JSON.stringify(marker));}catch(_){}
    return marker;
  }
  function clearKeywordTransitionMarker(keyword='',runId=''){
    try{
      const marker=readKeywordTransitionMarker();
      if(!marker){sessionStorage.removeItem(SPX_KEYWORD_TRANSITION_KEY);return;}
      const keywordMatches=!keyword||canonicalVisibleKeyword(marker.keyword)===canonicalVisibleKeyword(keyword);
      const runMatches=!runId||!marker.runId||String(marker.runId)===String(runId);
      if(keywordMatches&&runMatches)sessionStorage.removeItem(SPX_KEYWORD_TRANSITION_KEY);
    }catch(_){}
  }
  function searchResultSignature(){
    const allRows=[...document.querySelectorAll('li.search-product,li[class*="search-product" i],[data-testid*="search-product" i],[data-product-id][class*="product" i]')];
    const rows=allRows.slice(0,10);
    const parts=rows.map((row)=>String(row.getAttribute?.('data-product-id')||row.querySelector?.('a[href*="/vp/products/"]')?.getAttribute?.('href')||row.textContent||'').replace(/\s+/g,' ').trim().slice(0,160));
    return `${allRows.length}|${parts.join('||')}`;
  }
  async function waitForKeywordTransitionReady(keyword,beforeSignature,timeoutMs=12000){
    const targetKey=canonicalVisibleKeyword(keyword),startedAt=Date.now();
    while(Date.now()-startedAt<timeoutMs){
      if(contextInvalidated||!SPX.util.runtimeAlive?.())throw contextEndError();
      const status=searchPageReadiness();
      if(status.blocked){const error=new Error(status.blockReason||'쿠팡 접근 제한 화면');error.code='COUPANG_BLOCKED';throw error;}
      const urlKey=canonicalVisibleKeyword(urlCurrentKeyword?.());
      const input=document.querySelector('#headerSearchKeyword, form[action*="/np/search"] input[name="q"], input[name="q"]');
      const inputKey=canonicalVisibleKeyword(input?.value||'');
      const targetVisible=targetKey&&(urlKey===targetKey||inputKey===targetKey);
      const signature=searchResultSignature();
      const resultsChanged=signature!==beforeSignature;
      const ready=Boolean(status.noResults)||(Number(status.itemCount||0)>0||Number(status.anchorCount||0)>0);
      if(targetVisible&&ready&&resultsChanged&&document.readyState!=='loading')return{ready:true,status,signature};
      await automationAwareWait(jitterMs(90,170),activeRunId);
    }
    return{ready:false,timeout:true};
  }
  function transitionKeywordAndStart(keyword,options={}){
    const target=normalizeVisibleKeyword(keyword),runId=String(options.runId||activeRunId||'');
    if(!target)return Promise.reject(new Error('이동할 다음 키워드가 없습니다.'));
    if(keywordTransitionPromise){
      if(canonicalVisibleKeyword(keywordTransitionTarget)===canonicalVisibleKeyword(target)&&(!runId||!keywordTransitionRunId||keywordTransitionRunId===runId))return keywordTransitionPromise;
      return keywordTransitionPromise.catch(()=>null).then(()=>transitionKeywordAndStart(target,options));
    }
    const serial=++keywordTransitionSerial;
    keywordTransitionTarget=target;keywordTransitionRunId=runId;
    let navigating=false;
    const task=(async()=>{
      state.busy=true;state.autoStarting=false;state.autoStarted=true;
      clearAutoRunTimer();clearAutomationKickWatchdog();
      if(runId)activeRunId=runId;
      const currentKey=canonicalVisibleKeyword(urlCurrentKeyword?.()),targetKey=canonicalVisibleKeyword(target);
      const beforeSignature=searchResultSignature();
      const beforeStatus=searchPageReadiness();
      if(currentKey===targetKey&&(beforeStatus.noResults||Number(beforeStatus.itemCount||0)>0||Number(beforeStatus.anchorCount||0)>0)){
        clearKeywordTransitionMarker(target,runId);
        setText('spx-status','자동 분석 시작');
        setText('spx-auto-text',`“${target}” 검색결과 확인 완료 · 키워드 분석 즉시 시작`);
        state.busy=false;state.autoStarted=false;
        if(runId)armAutomationKickWatchdog(runId,target,'현재 검색결과 확인 완료');
        scheduleAutoRun(0);
        return{ok:true,reused:true};
      }
      writeKeywordTransitionMarker(target,runId,beforeSignature);
      setDisplay('spx-auto','flex');setText('spx-status','다음 키워드 검색 중');
      setText('spx-auto-text',`“${target}” 쿠팡 검색창 입력 → 검색버튼 클릭 → 결과 확인`);
      await submitCoupangSearchOnce(target,{fast:true,transitionManaged:true});
      const ready=await waitForKeywordTransitionReady(target,beforeSignature,12000);
      if(ready?.ready){
        markKeywordTransitionReady(target,runId,ready.signature||searchResultSignature());
        state.busy=false;state.autoStarted=false;
        setText('spx-status','자동 분석 시작');
        setText('spx-auto-text',`“${target}” 검색결과 준비 완료 · 키워드 분석 즉시 시작`);
        if(runId)armAutomationKickWatchdog(runId,target,'검색결과 준비 완료');
        scheduleAutoRun(0);
        return{ok:true,sameDocument:true};
      }
      const cleanUrl=searchUrlFor(target,1);
      setText('spx-status','검색결과 다시 불러오기');
      setText('spx-auto-text',`“${target}” 검색결과 전환이 지연되어 표준 검색주소로 한 번 다시 엽니다.`);
      const media=await runtimeMessage({type:'SPX_ENSURE_LOW_BANDWIDTH_COLLECTION_TAB',purpose:'keyword-transition-fallback'});
      if(!media?.ok)throw new Error(media?.error||'다음 검색페이지 이미지·영상·폰트 차단을 적용하지 못했습니다.');
      setLowBandwidthVisualModeV10156(true);
      navigating=true;
      try{location.assign(cleanUrl);}catch(_){location.href=cleanUrl;}
      return{ok:true,navigating:true};
    })().catch((error)=>{
      clearKeywordTransitionMarker(target,runId);
      if(error?.spxContextInvalidated)throw error;
      state.busy=false;state.autoStarted=false;
      setText('spx-status','다음 키워드 이동 실패');
      setText('spx-auto-text',error?.message||String(error));
      throw error;
    }).finally(()=>{
      if(serial===keywordTransitionSerial){
        keywordTransitionPromise=null;keywordTransitionTarget='';keywordTransitionRunId='';
        if(!navigating&&!contextInvalidated){state.busy=false;state.autoStarted=false;}
      }
    });
    keywordTransitionPromise=task;
    return task;
  }

  async function skipPendingNavigation() {
    const pending = pendingNavigation ? { ...pendingNavigation } : null;
    if (!pending?.url || !pending?.runId) return;
    const button = document.getElementById('spx-next-now');
    if (button) button.disabled = true;
    try {
      const response = await runtimeMessage({ type:'SPX_AUTOMATION_SKIP_WAIT', runId:pending.runId });
      if (!response?.ok) throw new Error(response?.error || '단건 다음 이동 승인 실패');
      clearNavigationTimer();
      await waitForServerSignal('normal');
      await transitionKeywordAndStart(pending.keyword,{runId:pending.runId,reason:'사용자 대기 생략'});
    } catch (error) {
      if (button) { button.disabled = false; button.hidden = false; }
      setText('spx-auto-text', `단건 다음 이동 실패 · ${error?.message || error}`);
    }
  }

  function clearAutoRunTimer() {
    if (autoRunTimer) clearTimeout(autoRunTimer);
    autoRunTimer = null;
  }

  function clearAutomationKickWatchdog() {
    if (automationKickTimer) clearTimeout(automationKickTimer);
    automationKickTimer = null;
    automationKickRunId = '';
  }

  /* v3.0.8.6: 단건 분석은 현재 탭에서 직접 파싱을 시작하지만, 연속·재수집·네이버 대기는
     서비스워커가 대기열을 선점하고 탭을 이동한 뒤 content script가 다시 자동 실행을 요청해야
     했습니다. 탭 이동과 document_idle 사이의 짧은 경합으로 scheduleAutoRun 1회가 사라지면
     화면에는 상품이 잡혀도 '수집 중'만 남았습니다. 같은 runId가 살아 있는 동안 짧게 재확인해
     자동 분석 시작 신호를 복구합니다. 실제 파싱이 시작되면 즉시 감시를 종료합니다. */
  function armAutomationKickWatchdog(runId, keyword = '', reason = '대기열 즉시 시작') {
    const targetRunId = String(runId || '').trim();
    if (!targetRunId || contextInvalidated) return false;
    clearAutomationKickWatchdog();
    automationKickRunId = targetRunId;
    const startedAt = Date.now();
    const tick = async () => {
      if (contextInvalidated || automationKickRunId !== targetRunId) return;
      let remote = null;
      try { remote = (await readAutomationState())?.state || null; } catch (_) {}
      if (!remote?.running || String(remote.runId || '') !== targetRunId) {
        clearAutomationKickWatchdog();
        return;
      }
      const expectedKeyword = String(remote.currentKeyword || keyword || '').trim();
      if (keywordTransitionPromise) {
        automationKickTimer=setTimeout(tick,650);
        return;
      }
      if (state.busy) {
        clearAutomationKickWatchdog();
        return;
      }
      if (!state.autoStarting && !state.autoStarted && !navigationTimer) {
        activeRunId = targetRunId;
        if (expectedKeyword) state.lockedKeyword = expectedKeyword;
        setDisplay('spx-auto', 'flex');
        setText('spx-status', '자동 수집 시작');
        setText('spx-auto-text', `${expectedKeyword || currentKeyword() || '대기열 키워드'} 즉시 분석 시작 · ${reason}`);
        scheduleAutoRun(0);
      }
      if (Date.now() - startedAt >= 12000) {
        clearAutomationKickWatchdog();
        return;
      }
      automationKickTimer = setTimeout(tick, 650);
    };
    automationKickTimer = setTimeout(tick, 0);
    return true;
  }

  function cancelAutomationWork(reason = '자동수집 중단', { updateUi = true, keepRunId = false } = {}) {
    automationEpoch += 1;
    clearNavigationTimer();
    clearAutoRunTimer();
    clearAutomationKickWatchdog();
    state.busy = false;
    state.autoStarting = false;
    state.autoStarted = false;
    automationContextFailureCount = 0;
    if (!keepRunId) activeRunId = null;
    if (updateUi && !contextInvalidated && currentKeyword()) {
      ensureUi();
      setDisplay('spx-auto', 'flex');
      const idleLabel={guided:'단건 대기',full:'연속 대기',local:'로컬DB 대기',refresh:'대기열 대기'}[normalizeSidebarSourcingMode(committedSidebarSourcingMode||sidebarSourcingMode)]||'수집 대기';
      setText('spx-status', idleLabel);
      setText('spx-auto-text', reason);
    }
  }

  function scheduleAutoRun(delayMs = 700) {
    if (contextInvalidated) return false;
    clearAutoRunTimer();
    const scheduledEpoch = automationEpoch;
    autoRunTimer = setTimeout(() => {
      autoRunTimer = null;
      if (contextInvalidated || scheduledEpoch !== automationEpoch) return;
      maybeAutoRun();
    }, Math.max(0, Number(delayMs) || 0));
  }

  function beginAutomationTask(runId) {
    if (contextInvalidated) throw contextEndError();
    clearNavigationTimer();
    automationEpoch += 1;
    activeRunId = String(runId || '');
    return { epoch: automationEpoch, runId: activeRunId };
  }

  function taskIsCurrent(task) {
    return Boolean(!contextInvalidated && task && !task.cancelled && task.runId && task.epoch === automationEpoch && task.runId === activeRunId);
  }

  function shouldDeferTerminalStateChange(next = {}) {
    const pending = pendingPageSaveResponse;
    if (!pending || !state.busy || next?.running !== false) return false;
    const sameRun = String(next?.runId || '') && String(next?.runId || '') === String(pending.runId || activeRunId || '');
    if (!sameRun) return false;
    const phase = String(next?.pageLoopPhase || '');
    return next?.keywordLoopCompleted === true || ['finalizing', 'keyword_complete', 'manual_complete'].includes(phase);
  }

  function rememberRenderedCompletion(runId) {
    recentlyRenderedCompletion = { runId:String(runId || ''), at:Date.now() };
  }

  function isRecentlyRenderedCompletion(next = {}) {
    const runId = String(next?.runId || '');
    return Boolean(runId && runId === recentlyRenderedCompletion.runId && Date.now() - Number(recentlyRenderedCompletion.at || 0) < 30000);
  }


  let activeStage = null;
  let stageTicker = null;
  function clearStageTicker() { if (stageTicker) clearInterval(stageTicker); stageTicker = null; }
  function stageElapsedText(stage = activeStage) {
    if (!stage) return '';
    const elapsed = Math.max(0, Date.now() - Number(stage.startedAt || Date.now()));
    const idle = Math.max(0, Date.now() - Number(stage.lastActivityAt || stage.startedAt || Date.now()));
    return `경과 ${Math.floor(elapsed/1000)}초 · 마지막 정상 ${Math.floor(idle/1000)}초 전`;
  }
  function startStage(name, attempt = 1) {
    activeStage = { name:String(name || '처리 중'), attempt, startedAt:Date.now(), lastActivityAt:Date.now() };
    clearStageTicker();
    stageTicker = setInterval(() => {
      if (!activeStage || contextInvalidated) return;
      setText('spx-ptime', stageElapsedText());
    }, 1000);
    console.info(`[SPX][watchdog] ${activeStage.name} 시작 · ${attempt}차`);
    return activeStage;
  }
  function touchStage(detail = '') {
    if (!activeStage) return;
    activeStage.lastActivityAt = Date.now();
    if (detail) console.info(`[SPX][watchdog] ${activeStage.name} · ${detail}`);
  }
  function finishStage(result = '완료') {
    if (activeStage) console.info(`[SPX][watchdog] ${activeStage.name} ${result} · ${stageElapsedText(activeStage)}`);
    activeStage = null;
    clearStageTicker();
  }
  async function runStageWithTimeout(task, name, timeoutMs, maxAttempts, factory, watchdog = {}) {
    let lastError = null;
    const attempts = Math.max(1, Number(maxAttempts) || 1);
    for (let attempt = 1; attempt <= attempts; attempt += 1) {
      if (task && !taskIsCurrent(task)) throw normalEnd('STALE_TASK', `${name} 중 페이지가 변경되었습니다.`);
      const stageTask = task ? { ...task, cancelled:false } : null;
      startStage(name, attempt);
      let timer = null;
      try {
        const timeout = new Promise((_, reject) => {const hard=Math.max(1000,Number(timeoutMs)||1000),requestedIdle=Number(watchdog?.idleTimeoutMs),idle=Number.isFinite(requestedIdle)?Math.max(30000,Math.min(hard,requestedIdle)):Math.min(90000,Math.max(30000,Math.round(hard*0.35)));timer=setInterval(()=>{const now=Date.now(),elapsed=now-Number(activeStage?.startedAt||now),inactive=now-Number(activeStage?.lastActivityAt||activeStage?.startedAt||now);if(elapsed<hard&&inactive<idle)return;if(stageTask)stageTask.cancelled=true;const reason=inactive>=idle?`마지막 DOM 활동 ${Math.round(inactive/1000)}초 없음`:`전체 ${Math.round(hard/1000)}초 초과`;const error=new Error(`${name} 제한시간 초과 · ${reason}`);error.code='STAGE_TIMEOUT';error.stage=name;error.attempt=attempt;clearInterval(timer);reject(error);},1000);});
        if(stageTask){stageTask.touch=(detail='')=>touchStage(detail);stageTask.assert=()=>{if(stageTask.cancelled||!taskIsCurrent(stageTask))throw normalEnd('STALE_TASK',`${name} 중 페이지가 변경되거나 작업이 취소되었습니다.`);};}
        const value = await Promise.race([Promise.resolve().then(() => factory(stageTask || task, attempt)), timeout]);
        clearInterval(timer); touchStage('정상 완료'); finishStage('완료'); return value;
      } catch (error) {
        clearInterval(timer); lastError = error;
        const lastActivityAt = Number(activeStage?.lastActivityAt || Date.now());
        if (error?.spxNormalEnd) {
          finishStage('정상 페이지 전환');
          console.info(`[SPX][watchdog] ${name} · 페이지 이동으로 현재 DOM 작업 정상 종료`, error.code || 'NORMAL_END');
          throw error;
        }
        const contextEnded = Boolean(
          error?.spxContextInvalidated ||
          SPX.util.isContextInvalidatedError?.(error) ||
          contextInvalidated
        );
        if (contextEnded) {
          finishStage('확장 업데이트로 정상 종료');
          if (!contextInvalidated) shutdownInvalidatedContext();
          /* 확장프로그램을 업데이트/새로고침하면 기존 쿠팡 탭의 content script 컨텍스트는
             정상적으로 폐기됩니다. Error 객체를 console.warn/error에 넘기면 Chrome이 이를
             확장프로그램 오류로 기록하므로, 사용자 조치가 필요한 오류가 아닌 경우 조용히
             종료하고 탭 새로고침 안내만 표시합니다. */
          console.info(`[SPX][watchdog] ${name} · 확장 업데이트로 기존 탭 작업을 조용히 종료합니다.`);
          throw contextEndError();
        }
        finishStage('실패');
        if(error?.code==='STAGE_TIMEOUT'||error?.code===SEARCH_LOAD_TIMEOUT) console.info(`[SPX][watchdog] ${name} ${attempt}/${attempts} 지연 · 카드정보 우선 복구`, error.message);
        else console.info(`[SPX][watchdog] ${name} ${attempt}/${attempts} 일반 실패 · ${error?.message||String(error)}`);
        if (error?.code === 'COUPANG_BLOCKED') throw error;
        if (attempt < attempts) {
          setProgress(4, `${name} 지연 · ${attempt + 1}차 자동 재시도`, `마지막 정상 ${Math.floor((Date.now()-lastActivityAt)/1000)}초 전`);
          await SPX.util.sleep(jitterMs(760*attempt,1180*attempt));
        }
      }
    }
    throw lastError || new Error(`${name} 실패`);
  }

  function normalEnd(code, message, extra = {}) {
    const error = new Error(message || '자동수집이 정상 종료되었습니다.');
    error.spxNormalEnd = true;
    error.code = code || 'NORMAL_END';
    Object.assign(error, extra || {});
    return error;
  }

  async function readAutomationState() {
    return runtimeMessage({ type: 'SPX_QUEUE_STATE' });
  }

  // v1.6.22: wait for the original ACK first; periodically check the *local* durable
  // checkpoint without restarting page parsing, re-uploading, or querying Supabase.
  async function sendPageWithDurableAckV1622(message) {
    const original=runtimeMessage(message).then(response=>({done:true,response}),error=>({done:true,error}));
    for(;;){
      const race=await Promise.race([original,SPX.util.sleep(10000).then(()=>({done:false}))]);
      if(race.done){
        if(!race.error)return race.response;
        // A MV3 channel can close *after* the worker committed. Read the proof first.
        const probe=await Promise.race([runtimeMessage({type:'SPX_AUTOMATION_PAGE_STATUS_V1622',runId:message.runId,requestId:message.requestId,keyword:message.keyword,page:message.page}).catch(()=>null),SPX.util.sleep(2500).then(()=>null)]);
        if(probe?.committed===true&&probe.response?.ok===true)return probe.response;
        throw race.error;
      }
      const probe=await Promise.race([runtimeMessage({type:'SPX_AUTOMATION_PAGE_STATUS_V1622',runId:message.runId,requestId:message.requestId,keyword:message.keyword,page:message.page}).catch(()=>null),SPX.util.sleep(2500).then(()=>null)]);
      if(probe?.committed===true&&probe.response?.ok===true){
        console.info('[SPX ACK] 저장완료 체크포인트로 응답 회복',probe.ackSource||'checkpoint');
        return probe.response;
      }
      if(probe?.busy&&probe.phase){
        setText('spx-auto-text',`페이지 저장 처리 중 · ${probe.phase} · 서버 재조회 없이 로컬 완료만 확인`);
      }
    }
  }

  let displayedDiscoveredKeywords=[];
  let displayedRelatedTerms=[];
  function removeDiscoveredKeywordFromSidebar(keyword){
    const target=SPX.canonicalKeyword?.(keyword)||String(keyword||'').replace(/\s+/g,'').toLowerCase();
    if(!target)return;
    displayedDiscoveredKeywords=displayedDiscoveredKeywords.filter((item)=>(SPX.canonicalKeyword?.(item)||String(item||'').replace(/\s+/g,'').toLowerCase())!==target);
    displayedRelatedTerms=displayedRelatedTerms.filter((item)=>(SPX.canonicalKeyword?.(item)||String(item||'').replace(/\s+/g,'').toLowerCase())!==target);
    renderDiscoveredKeywords(displayedDiscoveredKeywords,displayedRelatedTerms);
  }
  function renderDiscoveredKeywords(candidates = [], relatedTerms = []) {
    displayedDiscoveredKeywords=Array.isArray(candidates)?[...candidates]:[];
    displayedRelatedTerms=Array.isArray(relatedTerms)?[...relatedTerms]:[];
    const unique = [];
    const seen = new Set();
    /* [v2.0] 후보가 조용히 사라지지 않도록, 제외된 사유를 집계해서 함께 보여준다. */
    const excludedTally = { 중복:0, 금지어:0, 빈문자열:0 };
    for (const row of [...(candidates || []), ...(relatedTerms || []).map((keyword) => ({ keyword,raw_related:true }))]) {
      const rawKeyword = row?.keyword || row || '';
      const keyword = row?.raw_related===true ? String(rawKeyword||'').replace(/\s+/g,' ').trim() : (SPX.discovery?.sanitizeDiscoveredKeyword?.(rawKeyword) || '');
      if (!keyword) { if (String(rawKeyword || '').trim()) excludedTally.빈문자열 += 1; continue; }
      const key = SPX.util?.canonicalKeyword?.(keyword) || keyword.toLowerCase();
      if (!key) { excludedTally.빈문자열 += 1; continue; }
      if (seen.has(key)) { excludedTally.중복 += 1; continue; }
      if (row?.raw_related!==true && SPX.discovery?.isBlockedKeyword?.(keyword)) { excludedTally.금지어 += 1; continue; }
      seen.add(key); unique.push(keyword);
    }
    state.candidates = Array.isArray(candidates) ? candidates : [];
    const excludedTotal = excludedTally.중복 + excludedTally.금지어 + excludedTally.빈문자열;
    const excludedNote = excludedTotal
      ? ` · 제외 ${excludedTotal}(중복 ${excludedTally.중복}·금지어 ${excludedTally.금지어}·빈값 ${excludedTally.빈문자열})`
      : '';
    setText('spx-discovered', `발견 ${unique.length}개${unique.length ? ' · 순위순' : ' · 없음'}${excludedNote}`);
    const head = getUiElement('spx-discovered', { repair:false });
    if (head) head.title = unique.length ? `${unique.length}개 발견 · 아래 목록에서 클릭하면 바로 검색됩니다${excludedTotal ? ` · 제외 ${excludedTotal}개는 중복·금지어·빈 문자열 정제 결과입니다` : ''}` : '현재 검색결과에서 신규 분석 후보를 찾지 못했습니다.';
    /* [v2.0] 발견 키워드를 한 줄 요약(잘림)이 아니라, 순위 그대로 스크롤 리스트 전체로 보여준다.
       각 항목 클릭 시 쿠팡 검색으로 바로 이동, 복사 버튼으로 텍스트만 복사할 수 있다. */
    const list = getUiElement('spx-discovered-list', { repair:false });
    if (list) {
      list.hidden = unique.length === 0;
      list.innerHTML = unique.map((keyword, index) => `
        <div class="spx-discovered-item">
          <span class="spx-discovered-rank">${index + 1}</span>
          <span class="spx-discovered-word" role="button" tabindex="0" data-keyword="${esc(keyword)}">${esc(keyword)}</span>
          <button type="button" class="spx-discovered-copy" data-keyword="${esc(keyword)}">⧉</button>
        </div>`).join('');
    }
    return unique;
  }

  async function searchOnCoupang(keyword) {
    if (!keyword) return;
    await waitForServerSignal('normal');
    const media=await runtimeMessage({type:'SPX_ENSURE_LOW_BANDWIDTH_COLLECTION_TAB',purpose:'discovered-keyword-navigation'});
    if(!media?.ok)throw new Error(media?.error||'검색수집 이미지·영상·폰트 차단을 적용하지 못했습니다.');
    setLowBandwidthVisualModeV10156(true);
    location.href = `https://www.coupang.com/np/search?q=${encodeURIComponent(keyword)}&page=1&channel=user`;
  }

  function bindDiscoveredListActions() {
    const list = getUiElement('spx-discovered-list', { repair:false });
    if (!list || list.dataset.spxBound) return;
    list.dataset.spxBound = '1';
    list.addEventListener('click', (event) => {
      const copyBtn = event.target.closest('.spx-discovered-copy');
      if (copyBtn) {
        const keyword = copyBtn.dataset.keyword || '';
        navigator.clipboard?.writeText(keyword).then(() => {
          const old = copyBtn.textContent; copyBtn.textContent = '✓'; setTimeout(() => { copyBtn.textContent = old; }, jitterMs(780,1120));
        }).catch(() => {});
        return;
      }
      const word = event.target.closest('.spx-discovered-word');
      if (word) searchOnCoupang(word.dataset.keyword || '');
    });
    list.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      const word = event.target.closest('.spx-discovered-word');
      if (word) { event.preventDefault(); searchOnCoupang(word.dataset.keyword || ''); }
    });
  }

  const NAVER_STATUS_KO = Object.freeze({
    success:'조회 완료', cached:'캐시 완료', complete:'수집 완료', pending:'조회 중',
    enrichment_pending:'일부 자료 부족', rate_limited:'호출 제한', no_data:'정상조회 · 자료없음',
    not_available:'정상조회 · 자료없음', not_configured:'인증정보 필요', failed:'조회 실패', disabled:'사용 안 함', queued:'조회 대기', running:'조회 중', insufficient:'정상조회 · 자료부족',
  });
  
  
  
  
  
  

  
  
  async function syncSidebarAutoExtraPageSetting(){
    const settings=await safeGetSettings();
    const checked=sidebarExtraPageSessionOverride===null?settings.autoExtraPageEnabled===true:sidebarExtraPageSessionOverride===true;
    const sidebar=getUiElement('spx-auto-extra-page',{repair:false});if(sidebar)sidebar.checked=checked;
    const common=document.querySelector('#spx-overlay [data-common-field="autoExtraPageEnabled"]');if(common){common.checked=checked;syncCollectionToggleState(common);}
    return checked;
  }

  

  

  function clampNextNavigationDelayRange(minValue,maxValue){
    const min=Math.max(100,Math.min(120000,Math.round(Number(minValue)||NEXT_NAVIGATION_DELAY_DEFAULT.min)));
    const max=Math.max(min,Math.min(180000,Math.round(Number(maxValue)||NEXT_NAVIGATION_DELAY_DEFAULT.max)));
    return {min,max};
  }
  function applyNextNavigationDelayInputs(range=nextNavigationDelayRange){
    const normalized=clampNextNavigationDelayRange(range?.min,range?.max);
    nextNavigationDelayRange=normalized;
    const minInput=getUiElement('spx-next-delay-min-ms',{repair:false}),maxInput=getUiElement('spx-next-delay-max-ms',{repair:false});
    if(minInput&&document.activeElement!==minInput)minInput.value=String(normalized.min);
    if(maxInput&&document.activeElement!==maxInput)maxInput.value=String(normalized.max);
    return normalized;
  }
  async function syncNextNavigationDelaySetting(settings=null){
    const current=settings&&typeof settings==='object'?settings:await safeGetSettings();
    return applyNextNavigationDelayInputs({min:current?.nextNavigationDelayMinMs,max:current?.nextNavigationDelayMaxMs});
  }
  function readNextNavigationDelayInputs(){
    return clampNextNavigationDelayRange(getUiElement('spx-next-delay-min-ms',{repair:false})?.value,getUiElement('spx-next-delay-max-ms',{repair:false})?.value);
  }
  async function saveNextNavigationDelayFromSidebar(){
    clearTimeout(nextNavigationDelayPersistTimer);nextNavigationDelayPersistTimer=null;
    const range=applyNextNavigationDelayInputs(readNextNavigationDelayInputs());
    await SPX.util.setSettings({nextNavigationDelayMinMs:range.min,nextNavigationDelayMaxMs:range.max});
    return range;
  }
  function scheduleNextNavigationDelayPersistence(){
    const range=readNextNavigationDelayInputs();nextNavigationDelayRange=range;
    clearTimeout(nextNavigationDelayPersistTimer);
    nextNavigationDelayPersistTimer=setTimeout(()=>{nextNavigationDelayPersistTimer=null;saveNextNavigationDelayFromSidebar().catch(()=>{});},jitterMs(260,460));
  }
  function randomNextNavigationDelayMs(){
    const range=clampNextNavigationDelayRange(nextNavigationDelayRange.min,nextNavigationDelayRange.max);
    return jitterMs(range.min,range.max);
  }

  function sidebarAutoUploadCheckboxes(){return ['spx-auto-upload','spx-auto-upload-sourcing'].map((id)=>getUiElement(id,{repair:false})).filter(Boolean);}
  async function syncSidebarAutoUploadSetting(settings = null) {
    const boxes=sidebarAutoUploadCheckboxes();
    if (!boxes.length) return false;
    const current = settings && typeof settings === 'object' ? settings : await safeGetSettings();
    const enabled=current?.autoUpload === true;
    for(const checkbox of boxes){checkbox.checked=enabled;checkbox.title=enabled?'수집 완료 후 서버DB에 자동으로 올립니다.':'수집 결과를 업로드 대기로 남기고 올리기 버튼으로 직접 반영합니다.';}
    return enabled;
  }

  async function updateSidebarAutoUploadSetting(enabled) {
    const boxes=sidebarAutoUploadCheckboxes();
    for(const checkbox of boxes)checkbox.disabled=true;
    try {
      /* v4.0.98: 전용창의 자동 업로드도 추가페이지와 동일한 명시 사용자 설정으로 취급합니다.
         Native Host 보호본까지 write-through하여 다음 수집 시작 시 과거 OFF 값으로 되돌아가지 않습니다. */
      const response=await runtimeMessage({type:'SPX_UPDATE_AUTO_UPLOAD_POLICY',enabled:enabled===true,source:'sidebar'}).catch((error)=>({ok:false,error:error?.message||String(error)}));
      if(response?.ok!==true)await SPX.util.setSettings({ autoUpload: enabled === true });
      for(const checkbox of boxes)checkbox.checked=enabled===true;
      setClass('spx-dbstate', 'spx-ok');
      setText('spx-dbstate', enabled ? '● 완료 후 서버 직행' : '● 업로드 대기');
      return true;
    } catch (error) {
      for(const checkbox of boxes)checkbox.checked=!enabled;
      setClass('spx-dbstate', 'spx-err');
      setText('spx-dbstate', `● 설정 저장 실패: ${error?.message || error}`);
      return false;
    } finally {
      for(const checkbox of boxes)checkbox.disabled=false;
    }
  }

  function renderSidebarModeBadge(label = selectedSourcingModeLabel(sidebarSourcingMode), profile = activeCollectionProfile, running = false) {
    const modeBadge = getUiElement('spx-mode-badge', { repair:false });
    if (!modeBadge) return;
    const normalizedProfile = normalizeCollectionProfile(profile);
    modeBadge.dataset.profile = normalizedProfile;
    modeBadge.classList.remove('profile-pro');
    if (!label) { modeBadge.hidden = true; return; }
    modeBadge.hidden = false;
    modeBadge.textContent = label;
    modeBadge.title = running ? `현재 진행 중: ${label}` : `선택 상태: ${label}`;
  }

  function setSidebarCollecting(active){const overlay=getUiElement('spx-overlay',{repair:false});if(overlay)overlay.classList.toggle('spx-collecting',active===true);scanManagementRunningV1636=active===true;updateScanManagementLabelV1636();}
  /* v1.6.41: the SCAN button may display a confirmed management state while
     collecting. Never infer status from grades/progress. Reset when stopped. */
  let scanManagementRunningV1636=false;
  function updateScanManagementLabelV1636(data=null){
    const button=getUiElement('spx-scan',{repair:false});if(!button)return;
    if(!scanManagementRunningV1636){button.textContent='키워드 분석';button.style.removeProperty('color');button.dataset.originalText='키워드 분석';return;}
    if(button.textContent==='복구 중'||button.textContent==='시작 중…')return;
    const current=SPX.util?.canonicalKeyword?.(currentKeyword()||state.lockedKeyword||state.keyword||'')||'';
    if(!current||sidebarServerKeywordPresence.canonical!==current||sidebarServerKeywordPresence.known===false){button.textContent='키워드 분석';button.style.removeProperty('color');return;}
    const raw=String(data?.management_state||data?.collection_management_state||data?.statusLabel||'').replace(/\s+/g,'').trim();
    const code=String(data?.status||sidebarServerKeywordPresence.status||'').trim();
    let label='';
    for(const value of ['부족없음','갱신대기','보완필요','신규키워드','기준미달','제외'])if(raw.includes(value)){label=value;break;}
    if(data?.unknown===true)label='';
    if(!label&&data?.unknown!==true){label=({'server_complete':'부족없음','recollect_pending':'갱신대기','recollect_needed':'보완필요','discovered':'신규키워드','new':'신규키워드','below_criteria':'기준미달','excluded':'제외'})[code]||'';}
    if(!label&&code==='recollect_pending'&&/갱신|보완/.test(raw))label=raw.includes('갱신')?'갱신대기':'보완필요';
    const style=analysisManagementStatusV1632({management_state:label});
    button.textContent=style?.label||'키워드 분석';button.dataset.originalText='키워드 분석';
    if(style?.color)button.style.setProperty('color',style.color,'important');
    else button.style.removeProperty('color');
  }

  function activeSidebarKeyword(remote={}){return String(remote?.currentKeyword||currentKeyword()||state.lockedKeyword||state.keyword||'').trim();}
  const SIDEBAR_KEYWORD_STATUS_CLASSES=['server-keyword-status-server_complete','server-keyword-status-recollect_pending','server-keyword-status-naver_pending','server-keyword-status-discovered','server-keyword-status-recollect_needed'];
  let sidebarServerKeywordPresence={canonical:'',checkedAt:0,exists:false,status:'new',inFlight:null};
  function applySidebarServerKeywordPresence(exists=false,data={}){
    const button=getUiElement('spx-scan',{repair:false});
    const box=getUiElement('spx-overlay',{repair:false})?.querySelector?.('.spx-detect')||null;
    const status=['server_complete','recollect_pending','naver_pending','discovered','recollect_needed'].includes(String(data?.status||''))?String(data.status):'new';
    const label=String(data?.statusLabel||({server_complete:'서버 등록 · 부족 없음',recollect_pending:'서버 등록 · 보완 대기',naver_pending:'기존 자료 보완 대기',discovered:'발견 키워드',recollect_needed:'보완 대기',new:'새로운 키워드'}[status]||'새로운 키워드'));
    updateScanManagementLabelV1636(data?.unknown===true?null:(data||{status:'new'}));
    for(const node of [button,box]){
      if(!node)continue;
      node.classList.remove(...SIDEBAR_KEYWORD_STATUS_CLASSES);
      node.classList.toggle('server-keyword-exists',exists===true);
      if(exists===true&&status!=='new'){node.classList.add(`server-keyword-status-${status}`);node.dataset.serverKeyword='1';node.dataset.keywordIndexStatus=status;node.setAttribute('aria-label',`${label}${data?.serverKeyword?` · ${data.serverKeyword}`:''}`);}else{node.removeAttribute('data-server-keyword');node.removeAttribute('data-keyword-index-status');node.removeAttribute('aria-label');}
    }
  }
  async function syncSidebarServerKeywordPresence(force=false){
    const keyword=String(currentKeyword()||state.lockedKeyword||state.keyword||'').trim();
    const canonical=SPX.util?.canonicalKeyword?.(keyword)||String(keyword||'').replace(/\s+/g,'').toLowerCase();
    const button=getUiElement('spx-scan',{repair:false});
    if(!button)return;
    if(!canonical){sidebarServerKeywordPresence={canonical:'',checkedAt:Date.now(),exists:false,status:'new',known:false,inFlight:null};applySidebarServerKeywordPresence(false);return;}
    if(sidebarServerKeywordPresence.canonical!==canonical){
      applySidebarServerKeywordPresence(false);
      sidebarServerKeywordPresence={canonical,checkedAt:0,exists:false,status:'new',known:false,inFlight:null};
    }
    if(!force&&Date.now()-Number(sidebarServerKeywordPresence.checkedAt||0)<10000)return;
    if(sidebarServerKeywordPresence.inFlight)return sidebarServerKeywordPresence.inFlight;
    const task=(async()=>{
      try{
        const response=await runtimeMessage({type:'SPX_SERVER_KEYWORD_EXISTS',keyword,force:force===true});
        const data=response?.data||{};
        const liveCanonical=SPX.util?.canonicalKeyword?.(currentKeyword()||state.lockedKeyword||state.keyword||'')||'';
        if(liveCanonical!==canonical)return;
        const exists=response?.ok===true&&data.exists===true;
        sidebarServerKeywordPresence={canonical,checkedAt:Date.now(),exists,status:String(data.status||'new'),known:response?.ok===true&&data.unknown!==true,inFlight:null};
        applySidebarServerKeywordPresence(exists,data);
      }catch(_){sidebarServerKeywordPresence={...sidebarServerKeywordPresence,canonical,checkedAt:Date.now(),exists:false,status:'new',known:false,inFlight:null};applySidebarServerKeywordPresence(false);}
    })();
    sidebarServerKeywordPresence.inFlight=task;
    return task.finally(()=>{if(sidebarServerKeywordPresence.inFlight===task)sidebarServerKeywordPresence.inFlight=null;});
  }
  
  function isCurrentCoupangSearchPage(){try{return /(^|\.)coupang\.com$/i.test(location.hostname)&&location.pathname.startsWith('/np/search')&&Boolean(currentKeyword());}catch(_){return false;}}
  function setAnalysisStartFeedback(){const button=getUiElement('spx-scan',{repair:false});if(button){button.disabled=true;button.dataset.originalText=button.dataset.originalText||button.textContent||'키워드 분석';button.textContent='시작 중…';button.classList.add('starting');button.setAttribute('aria-busy','true');}setSidebarCollecting(true);setDisplay('spx-auto','flex');setText('spx-status','수집 준비');setText('spx-auto-text','선택한 방식과 키워드를 확인하고 바로 수집을 시작합니다.');}
  function clearAnalysisStartFeedback(){const button=getUiElement('spx-scan',{repair:false});if(button){button.textContent=button.dataset.originalText||'키워드 분석';button.classList.remove('starting');button.removeAttribute('aria-busy');button.disabled=state.busy===true;}}

  async function refreshSidebarRunButton(remoteState = null) {
    ;
    const button = getUiElement('spx-run-toggle', { repair:false });
    if (!button) return;
    let remote = remoteState;
    if (!remote) {
      const response = await readAutomationState().catch(() => null);
      remote = response?.state || null;
    }
    const startPending = sourcingStartPending === true;
    const recoveryPending=remote?.networkRecoveryPaused===true&&remote?.waitKind!=='network-reset-failed';
    /* 단건 분석 완료 상태가 저장된 뒤에도 이전 running 값이 한 번 더 전달되면 정지 버튼과
       '자동수집을 즉시 멈춥니다' 말풍선이 남았습니다. manual_complete를 최종 상태로 우선합니다. */
    const remoteManualComplete=String(remote?.pageLoopPhase||'')==='manual_complete'||(remote?.workScope==='manual'&&remote?.keywordLoopCompleted===true&&remote?.sidebarManual!==true);
    const localManualComplete=Boolean(localManualCompletedKeyword)&&normKeyword(localManualCompletedKeyword)===normKeyword(currentKeyword())&&!localManualScanActive;
    const manualTerminal=remoteManualComplete||localManualComplete;
    const localTaskActive=state.busy===true||Boolean(activeStage)||Boolean(activeRunId);
    const recoveryVisualActive=recoveryPending||recoveryUiOwner;
    const running = recoveryVisualActive || (!manualTerminal && (!!remote?.running || localManualScanActive || localTaskActive || startPending));
    const displayKeyword=activeSidebarKeyword(remote||{});
    if(displayKeyword);
    syncSidebarServerKeywordPresence(false).catch(()=>{});
    setSidebarCollecting(running);
    clearAnalysisStartFeedback();
    updateScanManagementLabelV1636();
    if(running&&!tabSessionStats.automationRunning)setTabAutomationTimer('start').catch(()=>{});
    else if(!running&&tabSessionStats.automationRunning)setTabAutomationTimer('stop').catch(()=>{});
    if(!running)await loadActiveCollectionProfile().catch(()=>{});

    button.dataset.running = String(running);
    button.textContent = running ? '■' : '▶';
    button.title = recoveryVisualActive ? '진행 중인 비행기 모드·IP 변경과 수집 재개를 중단합니다.' : startPending ? '연속 탐색 후보를 준비하는 시작 단계를 즉시 멈춥니다.' : running ? (localManualScanActive?'현재 단건 수집을 즉시 멈춥니다.':'자동수집을 즉시 멈춥니다.') : '팝업에서 선택한 수집 방식과 동일하게 자동수집을 시작합니다.';
    button.setAttribute('aria-label', recoveryVisualActive ? '쿠팡 차단 IP 복구 멈춤' : startPending ? '연속 탐색 후보 확인 멈춤' : running ? (localManualScanActive?'단건 수집 멈춤':'자동수집 멈춤') : '자동수집 시작');
    button.dataset.spxTip = button.title;
    button.classList.toggle('running', running);
    button.hidden=!running;
    button.disabled = false;
    /* [v2.0.3] 실행상태(감지됨/자동 중단 등)와 소싱 방식(지정 키워드/재수집 대기 우선 등)이
       한 배지에 같이 들어가 있어 텍스트가 겹치거나 줄바꿈되던 문제. 두 배지로 분리하고,
       멈춤 상태에서도 팝업에서 마지막으로 선택한 소싱 방식을 표시한다. */
    const statusEl = getUiElement('spx-status', { repair:false });
    if (statusEl) {
      const terminalPending = !running && shouldDeferTerminalStateChange(remote || {});
      const manualCompleted = !running && String(remote?.pageLoopPhase || '') === 'manual_complete';
      const idleLabel={guided:'단건 대기',full:'연속 대기',local:'로컬DB 대기',refresh:'대기열 대기'}[normalizeSidebarSourcingMode(committedSidebarSourcingMode||sidebarSourcingMode)]||'수집 대기';
      /* v4.0.26: 네트워크 복구 단계 문구는 recovery monitor 한 곳만 소유합니다.
         AUTO_KEY가 자주 바뀌어도 '수집 중/접근 제한' 같은 일반 상태가 복구 단계 위에 덮어쓰지 않습니다. */
      if(!(recoveryPending||recoveryUiOwner))statusEl.textContent = startPending ? '후보 확인 중' : running ? '수집 중' : terminalPending ? '최종 결과 반영 중' : manualCompleted ? '단건 분석 완료' : idleLabel;
      statusEl.removeAttribute('title');
    }
    /* 다음 버튼은 항상 표시합니다. 실행 중이면 현재 작업을 먼저 멈추고 같은 순서 목록의
       다음 키워드로 이동하며, 대기 상태이면 발견·재수집의 다음 키워드를 엽니다. */
    const skipBtn = getUiElement('spx-skip-keyword', { repair:false });
    if (skipBtn) {skipBtn.hidden=false;skipBtn.disabled=recoveryVisualActive||manualIpChangePending;}
    const ipChangeBtn = getUiElement('spx-change-ip', { repair:false });
    if (ipChangeBtn) {
      ipChangeBtn.hidden = false;
      ipChangeBtn.disabled = recoveryVisualActive || manualIpChangePending;
      ipChangeBtn.title = (recoveryVisualActive||manualIpChangePending) ? '현재 IP 변경이 진행 중입니다.' : '선택 네트워크 공인 IP를 변경하고 현재 수집 위치에서 재개합니다.';
    }
    const excludeBtn = getUiElement('spx-exclude-keyword', { repair:false });
    if (excludeBtn) excludeBtn.hidden = false;
    /* Next 아이콘 상자는 항상 같은 자리에 둡니다. 자동수집 중에는 숨기지 않고 비활성화합니다. */
    const stepBtn = getUiElement('spx-step-once', { repair:false });
    if (stepBtn) {
      stepBtn.hidden = false;
      stepBtn.disabled = recoveryVisualActive||manualIpChangePending;
    }
    const label = selectedSourcingModeLabel(sidebarSourcingMode);
    renderSidebarModeBadge(label, activeCollectionProfile, running);
    refreshNextKeywordHint(false).catch(()=>{});
    if(recoveryPending&&!recoveryCountdownTimer)startRecoveryCountdownMonitor();
  }

  /* [v2.1.3] 사용자가 화면을 보다가 지금 진행 중인 키워드를 건너뛰고 다음 키워드로 바로
     넘어갈 수 있게 한다. 특히 페이지가 많이 남아(예: 10페이지) 차단이 자주 뜨는 키워드를
     수동으로 넘길 때 유용하다. */
  /* [v2.2.0] 멈춤 상태에서도 선택된 소싱 방식으로 키워드 1개만 검색·수집하고 다시 멈추는
     수동 단계별 진행 기능. */
  function normalizeCollectionProfile(value){return 'lite';}
  function profileStorageMode(profile=activeCollectionProfile){return 'manual';}
  function renderCollectionProfileSwitch(){activeCollectionProfile='lite';}
  async function setActiveCollectionProfile(profile,options={}){
    activeCollectionProfile='lite';
    if(options.syncSettingsTab===true)switchCollectionSettingsTab('manual');
    if(options.persist!==false)await chrome.storage.local.set({[COLLECTION_PROFILE_KEY]:'lite'}).catch(()=>{});
    if(options.refresh!==false)await refreshSidebarRunButton().catch(()=>{});
    return activeCollectionProfile;
  }
  async function loadActiveCollectionProfile(){
    activeCollectionProfile='lite';
    await chrome.storage.local.set({[COLLECTION_PROFILE_KEY]:'lite'}).catch(()=>{});
    return activeCollectionProfile;
  }
  async function selectedCollectionProfileSettings(){
    await sidebarExtraPagePersistPromise.catch(()=>null);
    await loadActiveCollectionProfile();
    const baseSettings=await safeGetSettings();
    const profiles=await loadSidebarProfiles(baseSettings);
    const settingsOverride=profileToSettings(manualBaselineSettings(baseSettings),profiles.manual);
    const sidebarExtraPage=getUiElement('spx-auto-extra-page',{repair:false});
    if(sidebarExtraPage)settingsOverride.autoExtraPageEnabled=sidebarExtraPage.checked===true;
    else settingsOverride.autoExtraPageEnabled=baseSettings.autoExtraPageEnabled===true;
    const sidebarAutoUpload=getUiElement('spx-auto-upload-sourcing',{repair:false})||getUiElement('spx-auto-upload',{repair:false});
    if(sidebarAutoUpload)settingsOverride.autoUpload=sidebarAutoUpload.checked===true;
    else settingsOverride.autoUpload=baseSettings.autoUpload===true;
    settingsOverride.maxPagesPerKeyword=Math.max(1,Math.min(50,Number(settingsOverride.maxPagesPerKeyword)||1));
    return {profile:'lite',storageMode:'manual',profileData:profiles.manual,settingsOverride};
  }
  let activeSettingsTab = 'manual';
  function setAirplaneModeIndicatorV105(enabled,source='status'){
    const button=getUiElement('spx-airplane-toggle',{repair:false});if(!button)return;
    const on=enabled===true;
    button.dataset.enabled=on?'1':'0';
    button.classList.toggle('spx-airplane-active',on);
    button.dataset.spxTip=on?'휴대폰 비행기모드 ON · 클릭하면 OFF':'휴대폰 비행기모드 OFF · 클릭하면 ON';
    button.setAttribute('aria-label',button.dataset.spxTip);
    button.dataset.airplaneVisualSource=String(source||'status');
  }
  function applyAirplaneRecoveryIndicatorV105(network={},status='',phase='',hostPhase=''){
    const normalizedHost=String(hostPhase||network?.hostPhase||'').toLowerCase();
    const normalizedPhase=String(phase||network?.phase||'').toLowerCase();
    const normalizedStatus=String(status||network?.status||'').toLowerCase();
    if(normalizedPhase==='airplane-cycle'||['airplane-on','mobile-data-off'].includes(normalizedHost)){
      setAirplaneModeIndicatorV105(true,'recovery-telemetry');return;
    }
    if(['reconnecting','windows-network-restoring','public-ip-check','ip-confirmed','completed','failed','cancelled'].includes(normalizedPhase)||
       ['airplane-off','airplane-off-command','mobile-data-on','reconnecting','device-reconnect','tethering-check','device-restored','android-device-restored','public-ip-check','public-ip-unchanged','public-ip-failed','public-ip-confirmed'].includes(normalizedHost)||
       ['finalizing','completed','failed','cancelled'].includes(normalizedStatus)){
      setAirplaneModeIndicatorV105(false,'recovery-telemetry');
    }
  }
  async function syncAirplaneModeButton(){
    const button=getUiElement('spx-airplane-toggle',{repair:false});if(!button)return null;
    try{
      const response=await runtimeMessage({type:'SPX_NETWORK_AIRPLANE_STATUS'});
      if(!response?.ok)throw new Error(response?.error||'비행기모드 상태 확인 실패');
      const enabled=response?.data?.airplaneMode===true;
      setAirplaneModeIndicatorV105(enabled,'direct-status');
      return enabled;
    }catch(error){
      button.dataset.spxTip=`휴대폰 비행기모드 상태 확인 실패 · ${error?.message||String(error)}`;
      return null;
    }
  }
  async function togglePhoneAirplaneMode(){
    const button=getUiElement('spx-airplane-toggle',{repair:false});if(!button||button.disabled)return false;
    button.disabled=true;
    try{
      const current=await syncAirplaneModeButton();
      if(current===null)throw new Error('현재 비행기모드 상태를 먼저 확인하지 못했습니다.');
      const target=!current;
      setClass('spx-dbstate','spx-ok');setText('spx-dbstate',`● 휴대폰 비행기모드 ${target?'ON':'OFF'} 전환 확인 중`);
      const response=await runtimeMessage({type:'SPX_NETWORK_SET_AIRPLANE',enabled:target});
      if(!response?.ok)throw new Error(response?.error||`비행기모드 ${target?'ON':'OFF'} 실패`);
      const confirmed=response?.data?.airplaneMode===true;
      button.dataset.enabled=confirmed?'1':'0';button.classList.toggle('spx-airplane-active',confirmed);
      setClass('spx-dbstate','spx-ok');setText('spx-dbstate',`● 휴대폰 비행기모드 ${confirmed?'ON':'OFF'} 확인 완료`);
      button.dataset.spxTip=confirmed?'휴대폰 비행기모드 ON · 클릭하면 OFF':'휴대폰 비행기모드 OFF · 클릭하면 ON';
      return true;
    }catch(error){setClass('spx-dbstate','spx-err');setText('spx-dbstate',`● 비행기모드 전환 실패 · ${error?.message||String(error)}`);return false;}
    finally{button.disabled=false;}
  }

  async function syncSidebarNetworkToggle(){
    const input=getUiElement('spx-network-toggle',{repair:false});if(!input)return;
    const label=input.closest('.spx-network-check');
    const applyTip=(text)=>{
      input.removeAttribute('title');
      input.dataset.spxTip=text;
      input.setAttribute('aria-label',text);
      if(label){label.dataset.spxTip=text;label.setAttribute('aria-label',text);}
    };
    if(IS_SELECTED_NETWORK_DEDICATED_TAB){
      input.checked=true;
      input.disabled=false;
      label?.classList.add('active','dedicated-only');
      label?.classList.remove('unavailable');
      try{
        const response=await runtimeMessage({type:'SPX_NETWORK_STATUS'}),data=response?.data||{};
        const publicIp=String(data.publicIp||data.public_ip||'').trim();
        const adapter=String(data.windowAdapterName||data.selectedAdapterName||'선택 어댑터').trim();
        if(data.strictIsolationOk!==true){
          label?.classList.add('unavailable');
          applyTip(`선택망 분리 안전검사 실패 · ${data.isolationMessage||'테더링 어댑터가 Windows 기본 경로입니다.'} · 수집을 시작하지 않습니다.`);
        }else{
          label?.classList.remove('unavailable');
          applyTip(`선택 네트워크 전용 프로필 · ${adapter} · 외부 공인 IP ${publicIp||'확인 중'} · 쿠팡만 선택망 · 일반 인터넷 ${cleanNetworkDisplayTextV10155(data.systemDefaultInterfaceAlias,'Windows 기본 경로')}`);
        }
      }catch(error){applyTip(`선택 네트워크 전용 프로필 · 공인 IP 확인 대기 · ${error?.message||String(error)}`);}
      return;
    }
    try{
      const response=await runtimeMessage({type:'SPX_NETWORK_STATUS'});
      const data=response?.data||{};
      input.checked=false;
      input.disabled=false;
      label?.classList.remove('active');
      label?.classList.toggle('unavailable',response?.ok!==true);
      label?.classList.add('dedicated-only');
      const publicIp=String(data.publicIp||data.public_ip||'').trim();
      const adapter=data.windowAdapterName||data.selectedAdapterName||data.configuredAdapterName||'선택 어댑터';
      applyTip(response?.ok===true
        ?(data.strictIsolationOk!==true
          ?`선택망 분리 안전검사 실패 · ${data.isolationMessage||'일반 인터넷 어댑터를 켜세요.'}`
          :`클릭하면 쿠팡 도메인만 ${adapter}을 사용하는 전용 프로필을 엽니다. 외부 공인 IP ${publicIp||'전용창 연결 후 확인'} · 일반 브라우저는 ${cleanNetworkDisplayTextV10155(data.systemDefaultInterfaceAlias,'Windows 기본 인터넷')} 유지`)
        :`네트워크 상태 확인 실패 · ${response?.error||'설정 화면에서 확인하세요'}`);
    }catch(error){input.checked=false;input.disabled=false;applyTip(`네트워크 상태 확인 실패 · ${error?.message||String(error)}`);}
  }
  function selectedNetworkStartUrlV10155(){
    try{
      if(location.pathname.startsWith('/np/search')||location.pathname.startsWith('/np/categories/'))return location.href;
      const keyword=currentKeyword?.()||'';
      return `https://www.coupang.com/np/search?q=${encodeURIComponent(keyword||'상품')}&page=1&channel=user`;
    }catch(_){return 'https://www.coupang.com/np/search?q=%EC%83%81%ED%92%88&page=1&channel=user';}
  }

  async function toggleCollectionNetwork(enabled){
    const input=getUiElement('spx-network-toggle',{repair:false});if(input)input.disabled=true;
    try{
      if(IS_SELECTED_NETWORK_DEDICATED_TAB){
        if(input){input.checked=true;input.closest('.spx-network-check')?.classList.add('active');}
        setClass('spx-dbstate','spx-ok');setText('spx-dbstate','● 선택망 전용 탭 · 쿠팡만 선택망 사용 · 전용창을 닫으면 연결 종료');
        return;
      }
      if(!enabled){if(input)input.checked=false;return;}
      const settings=await safeGetSettings();
      if(!String(settings.collectionNetworkAdapterId||'').trim()){
        if(input)input.checked=false;
        await runtimeMessage({type:'SPX_OPEN_OPTIONS'}).catch(()=>{});
        throw new Error('설정의 수집 네트워크에서 USB 테더링 또는 사용할 어댑터를 먼저 선택하세요.');
      }
      setClass('spx-dbstate','spx-ok');setText('spx-dbstate','● 현재 쿠팡 탭을 선택망 전용창으로 이동하는 중');
      const response=await runtimeMessage({type:'SPX_NETWORK_TOGGLE_BROWSER_PROXY',enabled:true,adapterId:settings.collectionNetworkAdapterId||'',adapterName:settings.collectionNetworkAdapterName||'',startUrl:selectedNetworkStartUrlV10155(),source:'sidebar_network_button'});
      if(!response?.ok)throw new Error(response?.error||'선택망 전용창 이동 실패');
      if(input){input.checked=false;input.closest('.spx-network-check')?.classList.remove('active');}
      setClass('spx-dbstate','spx-ok');setText('spx-dbstate',`● 쿠팡 전용 선택망 창 열림 · 일반 브라우저 ${cleanNetworkDisplayTextV10155(response.data?.systemDefaultInterfaceAlias,'기본 인터넷')} 유지 · ${response.data?.selectedAdapterName||settings.collectionNetworkAdapterName||'선택 어댑터'}`);
    }catch(error){if(input)input.checked=false;setClass('spx-dbstate','spx-err');setText('spx-dbstate',`● 전용창 이동 실패 · ${error?.message||String(error)}`);}finally{if(input)input.disabled=false;}
  }
  async function openSelectedNetworkDedicatedWindow(){
    const input=getUiElement('spx-network-toggle',{repair:false});
    if(input)input.disabled=true;
    try{
      const settings=await safeGetSettings();
      if(!String(settings.collectionNetworkAdapterId||'').trim()){
        await runtimeMessage({type:'SPX_OPEN_OPTIONS'}).catch(()=>{});
        throw new Error('설정의 수집 네트워크에서 USB 테더링 또는 사용할 어댑터를 먼저 선택하세요.');
      }
      setClass('spx-dbstate','spx-ok');setText('spx-dbstate','● 선택 네트워크 전용창 여는 중');
      const response=await runtimeMessage({type:'SPX_NETWORK_OPEN_DEDICATED_WINDOW',adapterId:settings.collectionNetworkAdapterId||'',adapterName:settings.collectionNetworkAdapterName||'',startUrl:selectedNetworkStartUrlV10155(),source:'sidebar_ctrl_click'});
      if(!response?.ok)throw new Error(response?.error||'전용창 열기 실패');
      const data=response.data||{};
      setClass('spx-dbstate','spx-ok');
      setText('spx-dbstate',`● 쿠팡만 선택망 사용 · 일반 인터넷 ${cleanNetworkDisplayTextV10155(data.systemDefaultInterfaceAlias,'Windows 기본 경로')} · 원래 탭 유지`);
      await syncSidebarNetworkToggle();
    }catch(error){setClass('spx-dbstate','spx-err');setText('spx-dbstate',`● 전용창 열기 실패 · ${error?.message||String(error)}`);}finally{if(input)input.disabled=false;}
  }

  function closeCollectionSettings() { const modal = getUiElement('spx-settings-modal', { repair:false }); if (modal) modal.hidden = true; }
  function clampSetting(value,min,max,fallback){const n=Number(value);return Math.max(min,Math.min(max,Number.isFinite(n)?Math.round(n):fallback));}
  function manualBaselineSettings(base){return {...base,maxPagesPerKeyword:Math.max(1,Math.min(50,Number(base?.maxPagesPerKeyword)||1)),sourceDataTargetOrganic:60,sourceDataMaxProducts:200,lowReviewSampleSize:4,winnerMonthlySalesMin:Number(base?.winnerMonthlySalesMin)||200,winnerReviewMin:Number(base?.winnerReviewMin)||10,winnerReviewMax:Number(base?.winnerReviewMax)||1500,winnerRecentReviewMin:Number(base?.winnerRecentReviewMin)||1,collectDetailRecommendations:true};}
    async function loadSidebarProfiles(baseSettings=null){
    const globalSettings=baseSettings&&typeof baseSettings==='object'?baseSettings:await safeGetSettings();
    let saved={};try{saved=(await chrome.storage.local.get(SIDEBAR_PROFILE_KEY))[SIDEBAR_PROFILE_KEY]||{};}catch(_){}
    const legacyMax=Math.max(1,Math.min(50,Number(globalSettings?.maxPagesPerKeyword)||1));
    const manualSaved=saved.manual&&typeof saved.manual==='object'?saved.manual:{};
    const manualMax=Math.max(1,Math.min(50,Number(manualSaved.maxPagesPerKeyword)||legacyMax));
    const manualEnabled=manualSaved.enabled?.maxPages!==false;
    const recommendations=typeof manualSaved.collectDetailRecommendations==='boolean'?manualSaved.collectDetailRecommendations:(manualSaved.collectTogetherGood!==false||manualSaved.collectOthersViewed===true||manualSaved.collectLimitedDeal===true);
    return {manual:{...MANUAL_PROFILE_DEFAULT,...manualSaved,collectDetailRecommendations:recommendations,maxPagesPerKeyword:manualEnabled?manualMax:1,enabled:{...MANUAL_PROFILE_DEFAULT.enabled,...(manualSaved.enabled||{}),maxPages:manualEnabled}}};
  }
  function switchCollectionSettingsTab(mode){activeSettingsTab=mode==='common'?'common':(mode==='network'?'network':'manual');document.querySelectorAll('#spx-overlay [data-spx-profile-tab]').forEach(b=>b.classList.toggle('active',b.dataset.spxProfileTab===activeSettingsTab));document.querySelectorAll('#spx-overlay [data-spx-profile-panel]').forEach(p=>p.classList.toggle('active',p.dataset.spxProfilePanel===activeSettingsTab));}
  function syncCollectionToggleState(input){if(!input)return;const stateText=input.closest('.spx-setting-row')?.querySelector('.spx-toggle-state');if(stateText)stateText.textContent=input.dataset?.commonField==='blockRecoveryDeleteWingData'?(input.checked?'WING 포함':'WING 보존'):(input.checked?'사용':'해제');input.closest('.spx-setting-row')?.classList.toggle('disabled',!input.checked);}
  function syncProfileMaxPagesControl(source=null){
    const mode=source?.dataset?.mode||'manual';
    const toggle=source||document.querySelector(`#spx-overlay .spx-setting-use[data-mode="${mode}"][data-key="maxPages"]`);
    const input=document.querySelector(`#spx-overlay [data-mode="${mode}"][data-field="maxPagesPerKeyword"]`);
    if(!toggle||!input)return;
    const checked=toggle.checked===true;
    toggle.disabled=false;syncCollectionToggleState(toggle);
    if(!checked)input.value='1';
    input.disabled=!checked;
  }
  function writeProfileToForm(mode,profile){document.querySelectorAll(`#spx-overlay [data-mode="${mode}"][data-field]`).forEach(input=>{const k=input.dataset.field;if(input.type!=='checkbox')input.value=profile[k]??'';});document.querySelectorAll(`#spx-overlay .spx-setting-use[data-mode="${mode}"]`).forEach(input=>{const toggleField=input.dataset.toggleField;input.checked=toggleField?Boolean(profile[toggleField]):profile.enabled?.[input.dataset.key]!==false;syncCollectionToggleState(input);});}
  function readProfileFromForm(mode,base){const p={...base,enabled:{...(base.enabled||{})}};document.querySelectorAll(`#spx-overlay [data-mode="${mode}"][data-field]`).forEach(input=>{const k=input.dataset.field;p[k]=Number(input.value);});document.querySelectorAll(`#spx-overlay .spx-setting-use[data-mode="${mode}"]`).forEach(input=>{const toggleField=input.dataset.toggleField;if(toggleField){p[toggleField]=input.checked;p.enabled[input.dataset.key]=true;}else p.enabled[input.dataset.key]=input.checked;});p.maxPagesPerKeyword=clampSetting(p.maxPagesPerKeyword,1,50,1);p.sourceDataTargetOrganic=clampSetting(p.sourceDataTargetOrganic,1,200,60);p.sourceDataMaxProducts=clampSetting(p.sourceDataMaxProducts,1,200,200);p.lowReviewSampleSize=clampSetting(p.lowReviewSampleSize,0,20,4);p.winnerMonthlySalesMin=clampSetting(p.winnerMonthlySalesMin,1,100000,200);p.winnerReviewMin=clampSetting(p.winnerReviewMin,0,100000,10);p.winnerReviewMax=Math.max(p.winnerReviewMin,clampSetting(p.winnerReviewMax,1,1000000,1500));p.winnerRecentReviewMin=clampSetting(p.winnerRecentReviewMin,0,100000,1);return p;}
  const COMMON_COLLECTION_DEFAULTS={autoDiscover:true,autoUpload:true,sourceDataCollection:true,adaptiveFastCollect:true,autoScrollEnabled:true,autoScrollRandom:true,scrollStepMin:150,scrollStepMax:450,scrollDelayMin:250,scrollDelayMax:850,autoExtraPageEnabled:false,pageLoadingMaxWaitMinMs:90000,pageLoadingMaxWaitMaxMs:120000,maxKeywordsPerRun:30,organicSampleSize:50,candidatesPerKeyword:8,minIntentScore:50,winnerMonthlySalesMin:200,winnerReviewMin:10,winnerReviewMax:1500,winnerRecentReviewMin:1,fullExploreSeasonBoost:true,fullExploreAutoRefill:true,continuousExplore:true,fullExploreSeedCount:12,fullExploreCooldownDays:30,fullExploreMaxRefills:4,continuousRetryMinMs:270000,continuousRetryMaxMs:330000,autoWeeklyRecollectEnabled:true,autoWeeklyRecollectDays:7,humanDelayEnabled:true,humanDelayMinMs:2500,humanDelayMaxMs:4500,nextNavigationDelayMinMs:180,nextNavigationDelayMaxMs:420,humanRetryMax:2,humanRetryMinMs:5000,humanRetryMaxMs:12000,airplaneHoldMs:20000,blockRecoveryDeleteWingData:true};
  function writeCommonSettingsForm(settings={}){document.querySelectorAll('#spx-overlay [data-common-field]').forEach((input)=>{const key=input.dataset.commonField,value=settings[key]??COMMON_COLLECTION_DEFAULTS[key];if(input.type==='checkbox'){input.checked=Boolean(value);syncCollectionToggleState(input);}else input.value=key==='airplaneHoldMs'?Math.max(4,Math.min(300,Math.round(Number(value??20000)/1000))):(value??'');});}
  function readCommonSettingsForm(){const out={};document.querySelectorAll('#spx-overlay [data-common-field]').forEach((input)=>{const key=input.dataset.commonField;out[key]=input.type==='checkbox'?input.checked:(key==='airplaneHoldMs'?(Number(input.value)>0?Number(input.value)*1000:20000):Number(input.value));});const pair=(a,b,min,max,da,db)=>{out[a]=clampSetting(out[a],min,max,da);out[b]=Math.max(out[a],clampSetting(out[b],min,max,db));};out.maxKeywordsPerRun=clampSetting(out.maxKeywordsPerRun,1,200,30);out.organicSampleSize=clampSetting(out.organicSampleSize,1,10000,50);out.candidatesPerKeyword=clampSetting(out.candidatesPerKeyword,0,100,8);out.minIntentScore=clampSetting(out.minIntentScore,0,100,50);out.winnerMonthlySalesMin=clampSetting(out.winnerMonthlySalesMin,1,100000,200);out.winnerReviewMin=clampSetting(out.winnerReviewMin,0,100000,10);out.winnerReviewMax=Math.max(out.winnerReviewMin,clampSetting(out.winnerReviewMax,1,1000000,1500));out.winnerRecentReviewMin=clampSetting(out.winnerRecentReviewMin,0,100000,1);out.fullExploreSeedCount=clampSetting(out.fullExploreSeedCount,1,60,12);out.fullExploreCooldownDays=clampSetting(out.fullExploreCooldownDays,1,365,30);out.fullExploreMaxRefills=clampSetting(out.fullExploreMaxRefills,0,100,4);out.autoWeeklyRecollectDays=clampSetting(out.autoWeeklyRecollectDays,3,30,7);out.humanRetryMax=clampSetting(out.humanRetryMax,0,5,2);out.airplaneHoldMs=clampSetting(out.airplaneHoldMs,4000,300000,20000);pair('scrollStepMin','scrollStepMax',80,1200,150,450);pair('scrollDelayMin','scrollDelayMax',50,5000,250,850);pair('pageLoadingMaxWaitMinMs','pageLoadingMaxWaitMaxMs',30000,900000,90000,120000);pair('continuousRetryMinMs','continuousRetryMaxMs',1000,86400000,270000,330000);pair('humanDelayMinMs','humanDelayMaxMs',0,180000,2500,4500);pair('nextNavigationDelayMinMs','nextNavigationDelayMaxMs',0,180000,180,420);pair('humanRetryMinMs','humanRetryMaxMs',1000,300000,5000,12000);out.continuousRetryMinutes=Math.max(1,Math.round(((out.continuousRetryMinMs+out.continuousRetryMaxMs)/2)/60000));return out;}
  const NETWORK_ROUTE_DEFAULTS_V10156=Object.freeze({networkRouteCoupangSearch:'dedicated',networkRouteCoupangDetail:'dedicated',collectionPageDataMode:'save',collectionMediaMode:'block',collectionFontMode:'block',collectionResourceMode:'save',winnerImageNetworkMode:'system'});
  function normalizeNetworkRouteModeV10156(value,fallback='system'){return String(value||fallback).toLowerCase()==='dedicated'?'dedicated':'system';}
  function normalizeCollectionResourceModeV101510(value){return String(value||'save').toLowerCase()==='normal'?'normal':'save';}
  function normalizePageDataModeV10154R1(value){return String(value||'save').toLowerCase()==='normal'?'normal':'save';}
  function normalizeBinaryResourceModeV10154R1(value,fallback='block'){return String(value||fallback).toLowerCase()==='load'?'load':'block';}
  function writeNetworkRouteSettingsForm(settings={}){
    for(const key of ['networkRouteCoupangSearch','networkRouteCoupangDetail']){const fallback=NETWORK_ROUTE_DEFAULTS_V10156[key],value=normalizeNetworkRouteModeV10156(settings[key],fallback);document.querySelectorAll(`#spx-overlay [data-network-route-field="${key}"]`).forEach((input)=>{input.checked=String(input.value)===value;});}
    const legacyResourceMode=normalizeCollectionResourceModeV101510(settings.collectionResourceMode||NETWORK_ROUTE_DEFAULTS_V10156.collectionResourceMode);
    const pageDataMode=normalizePageDataModeV10154R1(settings.collectionPageDataMode||'save');document.querySelectorAll('#spx-overlay [data-resource-mode-field="collectionPageDataMode"]').forEach((input)=>{input.checked=String(input.value)===pageDataMode;});
    const mediaMode=normalizeBinaryResourceModeV10154R1(settings.collectionMediaMode||(legacyResourceMode==='normal'?'load':'block'));document.querySelectorAll('#spx-overlay [data-resource-mode-field="collectionMediaMode"]').forEach((input)=>{input.checked=String(input.value)===mediaMode;});
    const fontMode=normalizeBinaryResourceModeV10154R1(settings.collectionFontMode||(legacyResourceMode==='normal'?'load':'block'));document.querySelectorAll('#spx-overlay [data-resource-mode-field="collectionFontMode"]').forEach((input)=>{input.checked=String(input.value)===fontMode;});
    const winnerMode=normalizeNetworkRouteModeV10156(settings.winnerImageNetworkMode,NETWORK_ROUTE_DEFAULTS_V10156.winnerImageNetworkMode);document.querySelectorAll('#spx-overlay [data-winner-image-network-field="winnerImageNetworkMode"]').forEach((input)=>{input.checked=String(input.value)===winnerMode;});
  }
  function readNetworkRouteSettingsForm(){
    const out={};for(const key of ['networkRouteCoupangSearch','networkRouteCoupangDetail']){const fallback=NETWORK_ROUTE_DEFAULTS_V10156[key],checked=document.querySelector(`#spx-overlay [data-network-route-field="${key}"]:checked`);out[key]=normalizeNetworkRouteModeV10156(checked?.value,fallback);}
    out.collectionPageDataMode=normalizePageDataModeV10154R1(document.querySelector('#spx-overlay [data-resource-mode-field="collectionPageDataMode"]:checked')?.value);
    out.collectionMediaMode=normalizeBinaryResourceModeV10154R1(document.querySelector('#spx-overlay [data-resource-mode-field="collectionMediaMode"]:checked')?.value,'block');
    out.collectionFontMode=normalizeBinaryResourceModeV10154R1(document.querySelector('#spx-overlay [data-resource-mode-field="collectionFontMode"]:checked')?.value,'block');
    out.collectionResourceMode=(out.collectionMediaMode==='load'&&out.collectionFontMode==='load')?'normal':'save';
    out.winnerImageNetworkMode=normalizeNetworkRouteModeV10156(document.querySelector('#spx-overlay [data-winner-image-network-field="winnerImageNetworkMode"]:checked')?.value,'system');
    return out;
  }
  function validateLinkedCoupangNetworkRoutesV10156(routes={}){const search=normalizeNetworkRouteModeV10156(routes.networkRouteCoupangSearch,NETWORK_ROUTE_DEFAULTS_V10156.networkRouteCoupangSearch),detail=normalizeNetworkRouteModeV10156(routes.networkRouteCoupangDetail,NETWORK_ROUTE_DEFAULTS_V10156.networkRouteCoupangDetail),winnerImage=normalizeNetworkRouteModeV10156(routes.winnerImageNetworkMode,'system');if(search!==detail)throw new Error('NetworkHost 3.0.44 선택망 Bind 모드에서는 쿠팡 검색과 상세가 같은 브라우저 수집 프로필을 사용해야 합니다. 두 항목을 같은 네트워크로 맞춰주세요.');if(winnerImage==='dedicated'&&search!=='dedicated')throw new Error('효자상품 이미지를 전용 네트워크로 받으려면 쿠팡 검색·상세도 전용 네트워크로 설정해야 합니다. NetworkHost 3.0.44은 프로필 단위 프록시라 일반 브라우저에서 이미지만 전용망으로 보내는 동작은 만들지 않습니다.');return{...routes,networkRouteCoupangSearch:search,networkRouteCoupangDetail:detail,collectionPageDataMode:normalizePageDataModeV10154R1(routes.collectionPageDataMode),collectionMediaMode:normalizeBinaryResourceModeV10154R1(routes.collectionMediaMode,'block'),collectionFontMode:normalizeBinaryResourceModeV10154R1(routes.collectionFontMode,'block'),collectionResourceMode:normalizeCollectionResourceModeV101510(routes.collectionResourceMode),winnerImageNetworkMode:winnerImage,profileMode:search};}
  function collectionNetworkTargetForSettingsV135(settings={}){return normalizeNetworkRouteModeV10156(settings?.networkRouteCoupangSearch,NETWORK_ROUTE_DEFAULTS_V10156.networkRouteCoupangSearch)==='dedicated'?'window':'system';}
  function explicitCollectionNetworkTargetV135(settings=null){
    if(!settings||typeof settings!=='object'||!Object.prototype.hasOwnProperty.call(settings,'networkRouteCoupangSearch'))return '';
    return collectionNetworkTargetForSettingsV135(settings);
  }
  function collectionDedicatedCurrentTabV135(settings={}){return collectionNetworkTargetForSettingsV135(settings)==='window'&&IS_SELECTED_NETWORK_DEDICATED_TAB===true;}
  function explicitDedicatedCurrentTabV135(settings=null){return explicitCollectionNetworkTargetV135(settings)==='window'&&IS_SELECTED_NETWORK_DEDICATED_TAB===true;}
  async function resetNetworkRouteSettingsV10156(){writeNetworkRouteSettingsForm(NETWORK_ROUTE_DEFAULTS_V10156);await SPX.util.setSettings({...NETWORK_ROUTE_DEFAULTS_V10156});setText('spx-settings-message','네트워크 · 데이터 사용을 권장 기본값으로 되돌리고 즉시 적용했습니다.');}
  const ROUTE_HANDOFF_SAFE_SETTING_KEYS_V10156=Object.freeze([
    'maxPagesPerKeyword','sourceDataTargetOrganic','sourceDataMaxProducts','lowReviewSampleSize',
    'winnerMonthlySalesMin','winnerReviewMin','winnerReviewMax','winnerRecentReviewMin',
    'collectDetailRecommendations','autoDiscover','autoUpload',
    'sourceDataCollection','adaptiveFastCollect','autoExtraPageEnabled',
    'maxKeywordsPerRun','organicSampleSize','candidatesPerKeyword','minIntentScore','continuousExplore',
    'fullExploreAutoRefill','fullExploreSeedCount','fullExploreCooldownDays','fullExploreMaxRefills',
    'humanDelayEnabled','humanDelayMinMs','humanDelayMaxMs','nextNavigationDelayMinMs','nextNavigationDelayMaxMs',
    'humanRetryMax','humanRetryMinMs','humanRetryMaxMs','platformInterleaveEnabled','platformInterleaveDelayMinMs','platformInterleaveDelayMaxMs',
    'coupangSupplementOnly','serverUploadedKeywordPolicy',
    'networkRouteCoupangSearch','networkRouteCoupangDetail','collectionPageDataMode','collectionMediaMode','collectionFontMode','collectionResourceMode','winnerImageNetworkMode'
  ]);
  function sanitizeRouteHandoffSettingsV10156(settings={}){const out={};for(const key of ROUTE_HANDOFF_SAFE_SETTING_KEYS_V10156)if(Object.prototype.hasOwnProperty.call(settings||{},key))out[key]=settings[key];return out;}
  function sanitizeRouteHandoffMessageV10156(message={}){const out={...message};if(out.settingsOverride&&typeof out.settingsOverride==='object')out.settingsOverride=sanitizeRouteHandoffSettingsV10156(out.settingsOverride);delete out.serviceKey;delete out.supabaseKey;delete out.naverApiKey;delete out.naverSecretKey;return out;}
  function routedCollectionStartUrlV10156(keyword,payload){const q=String(keyword||currentKeyword()||'상품').replace(/\s+/g,' ').trim()||'상품';const token=encodeBase64UrlJsonV10156(payload);if(!token)throw new Error('네트워크 전환 수집정보를 만들지 못했습니다.');return `https://www.coupang.com/np/search?q=${encodeURIComponent(q)}&page=1&channel=user#spx-collect=${encodeURIComponent(token)}`;}
  async function ensureSearchCollectionRouteV10156({settings=null,keyword='',handoffMessage=null}={}){
    const effective=settings&&typeof settings==='object'?settings:await safeGetSettings();
    const linked=validateLinkedCoupangNetworkRoutesV10156(effective);
    const desired=linked.profileMode,current=IS_SELECTED_NETWORK_DEDICATED_TAB===true?'dedicated':'system';
    if(desired===current){
      const media=await runtimeMessage({type:'SPX_APPLY_COLLECTION_RESOURCE_POLICY_V101510',purpose:'search-route-preflight'});
      if(!media?.ok)throw new Error(media?.error||'검색수집 리소스 정책을 적용하지 못했습니다.');
      setLowBandwidthVisualModeV10156(false);
      return{ok:true,handedOff:false,target:desired,current,resourceMode:media?.data?.mode||linked.collectionResourceMode};
    }
    if(current==='dedicated'&&desired==='system')throw new Error('NetworkHost 3.0.44 선택망 Bind 모드에서는 전용 프로필에서 기본 브라우저 프로필로 자동 전환하지 않습니다. 일반 브라우저에서 같은 수집을 다시 시작해 주세요.');
    const safeMessage=sanitizeRouteHandoffMessageV10156(handoffMessage||{type:'SPX_START_SELECTED_MODE',mode:'guided',exactKeywords:[String(keyword||currentKeyword()||'').trim()].filter(Boolean)});
    const envelope={kind:'selected-mode',schema:'SPX_ROUTE_HANDOFF_V10156',createdAt:Date.now(),target:'dedicated',message:safeMessage};
    const startUrl=routedCollectionStartUrlV10156(keyword||safeMessage?.exactKeywords?.[0]||'',envelope);
    const adapterId=String(effective?.collectionNetworkAdapterId||'').trim(),adapterName=String(effective?.collectionNetworkAdapterName||'').trim();
    if(!adapterId)throw new Error('실제 쿠팡 검색수집을 전용 네트워크로 실행하려면 설정에서 사용할 네트워크 어댑터를 먼저 선택하세요.');
    const response=await runtimeMessage({type:'SPX_NETWORK_OPEN_DEDICATED_WINDOW',adapterId,adapterName,startUrl,source:'v10156_search_route_handoff'});
    if(!response?.ok)throw new Error(response?.error||'전용 네트워크 수집창 전환 실패');
    setDisplay('spx-auto','flex');setSidebarCollecting(false);setText('spx-status','수집 네트워크 전환');setText('spx-auto-text','전용 네트워크 수집창으로 이동해 같은 수집 요청을 이어서 시작합니다.');setProgress(2,'수집 네트워크 전환 완료 · 새 창에서 이어서 시작');
    return{ok:true,handedOff:true,target:'dedicated',current,startUrl,data:response.data||null};
  }
  function bindNetworkRouteQuickChoicesV164(){
    document.querySelectorAll('#spx-overlay [data-network-route-all]').forEach((button)=>{
      button.onclick=()=>{
        const mode=normalizeNetworkRouteModeV10156(button.dataset.networkRouteAll,'dedicated');
        for(const key of ['networkRouteCoupangSearch','networkRouteCoupangDetail']){
          document.querySelectorAll(`#spx-overlay [data-network-route-field="${key}"]`).forEach((input)=>{input.checked=String(input.value)===mode;});
        }
        document.querySelectorAll('#spx-overlay [data-winner-image-network-field="winnerImageNetworkMode"]').forEach((winner)=>{winner.checked=String(winner.value)===mode;});
        setText('spx-settings-message',mode==='dedicated'?'쿠팡 검색·상세를 모두 전용 네트워크로 선택했습니다. WING·Supabase·일반 인터넷은 기본 인터넷을 유지합니다.':'쿠팡 검색·상세를 모두 Windows 기본 네트워크로 선택했습니다. 전용망 제한은 저장 후 해제됩니다.');
      };
    });
  }
  async function openCollectionSettings(){
    const modal=getUiElement('spx-settings-modal',{repair:false});if(!modal)return;
    modal.hidden=false;
    const profiles=await loadSidebarProfiles();
    const settings=await safeGetSettings();
    writeProfileToForm('manual',profiles.manual);
    syncProfileMaxPagesControl(document.querySelector('#spx-overlay .spx-setting-use[data-mode="manual"][data-key="maxPages"]')||null);
    writeCommonSettingsForm(settings);
    writeNetworkRouteSettingsForm(settings);
    bindNetworkRouteQuickChoicesV164();
    await syncSidebarAutoExtraPageSetting();
    await loadActiveCollectionProfile();
    switchCollectionSettingsTab('manual');
    setText('spx-settings-message','단일 수집 기준을 편집합니다. 최대 페이지 체크를 해제하면 1페이지로 고정됩니다.');
  }
  function resetCollectionProfile(mode){
    const apply=async()=>{
      if(mode==='network'){
        await resetNetworkRouteSettingsV10156();
        return;
      }
      if(mode==='common'){
        writeCommonSettingsForm(COMMON_COLLECTION_DEFAULTS);
        sidebarExtraPageSessionOverride=COMMON_COLLECTION_DEFAULTS.autoExtraPageEnabled===true;
        sidebarExtraPagePersistPromise=runtimeMessage({type:'SPX_UPDATE_EXTRA_PAGE_POLICY',enabled:sidebarExtraPageSessionOverride,source:'settings-reset'}).catch(()=>SPX.util.setSettings({autoExtraPageEnabled:sidebarExtraPageSessionOverride}));
        await sidebarExtraPagePersistPromise.catch(()=>null);
        await SPX.util.setSettings(COMMON_COLLECTION_DEFAULTS);
        await syncSidebarAutoExtraPageSetting();
        setText('spx-settings-message','설정 탭을 권장 기본값으로 되돌리고 즉시 적용했습니다.');
        return;
      }
      const p={...MANUAL_PROFILE_DEFAULT,enabled:{...MANUAL_PROFILE_DEFAULT.enabled}};
      writeProfileToForm('manual',p);
      setText('spx-settings-message','수집 기준을 기본값으로 되돌렸습니다.');
    };apply();
  }
  function resetCollectionSetting(mode,field){
    const p={...MANUAL_PROFILE_DEFAULT,enabled:{...MANUAL_PROFILE_DEFAULT.enabled}};
    const el=document.querySelector(`#spx-overlay [data-mode="manual"][data-field="${field}"]`)||document.querySelector(`#spx-overlay [data-mode="manual"][data-toggle-field="${field}"]`);
    if(!el)return;
    if(el.type==='checkbox'){el.checked=Boolean(p[field]);syncCollectionToggleState(el);}else el.value=p[field]??'';
  }
  async function resetCommonSetting(field){const pairs={scrollStepMin:['scrollStepMin','scrollStepMax'],scrollStepMax:['scrollStepMin','scrollStepMax'],scrollDelayMin:['scrollDelayMin','scrollDelayMax'],scrollDelayMax:['scrollDelayMin','scrollDelayMax'],pageLoadingMaxWaitMinMs:['pageLoadingMaxWaitMinMs','pageLoadingMaxWaitMaxMs'],pageLoadingMaxWaitMaxMs:['pageLoadingMaxWaitMinMs','pageLoadingMaxWaitMaxMs'],continuousRetryMinMs:['continuousRetryMinMs','continuousRetryMaxMs'],continuousRetryMaxMs:['continuousRetryMinMs','continuousRetryMaxMs'],humanDelayMinMs:['humanDelayMinMs','humanDelayMaxMs'],humanDelayMaxMs:['humanDelayMinMs','humanDelayMaxMs'],nextNavigationDelayMinMs:['nextNavigationDelayMinMs','nextNavigationDelayMaxMs'],nextNavigationDelayMaxMs:['nextNavigationDelayMinMs','nextNavigationDelayMaxMs'],humanRetryMinMs:['humanRetryMinMs','humanRetryMaxMs'],humanRetryMaxMs:['humanRetryMinMs','humanRetryMaxMs'],platformInterleaveDelayMinMs:['platformInterleaveDelayMinMs','platformInterleaveDelayMaxMs'],platformInterleaveDelayMaxMs:['platformInterleaveDelayMinMs','platformInterleaveDelayMaxMs']};const patch={};for(const key of (pairs[field]||[field])){const el=document.querySelector(`#spx-overlay [data-common-field="${key}"]`);if(!el)continue;const value=COMMON_COLLECTION_DEFAULTS[key];patch[key]=value;if(el.type==='checkbox'){el.checked=Boolean(value);syncCollectionToggleState(el);}else el.value=key==='airplaneHoldMs'?Math.round(Number(value)/1000):(value??'');}await SPX.util.setSettings(patch);setText('spx-settings-message','선택 항목을 기본값으로 되돌리고 즉시 적용했습니다.');}
  async function saveCollectionSettings(){
    const saveButton=getUiElement('spx-settings-save',{repair:false});if(saveButton)saveButton.disabled=true;
    try{
      const old=await loadSidebarProfiles();
      const manual=readProfileFromForm('manual',old.manual);
      const common=readCommonSettingsForm();
      const networkRoutes=validateLinkedCoupangNetworkRoutesV10156(readNetworkRouteSettingsForm());
      sidebarExtraPageSessionOverride=common.autoExtraPageEnabled===true;
      const manualToggle=document.querySelector('#spx-overlay .spx-setting-use[data-mode="manual"][data-key="maxPages"]');
      const manualInput=document.querySelector('#spx-overlay [data-mode="manual"][data-field="maxPagesPerKeyword"]');
      manual.enabled.maxPages=manualToggle?.checked===true;
      manual.maxPagesPerKeyword=manual.enabled.maxPages?clampSetting(manualInput?.value,1,50,old.manual.maxPagesPerKeyword||1):1;
      const profileEnvelope={manual,_updatedAt:Date.now(),schemaVersion:'4.1.10-single-profile'};
      await chrome.storage.local.set({[SIDEBAR_PROFILE_KEY]:profileEnvelope,[COLLECTION_PROFILE_KEY]:'lite'});
      const profilePersist=await runtimeMessage({type:'SPX_PERSIST_SHARED_LOCAL_SETTINGS',keys:[SIDEBAR_PROFILE_KEY,COLLECTION_PROFILE_KEY]}).catch((error)=>({ok:false,error:error?.message||String(error)}));
      const profilePersistWarning=profilePersist?.ok===false?` · 전용창 공유 백업 지연: ${profilePersist.error||'보조도구 응답 없음'}`:'';
      const patch={...common,...networkRoutes};
      if(manual.enabled?.targetOrganic!==false)patch.sourceDataTargetOrganic=manual.sourceDataTargetOrganic;
      if(manual.enabled?.maxProducts!==false)patch.sourceDataMaxProducts=manual.sourceDataMaxProducts;
      if(manual.enabled?.lowReview!==false)patch.lowReviewSampleSize=manual.lowReviewSampleSize;
      if(manual.enabled?.detailRecommendations!==false)patch.collectDetailRecommendations=manual.collectDetailRecommendations!==false;
      patch.maxPagesPerKeyword=manual.maxPagesPerKeyword;
      await SPX.util.setSettings(patch);
      /* v1.0.15.10: 데이터 사용 선택은 수집 로직과 분리된 DNR 정책만 현재 탭에 즉시 반영합니다.
         페이지 reload/재수집은 하지 않으며 이미 완료된 요청을 다시 만들지도 않습니다. */
      const resourcePolicyResult=await runtimeMessage({type:'SPX_APPLY_COLLECTION_RESOURCE_POLICY_V101510',purpose:'settings-save'});
      if(resourcePolicyResult?.ok===false)throw new Error(`리소스 정책 적용 실패 · ${resourcePolicyResult.error||'차단 규칙 확인 실패'}`);
      await runtimeMessage({type:'SPX_UPDATE_AUTO_UPLOAD_POLICY',enabled:common.autoUpload===true,source:'settings-save'}).catch(()=>null);
      sidebarExtraPagePersistPromise=runtimeMessage({type:'SPX_UPDATE_EXTRA_PAGE_POLICY',enabled:common.autoExtraPageEnabled===true,source:'settings-save'}).catch(()=>null);
      await sidebarExtraPagePersistPromise.catch(()=>null);
      const autoUpload=getUiElement('spx-auto-upload',{repair:false});if(autoUpload)autoUpload.checked=common.autoUpload===true;
      const autoUploadSourcing=getUiElement('spx-auto-upload-sourcing',{repair:false});if(autoUploadSourcing)autoUploadSourcing.checked=common.autoUpload===true;
      await syncSidebarAutoExtraPageSetting();
      setText('spx-settings-message',`저장 완료 · 수집 ${manual.enabled.maxPages?`${manual.maxPagesPerKeyword}페이지`:'체크 해제 · 1페이지'}${common.autoExtraPageEnabled===true?' · 필요시 페이지 추가 ON':' · 필요시 페이지 추가 OFF'} · 네트워크 · 데이터 사용 저장${profilePersistWarning}.`);
      setTimeout(closeCollectionSettings,SPX.util.randomInt?.(420,680)||520);
    }catch(error){setText('spx-settings-message',`저장 실패 · ${error?.message||String(error)}`);}
    finally{if(saveButton)saveButton.disabled=false;}
  }
  function profileToSettings(base,p){const out={...base};if(p.enabled?.targetOrganic!==false)out.sourceDataTargetOrganic=p.sourceDataTargetOrganic;if(p.enabled?.maxProducts!==false)out.sourceDataMaxProducts=p.sourceDataMaxProducts;if(p.enabled?.lowReview!==false)out.lowReviewSampleSize=p.lowReviewSampleSize;if(p.enabled?.detailRecommendations!==false)out.collectDetailRecommendations=p.collectDetailRecommendations!==false;/* v4.1.7: 단일 수집 기준 저장값을 실행 스냅샷에 직접 사용합니다. */out.maxPagesPerKeyword=p.enabled?.maxPages===false?1:Math.max(1,Math.min(50,Number(p.maxPagesPerKeyword)||1));return out;}


  let sidebarSourcingMode = 'guided';
  const SIDEBAR_SOURCING_MODE_KEY='spxSelectedSourcingMode';
  const SIDEBAR_EXPLORATION_KEY='spxSidebarExplorationSettingsV2';
  const DEFAULT_SIDEBAR_EXPLORATION={guidedKeyword:'',guidedCoupangSupplementOnly:false,guidedNaverOnly:false,targets:['category'],waveEnabled:false,specifiedEnabled:false,coupangSupplementOnly:false,naverOnly:false,seedKeywords:[],targetMonth:0,targetMonths:[],targetMonthText:'0',targetMonthValid:true,targetMonthError:'',seasons:[],category1:'',category2:'',category3:'',categoryPath:'',categoryKeyword:'',queueBucket:'discovered',serverUploadedPolicy:'skip'};
  let committedSidebarSourcingMode='guided';
  let committedSidebarExploration={...DEFAULT_SIDEBAR_EXPLORATION};
  let committedSidebarProfile='lite';
  let sourcingDraftDirty=false;
  const SIDEBAR_CATEGORY_TREE=SPX.collectorCategorySeeds?.tree||{};
  function fillSidebarSourcingSelect(select,values,placeholder){if(!select)return;const previous=select.value;select.innerHTML=`<option value="">${placeholder}</option>`+values.map((value)=>`<option value="${String(value).replace(/"/g,'&quot;')}">${value}</option>`).join('');if(values.includes(previous))select.value=previous;}
  function syncSidebarSourcingCategories(level=1,config={}){const c1=getUiElement('spx-sourcing-category1',{repair:false}),c2=getUiElement('spx-sourcing-category2',{repair:false}),c3=getUiElement('spx-sourcing-category3',{repair:false});if(level<=1){fillSidebarSourcingSelect(c1,Object.keys(SIDEBAR_CATEGORY_TREE),'1차 전체');if(config.category1)c1.value=config.category1;}const level2=Object.keys(SIDEBAR_CATEGORY_TREE[c1?.value]||{});if(level<=2){fillSidebarSourcingSelect(c2,level2,'2차 전체');if(config.category2&&level2.includes(config.category2))c2.value=config.category2;}const level3=(SIDEBAR_CATEGORY_TREE[c1?.value]||{})[c2?.value]||[];fillSidebarSourcingSelect(c3,level3,'3차 전체');if(config.category3&&level3.includes(config.category3))c3.value=config.category3;}
  function selectedSidebarCategory(){const levels=['spx-sourcing-category1','spx-sourcing-category2','spx-sourcing-category3'].map((id)=>String(getUiElement(id,{repair:false})?.value||'').trim()).filter(Boolean);return{levels,path:levels.join(' > '),seed:levels.at(-1)||''};}
  const SOURCING_MODE_LABELS={guided:'단건 분석',full:'연속 탐색',local:'로컬DB',refresh:'대기열 수집'};
  let sidebarSourcingPersistTimer=null;
  function selectedQueueBucket(){const value=String(document.querySelector('#spx-overlay input[name="spx-queue-bucket"]:checked')?.value||'discovered');return ['discovered','manager'].includes(value)?value:'discovered';}
  function selectedSourcingModeLabel(mode=sidebarSourcingMode){if(mode==='refresh'){const bucket=selectedQueueBucket();return bucket==='manager'?'서버 재수집 대기열':'발견 키워드 수집';}return SOURCING_MODE_LABELS[mode]||SOURCING_MODE_LABELS.guided;}
  function normalizeSidebarSourcingMode(mode){return ['guided','full','local','refresh'].includes(String(mode||''))?String(mode):'guided';}
  async function lockSidebarToManualMode(reason='단건 분석 실행'){
    sidebarSourcingMode='guided';
    committedSidebarSourcingMode='guided';
    await chrome.storage.local.set({[SIDEBAR_SOURCING_MODE_KEY]:'guided',spxSidebarManualModeLockV30818:{mode:'guided',reason,at:Date.now()}}).catch(()=>{});
    selectSidebarSourcingMode('guided',{persist:false,markDirty:false});
    return 'guided';
  }
  function selectSidebarSourcingMode(mode,options={}){
    sidebarSourcingMode=normalizeSidebarSourcingMode(mode);
    document.querySelectorAll('#spx-overlay [data-spx-sourcing-mode]').forEach((button)=>button.classList.toggle('active',button.dataset.spxSourcingMode===sidebarSourcingMode));
    document.querySelectorAll('#spx-overlay [data-spx-sourcing-panel]').forEach((panel)=>panel.classList.toggle('active',panel.dataset.spxSourcingPanel===sidebarSourcingMode));
    syncSidebarExplorationOptions();
    renderSidebarModeBadge(selectedSourcingModeLabel(sidebarSourcingMode),activeCollectionProfile,false);
    if(options.persist===true)chrome.storage.local.set({[SIDEBAR_SOURCING_MODE_KEY]:sidebarSourcingMode}).catch(()=>{});
    if(options.markDirty===true)markSourcingDraftDirty();
    refreshSidebarRunButton().catch(()=>{});
  }
  // v4.0.95: 지정키워드 모드는 100개 제한 없음. wave/발굴 모드만 호출부에서 안전 상한을 넘깁니다.
  function parseTextSeeds(value,limit=null){const rows=[...new Set(String(value||'').split(/[\n,]+/).map((item)=>item.normalize('NFKC').replace(/\s+/g,' ').trim()).filter(Boolean))];const max=Number(limit);return Number.isFinite(max)&&max>0?rows.slice(0,max):rows;}
  function parseSidebarTargetMonths(value){
    const original=String(value??'').trim();
    if(!original||/^(?:0|전체|전체월)$/i.test(original.replace(/\s+/g,'')))return{valid:true,months:[],normalized:'0',error:''};
    const source=original.replace(/월/g,'').replace(/[，、]/g,',').replace(/[～〜~–—−]/g,'-');
    const segments=source.split(',').map((part)=>part.trim()).filter(Boolean);
    if(!segments.length)return{valid:true,months:[],normalized:'0',error:''};
    const months=[];
    const add=(month)=>{if(!months.includes(month))months.push(month);};
    for(const segment of segments){
      const range=segment.match(/^(\d{1,2})\s*-\s*(\d{1,2})$/);
      if(range){
        const start=Number(range[1]),end=Number(range[2]);
        if(start<1||start>12||end<1||end>12)return{valid:false,months:[],normalized:original,error:'월은 1~12 사이로 입력하세요.'};
        let current=start;
        for(let guard=0;guard<12;guard++){add(current);if(current===end)break;current=current===12?1:current+1;}
        continue;
      }
      if(!/^\d{1,2}$/.test(segment))return{valid:false,months:[],normalized:original,error:'예: 7,8 또는 7~8 형식으로 입력하세요.'};
      const month=Number(segment);
      if(month<1||month>12)return{valid:false,months:[],normalized:original,error:'월은 1~12 사이로 입력하세요.'};
      add(month);
    }
    const contiguous=months.length>1&&months.every((month,index)=>index===0||month===(months[index-1]===12?1:months[index-1]+1));
    const normalized=months.length===1?String(months[0]):contiguous?`${months[0]}~${months.at(-1)}`:months.join(',');
    return{valid:true,months,normalized,error:''};
  }
  function syncSidebarTargetMonthInput(options={}){const input=getUiElement('spx-sourcing-target-month',{repair:false});if(!input)return{valid:true,months:[],normalized:'0',error:''};const parsed=parseSidebarTargetMonths(input.value);input.setCustomValidity(parsed.valid?'':parsed.error);input.classList.toggle('spx-invalid',!parsed.valid);input.title=parsed.valid?(parsed.months.length?`적용 월: ${parsed.months.join(', ')}월`:'전체 월의 최고수요 기준'):parsed.error;if(options.normalize&&parsed.valid)input.value=parsed.normalized;if(options.persist)scheduleSidebarSourcingPersistence();return parsed;}
  function readSidebarExplorationForm(){const targets=[...document.querySelectorAll('#spx-overlay [data-spx-explore-target]:checked')].map((node)=>node.dataset.spxExploreTarget).filter(Boolean);const category=selectedSidebarCategory();const monthSelection=syncSidebarTargetMonthInput();const specifiedEnabled=getUiElement('spx-sourcing-specified-enabled',{repair:false})?.checked===true;const coupangSupplementOnly=true;const naverOnly=false;const guidedCoupangSupplementOnly=true;const guidedNaverOnly=false;return{guidedKeyword:String(getUiElement('spx-guided-keyword',{repair:false})?.value||'').replace(/\s+/g,' ').trim(),guidedCoupangSupplementOnly,guidedNaverOnly,targets,waveEnabled:!specifiedEnabled&&getUiElement('spx-sourcing-wave-enabled',{repair:false})?.checked===true,specifiedEnabled,coupangSupplementOnly,naverOnly,seedKeywords:parseTextSeeds(getUiElement('spx-sourcing-seed-keyword',{repair:false})?.value||'',specifiedEnabled?null:100),targetMonth:monthSelection.months[0]||0,targetMonths:monthSelection.months,targetMonthText:monthSelection.valid?monthSelection.normalized:String(getUiElement('spx-sourcing-target-month',{repair:false})?.value||''),targetMonthValid:monthSelection.valid,targetMonthError:monthSelection.error,seasons:[...document.querySelectorAll('#spx-overlay [data-spx-season]:checked')].map((node)=>node.dataset.spxSeason).filter(Boolean),category1:category.levels[0]||'',category2:category.levels[1]||'',category3:category.levels[2]||'',categoryPath:category.path,categoryKeyword:category.seed,queueBucket:selectedQueueBucket(),serverUploadedPolicy:String(document.querySelector('#spx-overlay input[name="spx-server-uploaded-policy"]:checked')?.value||'skip')==='reanalyze'?'reanalyze':'skip'};}
  function applySidebarExplorationForm(config={}){const guided=getUiElement('spx-guided-keyword',{repair:false});if(guided)guided.value=String(config.guidedKeyword||currentKeyword()||'').trim();const guidedSupplement=true;if(guidedSupplement)guidedSupplement.checked=config.guidedCoupangSupplementOnly===true;const targets=new Set((Array.isArray(config.targets)?config.targets:['category']).filter(t=>t!=='naver'));document.querySelectorAll('#spx-overlay [data-spx-explore-target]').forEach((node)=>{node.checked=targets.has(node.dataset.spxExploreTarget);});const specified=getUiElement('spx-sourcing-specified-enabled',{repair:false});if(specified)specified.checked=config.specifiedEnabled===true;const wave=getUiElement('spx-sourcing-wave-enabled',{repair:false});if(wave)wave.checked=config.specifiedEnabled!==true&&config.waveEnabled===true;const supplement=getUiElement('spx-coupang-supplement-only',{repair:false});if(supplement)supplement.checked=true;const seed=getUiElement('spx-sourcing-seed-keyword',{repair:false});if(seed)seed.value=Array.isArray(config.seedKeywords)?config.seedKeywords.join(', '):(config.seedKeyword||'');const month=getUiElement('spx-sourcing-target-month',{repair:false});if(month){const legacy=Number(config.targetMonth)||0;month.value=String(config.targetMonthText??(Array.isArray(config.targetMonths)&&config.targetMonths.length?config.targetMonths.join(','):legacy));syncSidebarTargetMonthInput({normalize:true});}const seasons=new Set(Array.isArray(config.seasons)?config.seasons:[]);document.querySelectorAll('#spx-overlay [data-spx-season]').forEach((node)=>{node.checked=seasons.has(node.dataset.spxSeason);});const rawQueue=String(config.queueBucket||'discovered');const queue=['discovered','manager'].includes(rawQueue)?rawQueue:'discovered';const queueRadio=document.querySelector(`#spx-overlay input[name="spx-queue-bucket"][value="${queue}"]`);if(queueRadio)queueRadio.checked=true;const serverUploadedPolicy=String(config.serverUploadedPolicy||'skip')==='reanalyze'?'reanalyze':'skip';const serverPolicyRadio=document.querySelector(`#spx-overlay input[name="spx-server-uploaded-policy"][value="${serverUploadedPolicy}"]`);if(serverPolicyRadio)serverPolicyRadio.checked=true;syncSidebarSourcingCategories(1,config);syncSidebarExplorationOptions();}
  function enforceSidebarKeywordMode(changedId=''){const wave=getUiElement('spx-sourcing-wave-enabled',{repair:false}),specified=getUiElement('spx-sourcing-specified-enabled',{repair:false});if(wave&&specified){if(changedId==='spx-sourcing-specified-enabled'&&specified.checked)wave.checked=false;else if(changedId==='spx-sourcing-wave-enabled'&&wave.checked)specified.checked=false;else if(wave.checked&&specified.checked)wave.checked=false;}}

  let managerQueuePreviewSeq=0;
  async function refreshManagerQueuePreview(options={}){
    const panel=getUiElement('spx-manager-queue-panel',{repair:false});
    if(!panel)return null;
    const active=sidebarSourcingMode==='refresh'&&selectedQueueBucket()==='manager';
    panel.hidden=!active;
    if(!active)return null;
    const seq=++managerQueuePreviewSeq;
    const countEl=getUiElement('spx-manager-queue-count',{repair:false});
    const listEl=getUiElement('spx-manager-queue-keywords',{repair:false});
    const failedEl=getUiElement('spx-manager-queue-failed',{repair:false});
    if(!options.silent){if(countEl)countEl.textContent='서버 재수집 대기열 확인 중...';if(listEl)listEl.textContent='Supabase 재수집 Queue 조회 중...';}
    try{
      const response=await runtimeMessage({type:'SPX_MANAGER_QUEUE_SUMMARY',limit:1000});
      if(seq!==managerQueuePreviewSeq)return null;
      if(!response?.ok)throw new Error(response?.error||'서버 재수집 Queue 조회 실패');
      const data=response.data||{};
      const queued=Math.max(0,Number(data.queued)||0),running=Math.max(0,Number(data.running)||0),failed=Math.max(0,Number(data.failed)||0);
      if(countEl)countEl.textContent=queued?`Manager 재수집 · 대기 ${queued.toLocaleString('ko-KR')}개`:'Manager 재수집 · 대기 없음';
      if(listEl)listEl.textContent=queued?(Array.isArray(data.keywords)&&data.keywords.length?data.keywords.join(', '):'대기 키워드를 불러오는 중...'):'Manager에서 요청한 재수집 키워드가 없습니다.';
      if(failedEl)failedEl.textContent=`수집중 ${running.toLocaleString('ko-KR')}건 · 실패 ${failed.toLocaleString('ko-KR')}건`;
      return data;
    }catch(error){
      if(seq!==managerQueuePreviewSeq)return null;
      if(countEl)countEl.textContent='Manager 재수집 · 조회 실패';
      if(listEl)listEl.textContent=error?.message||String(error);
      if(failedEl)failedEl.textContent='실패 상태 확인 불가';
      return null;
    }
  }
  function syncSidebarExplorationOptions(){enforceSidebarKeywordMode();const serverPolicy=getUiElement('spx-server-upload-policy',{repair:false});const targets=new Set([...document.querySelectorAll('#spx-overlay [data-spx-explore-target]:checked')].map((node)=>node.dataset.spxExploreTarget));const showMonth=['naver','monthly','category'].some((key)=>targets.has(key));const showCategory=['naver','monthly','steady','category'].some((key)=>targets.has(key));const showSeason=targets.has('seasonal');document.querySelectorAll('#spx-overlay [data-spx-explore-option="month"]').forEach((node)=>node.hidden=!showMonth);document.querySelectorAll('#spx-overlay [data-spx-explore-option="category"]').forEach((node)=>node.hidden=!showCategory);document.querySelectorAll('#spx-overlay [data-spx-explore-option="season"]').forEach((node)=>node.hidden=!showSeason);const waveEnabled=getUiElement('spx-sourcing-wave-enabled',{repair:false})?.checked===true;const specifiedEnabled=getUiElement('spx-sourcing-specified-enabled',{repair:false})?.checked===true;const supplement=getUiElement('spx-coupang-supplement-only',{repair:false});if(supplement){supplement.disabled=!specifiedEnabled;supplement.title=specifiedEnabled?'네이버 API를 호출하지 않고 쿠팡만 수집합니다.':'지정키워드를 먼저 선택하세요.';}const naverOnly=getUiElement('spx-naver-only',{repair:false});if(naverOnly){naverOnly.disabled=!specifiedEnabled;naverOnly.title=specifiedEnabled?'쿠팡 페이지를 이동하지 않고 네이버 검색량·추이만 수집합니다.':'지정키워드를 먼저 선택하세요.';}const seed=getUiElement('spx-sourcing-seed-keyword',{repair:false});if(seed){seed.disabled=!(waveEnabled||specifiedEnabled);seed.classList.toggle('spx-specified-mode',specifiedEnabled);seed.placeholder=specifiedEnabled?'지정 키워드를 앞에서부터 입력 순서대로 탐색합니다.\n쉼표 또는 줄바꿈으로 구분': '지정 키워드를 쉼표로 구분해 입력\n예: 화분 받침대, 화분 선반';}const count=parseTextSeeds(seed?.value||'',specifiedEnabled?null:100).length;const countEl=getUiElement('spx-sourcing-seed-count',{repair:false});if(countEl)countEl.textContent=`키워드 ${count}개`;const managerPanel=getUiElement('spx-manager-queue-panel',{repair:false});const managerActive=sidebarSourcingMode==='refresh'&&selectedQueueBucket()==='manager';if(serverPolicy)serverPolicy.hidden=managerActive;if(managerPanel)managerPanel.hidden=!managerActive;if(managerActive)refreshManagerQueuePreview({silent:true}).catch(()=>{});}
  function cloneSidebarExploration(config={}){
    const source=config&&typeof config==='object'?config:{};
    return {...DEFAULT_SIDEBAR_EXPLORATION,...source,
      targets:Array.isArray(source.targets)?[...source.targets]:[...DEFAULT_SIDEBAR_EXPLORATION.targets],
      seedKeywords:Array.isArray(source.seedKeywords)?[...source.seedKeywords]:[],
      targetMonths:Array.isArray(source.targetMonths)?[...source.targetMonths]:[],
      seasons:Array.isArray(source.seasons)?[...source.seasons]:[],
    };
  }
  function repairCommittedSidebarExploration(mode,config={}){
    const repaired=cloneSidebarExploration(config);
    let changed=false;
    if(repaired.specifiedEnabled===true&&repaired.waveEnabled===true){repaired.waveEnabled=false;changed=true;}
    if(repaired.guidedCoupangSupplementOnly===true&&repaired.guidedNaverOnly===true){repaired.guidedNaverOnly=false;changed=true;}
    if(repaired.coupangSupplementOnly===true&&repaired.naverOnly===true){repaired.naverOnly=false;changed=true;}
    /* v3.0.6.6 초기 저장본 중 지정키워드 목록과 빈 타겟은 남았지만 새 체크값만 빠진
       경우를 복구합니다. 이 조합은 일반 연속탐색으로는 실행 불가능하므로, 입력 목록을
       버리지 않고 지정키워드 모드로 안전하게 승계합니다. */
    if(normalizeSidebarSourcingMode(mode)==='full'&&repaired.specifiedEnabled!==true&&repaired.waveEnabled!==true&&!(repaired.targets||[]).length&&(repaired.seedKeywords||[]).length){
      repaired.specifiedEnabled=true;repaired.waveEnabled=false;changed=true;
    }
    return{exploration:repaired,changed};
  }
  function sourcingTargetLabels(exploration={}){
    const names={naver:'네이버 수요 상위',monthly:'특정 월/기간 수요',seasonal:'계절 키워드',surge:'급부상 신종',steady:'꾸준한 검색',category:'선택 카테고리'};
    return (Array.isArray(exploration.targets)?exploration.targets:[]).map((key)=>names[key]).filter(Boolean);
  }
  function describeSidebarSourcingExecution(mode=committedSidebarSourcingMode,exploration=committedSidebarExploration,profile=committedSidebarProfile){
    // v1.6.23: 이 함수의 범위에서 라벨을 선언해야 대기열 UI 갱신 시 ReferenceError가 발생하지 않음.
    const profileLabel='쿠팡 수집';
    const safeMode=normalizeSidebarSourcingMode(mode);
    if(safeMode==='guided'){const supplement=exploration?.guidedCoupangSupplementOnly===true?' 네이버 API는 호출하지 않고 기존 네이버 값을 유지한 채 쿠팡만 수집합니다.':exploration?.guidedNaverOnly===true?' 쿠팡 자료는 유지하고 네이버 검색량·12개월 추이 계열만 수집합니다.':'';return `단건 분석 — 키워드 분석 클릭 시 현재 키워드 1개만 수집합니다. 다음 키워드로 이동하지 않고 완료 상태로 멈춥니다.${supplement}`;}
    if(safeMode==='full'){
      const targets=sourcingTargetLabels(exploration);
      const serverPolicy=String(exploration?.serverUploadedPolicy||'skip')==='reanalyze'?'서버 등록 키워드 재수집':'부족항목 SKIP(부족없음·누락 0건)';
      if(exploration?.specifiedEnabled===true){const supplement=exploration?.coupangSupplementOnly===true?' API 생략 · 쿠팡만 수집':exploration?.naverOnly===true?' · 쿠팡 수집 생략만 수집':'';return `연속 탐색 — 지정키워드 ${Array.isArray(exploration.seedKeywords)?exploration.seedKeywords.length:0}개를 입력 순서대로 반복${supplement} · ${serverPolicy}.`;}
      const wave=exploration?.waveEnabled===true?` · 파도타기 ${Array.isArray(exploration.seedKeywords)?exploration.seedKeywords.length:0}개`:'';
      return `연속 탐색 — ${targets.length?targets.join(' · '):'선택 타겟 없음'}${wave} · ${serverPolicy}. 키워드 분석 클릭 시 선택 기준으로 대기열을 만들고 다음 키워드로 계속 진행합니다.`;
    }
    if(safeMode==='local')return `로컬DB — 새 네이버 키워드를 발굴하지 않습니다. 로컬DB 키워드만 순서대로 쿠팡에서 수집하고, 저장된 네이버 자료를 우선 사용하며 부족할 때만 키워드당 1회 보완합니다.`;
    const rawBucket=String(exploration?.queueBucket||'discovered');
    const bucket=rawBucket==='manager'?'서버 재수집 대기열':rawBucket==='naver'?'네이버 대기':'발견 키워드';
    if(rawBucket==='manager')return `${profileLabel} · 대기열 수집 — 공용 서버에 등록된 재수집 요청만 Queue에서 한 건씩 선점해 기존 단건 수집 엔진으로 처리합니다. 서버 기존등록 키워드도 건너뛰지 않습니다.`;
    return `${profileLabel} · 대기열 수집 — ${bucket} 항목을 쿠팡에서 한 건씩 처리합니다. 발견키워드 원본과 기존 서버 데이터는 보존하며 새로운 네이버 API 조회는 실행하지 않습니다.`;
  }
  function renderSidebarSourcingSummary(options={}){
    const draft=options.draft===true;
    const mode=draft?sidebarSourcingMode:committedSidebarSourcingMode;
    const exploration=draft?readSidebarExplorationForm():committedSidebarExploration;
    const profile=draft?activeCollectionProfile:committedSidebarProfile;
    const label=draft?'미저장 미리보기':'저장됨';
    const target=getUiElement('spx-sourcing-saved-summary-text',{repair:false});
    if(target)target.textContent=`${label} · ${describeSidebarSourcingExecution(mode,exploration,profile)}`;
    const save=getUiElement('spx-sourcing-save',{repair:false});
    if(save)save.classList.toggle('pending',draft);
  }
  function markSourcingDraftDirty(){
    sourcingDraftDirty=true;
    renderSidebarSourcingSummary({draft:true});
  }
  async function loadCommittedSidebarSourcingSelection(options={}){
    let stored={};
    try{stored=await chrome.storage.local.get([SIDEBAR_SOURCING_MODE_KEY,SIDEBAR_EXPLORATION_KEY,COLLECTION_PROFILE_KEY]);}catch(_){}
    committedSidebarSourcingMode=normalizeSidebarSourcingMode(stored?.[SIDEBAR_SOURCING_MODE_KEY]||committedSidebarSourcingMode||'guided');
    const repaired=repairCommittedSidebarExploration(committedSidebarSourcingMode,stored?.[SIDEBAR_EXPLORATION_KEY]||committedSidebarExploration);
    committedSidebarExploration=repaired.exploration;
    if(repaired.changed)await chrome.storage.local.set({[SIDEBAR_EXPLORATION_KEY]:committedSidebarExploration}).catch(()=>{});
    committedSidebarProfile=normalizeCollectionProfile(stored?.[COLLECTION_PROFILE_KEY]||committedSidebarProfile||activeCollectionProfile);
    if(options.apply===true){
      await setActiveCollectionProfile(committedSidebarProfile,{persist:false,syncSettingsTab:false,refresh:false});
      applySidebarExplorationForm(committedSidebarExploration);
      selectSidebarSourcingMode(committedSidebarSourcingMode,{persist:false,markDirty:false});
    }
    sourcingDraftDirty=false;
    renderSidebarSourcingSummary();
    return{mode:committedSidebarSourcingMode,exploration:cloneSidebarExploration(committedSidebarExploration),profile:committedSidebarProfile};
  }
  async function saveSidebarSourcingSelection(){
    const exploration=readSidebarExplorationForm();
    if(sidebarSourcingMode==='full'&&exploration.specifiedEnabled!==true&&exploration.targets.includes('monthly')&&!exploration.targetMonthValid)throw new Error(exploration.targetMonthError||'특정 월/기간 입력을 확인하세요.');
    committedSidebarSourcingMode=normalizeSidebarSourcingMode(sidebarSourcingMode);
    committedSidebarExploration=cloneSidebarExploration(exploration);
    committedSidebarProfile=normalizeCollectionProfile(activeCollectionProfile);
    await chrome.storage.local.set({
      [SIDEBAR_SOURCING_MODE_KEY]:committedSidebarSourcingMode,
      [SIDEBAR_EXPLORATION_KEY]:committedSidebarExploration,
      [COLLECTION_PROFILE_KEY]:committedSidebarProfile,
    });
    /* 사용자 소유 설정은 일반 '설정 저장' 버튼이 다시 쓰지 않습니다.
       체크/해제 change 이벤트가 이미 즉시 저장하므로 여기서는 그 저장 완료만 기다립니다. */
    sourcingDraftDirty=false;
    renderSidebarSourcingSummary();
    renderSidebarModeBadge(selectedSourcingModeLabel(committedSidebarSourcingMode),committedSidebarProfile,false);
    const button=getUiElement('spx-sourcing-save',{repair:false});
    if(button){const original='설정 저장';button.textContent='저장됨 ✓';button.classList.remove('pending');setTimeout(()=>{if(button.isConnected)button.textContent=original;},900);}
    setDisplay('spx-auto','flex');
    setText('spx-auto-text',describeSidebarSourcingExecution(committedSidebarSourcingMode,committedSidebarExploration,committedSidebarProfile));
    return{mode:committedSidebarSourcingMode,exploration:cloneSidebarExploration(committedSidebarExploration),profile:committedSidebarProfile};
  }
  function restoreSidebarSourcingSelection(){
    setActiveCollectionProfile(committedSidebarProfile,{persist:false,syncSettingsTab:false,refresh:false}).catch(()=>{});
    applySidebarExplorationForm(committedSidebarExploration);
    selectSidebarSourcingMode(committedSidebarSourcingMode,{persist:false,markDirty:false});
    sourcingDraftDirty=false;
    renderSidebarSourcingSummary();
  }
  async function persistSidebarSourcingSelection(){return saveSidebarSourcingSelection();}
  function scheduleSidebarSourcingPersistence(){
    clearTimeout(sidebarSourcingPersistTimer);
    sidebarSourcingPersistTimer=setTimeout(()=>{sidebarSourcingPersistTimer=null;markSourcingDraftDirty();},60);
  }
  function closeSourcingModal(options={}){
    if(sourcingDraftDirty)restoreSidebarSourcingSelection();
    const modal=getUiElement('spx-sourcing-modal',{repair:false});
    if(!modal)return false;
    const active=document.activeElement;
    if(active&&modal.contains(active)&&typeof active.blur==='function')active.blur();
    modal.hidden=true;
    modal.setAttribute('aria-hidden','true');
    if(options.restoreFocus!==false){
      const trigger=getUiElement('spx-mode-badge',{repair:false});
      if(trigger&&typeof trigger.focus==='function')requestAnimationFrame(()=>trigger.focus({preventScroll:true}));
    }
    return true;
  }
  async function openSourcingModal(){
    const modal=getUiElement('spx-sourcing-modal',{repair:false});
    if(!modal)return;
    /* 전용창에서는 로컬 브리지의 마지막 사용자 선택을 먼저 복원한 뒤 체크박스를 그립니다. */
    if(IS_SELECTED_NETWORK_DEDICATED_TAB)await runtimeMessage({type:'SPX_DEDICATED_PROFILE_HYDRATE',onlyWhenMissing:true}).catch(()=>null);
    await loadCommittedSidebarSourcingSelection({apply:true});
    const guidedInput=getUiElement('spx-guided-keyword',{repair:false});
    if(guidedInput&&!guidedInput.value&&currentKeyword())guidedInput.value=currentKeyword();
    await syncSidebarAutoUploadSetting().catch(()=>{});
    await syncNextNavigationDelaySetting().catch(()=>{});
    const globalSettings=await SPX.util.getSettings().catch(()=>({}));
    renderSidebarSourcingSummary();
    modal.hidden=false;
    modal.setAttribute('aria-hidden','false');
    if(committedSidebarSourcingMode==='refresh'&&String(committedSidebarExploration?.queueBucket||'')==='manager')refreshManagerQueuePreview({silent:false}).catch(()=>{});
    const firstFocus=getUiElement('spx-sourcing-close',{repair:false})||modal.querySelector('button,input,select,textarea');
    if(firstFocus&&typeof firstFocus.focus==='function')requestAnimationFrame(()=>firstFocus.focus({preventScroll:true}));
  }
  async function recoverSelectedModeStartAfterChannelClose(payload,error){
    if(!SPX.util.isTransientRuntimeMessageError?.(error)||!SPX.util.runtimeAlive?.())return null;
    /* v1.5.25: 시작 요청은 background가 실행 상태를 먼저 저장한 뒤 현재 탭을 이동할 수 있습니다.
       그 이동/Service Worker 교체 순간 응답 포트만 닫힌 경우 재시작 명령을 다시 보내지 않고
       storage의 authoritative 실행 상태를 확인해 이미 시작된 run을 그대로 이어갑니다. */
    for(const delay of [180,420,850,1400]){
      await new Promise((resolve)=>setTimeout(resolve,delay));
      try{
        const stored=await chrome.storage.local.get('spxAutomation');
        const live=stored?.spxAutomation;
        if(live?.running===true&&String(live?.runId||'')&&String(live?.currentKeyword||'').trim()){
          console.info('[SPX] 시작 응답 연결만 끊겨 실행 상태에서 복구',live.currentKeyword,live.runId);
          return{ok:true,state:live,runId:live.runId,automationTabId:live.automationTabId||null,recoveredFromChannelClose:true,navigationPending:true,message:'시작 응답 연결만 끊겨 저장된 실행 상태에서 자동 복구했습니다.'};
        }
      }catch(_){ }
    }
    return null;
  }

  const NAVER_ONLY_STATE_KEY_V163='spxNaverOnlyCollectionV163';
  
  
  
  

  async function startSidebarSelectedMode(options={}){
    const initialSelection=options.selection||await loadCommittedSidebarSourcingSelection({apply:true});
    ;
    
    localManualCompletedKeyword='';
    const button=getUiElement('spx-scan',{repair:false});if(button)button.disabled=true;
    setSidebarCollecting(true);setDisplay('spx-auto','flex');setText('spx-auto-text','저장된 수집 실행 설정을 확인하는 중...');setProgress(2,'저장 설정 확인 중');
    let startFailure='';
    try{
      /* v4.0.98: 수집 시작 직전 Native Host 전체 설정 hydrate 금지.
         전용창에서 사용자가 방금 선택한 자동 업로드/추가페이지 값을 과거 보호본이 다시 덮지 못하게 합니다.
         민감 연동키(Supabase/네이버)는 서비스워커 preflight에서 별도로 복구합니다. */
      const selection=options.selection||await loadCommittedSidebarSourcingSelection({apply:true});
      const executionMode=normalizeSidebarSourcingMode(selection.mode);
      const exploration=cloneSidebarExploration(selection.exploration);
      sidebarSourcingMode=executionMode;
      if(executionMode==='guided')await lockSidebarToManualMode('단건 분석 시작 설정 고정');
      const selectedProfile=await selectedCollectionProfileSettings();
      const profileLabel='수집';
      const profileMax=Math.max(1,Number(selectedProfile.settingsOverride?.maxPagesPerKeyword)||1);
      const profileOrganic=Math.max(1,Number(selectedProfile.settingsOverride?.sourceDataTargetOrganic)||60);
      const profileExtra=selectedProfile.settingsOverride?.autoExtraPageEnabled===true?'ON':'OFF';
      const profileUpload=selectedProfile.settingsOverride?.autoUpload===true?'서버 직행 ON':'업로드 대기 OFF';
      setText('spx-auto-text',`실행 기준 확인 · ${profileLabel} · 기본 최대 ${profileMax}페이지(상한) · 자연노출 목표 ${profileOrganic} · 추가페이지 ${profileExtra} · 자동업로드 ${profileUpload}`);
      setProgress(3,`수집 기준 적용 · ${profileLabel} · 최대 ${profileMax}p · 목표 ${profileOrganic}`);
      const selectedNetworkTarget=collectionNetworkTargetForSettingsV135(selectedProfile.settingsOverride);
      const payload={type:'SPX_START_SELECTED_MODE',mode:executionMode,useCurrentTab:true,collectionProfile:selectedProfile.profile,settingsOverride:{...selectedProfile.settingsOverride,coupangSupplementOnly:true,naverTrendEnabled:false,naverOnly:false,naverCollectionPolicy:'skip'},serverUploadedPolicy:String(exploration.serverUploadedPolicy||'skip')==='reanalyze'?'reanalyze':'skip',networkTarget:selectedNetworkTarget,dedicatedCurrentTab:selectedNetworkTarget==='window'&&IS_SELECTED_NETWORK_DEDICATED_TAB===true};
      if(executionMode==='guided'){
        payload.exactKeywords=[currentKeyword(),exploration.guidedKeyword].map((value)=>String(value||'').replace(/\s+/g,' ').trim()).filter(Boolean).slice(0,1);
        if(!payload.exactKeywords.length)throw new Error('단건 분석 키워드를 입력하세요.');
        const guidedSupplement=true;
        payload.settingsOverride={...(payload.settingsOverride||{}),coupangSupplementOnly:true,naverCollectionPolicy:'skip'};
      }else if(executionMode==='full'){
        if(exploration.specifiedEnabled!==true&&exploration.targets.includes('monthly')&&!exploration.targetMonthValid)throw new Error(exploration.targetMonthError||'특정 월/기간 입력을 확인하세요.');
        if(exploration.specifiedEnabled===true&&!exploration.seedKeywords.length)throw new Error('지정키워드 기입란에 탐색할 키워드를 입력하세요.');
        payload.exploration={...exploration,naverOnly:false,guidedNaverOnly:false,coupangSupplementOnly:true,targets:exploration.targets.filter(target=>target!=='naver'),seedKeywords:(exploration.waveEnabled||exploration.specifiedEnabled)?exploration.seedKeywords:[]};
      }else if(executionMode==='refresh'){
        payload.queueBucket=exploration.queueBucket;
        if(String(exploration.queueBucket||'')==='manager'){
          const summary=await refreshManagerQueuePreview({silent:false});
          if(!summary||Number(summary.queued||0)<=0)throw new Error('Manager에서 요청한 재수집 키워드가 없습니다.');
          payload.serverUploadedPolicy='reanalyze';
        }
      }
      const routeGate=await ensureSearchCollectionRouteV10156({settings:selectedProfile.settingsOverride,keyword:payload.exactKeywords?.[0]||exploration.seedKeywords?.[0]||currentKeyword(),handoffMessage:payload});
      if(routeGate?.handedOff){if(options.closeModal!==false)closeSourcingModal({restoreFocus:false});return routeGate;}
      const startRequestedAt=Date.now();
      let startHeartbeat=null;
      if(executionMode==='full'){
        sourcingStartPending=true;
        sourcingStartCancelRequested=false;
        await refreshSidebarRunButton({running:false,lastMessage:'쿠팡 시작 후보 준비 중 후보는 백그라운드 합류'}).catch(()=>{});
        const targetLabels={naver:'네이버 수요 상위',monthly:'특정 월/기간',seasonal:'계절성',surge:'급부상',steady:'꾸준한 검색',category:'선택 카테고리'};
        const labels=(exploration.targets||[]).map((key)=>targetLabels[key]).filter(Boolean);
        const specified=exploration.specifiedEnabled===true;
        const scopeText=specified?`지정키워드 ${exploration.seedKeywords.length}개${exploration.coupangSupplementOnly===true?' · 쿠팡만 수집':''}`:(labels.length?labels.join(' · '):(exploration.waveEnabled?'키워드 파도타기':'연속 탐색 후보'));
        setText('spx-status',specified?'지정키워드 즉시 시작':'연속 탐색 즉시 시작');
        setText('spx-auto-text',specified?`${scopeText} · 단건 분석과 같은 수집 단계를 키워드별로 반복합니다.${exploration.coupangSupplementOnly===true?' 네이버 API는 호출하지 않습니다.':''}`:`${scopeText} · 쿠팡 시작 후보를 먼저 준비합니다 후보/지표는 백그라운드에서 합류합니다.`);
        setProgress(specified?4:3,specified?`지정키워드 ${exploration.seedKeywords.length}개 순서 목록 전달`:'쿠팡 시작 후보 준비 후속은 비동기');
        if(!specified)startHeartbeat=setInterval(()=>{
          const sec=Math.max(1,Math.floor((Date.now()-startRequestedAt)/1000));
          setProgress(Math.min(5,3+(sec%3)),`쿠팡 시작 후보 준비 중 · ${sec}초/서버 동기화는 뒤에서 계속`);
          setText('spx-auto-text',`${scopeText} · 쿠팡 수집 시작을 우선 준비 중 (${sec}초) 결과를 기다려 전체 수집을 멈추지 않습니다.`);
        },1000);
      }
      let started;
      try{
        try{started=await runtimeMessage(payload);}
        catch(error){
          const recovered=await recoverSelectedModeStartAfterChannelClose(payload,error);
          if(!recovered)throw error;
          started=recovered;
        }
      }finally{if(startHeartbeat)clearInterval(startHeartbeat);sourcingStartPending=false;}
      if(!started?.ok){
        throw new Error(started?.error||'선택한 실행 방식 시작 실패');
      }
      if(started?.manualLocked)throw new Error(started?.message||'단건 분석 완료 후 다른 실행을 시작할 수 있습니다.');
      if(executionMode==='full'&&exploration.specifiedEnabled===true&&(!started?.state?.running||!started?.state?.currentKeyword)){
        /* v1.5.0: 서버 중복/보호된 수동 제외 등으로 모든 지정키워드가 즉시 terminal 처리될 수 있습니다.
           실제 오류가 없고 처리 카운트가 있으면 '시작 실패'가 아니라 정상 즉시 완료로 표시합니다. */
        const terminalCount=Math.max(0,Number(started?.state?.processed)||0)+Math.max(0,Number(started?.state?.excludedCount)||0)+Math.max(0,Number(started?.state?.serverDuplicateSkippedCount)||0)+Math.max(0,Number(started?.state?.failedCount)||0);
        const immediateComplete=terminalCount>0&&!String(started?.state?.lastError||'').trim();
        if(!immediateComplete)throw new Error(started?.state?.lastError||started?.state?.lastMessage||'지정키워드 첫 번째 항목을 순서 목록에서 시작하지 못했습니다.');
      }
      if(options.closeModal!==false)closeSourcingModal({restoreFocus:false});
      activeRunId=String(started?.state?.runId||started?.runId||'');
      setDisplay('spx-auto','flex');
      await setTabAutomationTimer('start');
      setText('spx-auto-text',started?.message||started?.state?.lastMessage||describeSidebarSourcingExecution(executionMode,exploration,selectedProfile.profile));
      if(started?.state?.running){
        const firstKeyword=String(started?.state?.currentKeyword||'').trim();
        const visibleKeyword=String(currentKeyword()||'').trim();
        const waitingNavigation=started?.navigationPending===true&&firstKeyword&&normKeyword(firstKeyword)!==normKeyword(visibleKeyword);
        setProgress(5,waitingNavigation?`${firstKeyword} 검색화면 이동 중`:firstKeyword?`${firstKeyword} 즉시 분석 시작`:'대기열 선점 중');
        armAutomationKickWatchdog(activeRunId,firstKeyword,'사이드바 실행');
        if(!waitingNavigation)scheduleAutoRun(0);
      }else setSidebarCollecting(false);
    }catch(error){
      if(sourcingStartCancelRequested||/사용자 중단|취소되었습니다|AbortError/i.test(String(error?.message||error))){
        setText('spx-status','연속 탐색 중단');setText('spx-auto-text','네이버 API 후보 확인을 사용자 요청으로 멈췄습니다.');setProgress(0,'사용자 중단');setSidebarCollecting(false);return;
      }
      startFailure=error?.message||String(error);setText('spx-auto-text',startFailure);setProgress(0,'시작 실패');setSidebarCollecting(false);throw error;
    }
    finally{sourcingStartPending=false;sourcingStartCancelRequested=false;clearAnalysisStartFeedback();if(button)button.disabled=false;await refreshSidebarRunButton().catch(()=>{});if(startFailure){setText('spx-status','시작 실패');setText('spx-auto-text',startFailure);setProgress(0,`시작 실패 · ${startFailure}`);}}
  }
  async function runSelectedAnalysisAction(options={}){
    const naverSelection=await loadCommittedSidebarSourcingSelection({apply:true});
    /* Naver only removed: Manager owns that pipeline. */
    
    const recoveryResponse=await runtimeMessage({type:'SPX_GET_NETWORK_RECOVERY_STATE'}).catch(()=>null);
    const recoveryState=recoveryResponse?.data?.networkRecovery||{};
    const recoveryStatus=String(recoveryState?.status||'').toLowerCase();
    if(['counting','resetting','finalizing'].includes(recoveryStatus)||recoveryUiOwner===true||manualIpChangePending===true){
      ensureUi();setDisplay('spx-auto','flex');setSidebarCollecting(true);setRecoveryActionLockV111(true);
      setText('spx-status','IP 변경 복구 진행 중');
      setText('spx-auto-text','현재 쿠팡 차단 복구가 끝나면 저장된 키워드·페이지에서 자동으로 수집을 이어갑니다. 키워드 분석을 다시 누를 필요가 없습니다.');
      startRecoveryCountdownMonitor();
      return {ok:false,recoveryActive:true};
    }
    setAnalysisStartFeedback();
    try{
      const selection=naverSelection;
      const executionMode=normalizeSidebarSourcingMode(selection.mode);
      if(executionMode==='guided')await lockSidebarToManualMode('키워드 분석 버튼 · 단건 모드 유지');
      setText('spx-auto-text',describeSidebarSourcingExecution(executionMode,selection.exploration,selection.profile));
      if(executionMode==='guided'&&isCurrentCoupangSearchPage())return await runManualScan({selection});
      return await startSidebarSelectedMode({selection,useCurrentKeyword:true,closeModal:false,...options});
    }catch(error){setText('spx-auto-text',error?.message||String(error));clearAnalysisStartFeedback();setSidebarCollecting(false);throw error;}
  }

  async function runSidebarUtility(buttonId, busyText, request, successFallback){
    const button=getUiElement(buttonId,{repair:false});const original=button?.textContent||'';
    if(button){button.disabled=true;button.textContent='…';}
    setDisplay('spx-auto','flex');setText('spx-auto-text',busyText);
    try{const response=await runtimeMessage(request);if(!response?.ok)throw new Error(response?.error||'처리 실패');setText('spx-auto-text',response.message||response.data?.message||successFallback);return response;}
    catch(error){setText('spx-auto-text',error?.message||String(error));return null;}
    finally{if(button){button.disabled=false;button.textContent=original;}}
  }
  function cleanExtensionMemory(){return runSidebarUtility('spx-memory-cleanup','수집기 임시 리소스를 정리하는 중...',{type:'SPX_MEMORY_CLEANUP_NOW',source:'sidebar'},'확장프로그램 임시 리소스 정리를 완료했습니다.');}
  async function clearBrowsingRecordsPreserveLogin(){const confirmed=globalThis.confirm('쿠팡 쇼핑(coupang.com·www.coupang.com)의 캐시와 사이트 저장소(CacheStorage·IndexedDB·LocalStorage·ServiceWorker 등)를 정리합니다. 쿠팡/WING 로그인 쿠키와 wing.coupang.com 저장소는 삭제하지 않습니다. 계속할까요?');if(!confirmed)return null;return runSidebarUtility('spx-clear-browsing','WING 로그인은 유지하고 쿠팡 쇼핑 캐시를 정리하는 중...',{type:'SPX_CLEAR_BROWSING_DATA_PRESERVE_LOGIN',removeCoupangSiteData:true,dedicatedNetworkTab:IS_SELECTED_NETWORK_DEDICATED_TAB===true},'WING 로그인 유지 · 쿠팡 쇼핑 캐시 정리를 완료했습니다.');}
  function setNativeInputValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
    if (setter) setter.call(input, value); else input.value = value;
    input.dispatchEvent(new Event('input', { bubbles:true }));
    input.dispatchEvent(new Event('change', { bubbles:true }));
  }

  async function submitCoupangSearchOnce(keyword, options={}) {
    const input = document.querySelector('#headerSearchKeyword') || document.querySelector('form[action*="/np/search"] input[name="q"]') || document.querySelector('input[name="q"]');
    if (!input) throw new Error('쿠팡 검색창을 찾지 못했습니다.');

    /* 쿠팡 검색창 내부 상태가 실제 입력과 같아질 때까지 짧게 확인한 뒤,
       사용자가 누르는 것과 같은 검색 버튼을 정확히 한 번만 클릭합니다. */
    setNativeInputValue(input, keyword);
    input.focus();
    await sleep(options?.fast===true?jitterMs(35,85):(SPX.util.randomInt?.(280,470)||350));
    if (String(input.value || '').trim() !== keyword) {
      setNativeInputValue(input, keyword);
      await sleep(options?.fast===true?jitterMs(25,65):(SPX.util.randomInt?.(130,290)||180));
    }

    const form=input.closest('form');
    const button = document.querySelector('#headerSearchBtn') || form?.querySelector('button[type="submit"], input[type="submit"]') || document.querySelector('button.search, .search-button');
    if (!button || typeof button.click !== 'function') {
      throw new Error('쿠팡 검색버튼을 찾지 못했습니다. 직접 검색버튼을 눌러주세요.');
    }
    setText('spx-status', '다음 키워드 검색 중');
    setDisplay('spx-auto', 'flex');
    setText('spx-auto-text', `“${keyword}” 입력 완료 · 불규칙 대기 후 검색버튼 1회 클릭 · 결과 대기`);
    if(options?.fast===true)await sleep(jitterMs(80,180));else await waitForServerSignal('normal');
    button.click();
  }

  async function stepOneKeyword(options={}) {
    const analyzeAfterSearch=options?.analyzeAfterSearch===true;
    localManualCompletedKeyword='';
    const buttons=['spx-skip-keyword','spx-step-once'].map((id)=>getUiElement(id,{repair:false})).filter(Boolean);
    const originals=buttons.map((button)=>button.textContent);
    for(const button of buttons){button.disabled=true;button.textContent='…';}
    try{
      setText('spx-status','현재 분석 중단 · 다음 준비');
      setDisplay('spx-auto','flex');
      setText('spx-auto-text',analyzeAfterSearch?'현재 분석을 멈추고 다음 키워드 검색 후 자동 분석을 준비합니다.':'현재 분석을 멈추고 다음 키워드 검색 화면에서 대기합니다.');
      cancelAutomationWork('',{updateUi:false});
      await chrome.storage.local.remove(STEP_ANALYZE_KEY).catch(()=>{});
      const response=await runtimeMessage({type:'SPX_ADVANCE_TO_NEXT_KEYWORD',currentKeyword:currentKeyword(),sourceKeyword:currentKeyword(),preferredBucket:'discovered',manualStepOnly:true});
      if(!response?.ok)throw new Error(response?.error||'다음 키워드를 찾지 못했습니다.');
      const keyword=String(response.nextKeyword||'').trim();if(!keyword)throw new Error('다음 키워드가 없습니다.');
      if(analyzeAfterSearch){
        await chrome.storage.local.set({[STEP_ANALYZE_KEY]:{keyword,createdAt:Date.now(),expiresAt:Date.now()+5*60*1000,profile:'lite',sourcingMode:sidebarSourcingMode,queueBucket:response.sourceBucket||'discovered'}});
      }
      setText('spx-status','다음 키워드 검색');
      setText('spx-auto-text',analyzeAfterSearch
        ?`다음 키워드 “${keyword}” · 쿠팡 검색 → 키워드 분석 자동 시작`
        :`다음 키워드 “${keyword}” · 쿠팡 검색 → 검색결과 화면에서 대기`);
      /* 선택 테더링 전용창은 키워드 사이의 인위적 지연이 필요하지 않습니다.
         DOM 전환 준비 확인은 검색 제출 뒤 기존 준비검사에서 그대로 수행합니다. */
      if(!IS_SELECTED_NETWORK_DEDICATED_TAB)await sleep(jitterMs(45,100));
      await submitCoupangSearchOnce(keyword,{fast:true});
    }catch(error){
      console.debug('[SPX] 다음 키워드 이동 실패',error?.message||String(error));
      setText('spx-status','다음 이동 실패');setDisplay('spx-auto','flex');setText('spx-auto-text',error?.message||String(error));
    }finally{
      buttons.forEach((button,index)=>{if(document.contains(button)){button.disabled=false;button.textContent=originals[index]|| (button.id==='spx-skip-keyword'?'다음 ⏭':'⏭');}});
      refreshNextKeywordHint(true).catch(()=>{});
    }
  }
  async function resumeStepAnalysisIfNeeded(){
    let pending=null;try{pending=(await chrome.storage.local.get(STEP_ANALYZE_KEY))[STEP_ANALYZE_KEY];}catch(_){}if(!pending)return false;
    if(Number(pending.expiresAt||0)<Date.now()){await chrome.storage.local.remove(STEP_ANALYZE_KEY).catch(()=>{});return false;}
    if(normKeyword(pending.keyword)!==normKeyword(currentKeyword()))return false;
    await chrome.storage.local.remove(STEP_ANALYZE_KEY).catch(()=>{});await setActiveCollectionProfile(pending.profile||'lite',{persist:false});selectSidebarSourcingMode(pending.sourcingMode||'guided',{persist:false});
    setDisplay('spx-auto','flex');setText('spx-auto-text',`“${currentKeyword()}” 검색 완료 · DOM 안정화 후 키워드 분석을 시작합니다.`);
    await waitForProducts(30000,null);await sleep(jitterMs(120,280));await runSelectedAnalysisAction({fromStep:true});return true;
  }

  /* [v2.2.2] 지금 진행 중인 키워드를 '제외' 확정하고 다음으로 넘어간다(건너뛰기와 달리
     나중에 자동으로 다시 수집되지 않는다). */
  async function excludeCurrentKeyword() {
    const btn = getUiElement('spx-exclude-keyword', { repair:false });
    const excludedKeyword=currentKeyword();
    if (btn) { btn.disabled = true; btn.textContent = '제외 중...'; }
    try {
      /* 현재 DOM 수집/분석 작업을 즉시 끊습니다. 연속 실행 runId는 서버가 다음 키워드를 선점할 때까지 유지합니다. */
      cancelAutomationWork('현재 키워드 제외 처리 중',{updateUi:false,keepRunId:true});
      const response = await runtimeMessage({ type: 'SPX_EXCLUDE_CURRENT_KEYWORD', keyword: excludedKeyword });
      if (!response?.ok) throw new Error(response?.error || '제외 처리 실패');
      await recordTabSessionEvent('manual-exclude-button',{excluded:1},{eventId:`manual-exclude-button:${excludedKeyword}:${Date.now()}`});
      if(response.manualComplete===true||response?.state?.running===false){
        cancelAutomationWork('단건 키워드 제외 완료',{updateUi:false,keepRunId:false});
        setDisplay('spx-auto','flex');setText('spx-status','제외 완료 · 단건 중지');
        setText('spx-auto-text',`“${excludedKeyword}”을 공통 제외 키워드에 즉시 저장하고 단건 분석을 중지했습니다.`);
        setProgress(100,`${excludedKeyword} · 제외 완료`);
        return;
      }
      const nextKeyword=String(response.nextKeyword||response?.state?.currentKeyword||'').trim();
      if(nextKeyword){
        activeRunId=String(response?.state?.runId||activeRunId||'');
        setDisplay('spx-auto','flex');setText('spx-status','제외 완료 · 다음 분석');
        setText('spx-auto-text',`“${excludedKeyword}” 제외 완료 → 다음 “${nextKeyword}” 즉시 검색·분석`);
        await transitionKeywordAndStart(nextKeyword,{runId:activeRunId,reason:'현재 키워드 제외 후 다음 키워드'});
      }else{
        setText('spx-status','제외 완료');setText('spx-auto-text',`“${excludedKeyword}”을 공통 제외 키워드에 저장했습니다. 다음 대기 키워드가 없습니다.`);
      }
    } catch (error) {
      console.warn('[SPX] 현재 키워드 제외 실패', error);
      setDisplay('spx-auto','flex');setText('spx-status','제외 실패');
      setText('spx-auto-text',`제외 실패 · ${error?.message||String(error)} · 서버 저장에 성공하지 않아 현재 키워드를 화면에서 제거하지 않았습니다.`);
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = '제외 ✕'; }
    }
  }

  async function skipCurrentKeyword() {
    return stepOneKeyword();
  }

  async function toggleSidebarAutomation() {
    const button = getUiElement('spx-run-toggle', { repair:false });
    if (!button || button.disabled) return;
    button.disabled = true;
    try {
      ;
      if(sourcingStartPending){
        sourcingStartCancelRequested=true;
        setText('spx-status','연속 탐색 중단 요청');
        setText('spx-auto-text','네이버 API 후보 확인 요청을 취소하고 있습니다.');
        await runtimeMessage({type:'SPX_QUEUE_STOP',reason:'쿠팡 사이드바 · 연속 탐색 후보 확인 중단'});
        sourcingStartPending=false;
        cancelAutomationWork('사용자가 연속 탐색 후보 확인을 멈췄습니다.');
        return;
      }
      const response = await readAutomationState();
      const remote = response?.state || {};
      const recoveryResponse=await runtimeMessage({type:'SPX_GET_NETWORK_RECOVERY_STATE'}).catch(()=>null);
      const recoveryState=recoveryResponse?.data?.networkRecovery||{};
      const recoveryStatus=String(recoveryState?.status||'').toLowerCase();
      const recoveryActive=remote?.networkRecoveryPaused===true||manualIpChangePending===true||recoveryUiOwner===true||['counting','resetting','finalizing'].includes(recoveryStatus);
      const buttonIsStop=button.getAttribute('aria-label')?.includes('멈춤')||button.classList.contains('running');
      if(recoveryActive||buttonIsStop&&recoveryStatus&&!['idle','completed','cancelled'].includes(recoveryStatus)){
        recoveryUiOwner=false;manualIpChangePending=false;
        setText('spx-status','수집 중단');setText('spx-auto-text','진행 중인 비행기 모드·IP 변경과 현재 수집을 함께 중단합니다.');
        cancelAutomationWork('',{updateUi:false});
        await setTabAutomationTimer('stop').catch(()=>{});
        await runtimeMessage({type:'SPX_QUEUE_STOP',reason:'쿠팡 사이드바 네트워크 복구 포함 전체 중단',stopAll:true}).catch(()=>null);
        stopRecoveryCountdownMonitorV1518()
        recoveryUiOwner=false;manualIpChangePending=false;activeRunId='';localManualScanActive=false;
        setSidebarCollecting(false);setText('spx-status','수집 대기');setText('spx-auto-text','수집과 IP 변경을 중단했습니다.');setProgress(0,'수집 중단 완료 · 네트워크 복구 상태 정리');
        return;
      }
      if(localManualScanActive||state.busy===true||Boolean(activeStage)||Boolean(activeRunId)||remote.running){
        /* v4.0.97: 연속/지정/대기열 수집 중단을 단건 abort 플래그로 오염시키지 않습니다.
           이 플래그는 실제 runManualSinglePageScan이 실행 중일 때 사용자가 ■를 누른 경우에만 세웁니다. */
        localManualAbortRequested=localManualScanActive===true;
        sourcingStartCancelRequested=true;
        setText('spx-status','전체 수집 중단');
        setText('spx-auto-text','쿠팡 수집·네이버 조회·업로드·후처리를 즉시 중단합니다.');
        cancelAutomationWork('사용자가 사이드바에서 모든 수집 진행을 멈췄습니다.');
        await setTabAutomationTimer('stop').catch(()=>{});
        await runtimeMessage({type:'SPX_QUEUE_STOP',reason:'쿠팡 사이드바 전체 즉시 중단',stopAll:true}).catch(()=>null);
        stopRecoveryCountdownMonitorV1518()
        recoveryUiOwner=false;manualIpChangePending=false;activeRunId='';localManualScanActive=false;
        setSidebarCollecting(false);setText('spx-status','수집 대기');setText('spx-auto-text','전체 수집을 중단했습니다.');setProgress(0,'전체 수집 중단 완료');
        return;
      }
      await openSourcingModal();
    } catch (error) {
      setDisplay('spx-auto', 'flex');
      setText('spx-auto-text', error?.message || String(error));
    } finally {
      await refreshSidebarRunButton().catch(() => {});
      if (button) button.disabled = false;
    }
  }

  async function assertRunActive(task, stage = '') {
    if (!taskIsCurrent(task)) throw normalEnd('STALE_TASK', '이전 페이지의 지연 작업을 중단했습니다.');
    const response = await readAutomationState();
    const remote = response?.state;
    if (!remote?.running) {
      cancelAutomationWork(remote?.lastMessage || '자동수집이 중단되었습니다.');
      throw normalEnd('STOPPED', remote?.lastMessage || '자동수집이 중단되었습니다.');
    }
    if (String(remote.runId || '') !== task.runId) {
      throw normalEnd('STALE_RUN', '', {
        silent:true, runId:String(remote.runId||''),
        nextUrl:remote.currentKeyword?`https://www.coupang.com/np/search?q=${encodeURIComponent(remote.currentKeyword)}&page=${Math.max(1,Number(remote.currentPage)||1)}`:null,
      });
    }
    if (state.keyword && remote.currentKeyword && normKeyword(state.keyword) !== normKeyword(remote.currentKeyword)) {
      throw normalEnd('STALE_KEYWORD', '현재 서버 처리 순서로 자동 동기화합니다.', { nextUrl: remote.currentKeyword ? `https://www.coupang.com/np/search?q=${encodeURIComponent(remote.currentKeyword)}&page=${Math.max(1, Number(remote.currentPage) || 1)}` : null, runId: remote.runId });
    }
    return remote;
  }

  function showStaleManualRestartPrompt(message, delaySec=3) {
    cancelAutomationWork('', { updateUi:false });
    ensureUi();
    setDisplay('spx-auto','flex');
    setText('spx-status','단건 수집 중단');
    setText('spx-auto-text','이전 요청을 정리한 뒤 다시 시작할 수 있습니다.');
    const waitSeconds=Math.max(1,Math.round(Number(delaySec)||3));
    setHtml('spx-body', `<div class="spx-empty">${esc(message||'이전 작업 요청이 뒤늦게 도착해 단건 수집을 안전하게 중단했습니다.')}<br><br><button type="button" id="spx-stale-manual-retry" class="spx-btn" disabled>대기 중 ${waitSeconds}초</button><button type="button" id="spx-stale-manual-close" class="spx-btn secondary">닫기</button></div>`);
    const retry=document.getElementById('spx-stale-manual-retry');
    const close=document.getElementById('spx-stale-manual-close');
    const readyAt=Date.now()+waitSeconds*1000;
    const update=()=>{
      if(!retry||!retry.isConnected)return;
      const left=Math.max(0,Math.ceil((readyAt-Date.now())/1000));
      if(left>0){retry.disabled=true;retry.textContent=`대기 중 ${left}초`;setTimeout(update,Math.min(1000,left*1000));return;}
      retry.disabled=false;retry.textContent='다시 수집';
      retry.addEventListener('click',()=>runSelectedAnalysisAction().catch((error)=>{setText('spx-auto-text',error?.message||String(error));}),{once:true});
    };
    close?.addEventListener('click',()=>{setDisplay('spx-auto','none');setHtml('spx-body','');},{once:true});
    update();
  }

  function handleNormalAutomationEnd(resultOrError) {
    const code = resultOrError?.code || 'NORMAL_END';
    const message = resultOrError?.reason || resultOrError?.message || '자동수집이 정상 종료되었습니다.';
    if (['STALE_TASK','STALE_RUN','STALE_KEYWORD','STALE_PAGE','NON_OWNER_TAB'].includes(code)) {
      const nextUrl = resultOrError?.nextUrl || null;
      const runId = String(resultOrError?.runId || activeRunId || '');
      cancelAutomationWork('', { updateUi: false, keepRunId: !!runId });
      if (nextUrl && runId) {
        activeRunId = runId;
        scheduleNavigate(nextUrl, 1, runId, '현재 처리 순서로 자동 동기화');
      } else {
        setDisplay('spx-auto', 'none');
      }
      return;
    }
    setTabAutomationTimer('stop').catch(()=>{});
    cancelAutomationWork(message, { updateUi: true });
    const idleLabel={guided:'단건 대기',full:'연속 대기',local:'로컬DB 대기',refresh:'대기열 대기'}[normalizeSidebarSourcingMode(committedSidebarSourcingMode||sidebarSourcingMode)]||'수집 대기';
    setText('spx-status', code === 'STOPPED' ? idleLabel : '자동 상태 변경');
    setHtml('spx-body', `<div class="spx-empty">${esc(message)}</div>`);
  }

  /* v1.6.41: status meanings are independent of A/B/S product grades.
     Do NOT invent status from an unavailable Naver field or raw grade. */
  function analysisManagementStatusV1632(m={}){
    const raw=String(m.management_state||m.collection_management_state||m.server_management_state||'').normalize('NFKC').trim();
    const code=raw.replace(/\s+/g,'').toLowerCase();
    const aliases={'부족없음':'부족없음','server_complete':'부족없음','갱신대기':'갱신대기','recollect_pending':'갱신대기','보완필요':'보완필요','recollect_needed':'보완필요','신규키워드':'신규키워드','new':'신규키워드','discovered':'신규키워드','기준미달':'기준미달','below_criteria':'기준미달','제외':'제외','excluded':'제외'};
    const resolved=aliases[code];
    const rules=[['부족없음','#4fd1ad'],['갱신대기','#6a9ff5'],['보완필요','#f1a553'],['신규키워드',null],['기준미달','#eed16b'],['제외','#fb8c84']];
    for(const [label,color] of rules){if(resolved===label)return{label,color};}
    return null;
  }
  function gradeColor(g) {
    /* SmartPage Manager/관리표 공통 등급 팔레트: S+ 보라 · S 파랑 · A 청록 · B 브라운 */
    if (g === 'S+') return '#896df0';
    if (g === 'S') return '#5f8fe5';
    if (g === 'A') return '#2ca68a';
    if (g === 'B') return '#bd8240';
    return 'var(--text-3)';
  }

  function row(label, value, pct, color, tip = '') {
    const tipAttr = tip ? ` data-tip="${esc(tip)}" tabindex="0"` : '';
    const safeValue=value==null||/^(?:null|undefined|nan)$/i.test(String(value).trim())?'미확인':value;
    return `<div class="spx-row"${tipAttr}><span class="spx-row-k">${label}</span><div class="spx-gauge"><div class="spx-gfill" style="width:${Math.max(3, Math.min(100, pct || 0))}%;background:${color}"></div></div><span class="spx-row-v">${safeValue}</span></div>`;
  }

  function sidebarWinnerProductIdsV426(m = {}) {
    const seen=new Set(),out=[];
    for(const raw of Array.isArray(m?.winner_products)?m.winner_products:[]){
      const pid=String(raw?.product_id||raw?.pid||raw?.productId||'').replace(/\D/g,'');
      if(pid&&!seen.has(pid)){seen.add(pid);out.push(pid);}
    }
    return out;
  }
  function sidebarWinnerProductIdV426(product = {}) {
    return String(product?.product_id||product?.pid||product?.productId||'').replace(/\D/g,'');
  }
  function sidebarWinnerViewMetricLabelV426(metric = {}, queueState = {}, productId = '') {
    const status=String(metric?.status||metric?.last_attempt_status||'').toLowerCase();
    const raw=metric?.view_count_28d??metric?.view_count;
    const value=(raw===null||raw===undefined||raw==='')?null:Number(raw);
    if(status==='complete'&&Number.isFinite(value)&&value>=0)return`[조회수(28일) ${fmt(Math.round(value))}]`;
    if(status==='not_found')return'[조회수(28일) 검색 결과 없음]';
    const pending=(Array.isArray(queueState?.pending)?queueState.pending:[]).some((item)=>String(item?.product_id||'').replace(/\D/g,'')===productId);
    const active=String(queueState?.active?.product_id||queueState?.active_product_id||'').replace(/\D/g,'')===productId;
    const queueStatus=String(queueState?.status||'').toLowerCase(),paused=String(queueState?.paused_reason||'').toLowerCase();
    if((pending||active)&&(paused==='auth_required'||queueStatus==='auth_required'))return'[조회수(28일) WING 로그인 필요]';
    if((pending||active)&&queueStatus==='cooldown')return'[조회수(28일) 재개 대기]';
    if(pending||active)return'[조회수(28일) 수집 중]';
    if(status==='auth_required')return'[조회수(28일) WING 로그인 필요]';
    if(['timeout','error','rate_limit'].includes(status))return'[조회수(28일) 재수집 대기]';
    return'[조회수(28일) 미확인]';
  }
  async function refreshSidebarWinnerViewMetricsV426() {
    const nodes=[...document.querySelectorAll('#spx-overlay .spx-winner-view-count[data-product-id]')];if(!nodes.length)return 0;
    const saved=await chrome.storage.local.get([SIDEBAR_WING_VIEW_METRIC_KEY,SIDEBAR_WING_VIEW_QUEUE_KEY]).catch(()=>({}));
    const store=saved?.[SIDEBAR_WING_VIEW_METRIC_KEY],byId=store?.byProductId&&typeof store.byProductId==='object'?store.byProductId:{};
    const queue=saved?.[SIDEBAR_WING_VIEW_QUEUE_KEY]&&typeof saved[SIDEBAR_WING_VIEW_QUEUE_KEY]==='object'?saved[SIDEBAR_WING_VIEW_QUEUE_KEY]:{};
    for(const node of nodes){
      const pid=String(node.dataset.productId||'').replace(/\D/g,'');
      const nextLabel=sidebarWinnerViewMetricLabelV426(pid?byId[pid]||{}:{},queue,pid);if(node.textContent!==nextLabel)node.textContent=nextLabel;
    }
    return nodes.length;
  }
  const sidebarWingEnqueueRequestedV103=new Set();
  async function ensureSidebarWinnerViewCollectionV103(){
    const nodes=[...document.querySelectorAll('#spx-overlay .spx-winner-view-count[data-product-id]')];if(!nodes.length)return 0;
    const saved=await chrome.storage.local.get([SIDEBAR_WING_VIEW_METRIC_KEY,SIDEBAR_WING_VIEW_QUEUE_KEY]).catch(()=>({}));
    const store=saved?.[SIDEBAR_WING_VIEW_METRIC_KEY],byId=store?.byProductId&&typeof store.byProductId==='object'?store.byProductId:{};
    const queue=saved?.[SIDEBAR_WING_VIEW_QUEUE_KEY]&&typeof saved[SIDEBAR_WING_VIEW_QUEUE_KEY]==='object'?saved[SIDEBAR_WING_VIEW_QUEUE_KEY]:{};
    const pendingIds=new Set((Array.isArray(queue?.pending)?queue.pending:[]).map((item)=>String(item?.product_id||'').replace(/\D/g,'')).filter(Boolean));
    const activeId=String(queue?.active?.product_id||queue?.active_product_id||'').replace(/\D/g,'');if(activeId)pendingIds.add(activeId);
    const products=new Map((Array.isArray(state.agg?.winner_products)?state.agg.winner_products:[]).map((item)=>[String(item?.product_id||item?.productId||item?.pid||'').replace(/\D/g,''),item]));
    const items=[];
    for(const node of nodes){
      const pid=String(node.dataset.productId||'').replace(/\D/g,'');if(!pid||pendingIds.has(pid)||sidebarWingEnqueueRequestedV103.has(pid))continue;
      const metric=byId[pid]||{},metricStatus=String(metric?.status||metric?.last_attempt_status||'').toLowerCase(),raw=metric?.view_count_28d??metric?.view_count,value=(raw===null||raw===undefined||raw==='')?null:Number(raw);
      if(metricStatus==='complete'&&Number.isFinite(value)&&value>=0)continue;
      const product=products.get(pid)||{};sidebarWingEnqueueRequestedV103.add(pid);
      items.push({...product,product_id:pid,keyword:String(state.agg?.keyword||state.lockedKeyword||state.keyword||currentKeyword()||'').trim(),source:'sidebar-visible-winner'});
    }
    if(!items.length)return 0;
    try{
      const response=await runtimeMessage({type:'SPX_WING_VIEW_ENQUEUE',items,force:false,source:'sidebar-visible-winner',resume:true});
      if(!response?.ok)throw new Error(response?.error||'WING 조회수 대기열 등록 실패');
      return items.length;
    }catch(error){for(const item of items)sidebarWingEnqueueRequestedV103.delete(item.product_id);console.debug('[SPX WING] 효자상품 조회수 대기열 등록 대기',error?.message||error);return 0;}
  }
  let sidebarWingEnsureTimerV103=0;
  function scheduleSidebarWinnerViewMetricsRefreshV426(delayMs=120) {
    if(sidebarWingEnsureTimerV103)clearTimeout(sidebarWingEnsureTimerV103);
    sidebarWingEnsureTimerV103=setTimeout(async()=>{
      sidebarWingEnsureTimerV103=0;
      await refreshSidebarWinnerViewMetricsV426().catch(()=>{});
      if(state.busy)return;
      await ensureSidebarWinnerViewCollectionV103().catch(()=>{});
    },Math.max(0,Number(delayMs)||0));
  }

  const esc = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function deliveryLabel(product = {}) {
    return product.rocket_type || product.delivery_type_raw || (product.is_seller_rocket ? '판매자로켓' : product.is_coupang_rocket ? '쿠팡판매 로켓' : product.is_general_delivery ? '일반배송' : '배송 미확인');
  }

  function isCoupangPlaceholderImageUrlV114(url=''){
    const text=String(url||'').trim().toLowerCase();
    if(!text)return false;
    return /(?:^|[\/_-])no[_-]?img(?:[\/_-]|\.|$)|no[_-]?image|image[_-]?ready|image[_-]?prepar/i.test(text);
  }
  async function activateWinnerImagesV10157(details){
    if(!details||details.open!==true||details.dataset.spxWinnerImagesReady==='1')return false;
    const images=[...details.querySelectorAll('img.spx-winner-thumb[data-spx-winner-src]')];
    const urls=[...new Set(images.map((img)=>String(img.dataset.spxWinnerSrc||'').trim()).filter((url)=>/^https?:\/\//i.test(url)&&!isCoupangPlaceholderImageUrlV114(url)))];
    if(!urls.length){details.dataset.spxWinnerImagesReady='1';return true;}
    try{
      const response=await runtimeMessage({type:'SPX_ALLOW_WINNER_SIDEBAR_IMAGES',urls});
      if(response?.ok!==true)throw new Error(response?.error||'효자상품 이미지 기본망 준비 실패');
      for(const img of images){const url=String(img.dataset.spxWinnerSrc||'').trim();if(url&&!isCoupangPlaceholderImageUrlV114(url)&&!img.getAttribute('src'))img.setAttribute('src',url);}
      details.dataset.spxWinnerImagesReady='1';
      return true;
    }catch(error){console.debug('[SPX] 효자상품 이미지 표시 보류',error?.message||error);return false;}
  }
  function bindWinnerImageActivationV10157(root){
    if(!root||root.dataset.spxWinnerImageBound==='1')return;
    root.dataset.spxWinnerImageBound='1';
    root.addEventListener('toggle',(event)=>{const details=event.target?.closest?.('details.spx-winner-list');if(details?.open)activateWinnerImagesV10157(details).catch(()=>{});},true);
  }

  function winnerProductsHtml(m = {}, {open=false} = {}) {
    const products = Array.isArray(m.winner_products) ? m.winner_products.slice(0, 40) : [];
    if (!products.length) return '';
    const rows = products.map((product, index) => {
      const name = product.name || product.product_name || `효자상품 ${index + 1}`;
      const price = Number(product.price);
      const reviews = Number(product.cumulative_reviews ?? product.reviews);
      const rating = Number(product.rating ?? product.average_rating ?? product.rating_score ?? product.ratingValue ?? product.star_rating ?? product.detailRating ?? product.detail_rating);
      const monthlySales = Number(product.estimated_monthly_sales);
      const monthlyRevenue = Number(product.estimated_monthly_revenue);
      const organicRank = Number(product.organic_rank);
      const meta = [
        Number.isFinite(monthlySales) ? `월판매 ${fmt(monthlySales)}개` : '월판매 미확인',
        Number.isFinite(monthlyRevenue) ? `월매출 ${fmt(Math.round(monthlyRevenue / 10000))}만원` : null,
        Number.isFinite(reviews) ? `리뷰 ${fmt(reviews)}개` : null,
        Number.isFinite(rating) && rating > 0 && rating <= 5 ? `별점 ${Number(rating.toFixed(2))}점` : '별점 미확인',
        Number.isFinite(price) ? `${fmt(price)}원` : null,
        deliveryLabel(product),
        Number.isFinite(organicRank) ? `자연순위 ${fmt(organicRank)}위` : null,
      ].filter(Boolean).join(' · ');
      const imageUrl=String(product.image_url||product.imageUrl||product.representative_image_url||product.thumbnail_url||product.thumbnail||'').trim();
      const thumb=imageUrl?`<img class="spx-winner-thumb" data-spx-winner-src="${esc(imageUrl)}" alt="" loading="lazy" decoding="async">`:'';
      const productId=sidebarWinnerProductIdV426(product);
      const body = `<span class="spx-winner-rank">${index + 1}</span>${thumb}<span class="spx-winner-main"><b>${esc(name)}</b><small>${esc(meta)} · <span class="spx-winner-view-count" data-product-id="${esc(productId)}">[조회수(28일) 미확인]</span></small></span><span class="spx-winner-open">${product.url || product.product_url ? '↗' : ''}</span>`;
      const url = product.url || product.product_url;
      return url
        ? `<a class="spx-winner-item" href="${esc(url)}" target="_blank" rel="noreferrer">${body}</a>`
        : `<div class="spx-winner-item">${body}</div>`;
    }).join('');
    return `<details class="spx-winner-list"${open?' open':''}><summary><span data-tip="효자상품 목록은 상세페이지에서 실제로 확인·저장된 순서(먼저 확인된 상품이 위)로 나열됩니다. 판매량·매출 순위가 아닙니다.">효자상품 ${fmt(products.length)}개<br>펼치기</span><small>상품명 · 월판매 · 월매출 · 리뷰 · 별점 · 판매가 · 배송유형 · 자연순위</small></summary><div class="spx-winner-items">${rows}</div></details>`;
  }

  function sidebarCanonicalScores(m = {}) {
    const pools=[m?.sidebar_metric_values,m?.grade_breakdown?.sidebar_metric_values,m?.external_metrics?.sidebar_metric_values].filter((value)=>value&&typeof value==='object');
    const get=(key)=>{for(const pool of pools){const value=finiteMetric(pool?.[key]);if(value!==null)return value;}return finiteMetric(m?.[key]);};
    return {
      demand_score:get('demand_score'),competition_score:get('competition_score'),profitability_score:get('profitability_score'),
      continuity_score:get('continuity_score'),differentiation_score:get('differentiation_score'),operational_score:get('operational_score'),
    };
  }

  function metricTips(m = {}) {
    const stored=m.sidebar_metric_details||m.grade_breakdown?.sidebar_metric_details||{};
    const scores=sidebarCanonicalScores(m);
    const tip=(key,fallback)=>typeof stored?.[key]?.tooltip==='string'&&stored[key].tooltip.trim()?stored[key].tooltip.trim():fallback;
    const breakdown = m.grade_breakdown || {};
    const marketEvidence = breakdown.market_evidence || {};
    const riskText = [...new Set([...(m.risk_flags || []), ...(m.grade_danger_flags || []), ...(m.grade_block_reasons || [])])].join(' · ') || '강한 위험 신호 없음';
    return {
      grade:`최종 ${m.grade || '-'} · ${m.grade_score ?? '-'}점. 기본 공통 등급식에 시장 실증 보정 ${marketEvidence.points >= 0 ? '+' : ''}${marketEvidence.points ?? 0}점을 반영했습니다. ${marketEvidence.reason || '효자상품 실증지표 미확인'}`,
      demand:tip('demand_score',`시장 수요 ${scores.demand_score ?? '-'}점. 자연노출 상위 ${fmt(m.top20_organic_count||0)}개 리뷰 중앙값 ${fmt(m.top20_review_med ?? m.top10_review_med ?? 0)}개, 전체 리뷰 중앙값 ${fmt(m.review_median ?? 0)}개, 표본 ${fmt(m.sample_size || m.product_count || 0)}개를 반영한 쿠팡 대체 수요지표입니다.`),
      competition:tip('competition_score',`경쟁 진입성 ${scores.competition_score ?? '-'}점. 리뷰 600개 이하 자연노출 ${fmt(m.top20_low_review_count || 0)}개, 일반 판매자 ${fmt(m.general_seller_ratio || 0)}%, 광고 ${fmt(m.ad_ratio || 0)}%, 쿠팡로켓 ${fmt(m.top20_coupang_rocket_ratio || 0)}%, 브랜드 집중 ${fmt(m.brand_concentration || 0)}%를 반영합니다.`),
      profitability:tip('profitability_score',`예상 수익성 ${scores.profitability_score ?? '-'}점. 판매가 중앙값 ${fmt(m.price_median || 0)}원, 하위25% ${fmt(m.price_p25 || 0)}원, 상위25% ${fmt(m.price_p75 || 0)}원 기준입니다. 실제 원가·수수료·광고비는 별도입니다.`),
      continuity:tip('continuity_score',`수요 지속성 ${scores.continuity_score ?? '-'}점. 과거 수집 이력 ${fmt(m.history_count || 0)}회와 현재 수요 변화로 ${m.trend_status || '추세 미확인'}을 판단했습니다. 첫 수집의 이력 부족은 등급을 막지 않습니다.`),
      differentiation:tip('differentiation_score',`차별화 가능성 ${scores.differentiation_score ?? '-'}점. 상위 상품명 구성의 다양성, 저리뷰 자연노출, 가격대 폭, 키워드의 세부 속성을 반영합니다.`),
      operational:tip('operational_score',`운영 안정성 ${scores.operational_score ?? '-'}점. 키워드 의도·계절성·브랜드·배송 위험을 반영합니다. 현재 확인사항: ${riskText}.`),
      organic:tip('top20_organic_count',`광고를 제외한 자연노출 상위 상품 ${fmt(m.top20_organic_count || 0)}개를 핵심 경쟁 표본으로 사용했습니다.`),
      delivery:tip('_delivery_summary',`자연노출 상위 ${fmt(m.delivery_sample_count||m.top20_organic_count||0)}개 배송구성: 쿠팡로켓 ${fmt(m.coupang_rocket_ratio ?? m.top20_coupang_rocket_ratio ?? 0)}%, 판매자로켓 ${fmt(m.seller_rocket_ratio ?? m.top20_seller_rocket_ratio ?? 0)}%, 로켓직구 ${fmt(m.rocket_global_ratio ?? m.top20_rocket_global_ratio ?? 0)}%, 로켓설치 ${fmt(m.rocket_install_ratio ?? m.top20_rocket_install_ratio ?? 0)}%, 일반배송 ${fmt(m.general_delivery_ratio ?? m.top20_general_delivery_ratio ?? 0)}%, 미확인 ${fmt(m.delivery_unknown_ratio ?? m.top20_delivery_unknown_ratio ?? 0)}%.`),
      general:tip('general_seller_ratio',`판매자로켓과 일반배송을 합친 일반 판매자 비율 ${fmt(m.general_seller_ratio || 0)}%입니다. 높을수록 쿠팡 직매입 전용시장이 아닐 가능성이 큽니다.`),
      winner:tip('winner_breadth_grade',`월판매 200개 이상 효자상품 ${fmt(m.winner_count || 0)}개, 500개 이상 ${fmt(m.strong_winner_count || 0)}개, 1,000개 이상 ${fmt(m.mega_winner_count || 0)}개입니다. 이 효자 확산은 v1.7.3부터 최종 등급의 시장 실증 보정에 반영됩니다.`),
      top1:tip('winner_top1_share',`효자상품 전체 월판매 중 1위 상품 점유율 ${m.winner_top1_share == null ? '미확인' : `${m.winner_top1_share}%`}입니다. 25% 이하는 시장이 한 상품에 몰리지 않은 분산 신호로 가점됩니다.`),
      lowWinner:tip('low_review_winner_count',`누적 리뷰가 낮은 효자상품 ${fmt(m.low_review_winner_count || 0)}개입니다. 신규 판매자가 따라갈 수 있는 상위노출 사례를 보여줍니다.`),
      lowReview:tip('top20_low_review_count',`자연노출 상위 ${fmt(m.top20_organic_count||0)}개 중 리뷰 600개 이하 ${fmt(m.top20_low_review_count || 0)}개입니다. 12개 이상이면 시장 실증 보정에 추가 가점됩니다.`),
      price:tip('source_price_median',`판매가 중앙값 ${fmt(m.price_median || 0)}원입니다. 중앙값은 극단적인 고가·저가 상품의 영향을 줄인 대표 판매가격입니다.`),
    };
  }

  function finiteMetric(...values) {
    for (const value of values) {
      if (value === null || value === undefined || value === '') continue;
      const n = Number(value); if (Number.isFinite(n)) return n;
    }
    return null;
  }
  function analysisBusinessMetrics(m = {}) {
    const winners = Array.isArray(m.winner_products) ? m.winner_products : Array.isArray(m.sample_products) ? m.sample_products.filter((row)=>row?.is_winner) : [];
    /* "총 판매량/총매출"은 전체 수집상품 합계 필드만 표시합니다. 효자상품 합계나
       대표상품 값으로 대신 표시하면 관리표의 같은 제목과 범위가 달라지므로 섞지 않습니다. */
    const totalSales = finiteMetric(m.source_total_monthly_sales);
    const totalRevenue = finiteMetric(m.source_total_monthly_revenue);
    const ratings = winners.map((r)=>finiteMetric(r.rating,r.average_rating,r.rating_score,r.detailRating)).filter((n)=>n!=null&&n>0);
    const searchVolume = finiteMetric(m.monthly_search_volume,(finiteMetric(m.monthly_search_pc)||0)+(finiteMetric(m.monthly_search_mobile)||0));
    const registeredCompetition = finiteMetric(m.competition_product_count);
    const pc=finiteMetric(m.monthly_search_pc)||0,mobile=finiteMetric(m.monthly_search_mobile)||0;
    const pcCtr=finiteMetric(m.naver_pc_ctr),mobileCtr=finiteMetric(m.naver_mobile_ctr);
    const ctrWeight=(pcCtr!=null?pc:0)+(mobileCtr!=null?mobile:0);
    const ctrValues=[pcCtr,mobileCtr].filter((value)=>value!=null);
    const naverCtr=finiteMetric(m.naver_ctr,ctrWeight>0?((pcCtr||0)*pc+(mobileCtr||0)*mobile)/ctrWeight:ctrValues.length?ctrValues.reduce((sum,value)=>sum+value,0)/ctrValues.length:null);
    return {
      totalSales,
      totalRevenue,
      netProfit:totalRevenue!=null?Math.round(totalRevenue*0.20):null,
      rating:ratings.length?ratings.reduce((a,b)=>a+b,0)/ratings.length:finiteMetric(m.winner_rating_average,m.average_rating),
      competition:searchVolume!=null&&searchVolume>0&&registeredCompetition!=null?registeredCompetition/searchVolume:null,
      naverCtr,registeredCompetition,searchVolume,
    };
  }
  function metricValue(value, suffix='', digits=0, pending='확인 안 됨') {
    return value == null || !Number.isFinite(Number(value)) ? pending : `${Number(value).toLocaleString('ko-KR',{maximumFractionDigits:digits,minimumFractionDigits:digits})}${suffix}`;
  }
  function formatKoreanWonCompact(value,pending='확인 안 됨'){const n=Number(value);if(!Number.isFinite(n))return pending;const sign=n<0?'-':'',abs=Math.abs(n);let eok=Math.floor(abs/100000000),man=Math.round((abs-eok*100000000)/10000);if(man>=10000){eok+=1;man-=10000;}if(eok>0)return `${sign}${eok.toLocaleString('ko-KR')}억${man>0?` ${man.toLocaleString('ko-KR')}만원`:''}`;return `${sign}${Math.round(abs/10000).toLocaleString('ko-KR')}만원`; }
  function sidebarCategoryInfo(m={},pending='확인 안 됨') {
    const clean=(value)=>String(value||'').trim().replace(/^(?:쿠팡\s*홈|쿠팡수입|쿠팡)\s*(?:>|›|\/|·|-)+\s*/i,'').trim();
    const path=clean(m.category_path||m.categoryPath||'');
    const leaf=clean(m.category||'')||((path.split(/\s*>\s*/).filter(Boolean).pop())||'');
    const levels=path.split(/\s*>\s*/).map((v)=>v.trim()).filter(Boolean);
    if(path&&levels.length>=2)return{label:`✓ ${leaf||levels[levels.length-1]}`,tooltip:`전체 카테고리 경로: ${path}`,complete:true};
    if(leaf||path)return{label:`${leaf||path} · 경로 일부`,tooltip:`현재 확보된 카테고리: ${path||leaf} · 전체 breadcrumb는 후속 수집 시 보강됩니다.`,partial:true};
    return{label:pending,tooltip:'카테고리 경로가 아직 확인되지 않았습니다. 카테고리 미확인만으로 기본 서버 업로드를 지연시키지는 않습니다.'};
  }

  function renderIdle() {
    if (!ensureUi()) return;
    if(!state.keyword&&isCoupangSearchLandingV103()){
      setText('spx-status','검색어 입력 대기');
      setDisplay('spx-auto','flex');
      setText('spx-auto-text','쿠팡 검색창에 검색어를 입력하면 같은 사이드바에서 바로 수집을 시작할 수 있습니다.');
      setHtml('spx-body', `<div class="spx-empty">
        <b>쿠팡 수집 준비 완료</b><br><br>
        검색어가 없어도 수집 사이드바를 유지합니다.<br>
        위 쿠팡 검색창에서 상품 키워드를 검색하세요.<br><br>
        검색 결과가 열리면 상품 감지 · 효자상품 분석 · WING 조회수(최근 28일) 수집 대기열이 이어집니다.
      </div>`);
      return;
    }
    setHtml('spx-body', `<div class="spx-empty">
      현재 검색결과에서 상품 <b>${state.detected}개</b>를 찾았습니다.<br><br>
      분석하면 단순 인기점수가 아니라<br><b>수요 · 경쟁 · 수익 · 지속성 · 차별화 · 운영위험</b>을 계산합니다.<br><br>
      상품명과 관련검색어에서 발견한 세부 상품형 키워드는 자동수집 대기열에 추가됩니다.
    </div>`);
  }

  function renderAgg(m, candidates = []) {
    m=m;
    if (!m || !ensureUi()) return;
    if(canonicalVisibleKeyword(m.keyword)===canonicalVisibleKeyword(state.lockedKeyword||state.keyword||currentKeyword()))state.agg=m;
    const tags = (m.tags || []).map((t) => `<span class="spx-tag">${esc(t)}</span>`).join('');
    const highs = (m.highlights || []).map((t) => `<div class="spx-highlight">${esc(t)}</div>`).join('');
    const risks = [...new Set([...(m.risk_flags || []), ...(m.grade_danger_flags || []), ...(m.grade_block_reasons || [])])].map((t) => `<span class="spx-risk">${esc(t)}</span>`).join('');
    const cands = candidates.slice(0, 6).map((c) => `<div class="spx-candidate"><b>${esc(c.keyword)}</b><span>${c.discovery_score}점 · ${esc(c.source)}</span></div>`).join('');
    const naming = (m.naming_phrases || []).slice(0, 6).map((row) => `<span class="spx-tag">${esc(row?.phrase || row)}</span>`).join('');
    const externalNote = m.sellerlife_detected
      ? `<div class="spx-highlight">외부 시장분석 감지 · 검색량 ${fmt(m.sellerlife_monthly_search_volume)} · 상품수 ${fmt(m.sellerlife_product_count)} · 평균가 ${fmt(m.sellerlife_average_price)}원</div>` : '';
    const winnerGrade = m.winner_breadth_grade || '-';
    const winnerConfidenceNote = Number(m.winner_provisional_count || 0) > 0
      ? `추정 ${fmt(m.winner_provisional_count)}개 · 재수집 후 실측 입력`
      : (Number(m.winner_confirmed_count || 0) > 0 ? `실측 ${fmt(m.winner_confirmed_count)}개` : '판매이력 미확인');
    const winnerSummary = `<div class="spx-highlight"><b>효자확산 ${esc(winnerGrade)}</b> · 일반판매자 효자 200개↑ ${fmt(m.winner_count || 0)}개 · 500개↑ ${fmt(m.strong_winner_count || 0)}개 · 1,000개↑ ${fmt(m.mega_winner_count || 0)}개<br><span style="opacity:.75">일반 판매자 효자 ${fmt(m.winner_general_seller_count || 0)}개 (${fmt(m.winner_general_seller_ratio || 0)}%) · 판매자로켓 ${fmt(m.winner_seller_rocket_count || 0)}개 · 쿠팡판매 로켓 ${fmt(m.winner_coupang_rocket_count || 0)}개<br>${esc(winnerConfidenceNote)} · 키워드 순도 ${esc(m.keyword_purity_status || '미확인')} ${m.keyword_purity_score == null ? '' : `(${m.keyword_purity_score}%)`}</span></div>`;
    const tips = metricTips(m);
    const canonicalScores=sidebarCanonicalScores(m);
    const business = analysisBusinessMetrics(m);
    const categoryInfo=sidebarCategoryInfo(m);
    const winnerWasOpenV10157=Boolean(getUiElement('spx-body',{repair:false})?.querySelector?.('.spx-winner-list[open]'));
    const winnerList = winnerProductsHtml(m,{open:winnerWasOpenV10157});
    const safeDisplayGradeV1630=(m.grade==null||/^(?:null|undefined|nan)?$/i.test(String(m.grade).trim()))?'미확인':String(m.grade).trim();
    const managementStatusV1632=analysisManagementStatusV1632(m);
    setHtml('spx-body', `
      <div class="spx-hero" data-tip="${esc(tips.grade)}" tabindex="0">
        <div class="spx-grade" style="color:${gradeColor(safeDisplayGradeV1630)}">${esc(safeDisplayGradeV1630)}</div>
        <div class="spx-score">${esc(safeDisplayGradeV1630)} · ${m.grade_score ?? '-'}점 · 신뢰도 ${m.grade_confidence ?? '-'}% · ${esc(m.trend_status || '추세 미확인')}</div>
        <div class="spx-kw">${esc(m.keyword)}</div>
        ${managementStatusV1632?`<div class="spx-verdict" style="font-weight:700;${managementStatusV1632.color?`color:${managementStatusV1632.color}`:''}">● ${esc(managementStatusV1632.label)}</div>`:''}
        <div class="spx-verdict">카테고리 ${esc(m.category_path || m.category || '미확인')} · ${esc(m.category_status || '미확인')} · 실측 ${m.category_verified_count ?? 0}개</div>
        <div class="spx-verdict">수요 ${esc(m.demand_level||'미확인')} · ${esc(m.competition_level||'미확인')} · ${esc(m.trend_status||'이력 미확인')}</div>
        <div class="spx-tags">${tags}</div>
      </div>
      ${row('시장 수요', `${canonicalScores.demand_score ?? '-'}점`, Number(canonicalScores.demand_score || 0), gradeColor(m.grade), tips.demand)}
      ${row('경쟁 진입성', `${canonicalScores.competition_score ?? '-'}점`, Number(canonicalScores.competition_score || 0), gradeColor(m.grade), tips.competition)}
      ${row('예상 수익성', `${canonicalScores.profitability_score ?? '-'}점`, Number(canonicalScores.profitability_score || 0), gradeColor(m.grade), tips.profitability)}
      ${row('수요 지속성', `${canonicalScores.continuity_score ?? '-'}점`, Number(canonicalScores.continuity_score || 0), gradeColor(m.grade), tips.continuity)}
      ${row('차별화 가능성', `${canonicalScores.differentiation_score ?? '-'}점`, Number(canonicalScores.differentiation_score || 0), gradeColor(m.grade), tips.differentiation)}
      ${row('운영 안정성', `${canonicalScores.operational_score ?? '-'}점`, Number(canonicalScores.operational_score || 0), gradeColor(m.grade), tips.operational)}
      ${row('카테고리', categoryInfo.label, categoryInfo.complete?100:(categoryInfo.partial?45:0), 'var(--text-3)', categoryInfo.tooltip)}
      ${row('전체 예상순익', formatKoreanWonCompact(business.netProfit), business.netProfit == null ? 0 : Math.min(100,business.netProfit/100000), 'var(--text-3)', '수집된 전체 상품 총매출의 20%를 단순 순수익 참고값으로 표시합니다. 별도 수집값이 아니며 실제 원가·수수료·광고비에 따라 달라집니다.')}
      ${row('총 판매량', metricValue(business.totalSales,'개'), business.totalSales == null ? 0 : Math.min(100,business.totalSales/20), 'var(--text-3)', '광고·품절을 제외한 수집상품 중 최근 28일 판매 추정 또는 실측 수량 합계입니다.')}
      ${row('총매출', formatKoreanWonCompact(business.totalRevenue), business.totalRevenue == null ? 0 : Math.min(100,business.totalRevenue/10000000), 'var(--text-3)', '광고·품절을 제외한 수집상품의 판매가×최근 28일 판매 수량 합계입니다.')}
      ${row('평균 별점', metricValue(business.rating,'점',2), business.rating == null ? 0 : Math.min(100,business.rating/5*100), 'var(--text-3)', '효자상품 상세에서 확인된 별점의 평균입니다.')}

      ${row('자연노출 표본', `${m.top20_organic_count}개`, Math.min(100, m.top20_organic_count * 5), 'var(--text-3)', tips.organic)}
      ${row('배송유형', `쿠팡판매 ${fmt(m.top20_coupang_rocket_ratio || 0)}% · 판매자로켓 ${fmt(m.top20_seller_rocket_ratio || 0)}% · 일반배송 ${fmt(m.top20_general_delivery_ratio || 0)}%`, 100 - Number(m.top20_coupang_rocket_ratio || 0), 'var(--text-3)', tips.delivery)}
      ${row('일반 판매자 비율', `${fmt(m.general_seller_ratio || 0)}%`, Number(m.general_seller_ratio || 0), gradeColor(m.grade), tips.general)}
      ${row('효자상품 확산', `${winnerGrade} · ${fmt(m.winner_count || 0)}개`, Math.min(100, Number(m.winner_count || 0) * 12.5), gradeColor(winnerGrade), tips.winner)}
      ${row('효자 Top1 점유', m.winner_top1_share == null ? '미확인' : `${m.winner_top1_share}%`, Number(m.winner_top1_share || 0), 'var(--text-3)', tips.top1)}
      ${row('저리뷰 효자', `${fmt(m.low_review_winner_count || 0)}개`, Math.min(100, Number(m.low_review_winner_count || 0) * 20), 'var(--text-3)', tips.lowWinner)}
      ${row('리뷰 600개↓', `${m.top20_low_review_count}개`, m.top20_low_review_ratio, 'var(--text-3)', tips.lowReview)}
      ${row('판매가 중앙값', `${fmt(m.price_median)}원`, Math.min(100, (m.price_median / 50000) * 100), 'var(--text-3)', tips.price)}
      <div class="spx-highlight-wrap">${winnerSummary}${highs}</div>
      ${winnerList}
      ${risks ? `<div class="spx-risk-wrap"><b>확인 필요</b>${risks}</div>` : ''}
      ${cands ? `<div class="spx-candidate-wrap"><div class="spx-section-title">쿠팡 연관검색어 및 원문 후보</div>${cands}</div>` : ''}
      ${naming ? `<div class="spx-candidate-wrap"><div class="spx-section-title">SmartPage 상품명 작성용 상위 반복 구문</div><div class="spx-tags">${naming}</div></div>` : ''}
      ${externalNote}
      <div class="spx-note">
        <b>수요점수는 절대 검색량이 아닙니다.</b> 쿠팡 리뷰·자연노출·표본 규모를 이용한 대체지표입니다.<br>
        7일·28일 이력은 등급을 막거나 감점하지 않으며 리뷰 증가·자연노출 변화·추세와 신뢰도 분석에만 사용됩니다.
      </div>`);
    scheduleSidebarWinnerViewMetricsRefreshV426();
  }

  /* [v2.2.4] 수집이 끝날 때까지 빈 화면·진행문구만 보여주지 않고, 현재 최종 결과 카드와 같은
     순서로 잠정 지표를 먼저 그린다. 상품 카드 파싱 → 상세 확인 → 과거 이력 → 최종 저장 순서로
     같은 카드의 숫자와 등급이 갱신되므로 단건·연속 수집 모두 중간 결과를 바로 확인할 수 있다. */
  let progressiveState = { keyword:'', phase:0, stage:'', aggregate:null, productCount:0 };

  function beginProgressiveView(keyword, stage = '수집 준비 중') {
    progressiveState = { keyword:String(keyword || state.keyword || ''), phase:0, stage, aggregate:null, productCount:0 };
    clearLiveLog();
    if (!ensureUi()) return;
    setHtml('spx-body', `
      <div class="spx-progressive-stage"><b>현재 수집 중</b><span>${esc(stage)}</span></div>
      <div class="spx-hero spx-progressive-hero">
        <div class="spx-grade" style="color:var(--text-3)">…</div>
        <div class="spx-score">상품 정보를 읽는 순서대로 이 화면에 반영합니다.</div>
        <div class="spx-kw">${esc(progressiveState.keyword || '키워드 확인 중')}</div>
        <div class="spx-verdict">등급·시장지표 계산 대기</div>
      </div>
      <div class="spx-progressive-wait"><span></span>${esc(stage)}</div>`);
  }

  function buildProgressiveAggregate(keyword, products, settings = {}, context = {}) {
    const items = Array.isArray(products) ? products : [];
    if (!items.length) return null;
    try {
      const m = SPX.aggregate(keyword, items, 'coupang', settings.minSample || 8, {
        history:Array.isArray(context.history) ? context.history : [],
        resultTotal:context.resultTotal ?? null,
        organicSampleSize:settings.organicSampleSize || 50,
        categoryId:context.searchCategory?.categoryId || null,
        categoryPath:context.searchCategory?.categoryPath || null,
        categorySource:context.searchCategory?.source || null,
        relatedTerms:context.relatedTerms || [],
        externalMetrics:context.externalMetrics || null,
        monthlyRevenue:context.externalMetrics?.estimated_monthly_revenue ?? null,
      });
      if (!m) return null;
      const snapshots = SPX.buildProductSnapshots?.(items, [], {
        analysisDate:SPX.util.today(),
        maxProducts:settings.sourceDataMaxProducts || 200,
        resultTotal:context.resultTotal ?? null,
        sourceKeyword:keyword,
        winnerThreshold:SPX.WINNER_MONTHLY_SALES_THRESHOLD || 200,
      }) || [];
      const winnerMetrics = SPX.computeWinnerMetrics?.(snapshots, {
        targetOrganic:settings.sourceDataTargetOrganic || 60,
        maxProducts:settings.sourceDataMaxProducts || 200,
        resultTotal:context.resultTotal ?? null,
        sourceKeyword:keyword,
        winnerThreshold:SPX.WINNER_MONTHLY_SALES_THRESHOLD || 200,
      }) || {};
      Object.assign(m, winnerMetrics);
      m.pagesCollected=Math.max(1,Number(context.pagesCollected||context.page||currentSearchPageNumber?.()||1)||1);
      SPX.recalculateSmartPageGrade?.(m);
      delete m.pagesCollected;
      return m;
    } catch (error) {
      console.warn('[SPX] 수집 중 잠정 지표 계산 생략', error);
      return null;
    }
  }

  function renderProgressiveAggregate(m, options = {}) {
    m=m;
    if (!m || !ensureUi()) return false;
    if(canonicalVisibleKeyword(m.keyword)===canonicalVisibleKeyword(state.lockedKeyword||state.keyword||currentKeyword()))state.agg=m;
    const phase = Math.max(1, Number(options.phase) || 1);
    const stage = String(options.stage || '수집 정보 반영 중');
    const productCount = Math.max(0, Number(options.productCount ?? m.sample_size ?? m.product_count) || 0);
    const pageText = options.page ? ` · ${fmt(options.page)}페이지` : '';
    const statusLabel = options.finalizing ? '등급 확정' : '잠정 분석';
    const tips = metricTips(m);
    const canonicalScores=sidebarCanonicalScores(m);
    const business = analysisBusinessMetrics(m);
    const categoryInfo=sidebarCategoryInfo(m,phase<2?'확인 중…':'확인 안 됨');
    const winnerGrade = m.winner_breadth_grade || '-';
    const winnerWasOpenV10157=Boolean(getUiElement('spx-body',{repair:false})?.querySelector?.('.spx-winner-list[open]'));
    const progressiveWinnerList=winnerProductsHtml(m,{open:winnerWasOpenV10157});
    progressiveState = { keyword:m.keyword || state.keyword, phase, stage, aggregate:m, productCount };
    setHtml('spx-body', `
      <div class="spx-progressive-stage"><b>${esc(statusLabel)}</b><span>${esc(stage)}${pageText}</span></div>
      <div class="spx-hero spx-progressive-hero" data-tip="${esc(tips.grade)}" tabindex="0">
        <div class="spx-grade" style="color:${gradeColor(m.grade)}">${esc(m.grade || '…')}</div>
        <div class="spx-score">${esc(statusLabel)} ${esc(m.grade || '-')} · ${m.grade_score ?? '-'}점 · 상품 ${fmt(productCount)}개 반영</div>
        <div class="spx-kw">${esc(m.keyword || state.keyword)}</div>
        <div class="spx-verdict">${esc(stage)}</div>
        <div class="spx-verdict">수요 ${esc(m.demand_level || '계산 중')} · ${esc(m.competition_level || '경쟁 계산 중')} · ${esc(m.trend_status || '이력 확인 전')}</div>
      </div>
      ${row('시장 수요', `${canonicalScores.demand_score ?? '-'}점`, Number(canonicalScores.demand_score || 0), gradeColor(m.grade), tips.demand)}
      ${row('경쟁 진입성', `${canonicalScores.competition_score ?? '-'}점`, Number(canonicalScores.competition_score || 0), gradeColor(m.grade), tips.competition)}
      ${row('예상 수익성', `${canonicalScores.profitability_score ?? '-'}점`, Number(canonicalScores.profitability_score || 0), gradeColor(m.grade), tips.profitability)}
      ${row('수요 지속성', `${canonicalScores.continuity_score ?? '-'}점`, Number(canonicalScores.continuity_score || 0), gradeColor(m.grade), tips.continuity)}
      ${row('차별화 가능성', `${canonicalScores.differentiation_score ?? '-'}점`, Number(canonicalScores.differentiation_score || 0), gradeColor(m.grade), tips.differentiation)}
      ${row('운영 안정성', `${canonicalScores.operational_score ?? '-'}점`, Number(canonicalScores.operational_score || 0), gradeColor(m.grade), tips.operational)}
      ${row('카테고리', categoryInfo.label, categoryInfo.complete?100:(categoryInfo.partial?45:0), 'var(--text-3)', categoryInfo.tooltip)}
      ${row('전체 예상순익', formatKoreanWonCompact(business.netProfit,phase<2?'계산 중':'미확인'), business.netProfit == null ? 0 : Math.min(100,business.netProfit/100000), 'var(--text-3)', '수집된 전체 상품 총매출의 20% 참고값입니다. 별도 수집 없이 총매출에서 계산됩니다.')}
      ${row('총 판매량', metricValue(business.totalSales,'개',0,phase<2?'계산 중':'미확인'), business.totalSales == null ? 0 : Math.min(100,business.totalSales/20), 'var(--text-3)', '광고·품절을 제외한 수집상품의 최근 28일 판매 수량 합계입니다.')}
      ${row('총매출', formatKoreanWonCompact(business.totalRevenue,phase<2?'계산 중':'미확인'), business.totalRevenue == null ? 0 : Math.min(100,business.totalRevenue/10000000), 'var(--text-3)', '광고·품절을 제외한 수집상품의 판매가×최근 28일 판매 수량 합계입니다.')}
      ${row('평균 별점', metricValue(business.rating,'점',2,phase<2?'상세 확인 중':'미확인'), business.rating == null ? 0 : Math.min(100,business.rating/5*100), 'var(--text-3)', '상세 확인이 끝난 효자상품의 평균 별점입니다.')}

      ${row('자연노출 표본', `${fmt(m.top20_organic_count || 0)}개`, Math.min(100, Number(m.top20_organic_count || 0) * 5), 'var(--text-3)', tips.organic)}
      ${row('배송유형', `쿠팡판매 ${fmt(m.top20_coupang_rocket_ratio || 0)}% · 판매자로켓 ${fmt(m.top20_seller_rocket_ratio || 0)}% · 일반배송 ${fmt(m.top20_general_delivery_ratio || 0)}%`, 100 - Number(m.top20_coupang_rocket_ratio || 0), 'var(--text-3)', tips.delivery)}
      ${row('일반 판매자 비율', `${fmt(m.general_seller_ratio || 0)}%`, Number(m.general_seller_ratio || 0), gradeColor(m.grade), tips.general)}
      ${row('효자상품 확산', `${esc(winnerGrade)} · ${fmt(m.winner_count || 0)}개${phase < 2 ? ' · 상세 확인 중' : ''}`, Math.min(100, Number(m.winner_count || 0) * 12.5), gradeColor(winnerGrade), tips.winner)}
      ${row('효자 Top1 점유', m.winner_top1_share == null ? (phase < 2 ? '상세 확인 중' : '미확인') : `${m.winner_top1_share}%`, Number(m.winner_top1_share || 0), 'var(--text-3)', tips.top1)}
      ${row('저리뷰 효자', `${fmt(m.low_review_winner_count || 0)}개${phase < 2 ? ' · 잠정' : ''}`, Math.min(100, Number(m.low_review_winner_count || 0) * 20), 'var(--text-3)', tips.lowWinner)}
      ${row('리뷰 600개↓', `${fmt(m.top20_low_review_count || 0)}개`, Number(m.top20_low_review_ratio || 0), 'var(--text-3)', tips.lowReview)}
      ${row('판매가 중앙값', `${fmt(m.price_median || 0)}원`, Math.min(100, (Number(m.price_median || 0) / 50000) * 100), 'var(--text-3)', tips.price)}
      ${progressiveWinnerList}
      <div class="spx-progressive-foot"><span class="spx-progressive-pulse"></span>${esc(stage)} · 완료된 값부터 같은 자리에서 계속 갱신됩니다.</div>`);
    scheduleSidebarWinnerViewMetricsRefreshV426();
    return true;
  }

  function updateProgressiveFromProducts(keyword, products, settings, context = {}, options = {}) {
    const m = buildProgressiveAggregate(keyword, products, settings, context);
    if (!m) return false;
    return renderProgressiveAggregate(m, { ...options, productCount:Array.isArray(products) ? products.length : 0 });
  }

  let liveLogEntries = [];
  function clampStatusLogHeight(value){
    const viewportMax=Math.max(120,Math.floor((globalThis.innerHeight||800)*0.52));
    return Math.max(SPX_STATUS_LOG_MIN_HEIGHT,Math.min(viewportMax,Math.round(Number(value)||SPX_STATUS_LOG_DEFAULT_HEIGHT)));
  }
  function applyStatusLogHeight(value,{persist=false}={}){
    statusLogHeight=clampStatusLogHeight(value);
    const log=getUiElement('spx-live-log',{repair:false});
    if(log)log.style.height=`${statusLogHeight}px`;
    if(persist){
      clearTimeout(statusLogHeightSaveTimer);
      statusLogHeightSaveTimer=setTimeout(()=>chrome.storage.local.set({[SPX_STATUS_LOG_HEIGHT_KEY]:statusLogHeight}).catch(()=>{}),180);
    }
    return statusLogHeight;
  }
  async function restoreStatusLogHeight(){
    try{
      const stored=await chrome.storage.local.get(SPX_STATUS_LOG_HEIGHT_KEY);
      applyStatusLogHeight(stored?.[SPX_STATUS_LOG_HEIGHT_KEY]||SPX_STATUS_LOG_DEFAULT_HEIGHT);
    }catch(_){applyStatusLogHeight(SPX_STATUS_LOG_DEFAULT_HEIGHT);}
  }
  function bindStatusLogResizer(root){
    const handle=root?.querySelector?.('#spx-log-resize-handle');
    const log=root?.querySelector?.('#spx-live-log');
    if(!handle||!log||handle.dataset.bound==='1')return;
    handle.dataset.bound='1';
    applyStatusLogHeight(statusLogHeight);
    let startY=0,startHeight=0,pointerId=null;
    const stop=(event)=>{
      if(pointerId===null)return;
      try{handle.releasePointerCapture(pointerId);}catch(_){ }
      pointerId=null;handle.classList.remove('dragging');
      applyStatusLogHeight(log.getBoundingClientRect().height,{persist:true});
      event?.preventDefault?.();
    };
    handle.addEventListener('pointerdown',(event)=>{
      if(event.button!==0)return;
      pointerId=event.pointerId;startY=event.clientY;startHeight=log.getBoundingClientRect().height||statusLogHeight;
      handle.classList.add('dragging');
      try{handle.setPointerCapture(pointerId);}catch(_){ }
      event.preventDefault();
    });
    handle.addEventListener('pointermove',(event)=>{
      if(pointerId===null||event.pointerId!==pointerId)return;
      applyStatusLogHeight(startHeight+(event.clientY-startY));
      event.preventDefault();
    });
    handle.addEventListener('pointerup',stop);
    handle.addEventListener('pointercancel',stop);
    handle.addEventListener('keydown',(event)=>{
      if(!['ArrowUp','ArrowDown','Home','End'].includes(event.key))return;
      const delta=event.key==='ArrowUp'?-20:event.key==='ArrowDown'?20:event.key==='Home'?-9999:9999;
      applyStatusLogHeight(statusLogHeight+delta,{persist:true});
      event.preventDefault();
    });
    restoreStatusLogHeight().catch(()=>{});
  }
  function clearLiveLog() { liveLogEntries = []; const el = getUiElement('spx-live-log', { repair:false }); if (el) el.replaceChildren(); }
  function appendLiveLog(text) {
    const el = getUiElement('spx-live-log', { repair:false });
    if (!el || !text) return;
    const family = String(text).replace(/[\d,]+/g, '#');
    const last = liveLogEntries[liveLogEntries.length - 1];
    el.querySelector('.spx-live-log-row.latest')?.classList.remove('latest');
    if (last && last.family === family && el.lastElementChild) {
      last.text = text;el.lastElementChild.textContent=text;el.lastElementChild.classList.add('latest');
    } else {
      liveLogEntries.push({ family, text });
      const row=document.createElement('div');row.className='spx-live-log-row latest';row.textContent=text;el.appendChild(row);
      if (liveLogEntries.length > 12) {liveLogEntries.shift();el.firstElementChild?.remove();}
    }
    el.scrollTop = el.scrollHeight;
  }
  let progressPaintTimer=null,progressPaintAt=0,pendingProgress=null;
  function paintProgress(){
    progressPaintTimer=null;
    const payload=pendingProgress;pendingProgress=null;if(!payload)return false;
    ensureUi();
    const shown=setDisplay('spx-prog','block');
    const filled=setStyle('spx-pfill','width',`${Math.max(0,Math.min(100,Number(payload.pct)||0))}%`);
    const labeled=setText('spx-ptxt',payload.text);
    if(payload.time!=null)setText('spx-ptime',payload.time);
    appendLiveLog(payload.text);progressPaintAt=performance.now();
    if(!shown||!filled||!labeled)queueUiRepair();
    return Boolean(shown&&filled&&labeled);
  }
  function setProgress(pct, text, time) {
    if(activeStage)activeStage.lastActivityAt=Date.now();
    pendingProgress={pct,text,time};
    const final=Number(pct)>=100,elapsed=performance.now()-progressPaintAt;
    if(final||elapsed>=48){if(progressPaintTimer){clearTimeout(progressPaintTimer);progressPaintTimer=null;}return paintProgress();}
    if(!progressPaintTimer)progressPaintTimer=setTimeout(()=>requestAnimationFrame(paintProgress),Math.max(8,48-elapsed));
    return true;
  }

  function bindSidebarDialogFocus(root){
    if(root.__spxDialogFocus)return;root.__spxDialogFocus=true;
    const previous=new WeakMap();
    const dialogs=[...root.querySelectorAll('[role="dialog"][aria-modal="true"]')];
    const focusable=dialog=>[...dialog.querySelectorAll('button,input,select,textarea,a[href],[tabindex]')].filter(el=>!el.disabled&&!el.hidden&&el.tabIndex>=0&&!el.closest('[hidden]'));
    for(const dialog of dialogs){
      const observer=new MutationObserver(()=>{
        dialog.setAttribute('aria-hidden',String(dialog.hidden));
        if(!dialog.hidden){if(!dialog.contains(document.activeElement))previous.set(dialog,document.activeElement);(focusable(dialog)[0]||dialog).focus?.({preventScroll:true});}
        else{const target=previous.get(dialog);if(target?.isConnected)target.focus?.({preventScroll:true});}
      });
      observer.observe(dialog,{attributes:true,attributeFilter:['hidden']});
    }
    root.addEventListener('keydown',event=>{
      if(event.key!=='Tab')return;
      const dialog=dialogs.find(el=>!el.hidden);if(!dialog)return;
      const items=focusable(dialog);if(!items.length){event.preventDefault();return;}
      const index=items.indexOf(document.activeElement);
      if(index<0||(!event.shiftKey&&index===items.length-1)||(event.shiftKey&&index===0)){
        event.preventDefault();items[event.shiftKey?items.length-1:0].focus({preventScroll:true});
      }
    });
  }
  async function prepareCategoryKeywordSelection(){
    if(state.busy||activeRunId)throw new Error('현재 수집을 먼저 중단하세요.');
    const parsed=SPX.parseSearchPage();
    const category=SPX.parseSearchCategoryContext?.()||{};
    const rows=SPX.discovery.categoryKeywordCandidates(parsed.items||[],category);
    if(!rows.length)throw new Error('현재 카테고리에서 구체적인 키워드 후보를 찾지 못했습니다. 상품을 표시한 뒤 다시 확인하세요.');
    await openSourcingModal();
    selectSidebarSourcingMode('full');
    applySidebarExplorationForm({...readSidebarExplorationForm(),specifiedEnabled:true,waveEnabled:false,seedKeywords:rows.map(row=>row.keyword)});
    markSourcingDraftDirty();
    setText('spx-status',`카테고리에서 키워드 ${rows.length}개 발견 · 선택 후 검색수집`);
  }
  function detect() {
    const n = document.querySelectorAll('a[href*="/vp/products/"]').length;
    state.detected = n;
    state.keyword = currentKeyword()||String(getUiElement('spx-guided-keyword',{repair:false})?.value||'').trim();
    setText('spx-count', fmt(n));
    setText('spx-kwlabel', state.keyword || ((FORCE_SIDEBAR_MODE||isCoupangSearchLandingV103())?'검색어 입력 대기':'키워드 없음'));
    setDisabled('spx-scan', (!state.keyword&&!FORCE_SIDEBAR_MODE) || state.busy);
    const categoryButton=getUiElement('spx-category-candidates',{repair:false});if(categoryButton){categoryButton.hidden=!location.pathname.startsWith('/np/categories/');categoryButton.disabled=state.busy||Boolean(activeRunId);}
  }


  /* v4.0.61: 숨겨진 쿠팡 탭은 Chrome이 setTimeout/requestAnimationFrame을 강하게 제한할 수 있습니다.
     화면을 보고 있지 않아도 수집이 이어지도록, 숨김 상태의 짧은 대기는 서비스워커 응답을
     clock source로 사용합니다. Supabase/네이버 요청은 전혀 추가하지 않습니다. */
  async function automationAwareWait(ms,runId=''){
    const delay=Math.max(0,Math.min(10000,Math.round(Number(ms)||0)));
    if(document.visibilityState==='visible')return SPX.util.sleep(delay);
    try{
      const response=await runtimeMessage({type:'SPX_AUTOMATION_BACKGROUND_WAIT',runId:String(runId||activeRunId||''),delayMs:delay});
      if(response?.ok)return true;
    }catch(_){ }
    return SPX.util.sleep(delay);
  }

  function currentSearchPageNumber(){
    try{return Math.max(1,Number(new URL(location.href).searchParams.get('page'))||1);}catch(_){return 1;}
  }
  function recoverySnapshotMatches(keyword,page,runId=''){
    const snap=networkRecoveryPageSnapshot;if(!snap)return false;
    const keywordMatch=canonicalVisibleKeyword(snap.keyword)===canonicalVisibleKeyword(keyword);
    const pageMatch=Math.max(1,Number(snap.page)||1)===Math.max(1,Number(page)||1);
    const runMatch=!runId||!snap.runId||String(snap.runId)===String(runId);
    return keywordMatch&&pageMatch&&runMatch&&Array.isArray(snap.items)&&snap.items.length>0;
  }
  function rememberNetworkRecoveryPageSnapshot(keyword,page,items,strategy=''){
    const rows=Array.isArray(items)?items:[];if(!rows.length)return null;
    networkRecoveryPageSnapshot={runId:String(activeRunId||''),keyword:String(keyword||''),page:Math.max(1,Number(page)||1),items:rows.map((row)=>({...row})),strategy:String(strategy||''),savedAt:Date.now()};
    return networkRecoveryPageSnapshot;
  }
  function clearNetworkRecoveryPageSnapshot(keyword='',page=0){
    if(!networkRecoveryPageSnapshot)return;
    if(keyword&&canonicalVisibleKeyword(networkRecoveryPageSnapshot.keyword)!==canonicalVisibleKeyword(keyword))return;
    if(page&&Math.max(1,Number(networkRecoveryPageSnapshot.page)||1)!==Math.max(1,Number(page)||1))return;
    networkRecoveryPageSnapshot=null;networkRecoverySoftResumeRequested=false;
  }

  /* v1.6.10 separate opt-in keyword 1/2: only fetches the two explicit sort pages and available seller shop links.
     No additional browser tabs, no IP recovery changes, no automatic collection-queue promotion. */
  const promptKeywordSeenV1610=new Set();
  const promptKeywordSortCacheV1652=new Map();
  function sourceProductsFromHtmlV1610(html){
    const doc=new DOMParser().parseFromString(String(html||''),'text/html');
    const nodes=[...doc.querySelectorAll('li.search-product, li[class*="search-product"], [data-product-id], [class*="product-item"], [class*="ProductCard"]')].slice(0,90);
    const items=[];const seen=new Set();
    for(const li of nodes){
      const nameEl=li.querySelector('.name, [class*="product-name"], [class*="ProductName"], [data-testid*="name"], [class*="name"], [class*="Name"]');
      // Some sorted responses expose product names only in image alt or product link title.
      // Never use the entire card text: it contains prices, rankings, and advertising labels.
      const a=li.querySelector('a[href*="/vp/products/"],a[href*="/products/"]');
      const name=String(nameEl?.getAttribute?.('title')||nameEl?.textContent||a?.getAttribute?.('title')||a?.querySelector('img')?.getAttribute('alt')||'').replace(/\s+/g,' ').trim();
      if(name.length<5||name.length>230)continue;
      const cardText=String(li.textContent||'');
      const href=li.querySelector('a[href*="/products/"]')?.getAttribute('href')||'';
      const pid=String(li.dataset?.productId||href.match(/\/products\/(\d+)/)?.[1]||'');
      let productUrl='',itemId='',vendorItemId='';
      try{const u=new URL(href,location.origin);if(u.protocol==='https:'&&/^(?:www\.)?coupang\.com$/i.test(u.hostname)&&/^\/vp\/products\/\d+/.test(u.pathname)){productUrl=u.href;itemId=u.searchParams.get('itemId')||'';vendorItemId=u.searchParams.get('vendorItemId')||'';}}catch(_){}
      const id=[pid||name.slice(0,50),vendorItemId||itemId].join('|');
      if(seen.has(id))continue;seen.add(id);
      const price=Number(String(li.querySelector('.price-value,[class*="price-value"],[class*="Price"]')?.textContent||'').replace(/[^\d]/g,''))||(Number(cardText.match(/([\d,]{3,})\s*원/)?.[1]?.replace(/,/g,''))||null);
      const rv=String(li.querySelector('.rating-total-count,[class*="rating-total-count"],[class*="reviewCount"],[class*="RatingCount"]')?.textContent||'').replace(/[^\d]/g,'');
      const reviews=rv?Number(rv):(cardText.match(/(?:상품평|리뷰|평가)\s*\(?([\d,]+)\)?/)?.[1]?Number(cardText.match(/(?:상품평|리뷰|평가)\s*\(?([\d,]+)\)?/)[1].replace(/,/g,'')):null);
      const deliveryText=String(li.querySelector('[class*="delivery"],[class*="rocket"],.badge')?.textContent||'')+' '+cardText.slice(-170);
      const isSellerRocket=/로켓그로스|판매자로켓/.test(deliveryText);
      const isAd=/^(?:광고|AD)$/i.test(String(li.querySelector('[class*="ad-badge"],[class*="adBadge"]')?.textContent||'').trim());
      const rocketType=isSellerRocket?'로켓그로스':(/로켓프레시/.test(deliveryText)?'로켓프레시':(/로켓배송/.test(deliveryText)?'로켓배송':(/일반배송/.test(deliveryText)?'일반배송':'배송유형 미확인')));
      items.push({pid,name,productUrl,itemId,vendorItemId,price,reviews,rank:items.length+1,isAd,isSellerRocket,
        isSoldOut:/품절|판매\s*종료/.test(cardText),rocketType,deliveryType:rocketType});
    }
    // Some sorted pages include structured product data but no static card DOM.
    // Only parse real schema.org Product data; never invent missing metrics.
    if(!items.length){
      const normalized=[];
      const visit=(value,depth=0)=>{
        if(depth>7||!value||typeof value!=='object')return;
        if(Array.isArray(value)){for(const x of value.slice(0,100))visit(x,depth+1);return;}
        const types=Array.isArray(value['@type'])?value['@type']:[value['@type']];
        if(types.some(t=>/^(?:Product|IndividualProduct)$/i.test(String(t||'')))){
          const name=String(value.name||'').trim(),offers=Array.isArray(value.offers)?value.offers[0]:value.offers||{};
          const priceRaw=offers.price??offers.lowPrice;
          const price=Number(String(priceRaw??'').replace(/[^\d.]/g,''))||null;
          const reviews=Number(value.aggregateRating?.reviewCount??value.aggregateRating?.ratingCount??NaN);
          if(name.length>=5&&name.length<=230&&/^https?:/i.test(String(value.url||'https://www.coupang.com'))){
            let productUrl='',pid='',itemId='',vendorItemId='';
            try{const u=new URL(value.url||offers.url,location.origin);if(u.protocol==='https:'&&/^(?:www\.)?coupang\.com$/i.test(u.hostname)&&/^\/vp\/products\/\d+/.test(u.pathname)){productUrl=u.href;pid=u.pathname.match(/\/products\/(\d+)/)[1];itemId=u.searchParams.get('itemId')||'';vendorItemId=u.searchParams.get('vendorItemId')||'';}}catch(_){}
            normalized.push({pid,productUrl,itemId,vendorItemId,name,price,reviews:Number.isFinite(reviews)?reviews:null,rank:normalized.length+1,
              isAd:false,isSellerRocket:false,isSoldOut:/OutOfStock|Discontinued/i.test(String(offers.availability||'')),rocketType:'배송유형 미확인',deliveryType:'미확인'});
          }
        }
        for(const k of ['itemListElement','item','@graph','mainEntity','hasPart'])if(value[k])visit(value[k],depth+1);
      };
      for(const script of doc.querySelectorAll('script[type="application/ld+json"]')){
        try{visit(JSON.parse(script.textContent||''));}catch(_){}
      }
      for(const item of normalized.slice(0,75)){const key=[item.pid||item.name,item.vendorItemId||item.itemId].join('|');if(!seen.has(key)){seen.add(key);items.push(item);}}
    }
    // Sorted pages sometimes ship product lists as hydration JSON without card DOM or JSON-LD.
    // Parse only product collections from the returned page; do not infer a sorted order or seller.
    if(!items.length){
      let visited=0;
      const found=new Map();
      const walk=(value,depth=0,productList=false)=>{
        if(!value||typeof value!=='object'||depth>12||visited++>50000||found.size>=75)return;
        if(Array.isArray(value)){for(const child of value.slice(0,250))walk(child,depth+1,productList);return;}
        if(productList){
          const pid=String(value.productId??value.product_id??'').replace(/\D/g,'');
          const name=String(value.productName??value.product_name??value.name??value.title??'').replace(/\s+/g,' ').trim();
          const priceValue=[value.salePrice,value.finalPrice,value.sellingPrice,value.discountPrice,value.price].find(x=>x!=null&&String(x).trim());
          const price=Number(String(priceValue??'').replace(/[^\d]/g,''));
          const itemId=String(value.itemId??value.item_id??'').replace(/\D/g,''),vendorItemId=String(value.vendorItemId??value.vendor_item_id??'').replace(/\D/g,'');
          const offerKey=[pid,vendorItemId||itemId].join('|');
          if(/^\d{6,16}$/.test(pid)&&name.length>=5&&name.length<=230&&price>0&&price<100000000&&!found.has(offerKey)){
            const rv=value.reviewCount??value.ratingCount??value.reviews;
            const reviews=rv==null?null:Number(String(rv).replace(/,/g,''));
            const evidence=String(value.deliveryType??value.rocketType??value.badgeType??'');
            const params=new URLSearchParams();if(itemId)params.set('itemId',itemId);if(vendorItemId)params.set('vendorItemId',vendorItemId);
            const rocketType=/판매자로켓|로켓그로스/i.test(evidence)?'로켓그로스':(/로켓프레시/i.test(evidence)?'로켓프레시':(/로켓배송/i.test(evidence)?'로켓배송':'배송유형 미확인'));
            found.set(offerKey,{pid,itemId,vendorItemId,productUrl:`https://www.coupang.com/vp/products/${pid}${params.size?'?'+params.toString():''}`,name,price,reviews:Number.isFinite(reviews)?reviews:null,rank:found.size+1,rocketType,
              isAd:value.isAd===true||value.ad===true,isSellerRocket:/판매자로켓|로켓그로스|seller.?rocket/i.test(evidence),
              isSoldOut:value.isSoldOut===true||value.soldOut===true,deliveryType:rocketType});
          }
        }
        for(const [key,child] of Object.entries(value)){
          if(child&&typeof child==='object')walk(child,depth+1,productList||/(?:searchResults?|productLists?|searchProducts|productItems|products|items|results)$/i.test(key));
        }
      };
      for(const script of [...doc.querySelectorAll('script#__NEXT_DATA__,script[type="application/json"],script:not([src])')].slice(0,18)){
        const raw=String(script.textContent||'').trim();
        if(raw.length<100||raw.length>5000000||!raw.startsWith('{')&&!raw.startsWith('['))continue;
        try{walk(JSON.parse(raw));}catch(_){}
        if(found.size>=75)break;
      }
      items.push(...found.values());
    }
    return items;
  }
  function extractSellerShopLinksV1610(products=[]){
    const urls=[],seen=new Set();
    const valid=(raw)=>{
      if(!raw)return null;
      try{
        const u=new URL(String(raw),location.href);
        if(u.protocol!=='https:'||!/(^|\.)coupang\.com$/i.test(u.hostname))return null;
        if(!/(?:\/(?:np|vp)\/(?:brandshops?|vendors?|sellers?|stores?)\/|\/np\/(?:brandshops?|vendors?|sellers?|stores?)\?|\/vp\/vendor\/)/i.test(u.pathname))return null;
        u.hash='';return u.href;
      }catch(_){return null;}
    };
    const add=(raw)=>{const url=valid(raw);if(url&&!seen.has(url)){seen.add(url);urls.push(url);}return urls.length>=2;};
    const cards=document.querySelectorAll('li.search-product,li[class*="search-product"],[data-product-id],[class*="ProductCard"]');
    const selectors='a[href*="brandshop"],a[href*="/vendors/"],a[href*="/sellers/"],a[href*="/seller/"],a[href*="/stores/"],a[href*="/store/"]';
    for(const card of cards){
      if(card.querySelector('[class*="ad-badge"],[class*="adBadge"]'))continue;
      const badge=String(card.textContent||'').slice(-350);
      if(/쿠팡직매입|로켓배송/.test(badge)&&!/판매자로켓|로켓그로스/.test(badge))continue;
      for(const a of card.querySelectorAll(selectors)){if(add(a.getAttribute('href')))return urls;}
      for(const field of ['data-store-url','data-shop-url','data-seller-url','data-brandshop-url']){
        if(add(card.getAttribute(field)))return urls;
      }
    }
    // Only already-observed product URLs, never invent seller IDs or store addresses.
    for(const row of (Array.isArray(products)?products:[])){
      const type=String(row?.rocketType||row?.deliveryTypeRaw||row?.deliveryType||'');
      if(/로켓배송|쿠팡직매입/.test(type)&&!/판매자로켓|로켓그로스/.test(type))continue;
      for(const field of ['sellerShopUrl','brandShopUrl','storeUrl','vendorUrl','sellerUrl']){
        if(add(row?.[field]))return urls;
      }
    }
    return urls;
  }
  function observedGeneralSellerProductsV1615(products=[]){
    return (Array.isArray(products)?products:[]).filter(row=>{
      if(!row||row.isAd||row.is_ad||row.isSoldOut||row.sold_out)return false;
      const type=String(row.rocketType||row.deliveryTypeRaw||row.deliveryType||'');
      if(/로켓배송|로켓프레시|쿠팡직매입|쿠팡판매/.test(type)&&!/판매자로켓|로켓그로스/.test(type))return false;
      return /판매자로켓|로켓그로스|일반배송/.test(type)||row.sellerType==='일반판매자';
    }).slice(0,75).map(row=>({...row,deliveryType:String(row.rocketType||row.deliveryTypeRaw||row.deliveryType||'일반배송')}));
  }
  async function fetchKeywordSortV1610(url,mode,sort,keyword){
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),5500);
    try{
      const response=await fetch(url,{credentials:'include',cache:'no-store',redirect:'follow',signal:controller.signal});
      if(!response.ok)return{ok:false,reason:`HTTP ${response.status}`,url:response.url};
      const html=await response.text();
      const redirected=new URL(response.url,location.origin);
      const requested=new URL(url,location.origin);
      if(mode==='search'&&(redirected.origin!==requested.origin||redirected.pathname!=='/np/search'
        ||redirected.searchParams.get('q')!==keyword||Number(redirected.searchParams.get('page')||1)!==1))return{ok:false,reason:'요청한 키워드 검색 1페이지와 다른 응답',url:response.url};
      const actualSort=redirected.searchParams.get('sorter');
      const sortVerified=actualSort===sort;
      if(!sortVerified)return{ok:false,reason:`정렬값 미확인 (${actualSort||'없음'})`,url:response.url};
      if(/보안문자|captcha|비정상적인 접근|접근이 제한|access denied/i.test(html.slice(0,9000)))return{ok:false,reason:'접근제한 또는 CAPTCHA 화면'};
      const products=sourceProductsFromHtmlV1610(html);
      if(!products.length)return{ok:false,reason:'상품카드 0건 · 동적 렌더링/HTML 변경 가능',bytes:html.length};
      // Candidate verification must not wait for the optional server title-registration ACK.
      const registration=runtimeMessage({type:'SPX_PROMPT_KEYWORDS_REGISTER_V1610',mode,sort,keyword,products,sourceUrl:response.url})
        .catch(error=>({ok:false,error:String(error?.message||error)}));
      return{ok:true,productItems:products,products:products.length,registration};
    }catch(error){return{ok:false,reason:String(error?.name==='AbortError'?'정렬페이지 요청 5.5초 초과':error?.message||error).slice(0,120)};}
    finally{clearTimeout(timer);}
  }
  async function collectPromptKeywordsForPageV1610(products,keyword,page,onSortCandidates=()=>{},options={}){
    if(!keyword||!Array.isArray(products)||products.length===0)return;
    const firstPage=Number(page)===1;
    const uniqueKey=String(activeRunId||'manual')+'|'+keyword+'|'+Number(page||1);
    const snapshot=await chrome.storage.local.get(SPX.promptKeywords.SETTINGS_KEY).catch(()=>({}));
    const controls=snapshot?.[SPX.promptKeywords.SETTINGS_KEY]||{};
    if(controls.keyword1!==true&&controls.keyword2!==true)return;
    const needsSearchSort=controls.keyword2===true&&firstPage;
    if(!needsSearchSort)onSortCandidates([]);
    const cached=promptKeywordSortCacheV1652.get(uniqueKey);
    if(promptKeywordSeenV1610.has(uniqueKey)&&options.fresh!==true&&activeRunId&&(!needsSearchSort||cached)){
      if(needsSearchSort&&cached)onSortCandidates(await cached);
      return;
    }
    promptKeywordSeenV1610.add(uniqueKey);
    let resolveCandidates,candidatesDelivered=false;
    const ready=new Promise(resolve=>{resolveCandidates=resolve;});
    promptKeywordSortCacheV1652.set(uniqueKey,ready);
    while(promptKeywordSortCacheV1652.size>4)promptKeywordSortCacheV1652.delete(promptKeywordSortCacheV1652.keys().next().value);
    const deliverCandidates=rows=>{if(candidatesDelivered)return;candidatesDelivered=true;resolveCandidates(rows);onSortCandidates(rows);};
    if(!needsSearchSort)deliverCandidates([]);
    try{
    const totals={sorted:0,sortJobs:0,extracted:0,local:0,server:0,already:0,products:0,shopLinks:0,sellerObserved:0};
    const errors=[];
    const registrations=[];
    const diag=(label,response={})=>{
      const examined=Number(response?.productsExamined??response?.products)||0;
      const eligible=Number(response?.eligible)||0;
      const local=Number(response?.local?.added)||0;
      const server=Number(response?.server?.added)||0;
      const serverUpdated=Number(response?.server?.updated)||0;
      const localUpdated=Number(response?.local?.updated)||0;
      const already=Number(response?.skippedKnown)||0;
      totals.extracted+=eligible;totals.local+=local;totals.server+=server;
      totals.already+=already;totals.products+=examined;
      const rawStats=response?.filterReasons||{};
      const reasonText=Number(rawStats.canonicalDuplicates)>0?` · 중복 후보 병합 ${rawStats.canonicalDuplicates}건`:'';
      const serverMessage=String(response?.server?.error|| (response?.server?.offline?'서버 연결 없음 · 로컬 발견에만 저장':'') ||'');
      const message=`[SPX 키워드1/2] ${label} · 상품 ${examined}개 · 원본 상품명 ${eligible}개 · 로컬 발견 신규 ${local}개/기존 ${localUpdated}개 · 서버 발견 신규 ${server}개/갱신 ${serverUpdated}개${already?` · 기존 처리 보호 ${already}개`:''}${reasonText}${serverMessage?` · 서버 등록 실패: ${serverMessage.slice(0,100)}`:''}`;
      console.info(message);appendLiveLog(message.replace('[SPX 키워드1/2] ',''));
      if(serverMessage)errors.push(`${label} 서버: ${serverMessage.slice(0,100)}`);
    };
    const register=(label,promise)=>registrations.push(Promise.resolve(promise).then(response=>{
      if(response?.ok===true)diag(label,response);
      else errors.push(`${label} 등록 실패: ${String(response?.error||'응답 없음')}`);
    }).catch(error=>errors.push(`${label} 등록 실패: ${String(error?.message||error)}`)));
    // Start the observed-title write first, without blocking the existing sorter requests on server ACKs.
    if(controls.keyword2===true){
      appendLiveLog('키워드2 · 현재 검색화면 원본 상품명 먼저 발견키워드에 저장 중 (정렬 미확인)');
      try{
        register(`현재 검색화면 ${page}페이지 · 정렬 미확인`,runtimeMessage({type:'SPX_PROMPT_KEYWORDS_REGISTER_V1610',mode:'search',sort:'currentObserved',keyword,products:products.slice(0,80)}));
      }catch(error){errors.push(`현재 검색화면 등록 실패: ${String(error?.message||error)}`);}
    }
    const jobs=[];
    if(controls.keyword2===true&&firstPage){
      for(const sorter of ['saleCountDesc','latestAsc']){
        const u=new URL(location.href);u.searchParams.set('q',keyword);u.searchParams.set('page','1');u.searchParams.set('sorter',sorter);
        if(!u.pathname.includes('/np/search'))u.pathname='/np/search';
        jobs.push({url:u.href,mode:'search',sort:sorter});
      }
    }
    if(controls.keyword1===true){
      // Keyword1 must not silently stop when Coupang omits brand-shop links on search cards.
      // Use the *actual observed* ordinary seller product cards as a separate, correctly
      // attributed source. This is not described as brand-shop sorting or verified sales.
      const sellers=observedGeneralSellerProductsV1615(products);
      totals.sellerObserved=sellers.length;
      if(sellers.length){
        try{
          register(`키워드1 일반판매자 관찰 · ${page}페이지 (브랜드샵 정렬 아님)`,runtimeMessage({type:'SPX_PROMPT_KEYWORDS_REGISTER_V1610',mode:'sellerObserved',sort:'sellerObserved',keyword,products:sellers}));
        }catch(error){errors.push(`키워드1 일반판매자 등록 실패: ${String(error?.message||error)}`);}
      }
      if(firstPage){
        const shops=extractSellerShopLinksV1610(products);
        totals.shopLinks=shops.length;
        if(!shops.length){
          const message=`키워드1 · 실제 브랜드샵 링크 0개 · 일반판매자 관찰 ${sellers.length}개 별도 분석`;
          console.info('[SPX 키워드1/2] '+message);appendLiveLog(message);
        }
        for(const link of shops){
          for(const sorter of ['saleCountDesc','latestAsc','scoreDesc']){
            const u=new URL(link);u.searchParams.set('sorter',sorter);u.searchParams.set('page','1');
            jobs.push({url:u.href,mode:'shop',sort:sorter});
          }
        }
      }
    }
    totals.sortJobs=jobs.length;
    const searchSortGroups=[];
    // 2 concurrent requests maximum; no tabs, no navigation, strict source verification.
    // AbortControllers inside fetchKeywordSortV1610 bound each network request.
    for(let i=0;i<jobs.length;i+=2){
      if(contextInvalidated)break;
      const group=jobs.slice(i,i+2);
      const settled=await Promise.all(group.map(async(job)=>({job,result:await fetchKeywordSortV1610(job.url,job.mode,job.sort,keyword)})));
      for(const {job,result} of settled){
        if(result.ok){
          totals.sorted++;
          register(`${job.mode==='shop'?'키워드1':'키워드2'}/${job.sort} · 정렬 페이지 상품 확보 (순서 미검증)`,result.registration);
          if(job.mode==='search')searchSortGroups.push({sort:job.sort,items:result.productItems||[]});
        }
        else errors.push(`${job.mode}/${job.sort}: ${result.reason||'응답 실패'}`);
      }
      if(group.some(job=>job.mode==='search')){
        // Alternate the two sorts so one response cannot consume the entire detail budget.
        const candidates=[];
        for(let n=0;n<Math.max(0,...searchSortGroups.map(group=>group.items.length));n++)for(const group of searchSortGroups){
          if(group.items[n])candidates.push({...group.items[n],sourceType:'keyword_sort_candidate',sourceSort:group.sort,rank:null,exposureRank:null,organicRank:null});
        }
        deliverCandidates(candidates);
      }
    }
    await Promise.all(registrations);
    const summary=`[SPX 키워드1/2] ${keyword} · ${page}페이지 · 브랜드샵 링크 ${totals.shopLinks}개 · 일반판매자 관찰 ${totals.sellerObserved}개 · 정렬 응답 ${totals.sorted}/${totals.sortJobs} · 상품 분석 ${totals.products}개 · 원본 상품명 ${totals.extracted}개 · 로컬 발견 신규 ${totals.local}개 · 서버 발견 신규 ${totals.server}개${errors.length?` · 오류 ${errors.length}건`:''}`;
    console.info(summary);appendLiveLog(summary.replace('[SPX 키워드1/2] ',''));
    if(errors.length){
      // Dynamic-rendered sorter HTML with zero product cards is expected on some Coupang pages;
      // the observed-page fallback still runs. Avoid storing the same nonfatal condition as
      // a new Chrome extension error on every keyword.
      console.info('[SPX 키워드1/2] 정렬 페이지 미확인 상세:',errors.join(' | '));
      appendLiveLog(`키워드1/2 오류 · ${errors[0].slice(0,135)}${errors.length>1?` · 외 ${errors.length-1}건`:''}`);
    }
    }finally{deliverCandidates([]);}
  }

  async function collectPage(progressPrefix = '', task = null, options = {}) {
    task?.touch?.('상품 카드 탐색 시작');task?.assert?.();
    const activeKeyword = String(options?.expectedKeyword || state.lockedKeyword || new URL(location.href).searchParams.get('q') || '').trim();
    const activePromoReason=SPX.discovery?.purePromotionUiReason?.(activeKeyword)||'';
    if(activePromoReason)throw new Error(`프로모션 UI 문구는 수집하지 않습니다: ${activeKeyword}`);
    if (task) await assertRunActive(task, '수집 시작 전');
    await retryEmptySearchIfNeeded();
    if (!(await waitForUi(10000, task))) {
      if (task && !taskIsCurrent(task)) throw normalEnd('STALE_TASK', '페이지 이동으로 이전 수집 작업을 중단했습니다.');
      throw new Error('수집기 UI 준비 시간 초과');
    }
    const allowEmpty = Boolean(options?.allowEmpty);
    // v1.6.11: optional keyword1/2 jobs may be skipped (empty result) or reuse a recovery snapshot.
    // Keep the promise in the outer collectPage scope so the final wait never raises ReferenceError.
    let promptKeywordScanV1610 = Promise.resolve();
    let resolveSortCandidates;
    const sortCandidatesV1652=new Promise(resolve=>{resolveSortCandidates=resolve;});
    let res;
    if (allowEmpty) {
      setProgress(70, `${progressPrefix}검색결과 없음 확인 · 빈 페이지 저장 중...`);
      res = { items: [], strategy: 'confirmed-no-results', diagnostic: null };
    } else {
      const currentPage=currentSearchPageNumber();
      const reusableSnapshot=(networkRecoverySoftResumeRequested||options.reuseDetailCheckpoint===true)&&recoverySnapshotMatches(activeKeyword,currentPage,activeRunId);
      if(reusableSnapshot){
        const snap=networkRecoveryPageSnapshot;
        res={items:snap.items.map((row)=>({...row})),strategy:`${snap.strategy||'search-dom'}+${options.reuseDetailCheckpoint===true?'detail-checkpoint':'network-resume'}`,diagnostic:null};
        networkRecoverySoftResumeRequested=false;
        setProgress(70,`${progressPrefix}IP 변경 전 확인한 상품 ${res.items.length}개 복원 · 상세확인 이어서 진행`);
        task?.touch?.(`IP 복구 체크포인트 상품 ${res.items.length}개 재사용`);
      }else{
        const canContinue = () => !contextInvalidated && !localManualAbortRequested && (!task || taskIsCurrent(task));
        setProgress(5, `${progressPrefix}검색결과 상품 확인 중...`);
        const baseScrollSettings = await safeGetSettings();
        const scrollSettings = options?.scrollOptions && typeof options.scrollOptions === 'object'
          ? { ...baseScrollSettings, ...options.scrollOptions }
          : baseScrollSettings;
        const scrollCompleted = scrollSettings.autoScrollEnabled === false ? true : await SPX.autoScroll((n) => {
          if (!task || taskIsCurrent(task)) setProgress(Math.min(60, 5 + n), `${progressPrefix}상품 ${n}개 발견`);
        }, canContinue, {
          random:scrollSettings.autoScrollRandom===true, stepMin:scrollSettings.scrollStepMin, stepMax:scrollSettings.scrollStepMax,
          delayMin:scrollSettings.scrollDelayMin, delayMax:scrollSettings.scrollDelayMax,
          isBackground:()=>document.visibilityState!=='visible',
          wait:(ms)=>automationAwareWait(ms,activeRunId),
          fastMode:options.fastCollectionV1714===true,
        });
        if (!scrollCompleted) {
          if(localManualAbortRequested)throw normalEnd('MANUAL_STOPPED','사용자가 단건 수집을 중단했습니다.');
          if (contextInvalidated) throw contextEndError();
          throw normalEnd('STALE_TASK', '페이지 이동 또는 중단으로 스크롤 수집을 종료했습니다.');
        }
        if (task) await assertRunActive(task, '스크롤 완료 후');
        setProgress(70, `${progressPrefix}상품 구조 분석 중...`);
        res = SPX.parseSearchPage();
        if (!res.items.length) {
          /* v4.1.18: 쿠팡 SPA가 스크롤 완료 직후 카드 DOM을 한 박자 늦게 붙이는 경우 현재 페이지만 짧게 재확인합니다. 페이지 수집 기준/상한은 바꾸지 않습니다. */
          for(const delay of [250,500,900]){
            await automationAwareWait(delay,activeRunId).catch(()=>{});
            if(localManualAbortRequested)throw normalEnd('MANUAL_STOPPED','사용자가 단건 수집을 중단했습니다.');
            res=SPX.parseSearchPage();if(res.items.length)break;
          }
        }
        if (!res.items.length) {
          const error = new Error('상품 카드가 아직 준비되지 않았습니다.');
          error.code = 'SEARCH_PARSE_EMPTY';
          throw error;
        }
        rememberNetworkRecoveryPageSnapshot(activeKeyword,currentPage,res.items,res.strategy||'search-dom');
      }
      promptKeywordScanV1610=collectPromptKeywordsForPageV1610(res.items,activeKeyword,currentSearchPageNumber(),resolveSortCandidates,{fresh:!task&&options.manualMode===true&&!reusableSnapshot})
        .catch((error)=>console.info('[SPX keyword scan] skipped',error?.message||error)).finally(()=>resolveSortCandidates([]));
      const stForDetail = await safeGetSettings();
      updateProgressiveFromProducts(activeKeyword, res.items, stForDetail, {
        resultTotal:SPX.parseResultTotal?.() || null,
        searchCategory:SPX.parseSearchCategoryContext?.() || null,
        pagesCollected:currentPage,
      }, {
        phase:1,
        stage:`${progressPrefix}상품 카드 분석 완료 · 상세정보 확인 준비`,
      });
      const collectDetail = options?.collectDetail !== false && Number(options?.detailLimit ?? 8) > 0;
      let priorityPids = Array.isArray(options?.priorityPids) ? options.priorityPids.map(String).filter(Boolean) : [];
      if (collectDetail) try {
        const provisionalResultTotal = SPX.parseResultTotal?.() || null;
        const provisionalSnapshots = SPX.buildProductSnapshots?.(res.items, [], {
          analysisDate: SPX.util.today(),
          resultTotal: provisionalResultTotal,
          maxProducts: stForDetail.sourceDataMaxProducts || 200,
          sourceKeyword: activeKeyword,
        }) || [];
        const provisionalWinners = SPX.computeWinnerMetrics?.(provisionalSnapshots, {
          resultTotal: provisionalResultTotal,
          maxProducts: stForDetail.sourceDataMaxProducts || 200,
          sourceKeyword: activeKeyword,
        }) || {};
        const representativePid = String(res.items.find((row) => !row?.isAd && (row?.pid || row?.product_id))?.pid || res.items.find((row) => !row?.isAd)?.product_id || '');
        const reviewMin = SPX.WINNER_REVIEW_MIN ?? 10;
        const reviewMax = SPX.WINNER_REVIEW_MAX ?? 1050;
        const salesThreshold = SPX.WINNER_MONTHLY_SALES_THRESHOLD ?? 200;
        const potentialWinnerPids = provisionalSnapshots
          .filter((row) => Number(row?.estimated_monthly_sales || row?.monthly_purchase_count || row?.detail_monthly_purchase_count || 0) >= salesThreshold)
          .filter((row) => Number(row?.cumulative_reviews ?? row?.reviews ?? 0) >= reviewMin && Number(row?.cumulative_reviews ?? row?.reviews ?? 0) <= reviewMax)
          .filter((row) => Number(row?.recent_reviews ?? 0) > 0 && !row?.is_ad && !row?.sold_out)
          .map((row) => String(row?.pid || row?.product_id || ''))
          .filter(Boolean);
        /* [v2.0] 리뷰 기반 임시추정치로 이미 "커 보이는" 상품만 상세확인 대상으로 뽑으면,
           리뷰는 적지만 실제로 잘 팔리는 상품은 이 단계에서 원천적으로 걸러져 영영 발견되지 않는다
           (상세확인이 필요한 바로 그 이유로 상세확인 대상에서 제외되는 순환 구조).
           그래서 리뷰기반 추정치와 무관하게, 리뷰 하한(reviewMin) 이상인 상품 중 쿠팡 자체 노출순위가
           높은 상품 일부를 추정치와 상관없이 항상 상세확인 대상에 포함한다. */
        const lowReviewSamplePids = provisionalSnapshots
          .filter((row) => !row?.is_ad && !row?.sold_out)
          .filter((row) => Number(row?.cumulative_reviews ?? row?.reviews ?? 0) >= reviewMin && Number(row?.cumulative_reviews ?? row?.reviews ?? 0) <= reviewMax)
          .filter((row) => !potentialWinnerPids.includes(String(row?.pid || row?.product_id || '')))
          .sort((a, b) => Number(a?.rankGlobal ?? a?.exposureRank ?? a?.rank ?? 99999) - Number(b?.rankGlobal ?? b?.exposureRank ?? b?.rank ?? 99999))
          .slice(0, Number(stForDetail.lowReviewSampleSize) || 4)
          .map((row) => String(row?.pid || row?.product_id || ''))
          .filter(Boolean);
        priorityPids = [...new Set([
          ...priorityPids,
          representativePid,
          ...potentialWinnerPids,
          ...lowReviewSamplePids,
          ...(provisionalWinners.winner_products || [])
            .filter((row) => Number(row?.estimated_monthly_sales || 0) >= salesThreshold)
            .map((row) => String(row?.pid || row?.product_id || ''))
            .filter(Boolean)
        ].filter(Boolean))];
      } catch (_) {}
      task?.touch?.(`상품 카드 ${res.items?.length||0}개 파싱 완료`);task?.assert?.();
      if (collectDetail) {
        setProgress(78, `${progressPrefix}체크된 효자상품 상세정보 확인 중...`);
        const cardItems=res.items;
        const keepDetailCheckpoint=items=>{
          if(contextInvalidated||localManualAbortRequested||task?.cancelled===true||task&&!taskIsCurrent(task))return;
          res.items=items;
          rememberNetworkRecoveryPageSnapshot(activeKeyword,currentPage,items,res.strategy||'search-dom');
        };
        try{
          res.items = await SPX.enrichProductDetails?.(res.items, {
            limit: Number.isFinite(Number(options?.detailLimit)) ? Number(options.detailLimit) : 8,
            priorityPids,
            keyword: activeKeyword,
            supplementaryCandidates:sortCandidatesV1652,
            collectComparisonCandidates: options?.collectComparisonCandidates !== false && stForDetail.collectDetailRecommendations!==false,
            comparisonCandidateLimit: Number.isFinite(Number(options?.comparisonCandidateLimit)) ? Number(options.comparisonCandidateLimit) : 8,
            recommendationSections:{enabled:stForDetail.collectDetailRecommendations!==false},
            onRecommendationCandidates:items=>{res.recommendationProducts=items;},
            manualMode:options?.manualMode===true,
            concurrency:options?.detailConcurrency,
            itemTimeoutMs:options?.detailItemTimeoutMs,
            priorityLimit:options?.priorityDetailLimit,
            fastDetail:options?.fastDetail===true,
            automatedFastPath:options?.automatedFastPath===true,
            selectedNetworkDedicated:IS_SELECTED_NETWORK_DEDICATED_TAB===true,
            shouldContinue: () => !contextInvalidated && !localManualAbortRequested && (!task || taskIsCurrent(task)) && task?.cancelled!==true,
            onCheckpoint:keepDetailCheckpoint,
            onProgress: (detail) => {const text=String(detail||'상세 확인 진행');task?.touch?.(text);setProgress(78,`${progressPrefix}${text}`);},
          }) || cardItems;
          /* v4.0.31: 1차 상세확인 뒤 실제 효자 후보를 다시 계산해, 최종 효자에 들어갈 상품 중
             대표이미지 또는 별점이 아직 비어 있는 상품만 한 번 더 확인합니다. 이 2차 패스는
             mediaOnly라 가격·리뷰·배송·판매량 등 판정값을 바꾸지 않고 이미지/별점만 보강합니다. */
          try{
            const mediaResultTotal=SPX.parseResultTotal?.()||null;
            const mediaSnapshots=SPX.buildProductSnapshots?.(res.items,[],{analysisDate:SPX.util.today(),resultTotal:mediaResultTotal,maxProducts:stForDetail.sourceDataMaxProducts||200,sourceKeyword:activeKeyword})||[];
            const mediaWinners=SPX.computeWinnerMetrics?.(mediaSnapshots,{resultTotal:mediaResultTotal,maxProducts:stForDetail.sourceDataMaxProducts||200,sourceKeyword:activeKeyword})||{};
            const itemByPid=new Map((res.items||[]).map((item)=>[String(item?.pid||item?.product_id||''),item]).filter(([pid])=>pid));
            /* v4.0.70: 메인 업로드 전 2차 미디어 보강은 대표이미지가 실제로 없는 효자만 대상으로 합니다.
               별점만 비어 있는 효자까지 여기서 다시 상세페이지를 기다리면 키워드당 수 초~수십 초가 늘어나므로,
               별점 최종 DOM 확인은 기본 업로드 뒤 서비스워커 저우선순위 큐에서 처리합니다. */
            const missingMediaPids=[...new Set((mediaWinners.winner_products||[]).map((row)=>String(row?.pid||row?.product_id||'')).filter((pid)=>{const item=itemByPid.get(pid);if(!item)return false;const image=String(item?.imageUrl||item?.image_url||item?.thumbnail_url||item?.thumbnail||'').trim();return !image;}))].slice(0,40);
            if(missingMediaPids.length){
              setProgress(79,`${progressPrefix}효자상품 대표이미지 ${missingMediaPids.length}개 보강 중...`);
              res.items=await SPX.enrichProductDetails?.(res.items,{limit:0,priorityPids:missingMediaPids,keyword:activeKeyword,collectComparisonCandidates:false,manualMode:options?.manualMode===true,concurrency:options?.detailConcurrency,itemTimeoutMs:options?.detailItemTimeoutMs,priorityLimit:40,fastDetail:options?.fastDetail===true,automatedFastPath:options?.automatedFastPath===true,selectedNetworkDedicated:IS_SELECTED_NETWORK_DEDICATED_TAB===true,mediaOnly:true,onCheckpoint:keepDetailCheckpoint,shouldContinue:()=>!contextInvalidated&&!localManualAbortRequested&&(!task||taskIsCurrent(task))&&task?.cancelled!==true,onProgress:(detail)=>{const text=String(detail||'효자 이미지 보강');task?.touch?.(text);setProgress(79,`${progressPrefix}${text}`);}})||res.items;
            }
          }catch(mediaError){console.warn('[SPX] 효자상품 대표이미지·별점 2차 보강 생략',mediaError);}
          /* v1.0.15.3: 평균별점은 별도 수집하지 않습니다. 검색카드와 이미 수행된 효자 상세확인에서
             확보된 개별 별점만 최종 효자상품 배열에 남기고, 평균은 그 유효 별점의 산술평균으로 계산합니다.
             별점이 없는 효자는 0점으로 넣지 않고 미확인으로 유지합니다. */
          task?.touch?.('상품 상세정보 확인 완료');task?.assert?.();
        }catch(error){
          if(error?.spxContextInvalidated||error?.spxNormalEnd||error?.code==='COUPANG_BLOCKED'||localManualAbortRequested)throw error;
          console.warn('[SPX] 상품 상세 확인 지연 · 검색카드 자료로 계속',error);
          res.items=Array.isArray(res.items)&&res.items.length?res.items:cardItems;res.detailFallback=true;res.detailFallbackReason=String(error?.message||error||'상세 확인 실패');
          setProgress(80,`${progressPrefix}상세 확인 지연 · 검색카드 기준으로 분석 계속`);
          task?.touch?.('상세 확인 지연 · 검색카드 기준 저장 계속');
        }finally{}
      } else setProgress(78, `${progressPrefix}상품 상세 확인 생략 · 선택 항목 집계 중...`);
    }
    const st = await safeGetSettings();
    if (task) await assertRunActive(task, '상품 상세정보 확인 후');
    if((res.recommendationProducts||[]).length&&st.collectDetailRecommendations!==false){
      void runtimeMessage({type:'SPX_PROMPT_KEYWORDS_REGISTER_V1610',mode:'recommendation',sort:'detailFirstLevel',keyword:activeKeyword,products:res.recommendationProducts,sourceUrl:location.href}).then(names=>{if(names?.ok!==true)console.info('[SPX] 추천상품 상품명 저장 확인 필요',names?.error||'응답 미확인');}).catch(error=>console.info('[SPX] 추천상품 상품명 저장 응답 지연',error?.message||error));
    }
    // v1.6.21: raw Coupang related search phrases; leave all post-processing to Gemini.
    const related = SPX.discovery.extractRelatedTermsFromDom?.() || [];
    const relatedDiscoveryTerms = related;
    /* 1차 정상 통과 후보를 우선 유지하면서 제외 후보도 네이버 조건부 구제 단계에 전달할 수
       있도록 내부 후보 풀은 최종 저장 한도보다 넓게 만듭니다. 서비스워커가 정상 후보 직행 후
       남은 슬롯에 대해서만 제외 후보를 조회하므로 API 요청은 늘리지 않습니다. */
    const finalCandidateLimit=Math.max(1,Number(st.candidatesPerKeyword)||8);
    const candidatePoolLimit=0; // v1.6.5: 발견 후보 자체는 무제한, 실제 자동수집 승격만 candidatesPerKeyword로 제한
    // The related terms are sent only to the raw inbox, not mixed into auto-queue candidates.
    const candidates = SPX.discovery.discoverFromProducts(state.keyword, res.items, [], candidatePoolLimit);
    renderDiscoveredKeywords(candidates, related);
    recordTabSessionEvent('discovered',{}, {discoveredKeywords:candidates.map((item)=>item?.keyword||item?.term||item?.name||item).filter(Boolean)}).catch(()=>{});
    const externalMetrics = SPX.parseExternalMarketMetrics?.() || { detected: false };
    const searchCategory = SPX.parseSearchCategoryContext?.() || { categoryPath: null, categoryId: null, source: '미확인' };
    const resultTotal = SPX.parseResultTotal?.() || null;
    updateProgressiveFromProducts(activeKeyword, res.items, st, {
      resultTotal, searchCategory, relatedTerms:related, externalMetrics,
    }, {
      phase:2,
      stage:`${progressPrefix}상품 상세정보 반영 완료 · 과거 추이 확인 준비`,
    });
    // Sorted offers have already joined shared verification; give title writes their existing grace window.
    // A small grace window allows completed batches to be registered before the next page transition.
    await Promise.race([promptKeywordScanV1610,new Promise(resolve=>setTimeout(resolve,25000))]);
    return { res, candidates, relatedTerms: related, relatedDiscoveryTerms, externalMetrics, searchCategory, resultTotal, settings: st };
  }

  /* [v2.2.5] 검색결과 없음 문구를 보고 검색버튼·form.submit을 자동으로 다시 누르던 기능은
     멈춤 직후에도 한 번 더 페이지를 전환시키고, 쿠팡의 component= 빈 URL을 다시 만들 수 있어
     제거한다. 결과 없음은 그대로 판정하며 페이지 이동은 사용자의 검색 또는 Next에서만 한다. */
  async function retryEmptySearchIfNeeded() {
    return false;
  }

  async function ensureCollectionIntegrationsBeforeStart(options={}){
    const response=await runtimeMessage({type:'SPX_COLLECTION_INTEGRATION_PREFLIGHT',force:true,skipNaver:options.skipNaver===true});
    if(response?.ready===true||response?.ok===true&&response?.needsOptions!==true)return response;
    const message=String(response?.message||response?.error||'수집 시작 전 네이버·Supabase 연동 설정을 확인하세요.');
    setDisplay('spx-auto','flex');setText('spx-status','연동 설정 필요');setText('spx-auto-text',message);setProgress(0,message);
    throw new Error(message);
  }

  async function runManualScan(options={}) {
    const sourcingSelection=options.selection||await loadCommittedSidebarSourcingSelection({apply:false}).catch(()=>null);
    ;
    ;
    const guidedSupplement=true;
    const routeSettings=await safeGetSettings();
    const routeMessage={type:'SPX_START_SELECTED_MODE',mode:'guided',useCurrentTab:true,collectionProfile:'lite',exactKeywords:[currentKeyword()].filter(Boolean),serverUploadedPolicy:String(sourcingSelection?.exploration?.serverUploadedPolicy||'skip')==='reanalyze'?'reanalyze':'skip',settingsOverride:{...sanitizeRouteHandoffSettingsV10156(routeSettings),coupangSupplementOnly:guidedSupplement,naverCollectionPolicy:guidedSupplement?'skip':'background'}};
    const routeGate=await ensureSearchCollectionRouteV10156({settings:routeSettings,keyword:currentKeyword(),handoffMessage:routeMessage});
    if(routeGate?.handedOff)return routeGate;
    await ensureCollectionIntegrationsBeforeStart({skipNaver:guidedSupplement});
    const selected = await selectedCollectionProfileSettings();
    const profile = selected.profileData;
    const override = selected.settingsOverride;
    const selectedProfileMaxPages=Math.max(1,Math.min(50,Number(override?.maxPagesPerKeyword)||1));
    activeCollectionSettingsOverride={...override,maxPagesPerKeyword:selectedProfileMaxPages,coupangSupplementOnly:guidedSupplement,naverCollectionPolicy:guidedSupplement?'skip':'background'};
    if (selectedProfileMaxPages > 1 || activeCollectionSettingsOverride.autoExtraPageEnabled===true) return runManualConfiguredScan({...profile,maxPagesPerKeyword:selectedProfileMaxPages,enabled:{...(profile.enabled||{}),maxPages:true}}, activeCollectionSettingsOverride);
    return runManualSinglePageScan(activeCollectionSettingsOverride);
  }

  async function runManualConfiguredScan(profile, settingsOverride) {
    if (state.busy) return;
    if (!(await waitForUi())) return;
    const keyword = currentKeyword();
    if (!keyword) return;
    state.busy = true;
    detect();
    setText('spx-status', '단건 수집 준비');
    beginProgressiveView(keyword, '설정값을 적용해 현재 키워드 수집을 준비합니다');
    setProgress(3, '단건 키워드 분석 준비 중...');
    try {
      /* [v2.5.1] 메인 단건 실행 함수에서도 상품 없음과 접근 차단을 먼저 분리합니다.
         명시적인 빈 결과는 대기열·차단 복구를 만들지 않고 현재 키워드의 정상 종료로 처리합니다. */
      const readiness = await waitForProducts(15000);
      if (readiness?.noResults) {
        if(activeCollectionSettingsOverride?.coupangSupplementOnly!==true);
        else ;
        setText('spx-status', '검색결과 없음');
        setHtml('spx-body', `<div class="spx-empty">“${esc(keyword)}”에 대한 검색결과가 없습니다.<br><br>접근 제한이 아니므로 대기 없이 현재 키워드 분석을 정상 종료합니다.</div>`);
        setProgress(100, '검색결과 없음 · 현재 키워드 정상 종료');
        state.autoStarted = false;
        return;
      }
      if (!readiness?.ready) {
        const blocked = readiness?.blocked === true;
        const error = new Error(blocked
          ? '쿠팡의 실제 접근 제한 또는 보안문자 화면이 감지되었습니다.'
          : '쿠팡 검색결과 로딩을 확인하지 못했습니다. 현재 탭에서 다시 시도해 주세요.');
        error.code = blocked ? 'COUPANG_BLOCKED' : SEARCH_LOAD_TIMEOUT;
        error.readiness = readiness;
        throw error;
      }
      const response = await runtimeMessage({
        type:'SPX_QUEUE_COLLECT_SELECTED_NOW',
        rows:[{ keyword, source:'사이드바 단건 키워드 분석', relation_type:'manual_sidebar' }],
        refreshType:'full',
        filterLabel:'사이드바 단건 키워드 분석',
        sourceLabel:'사이드바 단건 키워드 분석',
        stepOnce:true,
        sidebarManual:true,
        settingsOverride,
        collectionProfile:activeCollectionProfile,
        networkTarget:collectionNetworkTargetForSettingsV135(activeCollectionSettingsOverride||{}),
        dedicatedCurrentTab:collectionDedicatedCurrentTabV135(activeCollectionSettingsOverride||{}),
      });
      if (!response?.ok) throw new Error(response?.error || '단건 키워드 수집 시작 실패');
      activeRunId=String(response?.state?.runId||response?.runId||'');
      await refreshSidebarRunButton(response?.state).catch(()=>{});
      setText('spx-status', '단건 수집 시작');
      setDisplay('spx-auto', 'flex');
      ;
      ;
      setText('spx-auto-text', activeCollectionSettingsOverride.coupangSupplementOnly===true
        ? '현재 키워드를 단건 조건으로 수집합니다 API 0회 · 기존 네이버 값 유지 · 쿠팡만 수집 후 멈춥니다.'
        : '현재 키워드를 설정된 수집 기준 범위까지 수집하고 네이버 검색광고 데이터도 함께 갱신한 뒤 멈춥니다.');
      state.autoStarted = false;
      if(activeRunId)scheduleAutoRun(jitterMs(180,340));
    } catch (error) {
      if (error?.spxContextInvalidated) return;
      const lateReadiness=searchPageReadiness();
      if(lateReadiness.noResults){
        console.info('[SPX] 단건 키워드 빈 검색결과 정상 종료',lateReadiness.noResultSource||'본문 문구');
        if(activeCollectionSettingsOverride?.coupangSupplementOnly!==true);
        else ;
        setText('spx-status','검색결과 없음');
        setHtml('spx-body',`<div class="spx-empty">“${esc(keyword)}”에 대한 검색결과가 없습니다.<br><br>접근 제한이 아니므로 대기 없이 현재 키워드 분석을 정상 종료합니다.</div>`);
        setProgress(100,'검색결과 없음 · 현재 키워드 정상 종료');
        state.autoStarted=false;
        return;
      }
      if (error?.code === 'COUPANG_BLOCKED') {
        const manualVerification=error?.manualVerification===true||error?.readiness?.manualVerification===true;
        recoveryUiOwner=true;setText('spx-status','쿠팡 차단 감지 · 네트워크 모드 확인');startRecoveryCountdownMonitor();
        let blocked=null;
        try { blocked=await runtimeMessage({ type:'SPX_REPORT_BLOCKED', reason:error?.readiness?.blockReason || error.message, keyword, page:Math.max(1,Number(new URL(location.href).searchParams.get('page'))||1), url:location.href, manualVerification, blockSource:error?.blockSource||'main-page', collectionStage:String(activeStage?.name||''), networkTarget:explicitCollectionNetworkTargetV135(activeCollectionSettingsOverride), dedicatedTab:explicitDedicatedCurrentTabV135(activeCollectionSettingsOverride) }); } catch (_) {}
        if(blocked?.recoveryGuarded===true){
          recoveryUiOwner=false;setText('spx-status','수동 확인 필요');
          setHtml('spx-body','<div class="spx-empty">차단이 계속되고 있습니다.<br><br>자동 복구는 같은 차단에서 1회만 실행합니다. 현재 페이지를 확인한 뒤 필요하면 [IP↻]를 수동으로 눌러주세요.</div>');
          setProgress(100,'반복 사이트 데이터 정리 방지 · 현재 키워드 안전 중단');
        }else if(blocked?.autoResume===true){
          setHtml('spx-body','<div class="spx-empty">쿠팡 차단을 감지해 [IP↻] 수동 클릭과 같은 복구를 자동 실행했습니다.<br><br>차단 감지 → 바로 중단 → ♻ 1회 → 🧹 1회 → 설정 시간 비행기 모드 ON → OFF → 새 IP 확인 → 페이지 새로고침 F5 → 정상 확인 → 작업 재개 순서가 화면에 그대로 표시됩니다.</div>');
          startRecoveryCountdownMonitor();
        }else{
          recoveryUiOwner=false;
          const recoveryError=String(blocked?.error||'선택 네트워크/USB 테더링 상태를 확인하지 못해 IP 변경을 시작하지 못했습니다.');
          if(blocked?.systemNetwork===true){setText('spx-status','쿠팡 접근 제한 · 기본망 유지');setHtml('spx-body',`<div class="spx-empty">${esc(recoveryError)}<br><br>현재 분석만 중단했으며 공인 IP 변경은 실행하지 않았습니다.</div>`);setProgress(100,'기본 Windows 네트워크 · IP 변경 없음 · 현재 분석 중단');}
          else{setText('spx-status','쿠팡 차단 IP 복구 시작 실패');setHtml('spx-body',`<div class="spx-empty">${esc(recoveryError)}</div>`);setProgress(100,`쿠팡 차단 IP 복구 시작 실패 · ${recoveryError}`);}
        }
      } else {
        console.info('[SPX] 단건 키워드 수집 시작 실패', error?.code||error?.message||error);
        setText('spx-status', '단건 수집 실패');
        setHtml('spx-body', `<div class="spx-empty">${esc(error?.message || String(error))}</div>`);
      }
    } finally {
      state.busy = false;
      scheduleSidebarWinnerViewMetricsRefreshV426(80);
      detect();
    }
  }

  

  async function runManualSinglePageScan(settingsOverride = null) {
    if (state.busy) return;
    const keywordForIntent=currentKeyword();
    const localTaxonomy=SPX.keywordFilter?.classifyKeyword?.(keywordForIntent)||null;
    const effectiveResponse=await runtimeMessage({type:'SPX_KEYWORD_FILTER_CLASSIFY_EFFECTIVE',keyword:keywordForIntent,marketplace:'coupang'}).catch(()=>null);
    const taxonomy=effectiveResponse?.ok&&effectiveResponse?.data?.taxonomy?effectiveResponse.data.taxonomy:localTaxonomy;
    if(taxonomy?.brand_filter_excluded===true){
      const replacement=String(taxonomy?.filter_replacement_keyword||'').trim();
      ensureUi();setText('spx-status','브랜드 키워드 제외');
      setHtml('spx-body',`<div class="spx-empty">“${esc(keywordForIntent)}”은 브랜드 포함 키워드로 제외되어 있습니다.${replacement?`<br><br>브랜드를 뺀 수집 키워드: <b>${esc(replacement)}</b>`:''}</div>`);
      setProgress(100,replacement?`브랜드 제외 · 대체 ${replacement}`:'브랜드 키워드 · 수집 대상 제외');return;
    }
    if(taxonomy?.keyword_intent==='informational'||taxonomy?.keyword_intent==='food'||taxonomy?.is_shopping_keyword===false){
      const food=taxonomy?.keyword_intent==='food';
      await runtimeMessage({type:'SPX_EXCLUDE_INFORMATIONAL_KEYWORD',keyword:keywordForIntent,reason:taxonomy.reason||(food?'식품 제외 키워드':'정보 탐색형 키워드')}).catch(()=>null);
      ensureUi();
      setText('spx-status',food?'식품 키워드 제외':'검색형 키워드 제외');
      setHtml('spx-body',food?`<div class="spx-empty">“${esc(keywordForIntent)}”은 식품·건강식품 제외 기준에 해당합니다.<br><br>비식품 쇼핑 키워드만 수집하도록 제외 키워드 관리에 보존했습니다.</div>`:`<div class="spx-empty">“${esc(keywordForIntent)}”은 정보 탐색·방법 중심의 검색형 키워드입니다.<br><br>쇼핑성 키워드만 수집하도록 제외 키워드 관리에 보존했습니다.</div>`);
      setProgress(100,food?'식품 키워드 · 수집 대상 제외':'검색형 키워드 · 쇼핑 수집 대상 제외');
      return;
    }
    if (!(await waitForUi())) return;
    state.busy = true;
    localManualCompletedKeyword='';
    localManualScanActive = true;
    localManualAbortRequested = false;
    await refreshSidebarRunButton().catch(()=>{});
    activeCollectionSettingsOverride = settingsOverride;
    if (settingsOverride) SPX.setWinnerCriteria?.({monthlySalesMin:settingsOverride.winnerMonthlySalesMin,reviewMin:settingsOverride.winnerReviewMin,reviewMax:settingsOverride.winnerReviewMax,recentReviewMin:settingsOverride.winnerRecentReviewMin});
    detect();
    const t0 = performance.now();
    setText('spx-status', '분석 중');
    beginProgressiveView(state.keyword, '검색결과 상품 확인 중');
    try {
      const manualSettings=settingsOverride||await safeGetSettings();
      // v1.6.31: the Collector no longer calls any Naver source. Prevent an undefined
      // supplementOnly ReferenceError before SPX_SAVE and preserve actual Coupang products.
      const supplementOnly=true;
      /* v3.0.7.29: 쿠팡 상세 확인이 끝난 뒤 과거이력→후보→네이버를 차례로 시작하던
         직렬 대기를 제거합니다. 세 작업을 상품 DOM 분석과 동시에 시작하고, 최종 집계 직전에
         이미 도착한 결과를 한 번에 합칩니다. */
      const historyPromise=runtimeMessage({type:'SPX_HISTORY',keyword:state.keyword,limit:24}).catch((error)=>({ok:false,data:[],error:error?.message||String(error)}));
      const candidatePromise=runtimeMessage({type:'SPX_GET_CANDIDATE',keyword:state.keyword}).catch(()=>null);
      /* v1.6.21: no Naver lookup, prefetch or snapshot manipulation in Collector. */
      const naverPromise=Promise.resolve({ok:true,skipped:true,data:{}});
      const { res, candidates, relatedTerms, relatedDiscoveryTerms, externalMetrics, searchCategory, resultTotal, settings } = await collectPage('', null, {manualMode:true,detailConcurrency:manualSettings.manualDetailConcurrency});
      if(localManualAbortRequested)throw normalEnd('MANUAL_STOPPED','사용자가 단건 수집을 중단했습니다.');
      state.raw = res.items;
      state.candidates = candidates;
      setProgress(82, '최종 분석 계산 중...');
      const [histResp,candResp,naverResult]=await Promise.all([historyPromise,candidatePromise,naverPromise]);
      if(localManualAbortRequested)throw normalEnd('MANUAL_STOPPED','사용자가 단건 수집을 중단했습니다.');
      const history = (histResp?.data || []).filter((r) => r.date !== SPX.util.today());
      /* [v1.2.1] 단건 수집도 이 키워드가 등록된 탐색 카테고리를 조회해 지표에 보존한다 */
      const candRec = candResp?.data || null;
      const monthlySearch={};
      const mergedExternalMetrics={...(externalMetrics||{})};
      const m = SPX.aggregate(state.keyword, res.items, 'coupang', settings.minSample, {
        history, resultTotal, organicSampleSize: settings.organicSampleSize,
        categoryId: searchCategory?.categoryId || candRec?.explore_category || null,
        categoryPath: searchCategory?.categoryPath || null,
        categorySource: searchCategory?.source || null,
        categoryLabel: candRec?.explore_category_label || null,
        relatedTerms,
        namingInsights: SPX.discovery.extractNamingInsights?.(state.keyword, res.items, relatedTerms),
        externalMetrics:mergedExternalMetrics,
        monthlyRevenue: externalMetrics?.estimated_monthly_revenue ?? null,
        monthlySearchPc:monthlySearch?.monthly_search_pc ?? null,
        monthlySearchMobile:monthlySearch?.monthly_search_mobile ?? null,
        monthlySearchVolume:monthlySearch?.monthly_search_volume ?? null,
        monthlySearchRawPc:monthlySearch?.monthly_search_raw_pc ?? null,
        monthlySearchRawMobile:monthlySearch?.monthly_search_raw_mobile ?? null,
        monthlySearchKeyword:monthlySearch?.monthly_search_keyword ?? state.keyword,
        monthlySearchSource:monthlySearch?.monthly_search_source ?? null,
        monthlySearchCollectedAt:monthlySearch?.monthly_search_collected_at ?? null,
        monthlySearchStatus:monthlySearch?.monthly_search_status ?? null,
        monthlySearchError:monthlySearch?.monthly_search_error ?? null,
        monthlySearchCacheExpiresAt:monthlySearch?.monthly_search_cache_expires_at ?? null,
        monthlySearchRawResponse:monthlySearch?.monthly_search_raw_response ?? null,
        marketKeyword:(candRec?.market_keyword && candRec?.keyword_role !== '분석키워드') ? candRec.market_keyword : null, sourceKeyword:candRec?.source_keyword || state.keyword, sourceKeywords:candRec?.source_keywords || [candRec?.source_keyword || state.keyword],
      });
      /* [v2.7.6] 네이버 검색광고·데이터랩 결과는 aggregate 생성 옵션에만 의존하지 않고
         최종 저장 객체에도 명시적으로 병합합니다. 파서→서비스워커→로컬/서버→관리표 중
         어느 단계에서도 월검색량·12개월 추이·계절성이 빠지지 않도록 하는 마지막 안전망입니다. */
      if (m && monthlySearch && typeof monthlySearch === 'object' && Object.keys(monthlySearch).length>0) {
        const naverFields = [
          'monthly_search_pc','monthly_search_mobile','monthly_search_volume','monthly_search_raw_pc','monthly_search_raw_mobile',
          'monthly_search_keyword','monthly_search_source','monthly_search_volume_source','monthly_search_collected_at','monthly_search_status',
          'monthly_search_error','monthly_search_cache_expires_at','naver_competition_index','naver_monthly_pc_clicks','naver_monthly_mobile_clicks',
          'naver_pc_ctr','naver_mobile_ctr','naver_ad_depth','naver_searchad_status','naver_searchad_error','naver_searchad_collected_at',
          'naver_datalab_status','naver_datalab_error','naver_datalab_collected_at','naver_shopping_status','naver_shopping_error',
          'naver_shopping_collected_at','naver_shopping_category_id','shopping_search_trend_12m','naver_completion_status',
          'naver_completion_reason','monthly_search_trend_12m','monthly_search_trend_source','monthly_search_trend_status',
          'monthly_search_trend_error','monthly_search_trend_collected_at','monthly_demand_period','naver_peak_month','naver_demand_range','naver_preregistration_period','seasonality_status'
        ];
        for (const field of naverFields) if (Object.prototype.hasOwnProperty.call(monthlySearch, field)) m[field] = monthlySearch[field];
        m.external_metrics = { ...(m.external_metrics || {}), ...monthlySearch, detected:true, source:monthlySearch.monthly_search_source || 'naver_datalab_searchad_hybrid' };
      }
      /* [v1.4.9] 자동수집 경로와 동일하게, 효자상품 후보에 실측 이력 기반 최근리뷰·월매출을 채운다. */
      if (m && Array.isArray(m.sample_products) && m.sample_products.length) {
        m.sample_products = SPX.enrichSampleProductsWithHistory(
          m.sample_products, history, { analysisDate: SPX.util.today() }
        );
      }
      if (!m) throw new Error(`표본 ${res.items.length}개로 부족합니다. 더 넓은 키워드를 사용하세요.`);
      /* [v1.5.2] 단건 분석 화면에서도 서버 저장과 동일한 효자상품 확산지표를 즉시 계산합니다.
         첫 수집의 월판매는 리뷰 대체지표 기반 추정이며, 재수집 이력이 생기면 백그라운드 저장 단계에서 실측 이력으로 다시 계산됩니다. */
      const manualMarketKeyword = m.market_keyword || '';
      const manualMarketClusterKey = SPX.util?.canonicalKeyword?.(manualMarketKeyword) || null;
      const manualSourceKeyword = candRec?.source_keyword || state.keyword;
      const manualSourceKeywords = candRec?.source_keywords || [manualSourceKeyword];
      const manualSnapshots = SPX.buildProductSnapshots?.(res.items, [], {
        analysisDate: SPX.util.today(),
        maxProducts: settings.sourceDataMaxProducts || 200,
        resultTotal,
        marketKeyword: manualMarketKeyword,
        marketClusterKey: manualMarketClusterKey,
        sourceKeyword: manualSourceKeyword,
        sourceKeywords: manualSourceKeywords,
        winnerThreshold: SPX.WINNER_MONTHLY_SALES_THRESHOLD || 200,
        parserStrategy: res.strategy || null,
      }) || [];
      const manualWinnerMetrics = SPX.computeWinnerMetrics?.(manualSnapshots, {
        targetOrganic: settings.sourceDataTargetOrganic || 60,
        maxProducts: settings.sourceDataMaxProducts || 200,
        resultTotal,
        marketKeyword: manualMarketKeyword,
        marketClusterKey: manualMarketClusterKey,
        sourceKeyword: manualSourceKeyword,
        sourceKeywords: manualSourceKeywords,
        winnerThreshold: SPX.WINNER_MONTHLY_SALES_THRESHOLD || 200,
      }) || {};
      Object.assign(m, manualWinnerMetrics, { collection_parser_strategy: res.strategy || null });
      SPX.recalculateSmartPageGrade?.(m);
      SPX.attachSidebarMetricDetails?.(m);
      const directServerDisplay=settings.autoUpload===true&&Boolean(settings.supabaseUrl&&settings.serviceKey);
      renderProgressiveAggregate(m, {
        phase:3,
        finalizing:true,
        productCount:res.items.length,
        stage:directServerDisplay?'분석 완료 · 서버 업로드 중':'분석 완료 · 로컬 DB 저장 중',
      });
      setProgress(96, `등급 계산 완료 · ${m.grade || '-'}등급 · 효자상품 ${m.winner_count ?? 0}개`);
      /* [v2.0] "현재 키워드 분석"은 지금 검색한 키워드 자체의 분석만 즉시 끝내야 한다.
         발견된 새 후보 키워드를 큐에 등록하는 건 별개의 백그라운드 작업으로 분리 —
         기다리지 않고(await 제거) 흘려보내서, 후보가 많아도 현재 키워드 분석 속도에
         영향을 주지 않는다. */
      // Related search originals are stored even when product auto-discovery is disabled.
      if(manualSettings.coupangSupplementOnly!==true && ((settings.autoDiscover && candidates.length)||(relatedDiscoveryTerms||relatedTerms||[]).length))
        runtimeMessage({ type:'SPX_QUEUE_ADD', candidates:settings.autoDiscover?candidates:[], relatedTerms:relatedDiscoveryTerms||relatedTerms, sourceKeyword:state.keyword }).catch(()=>{});
      if (!SPX.isEligibleGrade?.(m) && m.evaluation_hold!==true && m.needs_recollect!==true) {
        const discarded = await runtimeMessage({ type: 'SPX_DISCARD_BELOW_B', keyword: state.keyword, score: m.sourcing_score, aggregate: m });
        state.agg = m;
        state.key = null;
        state.adminOverrideUploaded=false;
        const reason = (m.grade_block_reasons || []).length
          ? `${m.evaluation_hold ? '평가 보류' : '후보 제외'} · ${(m.grade_block_reasons || []).join(' · ')}`
          : `최종 합산 ${m.grade_score ?? '-'}점 · 4점 미만`;
        const lightIndexLabel=discarded?.indexedToServer===true?'경량 색인 저장':discarded?.indexQueued===true?'경량 색인 반영 대기':'경량 색인 미반영';
        setProgress(100, `${reason} · 전체데이터 미업로드 · ${lightIndexLabel}`, `${((performance.now() - t0) / 1000).toFixed(1)}s`);
        setText('spx-status', m.evaluation_hold ? '평가 보류' : '기준 미달');
        setDisabled('spx-upload', true);
        setText('spx-upload', discarded?.indexedToServer===true?'기준 미달 · 경량 색인 저장':discarded?.indexQueued===true?'기준 미달 · 색인 반영 대기':'기준 미달 · 전체데이터 미업로드');
        const adminButton=getUiElement('spx-admin-override-upload',{repair:false});if(adminButton){adminButton.hidden=false;adminButton.disabled=false;adminButton.textContent='관리자 통과 · 서버 올리기';}
        renderAgg(m,candidates);
        setHtml('spx-body', getUiElement('spx-body',{repair:false})?.innerHTML + `<div class="spx-admin-override-reason"><b>업로드 후보 탈락</b><span>${esc(reason)}</span><small>전체 수집데이터는 올리지 않고 서버에는 미달 색인만 저장합니다. 필요하면 아래 ‘관리자 통과 · 서버 올리기’로 전체데이터 업로드가 가능합니다.</small></div>`);
        if(discarded?.belowCriteria===true)await recordTabSessionEvent('manual-below-criteria',{processed:1,belowCriteria:1},{eventId:`manual-below-criteria:${state.keyword}:${Math.round(t0)}`});
        showDbInfo(discarded?.stats);
        return;
      }
      setProgress(92, directServerDisplay?'분석 완료 · 서버 업로드 중':'분석 완료 · 로컬 DB 저장 중...');
      const saved = await runtimeMessage({ type: 'SPX_SAVE', keyword: state.keyword, products: res.items, aggregate: m, coupangSupplementOnly:supplementOnly });
      if (!saved?.ok || saved?.excluded) throw new Error(saved?.error || saved?.reason || '저장 실패');
      state.agg = saved.aggregate || m;
      state.key = saved.key || null;
      renderAgg(state.agg, candidates);
      const analysisConclusion=`${res.items.length}건 분석 · 쿠팡 수집 완료`;
      await applySidebarUploadState({
        localKey:saved.key || null,
        autoUploadEnabled:saved.autoUploadEnabled === true,
        uploadedToServer:saved.uploadedToServer === true,
        uploadPending:saved.uploadPending !== false,
        uploadRetryQueued:saved.uploadRetryQueued===true,
        uploadRetryAt:Number(saved.uploadRetryAt)||0,
        uploadError:saved.uploadError || null,
        uploadDeferredForNaver:saved.uploadDeferredForNaver===true,
      }, state.agg);
      const finalUploadConclusion=finalUploadConclusionV10155(saved);
      setProgress(100,`${analysisConclusion} · ${finalUploadConclusion} · 후보 ${candidates.length}개`,`${((performance.now()-t0)/1000).toFixed(1)}s`);
      setText('spx-status',saved.uploadedToServer===true?'완료 · 서버 업로드 완료':(saved.uploadRetryQueued===true?'완료 · 자동 재업로드 대기':(saved.uploadPending!==false?'완료 · 업로드 대기':'완료 · 로컬 저장')));
      if(saved.uploadRetryQueued===true&&saved.uploadedToServer!==true){
        const retryAt=Math.max(0,Number(saved.uploadRetryAt)||0);
        const remainSec=retryAt>0?Math.max(1,Math.ceil((retryAt-Date.now())/1000)):null;
        setProgress(100,`${analysisConclusion} · 로컬 저장 완료 · 서버 업로드 실패 → 자동 재업로드${remainSec?` 약 ${remainSec}초 후`:''} · 상품 재수집 없음 · 후보 ${candidates.length}개`,`${((performance.now()-t0)/1000).toFixed(1)}s`);
        setText('spx-status','서버 자동 재업로드 대기');
      }
      if(saved.uploadedToServer===true)await recordTabSessionEvent('manual-uploaded',{processed:1,uploaded:1},{eventId:`manual-uploaded:${state.keyword}:${Math.round(t0)}`});
      else if(saved.uploadPending!==false)await recordTabSessionEvent('manual-upload-pending',{processed:1,uploadPending:1},{eventId:`manual-upload-pending:${state.keyword}:${Math.round(t0)}`});
      showDbInfo(saved.stats);
    } catch (e) {
      finishStage('중단');
      if (e?.spxContextInvalidated) return;
      if(e?.spxNormalEnd&&e?.code==='MANUAL_STOPPED'){ensureUi();setText('spx-status','단건 수집 중단');setProgress(100,'사용자가 단건 수집을 중단했습니다.');setHtml('spx-body','<div class="spx-empty">단건 수집을 중단했습니다.</div>');return;}
      if(e?.code==='COUPANG_BLOCKED'){
        ensureUi();const manualVerification=e?.manualVerification===true||e?.readiness?.manualVerification===true;recoveryUiOwner=true;setText('spx-status','쿠팡 차단 감지 · 네트워크 모드 확인');startRecoveryCountdownMonitor();
        let blocked=null;try{blocked=await runtimeMessage({type:'SPX_REPORT_BLOCKED',reason:e?.readiness?.blockReason||e.message,keyword:state.keyword,page:Math.max(1,Number(new URL(location.href).searchParams.get('page'))||1),url:location.href,manualVerification,blockSource:e?.blockSource||'main-page',collectionStage:String(activeStage?.name||''),networkTarget:explicitCollectionNetworkTargetV135(activeCollectionSettingsOverride),dedicatedTab:explicitDedicatedCurrentTabV135(activeCollectionSettingsOverride)});}catch(_){}
        if(blocked?.recoveryGuarded===true){recoveryUiOwner=false;setText('spx-status','수동 확인 필요');setHtml('spx-body','<div class="spx-empty">차단이 계속되고 있습니다.<br><br>자동 복구는 같은 차단에서 1회만 실행합니다. 현재 페이지를 확인한 뒤 필요하면 [IP↻]를 수동으로 눌러주세요.</div>');setProgress(100,'반복 사이트 데이터 정리 방지 · 현재 키워드 안전 중단');return;}
        if(blocked?.autoResume===true){setHtml('spx-body','<div class="spx-empty">[IP↻] 수동 클릭과 같은 복구를 자동 실행합니다. 차단 감지 → 바로 중단 → ♻ 1회 → 🧹 1회 → 설정 시간 비행기 모드 ON → OFF → 새 IP 확인 → 페이지 새로고침 F5 → 정상 확인 → 작업 재개 순서가 화면에 그대로 표시됩니다.</div>');startRecoveryCountdownMonitor();return;}
        recoveryUiOwner=false;const recoveryError=String(blocked?.error||'선택 네트워크/USB 테더링 상태를 확인하지 못해 IP 변경을 시작하지 못했습니다.');if(blocked?.systemNetwork===true){setText('spx-status','쿠팡 접근 제한 · 기본망 유지');setHtml('spx-body',`<div class="spx-empty">${esc(recoveryError)}<br><br>현재 분석만 중단했으며 공인 IP 변경은 실행하지 않았습니다.</div>`);setProgress(100,'기본 Windows 네트워크 · IP 변경 없음 · 현재 분석 중단');}else{setText('spx-status','쿠팡 차단 IP 복구 시작 실패');setHtml('spx-body',`<div class="spx-empty">${esc(recoveryError)}</div>`);setProgress(100,`쿠팡 차단 IP 복구 시작 실패 · ${recoveryError}`);}return;
      }
      console.error('[SPX] 분석 실패', e);
      ensureUi();
      setText('spx-status', '오류');
      setClass('spx-dbstate', 'spx-err');
      setText('spx-dbstate', `● ${e.message}`);
      setHtml('spx-body', `<div class="spx-empty">${esc(e.message)}<br><br>F12 콘솔의 [SPX] 기록을 확인하세요.</div>`);
      await recordTabSessionEvent('manual-failed',{processed:1,failed:1},{eventId:`manual-failed:${state.keyword}:${Math.round(t0)}`});
    } finally {
      activeCollectionSettingsOverride = null;
      try { const base = await getSettings(); SPX.setWinnerCriteria?.({monthlySalesMin:base.winnerMonthlySalesMin,reviewMin:base.winnerReviewMin,reviewMax:base.winnerReviewMax,recentReviewMin:base.winnerRecentReviewMin}); } catch (_) {}
      state.busy = false;
      scheduleSidebarWinnerViewMetricsRefreshV426(80);
      localManualScanActive = false;
      localManualAbortRequested = false;
      localManualCompletedKeyword=currentKeyword();
      await refreshSidebarRunButton().catch(()=>{});
      detect();
    }
  }

  async function restorePendingUploadForVisibleKeywordV107(){
    const visibleKeyword=String(currentKeyword()||state.keyword||'').replace(/\s+/g,' ').trim();
    try{
      const request=visibleKeyword
        ? {type:'SPX_SIDEBAR_COLLECTION_RESTORE',keyword:visibleKeyword,marketplace:'coupang',localOnly:true}
        : {type:'SPX_SIDEBAR_COLLECTION_RESTORE',keyword:'',marketplace:'coupang',localOnly:true,latestPending:true};
      const response=await runtimeMessage(request);
      const row=response?.ok&&response?.source==='local'&&response?.data&&typeof response.data==='object'?response.data:null;
      if(!row)return false;
      const status=String(row.status||'').toLowerCase();
      const uploadError=String(row.upload_error||row.uploadError||'').replace(/\s+/g,' ').trim();
      const pending=row.upload_pending===true||status==='pending'||Boolean(uploadError);
      if(!pending||row.uploadedToServer===true||status==='uploaded')return false;
      const restoredKeyword=String(row.keyword||visibleKeyword||'').replace(/\s+/g,' ').trim();
      if(!restoredKeyword)return false;
      state.keyword=restoredKeyword;
      state.agg={...row};
      state.key=String(row.k||'').trim()||null;
      try{renderAgg(state.agg,[]);}catch(_){}
      await applySidebarUploadState({
        localKey:state.key,
        autoUploadEnabled:true,
        uploadedToServer:false,
        uploadPending:true,
        uploadRetryQueued:false,
        uploadError:uploadError||'이전 서버 업로드가 완료되지 않았습니다.'
      },state.agg);
      setText('spx-status',`서버 업로드 대기 복원 · ${restoredKeyword}`);
      setProgress(100,`${restoredKeyword} 이전 수집결과 복원 완료 · 상품 재수집 없이 서버 재업로드 가능`);
      return true;
    }catch(error){
      console.debug('[SPX v1.0.7] 로컬 업로드 대기 복원 생략',error?.message||error);
      return false;
    }
  }

  function sidebarCategoryOnlyMissingV10151(aggregate={}) {
    const values=[];
    for(const list of [aggregate?.required_missing_fields,aggregate?.missing_core_fields,aggregate?.missing_grade_fields,aggregate?.manager_missing_fields_v4195,aggregate?.all_missing_fields]){
      if(Array.isArray(list))for(const value of list){const text=String(value||'').trim();if(text)values.push(text);}
    }
    const unique=[...new Set(values)];
    return unique.length>0&&unique.every((value)=>/category|카테고리/i.test(value));
  }

  function friendlyUploadFailureV118(raw='',diagnostic=null){
    const text=String(raw||diagnostic?.detail||'').replace(/\s+/g,' ').trim();
    if(diagnostic?.userMessage)return String(diagnostic.userMessage);
    if(/\b503\b|service unavailable/i.test(text))return '서버 연결 지연 · HTTP 503 · 로컬에 보관 중';
    if(/db connection|database connection|connection pool|too many clients|max_connections|connection timeout/i.test(text))return 'DB 연결 지연 · 로컬에 보관 중';
    if(/timeout|timed out|deadline|시간\s*초과|응답\s*지연/i.test(text))return '서버 응답 지연 · 로컬에 보관 중';
    if(/service worker|message port closed|receiving end does not exist|extension context invalidated/i.test(text))return '확장프로그램 전송 중단 · 로컬에 보관 중';
    if(/failed to fetch|network error|network_fetch_failed|internet disconnected|connection reset|name not resolved/i.test(text))return '서버 연결 실패 · 로컬에 보관 중';
    if(/\b401\b|\b403\b|authorization|unauthorized|forbidden|apikey|jwt|permission denied/i.test(text))return '서버 인증 실패 · 서버 설정 확인 필요';
    if(/canonical sync.*pending|현재 run canonical sync 대기/i.test(text))return '서버 반영 확인 지연 · 로컬에 보관 중';
    if(/rpc|pgrst202|42883|function .* does not exist/i.test(text))return '서버 처리 함수 오류 · RPC 확인 필요';
    return text?`서버 업로드 실패 · ${text.slice(0,140)}`:'서버 업로드 실패 · 로컬에 보관 중';
  }
  async function readUploadDiagnosticV118(){
    try{const response=await runtimeMessage({type:'SPX_GET_UPLOAD_DIAGNOSTIC_V118'});return response?.ok===true?response.data:null;}catch(_){return null;}
  }
  function uploadDiagnosticStageLabelV118(stage=''){
    return ({UPLOAD_STAGE_PREPARE:'업로드 요청 준비',UPLOAD_STAGE_FETCH_START:'서버 전송 시작',UPLOAD_STAGE_HTTP_RESPONSE:'서버 HTTP 응답',UPLOAD_STAGE_JSON_PARSE:'서버 응답 해석',UPLOAD_STAGE_SERVER_ACK:'서버 저장 확인',UPLOAD_STAGE_LOCAL_FINALIZE:'로컬 상태 정리'})[String(stage||'')]||'';
  }

  let pendingUploadBusyV10151=false;
  async function runLatestPendingUploadV10151(){
    if(contextInvalidated||pendingUploadBusyV10151||!(await requireUi()))return false;
    const icon=getUiElement('spx-pending-upload-now',{repair:false});
    pendingUploadBusyV10151=true;if(icon)icon.disabled=true;
    setDisabled('spx-upload',true);setText('spx-upload','업로드 대기 정리 준비...');
    setClass('spx-dbstate','spx-ok');setText('spx-dbstate','● 로컬 업로드 대기 확인 중 · 상품 재수집 없음 · 서버 사전조회 없음');
    const total={uploaded:0,finalized:0,acked:0,superseded:0,conflict:0,failed:0,held:0};
    try{
      const preview=await runtimeMessage({type:'SPX_PENDING_UPLOAD_REPAIR_PREVIEW'});
      if(preview?.ok!==true)throw new Error(preview?.error||'업로드 대기 현황 확인 실패');
      const initial=Math.max(0,Number(preview.total)||0),processableInitial=Math.max(0,Number(preview.processable??initial)||0);
      if(!initial){setDisabled('spx-upload',!state.agg);setText('spx-upload',state.agg?'서버 올리기':'먼저 분석하세요');setText('spx-dbstate','● 서버 업로드 대기 없음');return true;}
      if(!processableInitial){setDisabled('spx-upload',false);setText('spx-upload','업로드 대기 없음');setClass('spx-dbstate','spx-ok');setText('spx-dbstate','● 서버 업로드 가능한 로컬 대기 0건');return false;}
      let lastRemaining=processableInitial,loops=0;
      while(!contextInvalidated&&loops<1000){
        loops++;
        setText('spx-upload',`업로드 대기 정리 중 ${fmt(Math.max(0,processableInitial-lastRemaining))}/${fmt(processableInitial)}`);
        setText('spx-dbstate',`● 업로드 대기 ${fmt(lastRemaining)}건 · 서버 확인/전송 중`);
        const response=await runtimeMessage({type:'SPX_PENDING_UPLOAD_REPAIR_BATCH',limit:12});
        if(response?.ok!==true)throw new Error(response?.error||'업로드 대기 정리 실패');
        const data=response.data||{},sum=data.summary||{};
        for(const key of Object.keys(total))total[key]+=Math.max(0,Number(sum[key])||0);
        const remaining=Math.max(0,Number(data.remaining)||0),allPending=Math.max(0,Number(data.totalPendingAfter??remaining)||0);
        const transient=(Array.isArray(data.results)?data.results:[]).find((row)=>row?.transient===true);
        if(transient){setDisabled('spx-upload',false);setText('spx-upload','서버 안정 후 재전송');setClass('spx-dbstate','spx-err');setText('spx-dbstate',`● 서버 일시 장애 · 처리 ${fmt(processableInitial-remaining)}건 · 남음 ${fmt(allPending)}건 · 자동 중단`);break;}
        if(remaining<=0){
          await refreshDbInfo().catch(()=>{});
          if(allPending>0){setDisabled('spx-upload',false);setText('spx-upload','업로드 대기 재확인');setClass('spx-dbstate','spx-ok');setText('spx-dbstate',`● 처리 완료 · 서버 업로드 ${fmt(total.uploaded+total.acked+total.finalized+total.superseded)} · 남은 업로드 대기 ${fmt(allPending)}`);}
          else{setDisabled('spx-upload',true);setText('spx-upload','업로드 대기 정리 완료 ✓');setClass('spx-dbstate','spx-ok');setText('spx-dbstate',`● 업로드 대기 0건 · 업로드 ${fmt(total.uploaded)} · 서버완료확인 ${fmt(total.acked+total.finalized+total.superseded)}`);}
          await recordTabSessionEvent('pending-upload-cleanup',{uploaded:Math.max(0,total.uploaded+total.finalized+total.acked+total.superseded),uploadPending:-Math.max(0,initial-allPending)},{eventId:`pending-upload-cleanup:${Date.now()}`}).catch(()=>{});
          return allPending===0;
        }
        if(remaining>=lastRemaining){setDisabled('spx-upload',false);setText('spx-upload','업로드 대기 재확인');setClass('spx-dbstate','spx-err');setText('spx-dbstate',`● 서버 업로드 재확인 필요 · 서버 업로드 가능 ${fmt(remaining)}건`);break;}
        lastRemaining=remaining;await new Promise((resolve)=>setTimeout(resolve,350));
      }
      await refreshDbInfo().catch(()=>{});return false;
    }catch(error){
      if(error?.spxContextInvalidated)return false;
      const diagnostic=await readUploadDiagnosticV118(),friendly=friendlyUploadFailureV118(error?.message||error,diagnostic),stage=uploadDiagnosticStageLabelV118(diagnostic?.stage);
      setDisabled('spx-upload',false);setText('spx-upload','업로드 대기 재전송');setClass('spx-dbstate','spx-err');setText('spx-dbstate',`● 업로드 대기 정리 중단 · ${friendly}${stage?` · 단계: ${stage}`:''}`);return false;
    }finally{pendingUploadBusyV10151=false;if(icon&&icon.isConnected)icon.disabled=false;}
  }


  function finalUploadConclusionV10155(saved={}){
    if(saved?.uploadedToServer===true)return '로컬 저장 완료 · 서버 업로드 완료';
    if(saved?.uploadRetryQueued===true)return '로컬 저장 완료 · 서버 업로드 실패 → 자동 재업로드 대기';
    if(saved?.uploadPending!==false)return saved?.autoUploadEnabled===true?'로컬 저장 완료 · 서버 업로드 실패 → 업로드 대기':'로컬 저장 완료 · 업로드 대기';
    return '로컬 저장 완료';
  }

  async function applySidebarUploadState(result = {}, aggregate = state.agg) {
    const settings = await safeGetSettings().catch(() => ({}));
    const autoUploadEnabled = result.autoUploadEnabled === true || settings.autoUpload === true;
    syncSidebarAutoUploadSetting({ ...settings, autoUpload:autoUploadEnabled }).catch(() => {});
    const adminButton=getUiElement('spx-admin-override-upload',{repair:false});
    if (!SPX.isEligibleGrade?.(aggregate)) {
      setDisabled('spx-upload', true);
      setText('spx-upload', '기준 미달 · 경량 색인 저장');
      if(adminButton){adminButton.hidden=false;adminButton.disabled=!aggregate||state.adminOverrideUploaded===true;adminButton.textContent=state.adminOverrideUploaded?'관리자 통과 완료 ✓':'관리자 통과 · 서버 올리기';}
      return;
    }
    if(adminButton){adminButton.hidden=true;adminButton.disabled=true;}
    if (result.localKey) state.key = result.localKey;
    const uploadButton=getUiElement('spx-upload',{repair:false});
    if(result.uploadedToServer!==true&&(result.uploadDeferredForNaver===true||String(aggregate?.naver_completion_status||'')==='enrichment_pending'&&aggregate?.upload_deferred_for_naver===true)){
      setDisabled('spx-upload',false);
      setText('spx-upload','서버 올리기');
      setClass('spx-dbstate','spx-ok');
      setText('spx-dbstate','● 네이버 후속 수집 중 · 현재 결과는 바로 업로드 가능');
      if(uploadButton)uploadButton.title='네이버 일부 자료가 부족해도 현재 쿠팡 결과를 먼저 서버에 올릴 수 있습니다.';
      return;
    }
    if (result.uploadedToServer === true) {
      setDisabled('spx-upload', true);
      setText('spx-upload', '업로드 완료 ✓');
      setClass('spx-dbstate', 'spx-ok');
      setText('spx-dbstate', String(aggregate?.naver_completion_status||'')==='enrichment_pending'?'● 서버 반영됨 후속 수집 중':'● 서버 반영됨');
      removeDiscoveredKeywordFromSidebar(state.keyword);
      return;
    }
    if(result.uploadRetryQueued===true){
      const retryAt=Math.max(0,Number(result.uploadRetryAt)||0);
      const remainSec=retryAt>0?Math.max(1,Math.ceil((retryAt-Date.now())/1000)):null;
      setDisabled('spx-upload', true);
      setText('spx-upload','자동 재업로드 대기');
      setClass('spx-dbstate','spx-ok');
      setText('spx-dbstate',remainSec
        ? `● 서버 자동 재업로드 예약 · 약 ${remainSec}초 후 1회 재시도 · 로컬DB 안전 저장 · 상품 재수집 없음`
        : '● 서버 자동 재업로드 예약 · 로컬DB 안전 저장 · 상품 재수집 없음');
      setText('spx-status','서버 자동 재업로드 대기');
      return;
    }
    if ((aggregate?.needs_recollect === true || aggregate?.status === 'needs_recollect') && !sidebarCategoryOnlyMissingV10151(aggregate)) {
      setDisabled('spx-upload', true);
      setText('spx-upload', '입력 재수집 후 올리기');
      setClass('spx-dbstate', 'spx-err');
      setText('spx-dbstate', '● 재수집 입력 필요');
      return;
    }
    if(sidebarCategoryOnlyMissingV10151(aggregate)){
      setDisabled('spx-upload',false);
      setText('spx-upload','카테고리 미확인 · 서버 올리기');
      setClass('spx-dbstate','spx-ok');
      setText('spx-dbstate','● 카테고리 미수집 · 현재 결과 서버 업로드 가능');
      if(uploadButton)uploadButton.title='카테고리가 아직 없어도 현재 수집 결과는 서버에 업로드합니다.';
      return;
    }
    setDisabled('spx-upload', false);
    const retry = Boolean(result.uploadError);
    const uploadError=String(result.uploadError||'').replace(/\s+/g,' ').trim();
    const diagnostic=retry?await readUploadDiagnosticV118():null;
    const friendly=retry?friendlyUploadFailureV118(uploadError,diagnostic):'';
    const stage=retry?uploadDiagnosticStageLabelV118(diagnostic?.stage):'';
    setText('spx-upload', retry ? '서버 재업로드' : '서버 올리기');
    setClass('spx-dbstate', retry ? 'spx-err' : 'spx-ok');
    setText('spx-dbstate', retry
      ? `● ${friendly} · 업로드 대기${stage?` · 단계: ${stage}`:''}`
      : `● 업로드 대기${autoUploadEnabled ? ' · 직접 재시도 가능' : ''}`);
    if(uploadButton)uploadButton.title=retry?`서버 업로드만 다시 시도합니다. 로컬 수집 결과는 보존되어 있습니다.${stage?` 실패 단계: ${stage}.`:''}${uploadError?` 상세: ${uploadError}`:''}`:`현재 ${aggregate.grade||'-'}등급 결과를 서버에 업로드합니다.`;
  }

  async function runAdminOverrideUpload(){
    const aggregate=state.agg;
    if(contextInvalidated||!aggregate||SPX.isEligibleGrade?.(aggregate)||!(await requireUi()))return;
    const reasons=[...(aggregate.grade_block_reasons||[]),aggregate.evaluation_status].filter(Boolean).join(' · ')||'기준 미달';
    const reason=window.prompt(`현재 키워드: ${state.keyword||aggregate.keyword||'-'}\n탈락 사유: ${reasons}\n\n서버 관리자 통과 사유를 입력하세요.`,`고검색량·사업성 수동 검토 통과`);
    if(reason===null)return;
    if(!window.confirm('원래 등급과 탈락 사유를 보존한 채 서버에 관리자 통과로 올릴까요?'))return;
    const button=getUiElement('spx-admin-override-upload',{repair:false});if(button){button.disabled=true;button.textContent='관리자 통과 업로드 중...';}
    try{
      SPX.attachSidebarMetricDetails?.(aggregate);
      const response=await runtimeMessage({type:'SPX_UPLOAD_ADMIN_OVERRIDE',payload:SPX.sanitize(aggregate),localKey:state.key||null,overrideReason:String(reason||'관리자 수동 통과 업로드')});
      if(!response?.ok)throw new Error(response?.error||'관리자 통과 업로드 실패');
      state.adminOverrideUploaded=true;
      if(button){button.hidden=false;button.disabled=true;button.textContent='관리자 통과 완료 ✓';}
      setClass('spx-dbstate','spx-ok');setText('spx-dbstate','● 관리자 통과 · 서버 반영됨');
      removeDiscoveredKeywordFromSidebar(state.keyword);
      return true;
    }catch(error){if(button){button.disabled=false;button.textContent='관리자 통과 · 다시 올리기';}setClass('spx-dbstate','spx-err');setText('spx-dbstate',`● 관리자 통과 실패 · ${error?.message||String(error)}`);return false;}
  }

  async function runUpload() {
    if (contextInvalidated || !SPX.isEligibleGrade?.(state.agg) || !(await requireUi())) return;
    if (!setDisabled('spx-upload', true)) return;
    setText('spx-upload', '업로드 중...');
    try {
      SPX.attachSidebarMetricDetails?.(state.agg);
      const resp = await runtimeMessage({ type: 'SPX_UPLOAD', payload: SPX.sanitize(state.agg), localKey:state.key || null });
      if (!resp?.ok) throw new Error(resp?.error || '업로드 실패');
      if(resp.uploadDeferredForNaver===true){
        setDisabled('spx-upload',false);
        setText('spx-upload','서버 올리기');
        setClass('spx-dbstate','spx-ok');
        setText('spx-dbstate','● 네이버 후속 수집 중 · 현재 결과 즉시 업로드 가능');
        return true;
      }
      if(resp.uploadRetryQueued===true){
        setDisabled('spx-upload',false);
        setText('spx-upload','자동 재업로드 대기');
        setClass('spx-dbstate','spx-ok');
        setText('spx-dbstate','● 서버 재업로드 대기 · 로컬DB 안전 저장 · 상품 재수집 없음');
        return true;
      }
      if (state.key && resp?.localDeleted !== true) await runtimeMessage({ type: 'SPX_MARK_UPLOADED', key: state.key });
      setText('spx-upload', '업로드 완료 ✓');
      setClass('spx-dbstate', 'spx-ok');
      setText('spx-dbstate', '● 서버 반영됨');
      removeDiscoveredKeywordFromSidebar(state.keyword);
      const uploadButton=getUiElement('spx-upload',{repair:false});uploadButton?.classList.add('spx-upload-success');setTimeout(()=>uploadButton?.classList.remove('spx-upload-success'),jitterMs(820,1180));
      await recordTabSessionEvent('manual-upload-button',{uploaded:1,uploadPending:-1},{eventId:`manual-upload-button:${state.keyword}:${state.key||Date.now()}`});
      return true;
    } catch (e) {
      if (e?.spxContextInvalidated) return;
      const diagnostic=await readUploadDiagnosticV118(),friendly=friendlyUploadFailureV118(e?.message||e,diagnostic),stage=uploadDiagnosticStageLabelV118(diagnostic?.stage);
      setDisabled('spx-upload', false);
      setText('spx-upload', '서버 재업로드');
      setClass('spx-dbstate', 'spx-err');
      setText('spx-dbstate', `● ${friendly}${stage?` · 단계: ${stage}`:''}`);
      return false;
    }
  }

  /* v1.0.15.7: readiness hot-loop에서는 거대한 Coupang body를 deep-clone하지 않습니다.
     실제 수집 파서는 collectPage()에서 그대로 1회 실행하고, 접근제한/빈결과 감지는 가벼운
     textContent 스냅샷을 짧게 캐시해 CPU·메모리·GC 폭증을 막습니다. */
  const PAGE_TEXT_CACHE_MS_V10157=1200;
  let pageTextCacheV10157={at:0,url:'',text:''};
  function coupangPageTextForDetection() {
    /* [v1.3.7 핵심수정] 확장프로그램 오버레이의 안내문을 쿠팡 차단 문구로 다시 읽지 않습니다.
       이전 버전은 차단 안내에 포함된 “비정상적인 접근”을 재시작 시 자기 자신이 감지해
       차단 복구를 즉시 다시 시작하는 순환 오탐이 발생할 수 있었습니다. */
    const body = document.body;
    if (!body) return '';
    try {
      const clone = body.cloneNode(true);
      clone.querySelectorAll('#spx-overlay, #spx-tab, #spx-extension-update-notice, [data-spx-ui]').forEach((el) => el.remove());
      /* [v2.5.1] 빈 결과 안내가 상단 공통 메뉴 뒤쪽에 배치되는 쿠팡 화면에서도 문구를
         놓치지 않도록 감지 범위를 넓힙니다. 확장 UI는 위에서 제거했으므로 자기 문구 오탐은 없습니다. */
      return String(clone.innerText || clone.textContent || '').replace(/\s+/g, ' ').slice(0, 200000);
    } catch (_) {
      return String(body.innerText || '').replace(/\s+/g, ' ').slice(0, 200000);
    }
  }

  const SEARCH_CARD_SELECTOR='li.search-product,li[class*="search-product" i],[data-testid*="search-product" i],[data-product-id][class*="product" i]';
  const SEARCH_LOAD_TIMEOUT='SEARCH_LOAD_TIMEOUT'; // 레거시 진단 코드. 실제 무응답은 COUPANG_BLOCKED로 전환합니다.
  const EXPLICIT_EMPTY_SELECTORS=[
    '.search-product-empty','.empty-result','.search-empty','.no-result','.no-results',
    '[class*="search-product-empty" i]','[class*="empty-result" i]','[class*="search-empty" i]',
    '[data-testid="search-empty"]','[data-testid*="empty-result" i]','[data-testid*="no-result" i]',
    '[data-component="search-empty"]','[data-search-result="empty"]'
  ];
  /* [v2.5.0] 쿠팡은 빈 결과 전용 클래스 없이 본문 문구만 표시하는 화면도 사용합니다.
     이 문구는 접근 제한보다 먼저 판별해 정상적인 '상품 없음'을 차단으로 오인하지 않습니다. */
  const NO_SEARCH_RESULT_TEXT_RE=/(?:에?\s*대한\s*검색결과가\s*없습니다|에?\s*대한\s*검색\s+결과가\s*없습니다|검색\s*결과가\s*없습니다|다른\s*검색어를\s*입력하시거나|일치하는\s*상품이\s*없습니다|검색된\s*상품이\s*없습니다)/i;
  function hasExplicitNoSearchResultText(bodyText=''){
    return NO_SEARCH_RESULT_TEXT_RE.test(String(bodyText||'').replace(/\s+/g,' '));
  }
  function explicitEmptyResultElement(){
    for(const selector of EXPLICIT_EMPTY_SELECTORS){
      for(const element of document.querySelectorAll(selector)){
        const style=globalThis.getComputedStyle?.(element);
        const visible=!style||style.display!=='none'&&style.visibility!=='hidden';
        if(!visible)continue;
        const text=String(element.innerText||element.textContent||'').replace(/\s+/g,' ').trim();
        if(!text||/검색\s*결과가\s*(?:없습니다|없어요)|일치하는\s*상품이\s*없|상품을\s*찾을\s*수\s*없|검색된\s*상품이\s*없|no\s*(?:search\s*)?results?/i.test(text))return element;
      }
    }
    return null;
  }

  function searchPageReadiness() {
    const bodyText = coupangPageTextForDetection();
    const parsed = SPX.parseSearchPage?.() || { items: [], strategy: 'none' };
    const itemCount = Array.isArray(parsed.items) ? parsed.items.length : 0;
    const anchorCount = document.querySelectorAll('a[href*="/vp/products/"]').length;
    /* 카드 수 0만으로는 빈 페이지로 판정하지 않습니다. 명시적 빈 결과 DOM 또는 쿠팡의
       실제 빈 결과 안내 문구가 확인될 때만 정상적인 NO_RESULT로 판정합니다. */
    const emptyElement=explicitEmptyResultElement();
    const noResultText=hasExplicitNoSearchResultText(bodyText);
    const noResults=Boolean(emptyElement)||noResultText;
    const loading = document.readyState !== 'complete' || Boolean(document.querySelector(
      '[class*="loading"], [class*="Loading"], [aria-busy="true"], .loading, .spinner'
    ));
    const titleText = String(document.title || '').replace(/\s+/g, ' ');
    const manualVerificationText = /자동\s*입력\s*방지|보안\s*문자|captcha|robot\s*check|봇\s*확인|사람임을\s*확인|로봇이\s*아닙니다/i;
    const strongBlockText = /접근이\s*제한되었습니다|비정상적인\s*접근|자동\s*입력\s*방지|보안\s*문자|captcha|access\s*denied|robot\s*check|봇\s*확인|로봇이\s*아닙니다|사용\s*권한이\s*제한된|요청하신\s*페이지의\s*사용\s*권한이\s*없습니다|사용\s*권한이\s*없습니다|사용권한이\s*없습니다/i;
    const explicitRateLimitText = /요청이\s*너무\s*많|too\s*many\s*requests|error\s*429/i;
    const noProductSignals = itemCount === 0 && anchorCount === 0;
    const challengeCandidates = [...document.querySelectorAll([
      'input[name*="captcha"]','input[id*="captcha"]','input[placeholder*="보안"]',
      'iframe[src*="captcha"]','img[src*="captcha"]','[data-sitekey]','.g-recaptcha','#captcha'
    ].join(','))];
    const visibleChallengeElement = challengeCandidates.some((el) => {
      try{const style=getComputedStyle(el),rect=el.getBoundingClientRect();return style.display!=='none'&&style.visibility!=='hidden'&&Number(style.opacity||1)!==0&&rect.width>2&&rect.height>2;}catch(_){return false;}
    });
    const challengeControl = [...document.querySelectorAll('input,button')].some((el) => {
      const text=[el.id,el.name,el.placeholder,el.title,el.getAttribute('aria-label'),el.textContent].filter(Boolean).join(' ');
      if(!/captcha|보안\s*문자|사람임을\s*확인|로봇이\s*아닙니다/i.test(text))return false;
      try{const style=getComputedStyle(el),rect=el.getBoundingClientRect();return style.display!=='none'&&style.visibility!=='hidden'&&Number(style.opacity||1)!==0&&rect.width>2&&rect.height>2;}catch(_){return true;}
    });
    /* '요청하신 페이지의 사용권한이 없습니다'는 쿠팡의 일반 접근거부 화면입니다.
       페이지 내부에 숨겨진 captcha 마크업이 있더라도 사람 인증으로 오판하지 않고 차단/IP 복구가 먼저 실행되어야 합니다. */
    const permissionDenied = /요청하신\s*페이지의\s*사용\s*권한이\s*없습니다|사용\s*권한이\s*없습니다|사용권한이\s*없습니다/i.test(`${titleText} ${bodyText}`);
    const challengeDetected = Boolean(visibleChallengeElement || challengeControl);
    const blockedStrong = !noResults && strongBlockText.test(`${titleText} ${bodyText}`);
    const rateLimited = !noResults && noProductSignals && explicitRateLimitText.test(`${titleText} ${bodyText}`);
    const manualVerification = !noResults && !permissionDenied && (challengeDetected || manualVerificationText.test(`${titleText} ${bodyText}`));
    const blocked = !noResults && (blockedStrong || rateLimited || challengeDetected);
    const blockReason = manualVerification ? '보안문자·수동 확인 화면' : (rateLimited ? '요청 과다 429 화면' : (blockedStrong ? '명시적 접근 제한 화면' : ''));
    return { itemCount, anchorCount, noResults, noResultSource:emptyElement?'명시적 빈 결과 DOM':(noResultText?'쿠팡 빈 결과 안내 문구':null), explicitEmptySelector:emptyElement?.className||emptyElement?.getAttribute?.('data-testid')||null, blocked, manualVerification, blockReason, loading, strategy: parsed.strategy || 'none' };
  }

  async function waitForProducts(timeoutMs = 45000, task = null) {
    const effectiveTimeout=Math.max(8000,Math.min(600000,Number(timeoutMs)||30000));
    const cardSelector=SEARCH_CARD_SELECTOR;
    const startedAt=Date.now();
    let lastCount=-1,lastProductSignalAt=startedAt,wake=null;
    const watchedSelector=`${cardSelector},${EXPLICIT_EMPTY_SELECTORS.join(',')},a[href*="/vp/products/"]`;
    const observer=new MutationObserver((records)=>{
      const relevantMutation=records.some((record)=>[...(record.addedNodes||[])].some((node)=>
        node?.nodeType===Node.ELEMENT_NODE && (node.matches?.(watchedSelector) || node.querySelector?.(watchedSelector))
      ));
      if(relevantMutation)lastProductSignalAt=Date.now();
      if(wake){const fn=wake;wake=null;fn();}
    });
    try{observer.observe(document.documentElement||document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['class','aria-busy','data-testid']});}catch(_) {}
    const waitForSignal=(ms)=>new Promise((resolve)=>{
      let done=false;
      const finish=()=>{if(done)return;done=true;if(wake===finish)wake=null;resolve();};
      wake=finish;
      automationAwareWait(ms,activeRunId).then(finish).catch(finish);
    });
    try{
      while(Date.now()-startedAt<effectiveTimeout){
        if(contextInvalidated||!SPX.util.runtimeAlive?.()){shutdownInvalidatedContext();return {ready:false,contextEnded:true};}
        if(task&&!taskIsCurrent(task))return {ready:false,stale:true};
        if(!hasCompleteUi())ensureUi();
        detect();
        const status=searchPageReadiness();
        const domCardCount=document.querySelectorAll(cardSelector).length;
        if(status.noResults&&document.readyState!=='loading')return {ready:true,noResults:true,...status,domCardCount};
        if(status.blocked)return {ready:false,blocked:true,...status,domCardCount};
        const signalCount=Math.max(domCardCount,Number(status.anchorCount)||0,Number(status.itemCount)||0);
        if(signalCount!==lastCount){lastCount=signalCount;lastProductSignalAt=Date.now();}
        const stableFor=Date.now()-lastProductSignalAt;
        if(status.itemCount>=1 && (domCardCount>=1||status.anchorCount>=1) && document.readyState!=='loading' && stableFor>=80){
          return {ready:true,...status,domCardCount,stableFor};
        }
        const elapsedSec=Math.max(1,Math.round((Date.now()-startedAt)/1000));
        if(elapsedSec%5===0){setProgress(3,`쿠팡 검색결과 DOM 준비 대기 · ${elapsedSec}초`);task?.touch?.(`검색결과 DOM 준비 대기 ${elapsedSec}초`);}
        await waitForSignal(180+Math.floor(Math.random()*141));
      }
    } finally {try{observer.disconnect();}catch(_){} if(wake){const fn=wake;wake=null;fn();}}

    const finalStatus=searchPageReadiness();
    const domCardCount=document.querySelectorAll(cardSelector).length;
    if(finalStatus.noResults)return {ready:true,noResults:true,...finalStatus,domCardCount};
    if(finalStatus.itemCount>=1&&(domCardCount>=1||finalStatus.anchorCount>=1))return {ready:true,...finalStatus,domCardCount};
    /* [v2.5.1] 카드와 빈 결과 문구가 모두 없다는 사실만으로 접근 차단을 단정하지 않습니다.
       실제 차단 문구·캡차가 확인된 경우에만 blocked=true이며, 그 외는 일반 로딩 시간 초과로
       반환해 IP 변경 복구가 아니라 재시도/일반 실패 흐름으로 보냅니다. */
    if(finalStatus.blocked)return {ready:false,timeout:true,blocked:true,blockReason:finalStatus.blockReason||'실제 접근 제한 문구 또는 보안문자 감지',...finalStatus,domCardCount};
    return {ready:false,timeout:true,blocked:false,blockReason:'',...finalStatus,domCardCount};
  }

  async function waitForExecutionReady(timeoutMs = 15000, task = null) {
    if (task) await assertRunActive(task, '실행 대기 전');
    /* [v2.6.1] 페이지 전환 직후에는 확장 UI보다 쿠팡 상품 DOM이 먼저 준비될 수 있습니다.
       UI 생성 여부를 선행 조건으로 삼지 않고 상품/빈 결과 DOM을 먼저 판별한 뒤, 보존된
       실행 키워드로 사이드바를 재생성해 정상 페이지 이동을 UI 실패로 오인하지 않습니다. */
    const readiness = await waitForProducts(timeoutMs, task);
    if (!readiness?.ready) {
      if (task && !taskIsCurrent(task)) throw normalEnd('PAGE_NAVIGATION', '정상적인 페이지 이동으로 이전 상품 대기 작업을 종료했습니다.');
      const blocked = readiness?.blocked === true;
      const error = new Error(blocked
        ? '쿠팡의 실제 접근 제한 또는 보안문자 화면이 감지되어 IP 변경 복구를 시작합니다.'
        : '쿠팡 검색결과 로딩 시간이 초과되었습니다. 접근 제한 증거가 없어 일반 실패로 처리합니다.');
      error.code = blocked ? 'COUPANG_BLOCKED' : SEARCH_LOAD_TIMEOUT;
      error.readiness = readiness;
      throw error;
    }
    if (!(await requireUi(12000, task))) {
      if (task && !taskIsCurrent(task)) throw normalEnd('PAGE_NAVIGATION', '정상적인 페이지 이동으로 이전 UI 재생성 작업을 종료했습니다.');
      queueUiRepair(jitterMs(240,390));
      console.info('[SPX] 상품 DOM 준비 완료 · 사이드바 UI 지연 복구 예약');
    }
    if (task) await assertRunActive(task, '실행 직전');
    return readiness;
  }

  function automationExpectedKeyword(ctx) { return String(ctx?.state?.currentKeyword || ctx?.keyword || '').trim(); }
  function searchUrlFor(keyword, page = 1) { return `https://www.coupang.com/np/search?q=${encodeURIComponent(String(keyword || '').trim())}&page=${Math.max(1,Number(page)||1)}`; }
  /* [v2.5.2] 페이지 이동 주소는 쿠팡 DOM의 페이지 링크나 현재 URL을 재사용하지 않습니다.
     연관검색어·추천어·redirect 파라미터가 섞여도 서비스워커가 선점한 원본 키워드와 page만
     사용해 q/page/channel 세 값으로 새 주소를 만듭니다. */
  function normalizeAutomationTargetUrl(url, expectedKeyword, fallbackPage = 1) {
    let page=Math.max(1,Number(fallbackPage)||1);
    let targetKeyword='';
    try {
      const target = new URL(url || '', location.origin);
      page=Math.max(1,Number(target.searchParams.get('page'))||page);
      targetKeyword=String(target.searchParams.get('q')||'').trim();
    } catch (_) {}
    const keyword=String(expectedKeyword || state.lockedKeyword || '').trim();
    if(!keyword) return '';
    if(targetKeyword && normKeyword(targetKeyword)!==normKeyword(keyword)) {
      console.debug(`[SPX][원본 키워드 잠금] 쿠팡 추천·리다이렉트 q 제거 · ${targetKeyword} → ${keyword}`);
    }
    return searchUrlFor(keyword,page);
  }

  function pageTransitionMeta(keyword, page, maxPages = 1) {
    return { kind:'PAGE', keyword:String(keyword || '').trim(), page:Math.max(1, Number(page) || 1), maxPages:Math.max(1, Number(maxPages) || 1) };
  }


  function paginationContainers(){
    return [...document.querySelectorAll([
      '.search-pagination','.pagination','.paging','.page-box','[class*="pagination" i]','[class*="paging" i]',
      '[data-testid*="pagination" i]','nav[aria-label*="페이지"]','nav[aria-label*="pagination" i]'
    ].join(','))];
  }
  function paginationCandidateScore(element,targetPage,allowTextOnly=false){
    const text=String(element?.textContent||element?.innerText||'').replace(/\s+/g,' ').trim();
    const aria=String(element?.getAttribute?.('aria-label')||element?.title||'').trim();
    const dataPage=Number(element?.getAttribute?.('data-page')||element?.dataset?.page||0);
    let hrefPage=0,hasPageHref=false,searchHref=false;try{const href=element?.href||element?.getAttribute?.('href')||'';const parsed=new URL(href,location.href);hrefPage=Math.max(0,Number(parsed.searchParams.get('page'))||0);hasPageHref=parsed.searchParams.has('page');searchHref=/^\/np\/(?:search|categories)(?:\/|$)/i.test(parsed.pathname);}catch(_){}
    if(dataPage===targetPage||(searchHref&&hrefPage===targetPage)||(allowTextOnly&&text===String(targetPage)))return 100;
    if(((searchHref&&hasPageHref)||allowTextOnly)&&/다음|next|›|»|＞|→/i.test(`${text} ${aria}`))return 30;
    return 0;
  }
  async function findPaginationTarget(targetPage,timeoutMs=8000){
    const deadline=Date.now()+Math.max(1000,Number(timeoutMs)||8000);
    try{window.scrollTo({top:Math.max(document.body?.scrollHeight||0,document.documentElement?.scrollHeight||0),behavior:'auto'});}catch(_){}
    while(Date.now()<deadline){
      const status=searchPageReadiness();
      if(status.noResults)return {noResults:true,status};
      const containers=paginationContainers();
      const roots=containers.length?containers:[document];
      const candidates=[];
      for(const root of roots){
        const allowTextOnly=root!==document;
        root.querySelectorAll?.('a,button,[role="button"]').forEach((element)=>{
          const disabled=element.disabled||element.getAttribute('aria-disabled')==='true'||element.classList?.contains('disabled');
          if(disabled)return;
          const score=paginationCandidateScore(element,targetPage,allowTextOnly);
          if(score)candidates.push({element,score});
        });
      }
      candidates.sort((a,b)=>b.score-a.score);
      if(candidates[0])return {element:candidates[0].element,score:candidates[0].score};
      await automationAwareWait(220+Math.floor(Math.random()*181),activeRunId);
    }
    return {element:null,status:searchPageReadiness()};
  }
  async function clickPaginationTarget(targetPage,expectedKeyword,runId){
    const found=await findPaginationTarget(targetPage,9000);
    if(found.noResults)return {ok:false,noResults:true,status:found.status};
    const target=found.element;
    if(!target)return {ok:false,missing:true,status:found.status};
    const beforeHref=location.href;
    const beforeKeyword=currentKeyword();
    try{target.scrollIntoView?.({block:'center',inline:'center'});}catch(_){}
    await automationAwareWait(160+Math.floor(Math.random()*181),activeRunId);
    try{
      target.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));
      target.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));
      target.click();
    }catch(error){return {ok:false,error};}
    try{sessionStorage.setItem('spxLastNavigationAt',String(Date.now()));}catch(_){}
    console.info('[SPX][페이지네이션 DOM 이동]',{expectedKeyword,targetPage,runId,beforeHref,beforeKeyword,control:String(target.textContent||target.getAttribute?.('aria-label')||'').trim()});
    /* 쿠팡이 전체 새로고침 대신 SPA 방식으로 페이지를 바꾸는 경우를 위한 안전 재실행입니다.
       실제 문서 이동이면 이 타이머는 문서와 함께 사라집니다. */
    queueUiRepair(jitterMs(280,440));
    scheduleAutoRun(jitterMs(760,1180));
    return {ok:true,clicked:true};
  }
  async function finishMissingPaginationAsNoResult(runId,keyword,page,manualMode=false){
    const response=await runtimeMessage({
      type:'SPX_AUTOMATION_PAGE',runId,keyword,page,products:[],noSearchResults:true,
      parserStrategy:'pagination-dom-target-missing',candidates:[],relatedTerms:[],
      externalMetrics:{detected:false},searchCategory:null,resultTotal:null,manualMode:Boolean(manualMode),
    });
    return response;
  }

  function scheduleNavigate(url, delaySec, runId, delayReason = '', expectedKeywordOverride = '', transitionMeta = null) {
    if (contextInvalidated) return false;
    clearNavigationTimer();
    ensureUi();

    const meta = transitionMeta && typeof transitionMeta === 'object' ? { ...transitionMeta } : null;
    if (!url && meta?.kind !== 'PAGE') {
      setText('spx-auto-text', '자동 소싱 대기열 완료');
      setTabAutomationTimer('stop').catch(()=>{});
      state.autoStarted = false;
      return false;
    }

    const targetRunId = String(runId || '');
    const firstStateKeyword = String(expectedKeywordOverride || state.lockedKeyword || '').trim();
    if(meta?.kind!=='PAGE'){
      url = normalizeAutomationTargetUrl(url, firstStateKeyword);
      if(!url){setText('spx-auto-text','원본 키워드를 확인하지 못해 이동을 취소했습니다.');state.autoStarted=false;return false;}
    }
    if (meta?.kind === 'PAGE') {
      meta.keyword = String(meta.keyword || firstStateKeyword || '').trim();
      meta.page = Math.max(1, Number(meta.page) || 1);
      meta.maxPages = Math.max(meta.page, Number(meta.maxPages) || meta.page);
      /* 다음 페이지는 주소를 조립하지 않고 쿠팡 로그인 화면의 실제 페이지네이션 DOM을 클릭합니다. */
      url = '';
    }
    pendingNavigation = { url, runId:targetRunId, keyword:firstStateKeyword, transition:meta };
    const nextButton = document.getElementById('spx-next-now');
    if (nextButton) {nextButton.hidden=false;nextButton.disabled=false;const pendingKeyword=String(firstStateKeyword||meta?.keyword||'').trim();nextButton.title=pendingKeyword?`대기 생략 · 다음 키워드: ${pendingKeyword}`:'대기 시간을 생략하고 다음 단계로 이동';nextButton.dataset.spxTip=nextButton.title;}
    /* v1.3.9: 서비스워커가 이미 계산해 상태에 기록한 전환 대기를 그대로 1회만 사용합니다.
       콘텐츠에서 별도 800~1500ms 난수를 다시 뽑아 중복 대기하던 경로를 제거합니다. */
    const requestedDelayMs=Number(delaySec)*1000;
    const delayMs=Number.isFinite(requestedDelayMs)&&requestedDelayMs>=0
      ? Math.max(100,Math.min(180000,Math.round(requestedDelayMs)))
      : randomNextNavigationDelayMs();
    const deadline = Date.now() + delayMs;
    let tickBusy = false;

    const waitLabel = String(delayReason || '다음 수집으로 이동').replace(/\s*·\s*\d+(?:\.\d+)?초$/, '');
    const renderRemaining = () => {
      const remainMs=Math.max(0,deadline-Date.now());
      setText('spx-auto-text', `${waitLabel} · ${remainMs.toLocaleString('ko-KR')}ms 남음`);
      return remainMs;
    };
    renderRemaining();

    const tick = async () => {
      navigationTimer = null;
      if (tickBusy) {
        navigationTimer = setTimeout(tick, jitterMs(190,360));
        return;
      }
      tickBusy = true;
      try {
        if (String(activeRunId || '') !== targetRunId) {
          state.autoStarted = false;
          return;
        }

        const remainMs=renderRemaining();
        if (remainMs <= 0) {
          const transition = pendingNavigation?.transition || null;
          /* 키워드 A→B 전환은 이미 서비스워커가 확정한 순서입니다. 여기서 상태 응답을 다시
             기다리면 메시지 채널이 늦을 때 150ms 화면에서 수분간 멈춥니다. 키워드 전환은
             즉시 검색창으로 넘기고, 페이지 전환만 1.5초 제한의 보조 상태 확인을 사용합니다. */
          if(transition?.kind!=='PAGE'){
            clearNavigationTimer();pendingNavigation=null;state.busy=false;state.autoStarted=false;
            await transitionKeywordAndStart(firstStateKeyword,{runId:targetRunId,reason:waitLabel});
            return;
          }
          let latest=null;
          try{
            const lastCheck=await Promise.race([
              readAutomationState(),
              sleep(1500).then(()=>null),
            ]);
            latest=lastCheck?.state||null;
          }catch(_){latest=null;}
          if(latest&&(!latest.running||String(latest.runId||'')!==targetRunId)){
            if(!latest.running)handleNormalAutomationEnd({code:'STOPPED',reason:latest.lastMessage||'자동수집이 중단되었습니다.'});
            else handleNormalAutomationEnd({code:'STALE_RUN',silent:true,runId:String(latest.runId||'')});
            return;
          }
          latest=latest||{running:true,runId:targetRunId,currentKeyword:firstStateKeyword,currentPage:transition?.page||1,pageLoopPhase:'navigating',keywordLoopCompleted:false};
          if (latest?.running && String(latest.runId || '') === targetRunId) {
            let expectedKeyword = String(transition?.keyword || latest?.currentKeyword || firstStateKeyword || state.lockedKeyword || '').trim();
            let expectedPage = Math.max(1, Number(transition?.page || latest?.currentPage) || 1);
            if (transition?.kind === 'PAGE') {
              expectedKeyword = String(transition.keyword || firstStateKeyword || '').trim();
              expectedPage = Math.max(1, Number(transition.page) || 1);
              const sameKeyword = normKeyword(latest?.currentKeyword) === normKeyword(expectedKeyword);
              const samePage = Math.max(1, Number(latest?.currentPage) || 1) === expectedPage;
              const loopStillActive = latest?.keywordLoopCompleted !== true && ['collecting','navigating'].includes(String(latest?.pageLoopPhase || ''));
              if (!sameKeyword || !samePage || !loopStillActive) {
                console.warn('[SPX][페이지 루프 보호] 다음 페이지 이동 전 상태가 다음 키워드로 바뀌어 이동을 취소했습니다.', {expectedKeyword,expectedPage,currentKeyword:latest?.currentKeyword,currentPage:latest?.currentPage,pageLoopPhase:latest?.pageLoopPhase});
                clearNavigationTimer(); state.busy=false; state.autoStarted=false; pendingNavigation=null;
                setText('spx-status','페이지 순서 보호');
                setText('spx-auto-text','현재 키워드 페이지 루프 상태가 바뀌어 잘못된 다음 키워드 이동을 차단했습니다.');
                scheduleAutoRun(jitterMs(560,880));
                return;
              }
            }
            clearNavigationTimer();
            pendingNavigation = null;
            if(transition?.kind==='PAGE'){
              state.busy = false;
              state.autoStarted = false;
              const visiblePage=Math.max(1,Number(new URLSearchParams(location.search).get('page'))||1);
              if(visiblePage===expectedPage){
                /* 같은 페이지 DOM 재확인은 주소 이동이나 다음 버튼 클릭 없이 현재 문서에서 다시 실행합니다. */
                scheduleAutoRun(jitterMs(270,460));
                return;
              }
              const pagination=await clickPaginationTarget(expectedPage,expectedKeyword,targetRunId);
              if(pagination.ok)return;
              /* 다음 페이지 버튼이 없으면 존재하지 않는 페이지로 URL 요청을 만들지 않습니다.
                 이전 페이지까지 저장된 원천상품으로 정상 집계하도록 빈 결과 완료 신호를 보냅니다. */
              const noResult=await finishMissingPaginationAsNoResult(targetRunId,expectedKeyword,expectedPage,latest?.sidebarManual===true||latest?.workScope==='manual');
              if(!noResult?.ok&&!noResult?.normalEnd&&!noResult?.ignored)throw new Error(noResult?.error||'페이지네이션 종료 저장 실패');
              if(noResult?.transition==='MANUAL_COMPLETE'||noResult?.state?.running===false){
                setText('spx-status','단건 분석 완료');
                setText('spx-auto-text',noResult?.state?.lastMessage||`${expectedKeyword} 단건 분석 완료`);
                setProgress(100,'페이지네이션 마지막 페이지 · 현재까지 자료로 정상 완료');
                activeRunId='';
                return;
              }
              if(noResult?.nextUrl){
                scheduleNavigate(noResult.nextUrl,noResult.delaySec||1,targetRunId,noResult.delayReason||'다음 키워드 이동',noResult?.state?.currentKeyword||'');
              }
              return;
            }
          }
          handleNormalAutomationEnd({ code: 'STOPPED', reason: latest?.lastMessage || '자동수집이 중단되어 페이지 이동을 취소했습니다.' });
          return;
        }

        ensureUi();
        renderRemaining();
        navigationTimer = setTimeout(tick, jitterMs(90,190));
      } catch (error) {
        if (error?.spxContextInvalidated) return;
        console.info(`[SPX] 페이지 이동 상태 확인 지연 · ${error?.message||String(error)}`);
        clearNavigationTimer();
        state.busy = false;
        state.autoStarted = false;
        pendingNavigation = null;
        setText('spx-status','이동 확인 실패');
        setText('spx-auto-text','페이지 이동 확인에 실패해 안전하게 중단했습니다. 수집 버튼으로 다시 시작하세요.');
      } finally {
        tickBusy = false;
      }
    };

    /* 백그라운드 탭에서는 navigationTimer가 수십 초~수분으로 지연될 수 있으므로 같은 지연시간을
       서비스워커에도 한 번 맡깁니다. 응답이 돌아올 때 아직 같은 pending 이동이면 tick을 직접 깨웁니다.
       눈에 보이는 탭에서는 기존 타이머가 먼저 실행되고, 이 백업은 pendingNavigation이 사라져 아무 일도 하지 않습니다. */
    automationAwareWait(delayMs+80,targetRunId).then(()=>{
      const pending=pendingNavigation;
      if(!pending||String(pending.runId||'')!==targetRunId||String(activeRunId||'')!==targetRunId)return;
      void tick();
    }).catch(()=>{});
    navigationTimer = setTimeout(tick, jitterMs(70,150));
    return true;
  }

  function loadRetryKey(runId, keyword, page) {
    return `spxLoadRetry:${String(runId || '')}:${normKeyword(keyword)}:${Math.max(1, Number(page) || 1)}`;
  }

  function clearLoadRetry(key) {
    try { sessionStorage.removeItem(key); } catch (_) {}
  }

  async function runAutomationPage(ctx) {
    if (state.busy) return false;
    const runId = String(ctx?.runId || ctx?.state?.runId || '');
    if (!runId) return false;
    const task = beginAutomationTask(runId);
    /* v3.0.11: 지정키워드/관리표 순차 수집은 '자동 전용 방식'이 아니라 단건 분석을 그대로 반복합니다. */
    /* 연속 수집은 단건과 같은 DOM·상세확인·대기시간을 사용하되, 실행 생명주기까지 단건으로 오인하면
       키워드 완료/다음 이동/자동업로드 판정이 달라집니다. 수집 조건과 실제 단건 실행 여부를 분리합니다. */
    const manualCollectionRun=ctx?.state?.sidebarManual===true||ctx?.state?.workScope==='manual';
    const singleCollectionSemantics=manualCollectionRun||ctx?.state?.sequentialSingleLoop===true;
    let navigationScheduled = false;
    let pageSaveMarker = null;
    let finalSaveStarted = false;
    let acknowledgedSaveResponse = null;
    let expectedKeyword=automationExpectedKeyword(ctx);
    const settings = (ctx?.settings && typeof ctx.settings === 'object') ? ctx.settings : {};
    const maxPages = Math.max(1, Number(ctx?.settingsOverride?.maxPagesPerKeyword ?? settings.maxPagesPerKeyword) || 1);
    const expectedPage = Math.max(
      1,
      Number(ctx?.state?.currentPage)
        || Number(new URLSearchParams(location.search).get('page'))
        || 1
    );

    try {
      SPX.setWinnerCriteria?.({
        monthlySalesMin:ctx?.settings?.winnerMonthlySalesMin,
        reviewMin:ctx?.settings?.winnerReviewMin,
        reviewMax:ctx?.settings?.winnerReviewMax,
        recentReviewMin:ctx?.settings?.winnerRecentReviewMin,
        marginRateMin:ctx?.settings?.winnerMarginRateMin,
      });
      expectedKeyword = automationExpectedKeyword(ctx);
      const actualKeyword = currentKeyword();
      /* [v2.5.7] 대기열 canonicalKey가 띄어쓰기를 제거했더라도 화면의 검색어와 본질적으로
         같은 키워드라면 사람이 입력한 띄어쓰기가 보존된 actualKeyword를 현재 루프의 원본으로
         사용합니다. 다른 키워드일 때만 아래 경합·리다이렉트 분기로 들어갑니다. */
      const compactKeyword=(value)=>String(value||'').normalize('NFKC').replace(/\s+/g,'').toLowerCase();
      if(expectedKeyword&&actualKeyword&&compactKeyword(expectedKeyword)===compactKeyword(actualKeyword))expectedKeyword=actualKeyword;
      state.lockedKeyword=expectedKeyword;
      if(expectedKeyword)state.keyword=expectedKeyword;
      if (expectedKeyword && actualKeyword && normKeyword(expectedKeyword) !== normKeyword(actualKeyword)) {
        setDisplay('spx-auto','flex');

        /* [v2.5.5] 1페이지의 키워드 불일치는 대기열 경합일 수 있으므로 기존처럼 원래
           키워드로 복구합니다. 그러나 2페이지 이상에서 쿠팡이 결과 없음 대신 연관 키워드로
           리다이렉트한 경우 다시 원래 2페이지로 이동하면 쿠팡↔확장프로그램 사이에 무한
           핑퐁이 생기고 짧은 시간에 요청이 누적됩니다. 뒤 페이지의 키워드 불일치는 명시적
           검색결과 없음과 동일하게 정상 완료 처리하고 절대로 scheduleNavigate로 복구하지 않습니다. */
        if (expectedPage <= 1) {
          console.debug(`[SPX][키워드 경합 복구] 1페이지 화면 ${actualKeyword || '-'} · 대기열 ${expectedKeyword}`);
          setText('spx-status','키워드 동기화');
          setText('spx-auto-text',`대기열 키워드 “${expectedKeyword}”로 복귀합니다.`);
          navigationScheduled = scheduleNavigate(
            searchUrlFor(expectedKeyword, 1),
            1,
            runId,
            '1페이지 키워드 순서 자동 복구',
            expectedKeyword
          );
          return navigationScheduled;
        }

        console.info('[SPX][리다이렉트 종료] 뒤 페이지가 다른 키워드로 전환되어 검색결과 없음으로 정상 처리합니다.', {
          expectedKeyword,
          actualKeyword,
          expectedPage,
        });
        setText('spx-status','검색결과 없음');
        setText('spx-auto-text',`${expectedKeyword} ${expectedPage}페이지가 연관 검색어로 전환되어 현재 키워드 수집을 정상 종료합니다.`);
        setProgress(96,'연관 검색어 리다이렉트 감지 · 현재 키워드 정상 종료');

        const redirectRequestId=`${runId}:${normKeyword(expectedKeyword)}:${expectedPage}:redirect-no-result`;
        pageSaveMarker={runId,requestId:redirectRequestId,keyword:expectedKeyword,page:expectedPage,startedAt:Date.now()};
        pendingPageSaveResponse=pageSaveMarker;
        const redirectedNoResult = await runtimeMessage({
          type:'SPX_AUTOMATION_PAGE',
          requestId:redirectRequestId,
          runId,
          keyword:expectedKeyword,
          page:expectedPage,
          products:[],
          noSearchResults:true,
          parserStrategy:'redirected-keyword-no-results',
          candidates:[],
          relatedTerms:[],
          externalMetrics:{detected:false},
          searchCategory:null,
          resultTotal:null,
          redirectedKeyword:actualKeyword,
          manualMode:manualCollectionRun,
        });

        if (redirectedNoResult?.ignored || redirectedNoResult?.normalEnd) {
          if (redirectedNoResult?.manualRestartRequired) {
            showStaleManualRestartPrompt(redirectedNoResult.reason, redirectedNoResult.delaySec || 3);
            return false;
          }
          if (redirectedNoResult?.resync && redirectedNoResult?.nextUrl) {
            const resyncKeyword=String(redirectedNoResult?.state?.currentKeyword||expectedKeyword||'').trim();
            navigationScheduled=scheduleNavigate(
              redirectedNoResult.nextUrl,
              redirectedNoResult.delaySec||1,
              runId,
              redirectedNoResult.delayReason||'리다이렉트 종료 후 순서 동기화',
              resyncKeyword
            );
            return navigationScheduled;
          }
          handleNormalAutomationEnd(redirectedNoResult);
          return false;
        }
        if (!redirectedNoResult?.ok) {
          throw new Error(redirectedNoResult?.error || '리다이렉트 검색결과 없음 저장 실패');
        }

        setText('spx-status',redirectedNoResult?.state?.running?'다음 준비':'자동 완료');
        setHtml('spx-body',`<div class="spx-empty">“${esc(expectedKeyword)}” ${expectedPage}페이지가 쿠팡 연관 검색어로 전환되어 더 이상 결과가 없는 것으로 정상 처리했습니다.</div>`);
        setProgress(100,'리다이렉트 검색결과 없음 · 현재 키워드 정상 종료');
        if(redirectedNoResult?.transition==='MANUAL_COMPLETE'||redirectedNoResult?.state?.running===false){
          rememberRenderedCompletion(runId);setText('spx-status','단건 분석 완료');activeRunId='';return false;
        }
        navigationScheduled=scheduleNavigate(
          redirectedNoResult.nextUrl,
          redirectedNoResult.delaySec||1,
          runId,
          redirectedNoResult.delayReason||'리다이렉트 종료 후 다음 키워드 이동',
          redirectedNoResult?.state?.currentKeyword||expectedKeyword
        );
        return navigationScheduled;
      }
      /* v3.0.11: 지정키워드/대기열 연속수집은 단건 분석을 그대로 반복합니다.
         자동 모드 전용 90~120초 대기를 적용하지 않고 단건과 동일한 15초 검색결과 준비 기준을 사용합니다. */
      /* v3.0.21: 단건과 연속 단건 반복 모두 같은 준비 기준을 사용합니다. 15초는 쿠팡 검색 DOM이
         늦게 붙는 정상 페이지도 일반 실패로 오인할 수 있어 25초로 완화합니다. 실제 차단/CAPTCHA는
         waitForProducts가 즉시 차단 증거를 판별하므로 이 대기 상향이 접근제한 복구를 늦추지 않습니다. */
      const pageLoadingMinMs=singleCollectionSemantics?25000:Math.max(30000,Math.min(900000,Math.round(Number(settings.pageLoadingMaxWaitMinMs)||90000)));
      const pageLoadingMaxMs=singleCollectionSemantics?25000:Math.max(pageLoadingMinMs,Math.min(900000,Math.round(Number(settings.pageLoadingMaxWaitMaxMs)||120000)));
      const pageLoadingMaxWaitMs=singleCollectionSemantics?25000:jitterMs(pageLoadingMinMs,pageLoadingMaxMs);
      const pageWatchdog={idleTimeoutMs:pageLoadingMaxWaitMs};
      const readiness = await runStageWithTimeout(task, '검색결과·상품 카드 준비', singleCollectionSemantics?Math.max(45000,pageLoadingMaxWaitMs+15000):Math.max(50000,pageLoadingMaxWaitMs), singleCollectionSemantics?1:2, (stageTask) => waitForExecutionReady(pageLoadingMaxWaitMs, stageTask), pageWatchdog);
      await assertRunActive(task, '자동수집 실행 전');
      /* [v2.6.1] 상품 DOM이 준비됐다면 사이드바 UI 재생성이 늦어도 수집을 중단하지 않습니다.
         페이지네이션으로 문서가 교체되는 찰나에는 UI host가 잠깐 사라질 수 있으므로 복구를
         예약하고 데이터 파싱을 계속합니다. 상태·진행률 함수는 요소가 없으면 안전하게 생략됩니다. */
      if (!(await requireUi(1200, task))) {
        if (!taskIsCurrent(task)) throw normalEnd('PAGE_NAVIGATION', '정상적인 페이지 이동으로 이전 UI 확인 작업을 종료했습니다.');
        queueUiRepair(jitterMs(190,340));
        console.info('[SPX] 자동수집 UI 재생성 지연 · 상품 DOM 기준으로 수집 계속');
      }

      state.busy = true;
      clearAutomationKickWatchdog();
      setDisplay('spx-auto', 'flex');
      setText('spx-status', '자동 수집');
      beginProgressiveView(state.keyword, '자동수집 검색결과 상품 확인 중');

      const page = expectedPage;
      const retryKey = loadRetryKey(runId, state.keyword || expectedKeyword || actualKeyword, page);
      const modeLabel = ctx.state.runLabel || (ctx.state.mode === 'full' ? '연속 탐색' : '단건 분석');
      const configuredPageLimit=Math.max(1,Number(settings.configuredMaxPages)||maxPages);
      const adaptiveExpansion=settings.autoExtraPageEnabled===true&&maxPages>configuredPageLimit;
      const pageLabel = `${page}/${maxPages}페이지${adaptiveExpansion||settings.fullMarketRefresh&&maxPages>configuredPageLimit?' · 조건식 확장':settings.autoExtraPageEnabled===true&&maxPages===configuredPageLimit?' · 필요시 추가확인 가능':''}`;
      setText('spx-auto-text', `${modeLabel} · ${ctx.state.processed + 1}번째 · ${pageLabel}`);

      /* 검색결과 DOM 수집과 보조 스크롤을 동시에 실행하면 페이지 이동 직전의 오래된 작업이
         새 키워드 DOM을 건드릴 수 있어 키워드가 바뀌거나 교착되는 원인이 되었습니다.
         v2.2.9부터 한 단계씩 순차 실행하고 각 단계에 타임아웃·재시도를 적용합니다. */
      const detailLimitForTimeout=Math.max(0,Number(settings.detailProductLimit)||0),detailConcurrencyForTimeout=Math.max(1,singleCollectionSemantics?(Number(settings.manualDetailConcurrency)||3):Math.max(2,Number(settings.detailConcurrency)||1));
      const detailStageTimeoutMs=Math.max(90000,Math.min(240000,45000+Math.ceil(Math.max(detailLimitForTimeout,settings.collectWinnerDetails!==false?16:0)/detailConcurrencyForTimeout)*12000));
      let pageResult;
      try{
        pageResult = await runStageWithTimeout(task, 'DOM 탐색·상품 상세정보 확인', detailStageTimeoutMs, 1, (stageTask) => collectPage(`자동 ${pageLabel} · `, stageTask, {
          allowEmpty: Boolean(readiness?.noResults),
          detailLimit: settings.detailProductLimit,
          priorityPids: settings.detailPriorityPids || [],
          collectDetail: settings.collectWinnerDetails !== false,
          collectComparisonCandidates: settings.collectDetailRecommendations !== false,
          comparisonCandidateLimit: settings.comparisonCandidateLimit,
          recommendationSections:{enabled:settings.collectDetailRecommendations!==false},
          scrollOptions: settings.scrollOptions || null,
          /* v4.1.14: 연속 탐색은 단건 수집의 반복입니다. 실행 생명주기는 자동으로 유지하되,
             실제 상품 상세 수집에는 단건과 동일한 manual detail 정책(동시성·지연·휴식)을 적용합니다.
             이전에는 timeout 계산은 manualDetailConcurrency 기준인데 실제 enrich는 manualMode=false라
             최대 동시성이 2로 낮아져 연속에서만 상세 단계 timeout→카드 fallback이 발생할 수 있었습니다. */
          manualMode:singleCollectionSemantics,
          expectedKeyword,
          detailConcurrency:singleCollectionSemantics?settings.manualDetailConcurrency:settings.detailConcurrency,
          detailItemTimeoutMs:15000,
          priorityDetailLimit:40,
          fastDetail:true,
          automatedFastPath:true,
          fastCollectionV1714:settings.fastUploadOverlapEnabled===true&&!manualCollectionRun,
        }), {idleTimeoutMs:25000});
      }catch(detailError){
        if(detailError?.code!=='STAGE_TIMEOUT')throw detailError;
        setProgress(72,'상세확인 지연 · 검색카드 정보로 안전 저장','현재 키워드 전체 실패 대신 확인된 상품을 먼저 보존합니다.');
        pageResult=await runStageWithTimeout(task,'검색카드 정보 안전 복구',Math.max(70000,pageLoadingMaxWaitMs),1,(stageTask)=>collectPage(`자동 ${pageLabel} · 카드복구 · `,stageTask,{
          allowEmpty:Boolean(readiness?.noResults),reuseDetailCheckpoint:true,detailLimit:0,priorityPids:[],collectDetail:false,
          collectComparisonCandidates:false,comparisonCandidateLimit:0,recommendationSections:null,
          scrollOptions:null,manualMode:singleCollectionSemantics,expectedKeyword,detailConcurrency:1,
        }),pageWatchdog);
        pageResult={...pageResult,detailFallback:true,detailFallbackReason:detailError.message};
      }
      const { res, candidates, relatedTerms, relatedDiscoveryTerms, externalMetrics, searchCategory, resultTotal } = pageResult;
      clearLoadRetry(retryKey);
      await assertRunActive(task, '저장 요청 전');
      setProgress(88, '최종 집계 완료 · 저장/업로드 확인 중...', 'Local 저장을 먼저 확정하고 자동 업로드는 1회만 확인합니다. 서버가 지연되면 업로드 대기로 보존한 뒤 다음 작업으로 이동합니다.');

      const pageRequestId=`${runId}:${normKeyword(state.keyword||expectedKeyword)}:${page}`;
      const pageAckWaitStartedV1622=performance.now();
      finalSaveStarted = true;
      pageSaveMarker = { runId, requestId:pageRequestId, keyword:state.keyword||expectedKeyword, page, startedAt:Date.now() };
      pendingPageSaveResponse = pageSaveMarker;
      const r = await runStageWithTimeout(task, '페이지 합산·최종 저장', Math.max(95000,pageLoadingMaxWaitMs), 1, () => sendPageWithDurableAckV1622({
        type: 'SPX_AUTOMATION_PAGE',
        requestId:pageRequestId,
        runId,
        keyword: state.keyword,
        page,
        products: res.items,
        noSearchResults: Boolean(readiness?.noResults),
        parserStrategy: res.strategy || null,
        candidates,
        relatedTerms,
        relatedDiscoveryTerms,
        externalMetrics,
        searchCategory,
        resultTotal,
        manualMode:manualCollectionRun,
      }),{...pageWatchdog,idleTimeoutMs:Math.max(95000,pageLoadingMaxWaitMs)});

      if (r?.ignored || r?.normalEnd) {
        if (r?.manualRestartRequired) {
          showStaleManualRestartPrompt(r.reason, r.delaySec || 3);
          return false;
        }
        if (r?.resync && r?.nextUrl) {
          ensureUi();
          setText('spx-status', '순서 동기화');
          setHtml('spx-body', '<div class="spx-empty">중복 페이지 요청을 종료하고 현재 처리 순서로 자동 복귀합니다.</div>');
          const resyncKeyword=String(r?.state?.currentKeyword||expectedKeyword||'').trim();
          const resyncPage=Math.max(1,Number(r?.state?.currentPage)||page);
          const resyncMeta=r?.state?.keywordLoopCompleted!==true&&['collecting','navigating'].includes(String(r?.state?.pageLoopPhase||''))
            ? pageTransitionMeta(resyncKeyword,resyncPage,r?.state?.pageLoopMaxPages||maxPages):null;
          navigationScheduled = scheduleNavigate(r.nextUrl, r.delaySec || 1, runId, r.delayReason || '페이지 순서 자동 동기화', resyncKeyword, resyncMeta);
          return navigationScheduled;
        }
        if (r?.silent || r?.ownerTabMismatch || r?.code === 'NON_OWNER_TAB') {
          cancelAutomationWork('', { updateUi: false });
          setDisplay('spx-auto', 'none');
          return false;
        }
        handleNormalAutomationEnd(r);
        return false;
      }
      if (!r?.ok) throw new Error(r?.error || '자동수집 저장 실패');
      console.info('[SPX PERF v1.6.24] 페이지 저장 ACK',state.keyword,page,Math.round(performance.now()-pageAckWaitStartedV1622),'ms',r.recoveredPageAck?'체크포인트 복구':'정상 응답');
      clearNetworkRecoveryPageSnapshot(state.keyword||expectedKeyword,page);
      if (r?.doneKeyword && r?.collectionAck !== true) {
        const error = new Error('수집 결과 저장 확인을 받지 못했습니다. 같은 키워드를 실패 상태로 기록하고 다음 작업 전 재확인합니다.');
        error.code = 'COLLECTION_ACK_MISSING';
        throw error;
      }
      if (!taskIsCurrent(task)) throw normalEnd('STALE_TASK', '페이지가 변경되어 이전 저장 응답을 무시했습니다.');
      /* v4.0.95: 여기까지 왔으면 background가 현재 페이지/키워드 저장을 정상 수락했습니다.
         이후 진행문구·렌더링 같은 UI 오류는 이미 저장된 수집 결과를 기술오류로 되돌리지 않습니다. */
      acknowledgedSaveResponse = r;
      if(r.recoveredPageAck===true){
        setText('spx-status','로컬 저장 체크포인트 확인');
        setProgress(95,'ACK 복구 완료 · 기존 페이지 재수집 없이 다음 순서 진행');
      }

      await requireUi(6000, task);
      state.candidates = candidates;
      const collectedCount = Number(r.collectedProductCount ?? r.totalCollected ?? res.items.length) || 0;
      if (r.retryPage && r.nextUrl) {
        const retryPage=Math.max(1,Number(r.expectedPage)||page);
        const retryKeyword=String(r.expectedKeyword||expectedKeyword||'').trim();
        if(normKeyword(retryKeyword)!==normKeyword(expectedKeyword)){
          const err=new Error(`페이지 재확인 키워드 불일치 · ${retryKeyword || '-'} / ${expectedKeyword}`);
          err.code='PAGE_LOOP_STATE_MISMATCH';throw err;
        }
        setText('spx-status','현재 페이지 재확인');
        setProgress(90,`${expectedKeyword} ${retryPage}/${maxPages}페이지 결과를 다시 확인합니다.`);
        navigationScheduled=scheduleNavigate(
          searchUrlFor(expectedKeyword,retryPage),r.delaySec||2,runId,r.delayReason||'현재 페이지 결과 재확인',expectedKeyword,
          pageTransitionMeta(expectedKeyword,retryPage,maxPages)
        );
        return navigationScheduled;
      }
      if (r.doneKeyword === false) {
        const targetOrganic=Math.max(1,Number(settings?.sourceDataTargetOrganic||60)||60);
        const organicCollected=Math.max(0,Number(r.organicCollected)||0);
        const organicProgress=`누적 자연노출 ${fmt(organicCollected)}/${fmt(targetOrganic)} · 누적 상품 ${fmt(collectedCount)}개`;
        if (r.partialAggregate) {
          state.agg = r.partialAggregate;
          renderProgressiveAggregate(r.partialAggregate, {
            phase:2,
            productCount:collectedCount,
            page:r.pageCompleted || page,
            stage:`${organicProgress} 반영 완료 · 다음 페이지 수집 대기`,
          });
        }
        setProgress(90, `${state.keyword} ${r.pageCompleted || page}페이지 완료 · ${organicProgress} · 다음 페이지 준비`);
        setText('spx-status', '다음 페이지 준비');
        await refreshDbInfo();
        const nextPage = Math.max(1, Number(r.expectedPage || r?.state?.currentPage) || 1);
        const responseKeyword = String(r.expectedKeyword || r?.state?.currentKeyword || '').trim();
        if (r.transition && r.transition !== 'NEXT_PAGE') throw new Error(`페이지 루프 응답 형식 오류: ${r.transition}`);
        if (normKeyword(responseKeyword) !== normKeyword(expectedKeyword) || nextPage !== page + 1) {
          const err = new Error(`다음 페이지 상태 불일치 · 기대 ${expectedKeyword} ${page + 1}페이지 / 응답 ${responseKeyword || '-'} ${nextPage}페이지`);
          err.code='PAGE_LOOP_STATE_MISMATCH';
          throw err;
        }
        navigationScheduled = scheduleNavigate(
          searchUrlFor(expectedKeyword, page + 1), r.delaySec, runId, r.delayReason, expectedKeyword,
          pageTransitionMeta(expectedKeyword, page + 1, maxPages)
        );
        return navigationScheduled;
      }
      /* v4.0.58: 최대 검색 페이지는 목표가 아니라 상한입니다. 백그라운드가 광고 제외 누적 자연노출
         목표 달성 등 정상 조기완료를 확정하면 최대 페이지 이전이어도 즉시 종료합니다. */
      if (r.aggregate) {
        state.agg = r.aggregate;
        state.key = r.localKey || null;
        renderAgg(r.aggregate, candidates);
        setProgress(100, `${state.keyword} 상품 ${collectedCount}개 수집·분석 완료${Number(r.organicCollected)>=Math.max(1,Number(settings?.sourceDataTargetOrganic||60)||60)?` · 자연노출 목표 ${fmt(r.organicCollected)}/${fmt(Math.max(1,Number(settings?.sourceDataTargetOrganic||60)||60))} 충족`:''} · 로컬DB ${r.aggregate.grade} 저장${r.adaptiveFastComplete ? ' · 충분한 표본으로 다음 페이지 생략' : ''}`);
        await applySidebarUploadState(r, r.aggregate);
        const automationUploadConclusion=r.serverStatusUnknown===true?'서버 상태 별도 확인 필요':r.uploadedToServer===true?'서버 업로드 완료':(r.uploadPending!==false?'업로드 대기':'로컬 저장 완료');
        setProgress(100,`${state.keyword} 상품 ${collectedCount}개 수집·분석 완료 · ${automationUploadConclusion}${r.uploadError?` · ${String(r.uploadError).slice(0,90)}`:''}`);
        if(r.uploadedToServer===true)await recordTabSessionEvent('auto-uploaded',{processed:1,uploaded:1},{eventId:`auto-uploaded:${runId}:${state.keyword}`});
        else if(r.uploadPending!==false)await recordTabSessionEvent('auto-upload-pending',{processed:1,uploadPending:1},{eventId:`auto-upload-pending:${runId}:${state.keyword}`});
      } else if (r.collectionOutcome === 'below_criteria') {
        state.agg = r.belowCriteriaAggregate || null;
        state.key = null;
        state.adminOverrideUploaded=false;
        if(state.agg)renderAgg(state.agg,candidates);
        setDisabled('spx-upload', true);
        setText('spx-upload', r.belowCriteriaIndexStatusV165==='saved'?'기준 미달 · 경량 색인 저장':r.belowCriteriaIndexStatusV165==='queued'?'기준 미달 · 색인 반영 대기':'기준 미달 · 전체데이터 미업로드');
        const adminButton=getUiElement('spx-admin-override-upload',{repair:false});if(adminButton){adminButton.hidden=!state.agg;adminButton.disabled=!state.agg;adminButton.textContent='관리자 통과 · 서버 올리기';}
        const reason = r.excludedReason || r.evaluationStatus || `최종 합산 ${state.agg?.grade_score ?? '-'}점 · B 기준 4점 미만`;
        if(!state.agg)setHtml('spx-body', `<div class="spx-empty">상품 <b>${fmt(collectedCount)}개</b>는 정상 수집했습니다.<br><br>${esc(reason)}<br><br>기술적 실패가 아니라 수집등급 기준미달로 종료했습니다.</div>`);
        setText('spx-auto-text', `${state.keyword} 실측 집계 완료 · 기준미달 · 전체데이터 미업로드 · ${r.belowCriteriaIndexStatusV165==='saved'?'경량 색인 저장':r.belowCriteriaIndexStatusV165==='queued'?'색인 반영 대기':'색인 미반영'} · ${reason}`);
        setProgress(100, `${state.keyword} 상품 ${collectedCount}개 수집·집계 완료 · 기준미달`);
        const belowCriteriaDelta={processed:1,belowCriteria:1};await recordTabSessionEvent('auto-below-criteria',belowCriteriaDelta,{eventId:`auto-below-criteria:${runId}:${state.keyword}`});
      } else if (r.excluded) {
        state.agg = r.excludedAggregate || null;
        state.key = null;
        state.adminOverrideUploaded=false;
        /* 정상 집계된 기준미달 결과는 실패 화면 대신 계산된 점수/지표를 그대로 보여줍니다. */
        if(state.agg)renderAgg(state.agg,candidates);
        setDisabled('spx-upload', true);
        setText('spx-upload', '기준 미달 · 일반 업로드 불가');
        const adminButton=getUiElement('spx-admin-override-upload',{repair:false});if(adminButton){adminButton.hidden=!state.agg;adminButton.disabled=!state.agg;adminButton.textContent='관리자 통과 · 서버 올리기';}
        const reason = r.excludedReason || (r.evaluationStatus === '평가 보류' ? '평가 보류 · 재수집 필요' : 'S+·S·A·B 후보 기준 미달');
        if(!state.agg)setHtml('spx-body', `<div class="spx-empty">상품 <b>${fmt(collectedCount)}개</b>는 정상 수집했습니다.<br><br>${esc(reason)}<br><br>기술적 집계 실패가 아니라 후보 기준 미달로 종료했습니다.</div>`);
        setText('spx-auto-text', `${state.keyword} 실측 집계 완료 · ${reason}`);
        setProgress(100, `${state.keyword} 상품 ${collectedCount}개 수집·집계 완료 · 후보 기준 미달`);
        await recordTabSessionEvent('auto-excluded',{processed:1,excluded:1},{eventId:`auto-excluded:${runId}:${state.keyword}`});
      } else {
        setDisabled('spx-upload', true);
        setText('spx-upload', '집계 실패 · 올리기 불가');
        setHtml('spx-body', `<div class="spx-empty">상품 <b>${fmt(collectedCount)}개</b> 수집 후 집계에 실패했습니다.<br><br>대기열의 실패 사유를 확인해 주세요.</div>`);
        setProgress(100, `${state.keyword} 상품 ${collectedCount}개 수집 · 집계 실패`);
      }
      setText('spx-status', r.state?.running ? '다음 준비' : '자동 완료');
      await refreshDbInfo();

      if(r.transition==='MANUAL_COMPLETE'||ctx?.state?.sidebarManual===true&&r?.state?.running===false){
        rememberRenderedCompletion(runId);
        setText('spx-status','단건 분석 완료');
        setText('spx-auto-text',r?.state?.lastMessage||`${state.keyword} 단건 분석 완료 · 자동 대기열은 정지 상태를 유지합니다.`);
        await setTabAutomationTimer('stop');
        state.autoStarted=false;activeRunId='';
        return false;
      }
      if (r.transition && r.transition !== 'NEXT_KEYWORD') throw new Error(`키워드 완료 응답 형식 오류: ${r.transition}`);
      navigationScheduled = scheduleNavigate(r.nextUrl, r.delaySec, runId, r.delayReason, r?.state?.currentKeyword || '');
      return navigationScheduled;
    } catch (e) {
      finishStage('중단');
      if (e?.spxContextInvalidated) return false;
      if (e?.spxNormalEnd) {
        if(String(e?.code||'')==='PAGE_NAVIGATION'){
          /* v4.0.95: 쿠팡 SPA가 검색결과 DOM/UI를 재생성하면 기존 content task의 epoch가
             자연스럽게 오래된 상태가 될 수 있습니다. 이 정상 페이지 전환을 자동수집 종료로
             처리하면 background는 running인데 화면만 중단되어 같은 문구/분석 시작이 반복됩니다.
             background 실행은 유지하고 현재 state를 1회 재확인해 정확한 키워드/페이지로만 재동기화합니다. */
          console.debug('[SPX] 정상 페이지 이동 · 이전 DOM 작업만 폐기하고 현재 실행 계속',e?.message||'');
          state.busy=false;state.autoStarted=false;
          let latest=null;
          try{const snapshot=await Promise.race([readAutomationState(),sleep(1200).then(()=>null)]);latest=snapshot?.state||null;}catch(_){latest=null;}
          if(latest?.running===true&&String(latest?.runId||'')===String(runId||activeRunId||'')){
            const resumeKeyword=String(latest.currentKeyword||expectedKeyword||state.lockedKeyword||state.keyword||'').trim();
            const resumePage=Math.max(1,Number(latest.currentPage)||Number(new URLSearchParams(location.search).get('page'))||1);
            const visibleKeyword=currentKeyword(),visiblePage=Math.max(1,Number(new URLSearchParams(location.search).get('page'))||1);
            setDisplay('spx-auto','flex');setText('spx-status','페이지 전환 동기화');
            setText('spx-auto-text',`${resumeKeyword||'현재 키워드'} ${resumePage}페이지 · 최신 화면 기준으로 수집을 계속합니다.`);
            if(resumeKeyword&&(normKeyword(visibleKeyword)!==normKeyword(resumeKeyword)||visiblePage!==resumePage)){
              navigationScheduled=scheduleNavigate(searchUrlFor(resumeKeyword,resumePage),0.35,runId,'정상 페이지 이동 후 현재 작업 재동기화',resumeKeyword,
                latest?.keywordLoopCompleted!==true&&['collecting','navigating'].includes(String(latest?.pageLoopPhase||''))?pageTransitionMeta(resumeKeyword,resumePage,latest?.pageLoopMaxPages||maxPages):null);
              return navigationScheduled;
            }
            scheduleAutoRun(jitterMs(220,380));
            return false;
          }
          /* background까지 이미 종료된 경우에만 실제 종료 UI를 사용합니다. */
          handleNormalAutomationEnd({code:'STOPPED',reason:latest?.lastMessage||'자동수집 실행이 종료되었습니다.'});
          return false;
        }
        handleNormalAutomationEnd(e);
        return false;
      }

      const page = Math.max(1, Number(ctx?.state?.currentPage) || Number(new URLSearchParams(location.search).get('page')) || 1);

      /* [v2.5.2] MutationObserver 대기 중 늦게 빈 결과 문구가 나타난 경우에도 catch에서
         차단·실패로 보내지 않고 빈 페이지 완료 메시지를 저장하여 현재 키워드를 정상 종료합니다. */
      const lateReadiness=searchPageReadiness();
      if(lateReadiness.noResults){
        console.info('[SPX] 명시적 빈 검색결과 · 실패/IP변경 없이 정상 완료',lateReadiness.noResultSource||'본문 문구');
        const noResultRequestId=`${runId}:${normKeyword(expectedKeyword||state.lockedKeyword||state.keyword)}:${page}:late-no-result`;
        pageSaveMarker={runId,requestId:noResultRequestId,keyword:expectedKeyword||state.lockedKeyword||state.keyword,page,startedAt:Date.now()};
        pendingPageSaveResponse=pageSaveMarker;
        const noResultResponse=await runtimeMessage({
          type:'SPX_AUTOMATION_PAGE',requestId:noResultRequestId,runId,keyword:expectedKeyword||state.lockedKeyword||state.keyword,page,
          products:[],noSearchResults:true,parserStrategy:'confirmed-no-results-late',
          candidates:[],relatedTerms:[],externalMetrics:{detected:false},searchCategory:null,resultTotal:null,
          manualMode:manualCollectionRun,
        });
        if(noResultResponse?.ignored||noResultResponse?.normalEnd){
          if(noResultResponse?.manualRestartRequired){showStaleManualRestartPrompt(noResultResponse.reason,noResultResponse.delaySec||3);return false;}
          if(noResultResponse?.resync&&noResultResponse?.nextUrl){
            const resyncKeyword=String(noResultResponse?.state?.currentKeyword||expectedKeyword||'').trim();
            const resyncPage=Math.max(1,Number(noResultResponse?.state?.currentPage)||page);
            const resyncMeta=noResultResponse?.state?.keywordLoopCompleted!==true&&['collecting','navigating'].includes(String(noResultResponse?.state?.pageLoopPhase||''))
              ? pageTransitionMeta(resyncKeyword,resyncPage,noResultResponse?.state?.pageLoopMaxPages||maxPages):null;
            navigationScheduled=scheduleNavigate(noResultResponse.nextUrl,noResultResponse.delaySec||1,runId,noResultResponse.delayReason||'빈 결과 후 순서 동기화',resyncKeyword,resyncMeta);
            return navigationScheduled;
          }
          handleNormalAutomationEnd(noResultResponse);return false;
        }
        if(!noResultResponse?.ok)throw new Error(noResultResponse?.error||'빈 검색결과 정상 종료 저장 실패');
        setText('spx-status',noResultResponse?.state?.running?'다음 준비':'자동 완료');
        setHtml('spx-body',`<div class="spx-empty">“${esc(expectedKeyword||state.keyword)}” ${page}페이지에서 더 이상 검색결과가 없어 현재 키워드 수집을 정상 종료했습니다.</div>`);
        setProgress(100,'검색결과 없음 · 현재 키워드 정상 종료');
        if(noResultResponse?.transition==='MANUAL_COMPLETE'||noResultResponse?.state?.running===false){rememberRenderedCompletion(runId);setText('spx-status','단건 분석 완료');activeRunId='';return false;}
        navigationScheduled=scheduleNavigate(noResultResponse.nextUrl,noResultResponse.delaySec||1,runId,noResultResponse.delayReason||'빈 결과 후 다음 키워드 이동',noResultResponse?.state?.currentKeyword||expectedKeyword);
        return navigationScheduled;
      }

      /* v4.0.26: 차단 복구 UI는 단일 상태 소유자가 순차 표시하고 현재 키워드·페이지 체크포인트를 유지합니다. */
      if(e?.code==='STAGE_TIMEOUT'&&e?.stage==='페이지 합산·최종 저장'&&finalSaveStarted){
        // The page-save request is still allowed to finish in the service worker after Promise.race.
        // Do not mislabel this as product failure or send a competing SPX_AUTOMATION_FAIL.
        finishStage('최종 저장 ACK 미확인 · 상태 재조회');
        setDisplay('spx-auto','flex');setText('spx-status','최종 저장 확인 지연');
        setText('spx-auto-text','서버 응답 대기 제한 도달 · 로컬/서버 작업 상태를 다시 확인합니다. 업로드 완료로 표시하지 않습니다.');
        setProgress(92,'저장 ACK 미확인 · 동일 키워드와 페이지 보존 · 상태 재조회');
        state.busy=false;state.autoStarted=false;
        scheduleAutoRun(jitterMs(1500,2200));
        return false;
      }

      if (e?.code === 'COUPANG_BLOCKED') {
        console.info('[SPX] 쿠팡 접근 제한 감지 · 안전 복구 전환', e?.readiness?.blockReason||e?.message||'');
        ensureUi();
        if(!recoveryUiOwner){recoveryUiOwner=true;setText('spx-status','쿠팡 차단 감지 · 네트워크 모드 확인');}startRecoveryCountdownMonitor();
        try {
          const manualVerification=e?.manualVerification===true||e?.readiness?.manualVerification===true;
          const blockedRequest=runtimeMessage({ type:'SPX_REPORT_BLOCKED', reason:e?.readiness?.blockReason || e?.message || '쿠팡 접근 제한 화면 감지', keyword:expectedKeyword||state.keyword||currentKeyword(), page, url:location.href, manualVerification, blockSource:e?.blockSource||'main-page', collectionStage:String(activeStage?.name||''), snapshotAvailable:recoverySnapshotMatches(expectedKeyword||state.keyword||currentKeyword(),page,runId), networkTarget:explicitCollectionNetworkTargetV135(activeCollectionSettingsOverride), dedicatedTab:explicitDedicatedCurrentTabV135(activeCollectionSettingsOverride) });
          setTimeout(()=>startRecoveryCountdownMonitor(),300);
          const blocked = await blockedRequest;
          if(blocked?.systemNetwork===true){
            recoveryUiOwner=false;
            const systemError=esc(String(blocked?.error||'기본 Windows 네트워크 수집 중 쿠팡 접근 제한이 감지되었습니다.'));
            setText('spx-status','쿠팡 접근 제한 · 기본망 유지');
            setHtml('spx-body',`<div class="spx-empty">🛑 쿠팡 접근 제한 감지<br><br>${systemError}<br><br>현재 수집만 중단했으며 USB 테더링 확인·IP↻·비행기모드·공인 IP 변경은 실행하지 않았습니다.</div>`);
            setProgress(100,'기본 Windows 네트워크 · 테더링 복구 없음 · IP 변경 없음');
          }else{
            const action = esc(blocked?.action || '진행상태 저장 후 복구 대기');
            const recheck = blocked?.autoResume ? `<br><br><b id="spx-recovery-inline-countdown">복구 상태 확인 중</b><br>[IP↻] 수동 클릭과 동일한 단일 복구 경로 · 차단 감지 → 바로 중단 → ♻ 1회 → 🧹 1회 → 설정 시간 비행기 모드 ON → OFF → 새 IP 확인 → 페이지 새로고침 F5 → 정상 확인 → 작업 재개 순서로 진행합니다.` : '<br><br>동일 run·키워드에서 자동 IP↻ 1회를 이미 사용했거나 복구를 시작하지 못했습니다.';
            setHtml('spx-body', `<div class="spx-empty">🛑 쿠팡 접근 제한 감지<br><br><b>${action}</b>${recheck}<br><br>차단이 계속되면 자동 복구는 같은 차단에서 1회만 실행합니다. 현재 페이지를 확인한 뒤 필요하면 [IP↻]를 수동으로 눌러주세요.</div>`);
            if(blocked?.autoResume)startRecoveryCountdownMonitor();
            else {recoveryUiOwner=false;setProgress(0,'쿠팡 차단 · 사용자 확인 필요');}
          }
        } catch (reportError) {
          recoveryUiOwner=false;
          console.warn('[SPX] 차단 보고 실패', reportError);
          setHtml('spx-body', `<div class="spx-empty">🛑 쿠팡 접근 제한 화면이 감지되었습니다. 자동수집을 중단해 주세요.</div>`);
        }
        navigationScheduled = false;
        return false;
      }

      if (['PAGE_LOOP_STATE_MISMATCH'].includes(String(e?.code || ''))) {
        console.warn('[SPX][페이지 루프 보호] 다음 키워드 전환 대신 현재 키워드 상태를 다시 확인합니다.', e);
        ensureUi(); setText('spx-status','페이지 루프 복구');
        setHtml('spx-body',`<div class="spx-empty">${esc(expectedKeyword)}의 다음 페이지 처리 상태를 다시 맞추고 있습니다.<br><br>다음 키워드 이동은 차단했습니다.</div>`);
        state.autoStarted=false; state.busy=false; scheduleAutoRun(jitterMs(650,1050));
        return false;
      }

      /* v1.5.25: MV3 Service Worker가 페이지 저장/집계 중 재기동되면
         receiving-end / async response channel closed가 발생할 수 있습니다. 이것을 실제 수집 실패로
         SPX_AUTOMATION_FAIL 처리하면 키워드가 실패로 확정되고 처음 상태로 돌아갑니다.
         상태 mutation은 하지 않고 짧게 다시 context를 읽어 현재 run/페이지 체크포인트에서 재개합니다. */
      if(SPX.util.isTransientRuntimeMessageError?.(e)&&SPX.util.runtimeAlive?.()){
        console.info('[SPX] 자동수집 메시지 연결 일시 종료 · 실패 처리 없이 재연결',e?.message||String(e));
        ensureUi();
        setText('spx-status','연결 복구 중');
        setText('spx-auto-text',`${expectedKeyword||state.keyword||'현재 키워드'} · Service Worker 응답 연결을 다시 확인한 뒤 저장된 페이지에서 계속합니다.`);
        setProgress(Math.max(5,Math.min(95,Number(getUiElement('spx-pfill',{repair:false})?.style?.width?.replace('%',''))||5)),'확장 메시지 연결 복구 중 · 실패로 기록하지 않음');
        state.autoStarted=false;state.busy=false;
        setTimeout(()=>{if(!contextInvalidated&&SPX.util.runtimeAlive?.())scheduleAutoRun(jitterMs(700,1200));},450);
        return false;
      }

      const expectedCode=String(e?.code||'');
      if (acknowledgedSaveResponse?.ok === true) {
        /* 저장 확인 이후의 표시/UI 오류는 수집 실패가 아닙니다. 이미 저장한 상품을 다시 1/15부터
           수집하거나 실패·기술오류 이력을 만들지 않고 background가 정한 다음 순서로 이동합니다. */
        console.warn('[SPX] 저장 완료 후 화면 처리 오류 · 저장 상태 유지 후 다음 순서 진행', e);
        ensureUi();
        setText('spx-status', '저장 완료 · 다음 준비');
        setText('spx-auto-text', `${state.keyword || expectedKeyword} 저장 완료 · 화면 표시 오류는 수집 실패로 처리하지 않습니다.`);
        const saved = acknowledgedSaveResponse;
        if(saved.doneKeyword === false){
          const nextPage=Math.max(1,Number(saved.expectedPage||saved?.state?.currentPage)||page+1);
          const nextKeyword=String(saved.expectedKeyword||saved?.state?.currentKeyword||expectedKeyword||'').trim();
          navigationScheduled=scheduleNavigate(
            saved.nextUrl||searchUrlFor(nextKeyword,nextPage),saved.delaySec||1,runId,saved.delayReason||'저장 완료 후 다음 페이지',nextKeyword,
            pageTransitionMeta(nextKeyword,nextPage,maxPages)
          );
          return navigationScheduled;
        }
        if(saved.transition==='MANUAL_COMPLETE'||saved?.state?.running===false){
          rememberRenderedCompletion(runId);
          setText('spx-status','단건 분석 완료');
          activeRunId='';
          return false;
        }
        if(saved.nextUrl){
          navigationScheduled=scheduleNavigate(saved.nextUrl,saved.delaySec||1,runId,saved.delayReason||'저장 완료 후 다음 키워드',saved?.state?.currentKeyword||'');
          return navigationScheduled;
        }
        return false;
      }
      if(['STAGE_TIMEOUT','SEARCH_LOAD_TIMEOUT','STALE_RUN','STALE_TASK','STALE_KEYWORD','STALE_PAGE','NON_OWNER_TAB','COUPANG_BLOCKED'].includes(expectedCode))console.info('[SPX] 자동수집 안전 종료·복구',expectedCode,e?.message||'');
      else console.error('[SPX] 자동수집 실패', e);
      ensureUi();
      setText('spx-status', '자동 오류');

      let stillActive = false;
      try {
        await assertRunActive(task, '실패 처리 전');
        stillActive = true;
      } catch (stopError) {
        if (stopError?.spxNormalEnd) {
          handleNormalAutomationEnd(stopError);
          return false;
        }
      }
      if (!stillActive) return false;

      const r = await runtimeMessage({
        type: 'SPX_AUTOMATION_FAIL',
        runId,
        keyword: state.keyword,
        error: e.message,
        /* 상세상품 수집이 이미 끝난 뒤 최종 집계/저장 코드 오류라면 같은 USB 테더링 상품 상세를
           1/15부터 다시 두 번 반복하지 않습니다. 원천상품은 background에 이미 안전 저장되어 있습니다. */
        noPageRetry: finalSaveStarted === true,
        manualMode:manualCollectionRun,
      });
      if (r?.retryPage && r?.nextUrl) {
        setText('spx-status','현재 페이지 재확인');
        setHtml('spx-body',`<div class="spx-empty">${esc(expectedKeyword)} ${Math.max(1,Number(r.expectedPage)||page)}페이지에서 일시 오류가 발생했습니다.<br><br>다음 키워드로 넘어가지 않고 같은 페이지를 다시 확인합니다.</div>`);
        navigationScheduled=scheduleNavigate(
          searchUrlFor(expectedKeyword,Math.max(1,Number(r.expectedPage)||page)),r.delaySec||2,runId,r.delayReason||'현재 페이지 재확인',expectedKeyword,
          pageTransitionMeta(expectedKeyword,Math.max(1,Number(r.expectedPage)||page),maxPages)
        );
        return navigationScheduled;
      }
      if (r?.ignored || r?.normalEnd) {
        if (r?.manualRestartRequired) {
          showStaleManualRestartPrompt(r.reason, r.delaySec || 3);
          return false;
        }
        if (r?.resync && r?.nextUrl) {
          const resyncKeyword=String(r?.state?.currentKeyword||expectedKeyword||'').trim();
          const resyncPage=Math.max(1,Number(r?.state?.currentPage)||page);
          const resyncMeta=r?.state?.keywordLoopCompleted!==true&&['collecting','navigating'].includes(String(r?.state?.pageLoopPhase||''))
            ? pageTransitionMeta(resyncKeyword,resyncPage,r?.state?.pageLoopMaxPages||maxPages):null;
          navigationScheduled = scheduleNavigate(r.nextUrl, r.delaySec || 1, runId, r.delayReason || '페이지 순서 자동 동기화', resyncKeyword, resyncMeta);
          return navigationScheduled;
        }
        if (r?.silent || r?.ownerTabMismatch || r?.code === 'NON_OWNER_TAB') {
          cancelAutomationWork('', { updateUi: false });
          setDisplay('spx-auto', 'none');
          return false;
        }
        handleNormalAutomationEnd(r);
        return false;
      }
      await requireUi(5000, task);
      setHtml('spx-body', `<div class="spx-empty">${esc(state.keyword)} 수집 실패<br>${esc(e.message)}<br><br>현재 페이지 재확인 한도를 초과해 이 키워드를 실패 처리했습니다.</div>`);
      await recordTabSessionEvent('auto-failed',{processed:1,failed:1},{eventId:`auto-failed:${runId}:${state.keyword}`});

      navigationScheduled = scheduleNavigate(r?.nextUrl, r?.delaySec || 5, runId, r?.delayReason || '실패 후 다음 키워드 이동 대기', r?.state?.currentKeyword || expectedKeyword);
      return navigationScheduled;
    } finally {
      if (pendingPageSaveResponse === pageSaveMarker) pendingPageSaveResponse = null;
      if (taskIsCurrent(task)) state.busy = false;
      if (!navigationScheduled && !navigationTimer) state.autoStarted = false;
    }
  }

  async function maybeAutoRun() {
    if (contextInvalidated || !SPX.util.runtimeAlive?.()) { shutdownInvalidatedContext(); return; }
    if (state.autoStarting || state.autoStarted || state.busy || navigationTimer || keywordTransitionPromise) return;

    state.keyword = currentKeyword();
    if (!state.keyword) return;

    state.autoStarting = true;
    let handedOff = false;

    try {
      if (!(await requireUi(12000))) {
        console.info('[SPX] 자동수집 UI 생성 대기 · 재시도');
        queueUiRepair(jitterMs(140,240));
        scheduleAutoRun(jitterMs(650,1050));
        return;
      }

      /* 지정키워드·발견·재수집·네이버 대기는 모두 동일한 직접 순서 목록입니다.
         쿠팡이 검색창 값과 URL q를 잠시 다르게 유지해도, 검색창에 현재 순서 키워드가 있고
         상품 결과가 준비됐으면 그 키워드를 신뢰해 곧바로 단건 분석을 시작합니다. */
      const preContextRemote=(await readAutomationState().catch(()=>null))?.state||null;
      let contextKeyword=state.keyword;
      if(preContextRemote?.running&&preContextRemote?.directSequentialList===true&&preContextRemote?.currentKeyword){
        const expected=normalizeVisibleKeyword(preContextRemote.currentKeyword);
        const input=document.querySelector?.('#headerSearchKeyword, form[action*="/np/search"] input[name="q"], input[name="q"]');
        const inputKeyword=normalizeVisibleKeyword(input?.value||'');
        if(expected&&canonicalVisibleKeyword(inputKeyword)===canonicalVisibleKeyword(expected)){
          contextKeyword=expected;
          state.keyword=expected;
          state.lockedKeyword=expected;
          markKeywordTransitionReady(expected,String(preContextRemote.runId||activeRunId||''),searchResultSignature());
        }
      }
      const ctx = await runtimeMessage({ type: 'SPX_AUTOMATION_CONTEXT', keyword: contextKeyword });
      automationContextFailureCount=0;
      if (ctx?.code === 'FLOW_BUSY') {
        setDisplay('spx-auto','flex');
        setText('spx-status','최종 집계 대기');
        setText('spx-auto-text','이전 페이지 집계 처리 완료 대기 · 완료 즉시 자동으로 이어서 진행합니다.');
        scheduleAutoRun(jitterMs(1900,2600));
        return;
      }
      if (ctx?.ownerTabMismatch || ctx?.code === 'NON_OWNER_TAB') {
        cancelAutomationWork('', { updateUi: false });
        setDisplay('spx-auto', 'none');
        return;
      }
      if (!ctx?.ok || !ctx.running) {
        if (ctx?.state && !ctx.state.running) {
          cancelAutomationWork(ctx.state.lastMessage || '자동수집이 중단되었습니다.', { updateUi: false });
        }
        return;
      }

      state.lockedKeyword=String(ctx?.state?.currentKeyword||ctx?.keyword||'').trim();
      const runId = String(ctx.runId || ctx.state?.runId || '');
      if (!runId) return;

      const remote = await readAutomationState();
      if (!remote?.state?.running || String(remote.state.runId || '') !== runId) {
        handleNormalAutomationEnd({ code: 'STALE_RUN', reason: '실행 직전 상태가 바뀌어 자동수집을 시작하지 않았습니다.' });
        return;
      }

      if (!(await requireUi(6000))) {
        console.info('[SPX] 자동수집 직전 UI 재생성 대기');
        queueUiRepair(jitterMs(140,240));
        scheduleAutoRun(jitterMs(650,1050));
        return;
      }

      activeRunId = runId;
      state.autoStarted = true;
      setDisplay('spx-auto', 'flex');

      if (ctx.waiting && !ctx.shouldRun) {
        setText('spx-auto-text', ctx.state?.lastMessage || '새 후보 대기 중');
        setText('spx-status', '후보 대기');
        return;
      }

      if (ctx.nextUrl && !ctx.shouldRun) {
        setText('spx-auto-text', '대기열 키워드로 이동');
        handedOff = scheduleNavigate(ctx.nextUrl, 1, runId, '대기열 키워드로 이동', ctx?.state?.currentKeyword || state.lockedKeyword);
        return;
      }

      if (ctx.shouldRun) {
        const urlKey=canonicalVisibleKeyword(urlCurrentKeyword?.()),runKey=canonicalVisibleKeyword(state.lockedKeyword||state.keyword);
        if(urlKey&&runKey&&urlKey===runKey)clearKeywordTransitionMarker(state.lockedKeyword||state.keyword,runId);
        else markKeywordTransitionReady(state.lockedKeyword||state.keyword,runId,searchResultSignature());
        await setTabAutomationTimer('start');
        handedOff = await runAutomationPage(ctx);
      }
    } catch (e) {
      if (e?.spxContextInvalidated) return;
      automationContextFailureCount+=1;
      const timeoutLike=/응답 시간이 초과|timeout/i.test(String(e?.message||e||''));
      if(timeoutLike)console.info(`[SPX] 자동수집 상태 응답 지연 · ${String(e?.message||e||'')}`);
      else console.warn('[SPX] 자동수집 상태 확인 실패', e);
      if(automationContextFailureCount>=3&&!timeoutLike){
        ensureUi();setDisplay('spx-auto','flex');
        setText('spx-status','자동 분석 시작 실패');
        setText('spx-auto-text',`자동 분석 시작 응답 실패 · ${e?.message||String(e)} · 확장프로그램을 새로고침한 뒤 같은 목록을 다시 실행하세요.`);
        clearAutomationKickWatchdog();
        return;
      }
      scheduleAutoRun(jitterMs(500,850));
    } finally {
      state.autoStarting = false;
      if (!handedOff && !state.busy && !navigationTimer) {
        state.autoStarted = false;
      }
    }
  }

  function showDbInfo() {
    ensureTabSessionTicker();
    renderTabSessionStats();
  }
async function refreshDbInfo() {
    ensureTabSessionTicker();
    void refreshTabSessionStats().catch(()=>{});
    void refreshTransferCountsV1631().catch(()=>{});
    void runtimeMessage({type:'SPX_STATS'}).then((stats)=>{
      if(stats?.ok&&stats?.data){
        // SPX_STATS is an operational preview, not the cumulative history snapshot.
        // Keep its attention flag without overriding the single authoritative count owner.
        tabSessionStats.uploadPendingAttentionDb=Math.max(0,Number(stats.data.pendingAttention)||0);
      }
    }).catch(()=>{});
    return true;
  }

  async function resetForPageChange() {
    if (contextInvalidated) return;
    cancelAutomationWork('페이지 이동으로 이전 작업을 정리했습니다.', { updateUi: false });
    const lockedKeyword=state.lockedKeyword||'';
    state = { keyword: '', lockedKeyword, detected: 0, agg: null, key: null, raw: [], busy: false, autoStarting: false, autoStarted: false, candidates: [] };
    if (!(await waitForUi())) return;
    detect();
    renderIdle();
    setDisabled('spx-upload', true);
    setText('spx-upload', '먼저 분석하세요');
    const adminButton=getUiElement('spx-admin-override-upload',{repair:false});if(adminButton){adminButton.hidden=true;adminButton.disabled=true;adminButton.textContent='관리자 통과 · 서버 올리기';}
    state.adminOverrideUploaded=false;
    setDisplay('spx-prog', 'none');
    const remote=(await readAutomationState().catch(()=>null))?.state||null;
    if(remote?.running&&remote?.runId){
      activeRunId=String(remote.runId||'');
      armAutomationKickWatchdog(activeRunId,remote.currentKeyword||'','페이지 이동 완료');
      scheduleAutoRun(0);
    }else scheduleAutoRun(jitterMs(560,880));
  }

  function nodeIsCollectorUiV10157(node){
    if(!node)return false;
    const el=node.nodeType===1?node:node.parentElement;
    if(!el)return false;
    return el.id==='spx-overlay'||el.id==='spx-tab'||el.id==='spx-tooltip'||Boolean(el.closest?.('#spx-overlay,#spx-tab,#spx-tooltip'));
  }
  function mutationIsCollectorUiOnlyV10157(record){
    if(nodeIsCollectorUiV10157(record?.target))return true;
    const nodes=[...(record?.addedNodes||[]),...(record?.removedNodes||[])].filter(Boolean);
    return nodes.length>0&&nodes.every(nodeIsCollectorUiV10157);
  }
  function lifecycleSignatureV10157(){
    const keyword=normalizeVisibleKeyword(currentKeyword()||String(getUiElement('spx-guided-keyword',{repair:false})?.value||''));
    const productLinks=document.querySelectorAll('a[href*="/vp/products/"]').length;
    return `${location.pathname}${location.search}|${keyword}|${productLinks}`;
  }
  function startLifecycleWatch() {
    if (contextInvalidated || lifecycleTimer) return;
    lifecycleTimer = setInterval(() => {
      if (contextInvalidated || !SPX.util.runtimeAlive?.()) {
        shutdownInvalidatedContext();
        return;
      }
      const urlChanged = location.href !== lastUrl;
      if (urlChanged) {
        lastUrl = location.href;
        lifecyclePageDirtyV10157=true;
        lifecycleLastSignatureV10157='';
        resetForPageChange();
        return;
      }
      if (!sidebarContextAvailableV103()) return;
      const uiMissing=!hasCompleteUi();
      if(!lifecyclePageDirtyV10157&&!uiMissing)return;
      const signature=lifecycleSignatureV10157();
      if(uiMissing)ensureUi();
      if(uiMissing||signature!==lifecycleLastSignatureV10157){
        detect();
        const keyword=currentKeyword();
        if(keyword)syncSidebarServerKeywordPresence(false).catch(()=>{});
        lifecycleLastSignatureV10157=signature;
      }
      lifecyclePageDirtyV10157=false;
    }, 3000);

    lifecycleObserver = new MutationObserver((records) => {
      if(contextInvalidated)return;
      if(records?.length&&records.every(mutationIsCollectorUiOnlyV10157))return;
      lifecyclePageDirtyV10157=true;
      if(!hasCompleteUi())queueUiRepair();
    });
    lifecycleObserver.observe(document.documentElement,{childList:true});
    if(document.body)lifecycleObserver.observe(document.body,{childList:true});
  }


  async function removeCompletedSpecifiedKeyword(keyword) {
    const key=SPX.util?.canonicalKeyword?.(keyword)||String(keyword||'').replace(/\s+/g,'').toLowerCase();if(!key)return false;
    const filter=(list)=>parseTextSeeds(Array.isArray(list)?list.join(','):String(list||''),null).filter((item)=>(SPX.util?.canonicalKeyword?.(item)||String(item).replace(/\s+/g,'').toLowerCase())!==key);
    const remaining=filter(committedSidebarExploration.seedKeywords||[]);if(remaining.length===(committedSidebarExploration.seedKeywords||[]).length)return false;
    committedSidebarExploration={...committedSidebarExploration,seedKeywords:remaining};
    const seed=getUiElement('spx-sourcing-seed-keyword',{repair:false});if(seed){seed.value=remaining.join(', ');syncSidebarExplorationOptions();}
    await chrome.storage.local.set({[SIDEBAR_EXPLORATION_KEY]:committedSidebarExploration}).catch(()=>{});renderSidebarSourcingSummary();return true;
  }

  function bindAutomationStateWatch() {
    storageChangeHandler = (changes, areaName) => {
      if (contextInvalidated || areaName !== 'local') return;
      if(changes[SPX_SIDEBAR_COLLAPSED_KEY_V1632]){
        // 다른 쿠팡 탭의 S 버튼 조작도 새로고침 없이 동일 상태로 반영합니다.
        sidebarCollapsedRevisionV1632++;
        sidebarCollapsedV1632=changes[SPX_SIDEBAR_COLLAPSED_KEY_V1632].newValue===true;
        sidebarCollapsedReadyV1632=true;
        renderSidebarCollapsedV1632();
      }
      if(changes[RECENT_HISTORY_CLEAR_KEY_V101510]){
        persistentHistoryResetAtV101510=Math.max(persistentHistoryResetAtV101510,Number(changes[RECENT_HISTORY_CLEAR_KEY_V101510]?.newValue)||0);
        if(currentAutomationSummary){const normalized=normalizeAutomationSummaryForHistoryReset(currentAutomationSummary);currentAutomationSummary=normalized?._historyVisibleActivity===false?null:normalized;}
      }
      if(changes['spxConnectivityRecoveryV3067']){
        /* v1.1.4: storage newValue 자체로 먼저 동기 렌더링합니다. runtime 왕복/busy lock보다 앞서 그려
           ♻→🧹→✈처럼 짧게 지나가는 실제 단계도 화면에서 건너뛰지 않습니다. */
        const recovery=changes['spxConnectivityRecoveryV3067']?.newValue||{};
        const activeNow=renderRecoveryStoragePhaseV114(recovery);
        if(activeNow)startRecoveryCountdownMonitor();
        renderRecoveryCountdownOnce({autoStart:false}).then((active)=>{if(active)startRecoveryCountdownMonitor();}).catch(()=>{});
      }
      if (changes[SPX.util.SETTINGS_KEY || 'settings']) {
        const updatedSettings=changes[SPX.util.SETTINGS_KEY || 'settings'].newValue || {};
        syncSidebarAutoUploadSetting(updatedSettings).catch(() => {});
        syncNextNavigationDelaySetting(updatedSettings).catch(() => {});
        if(sidebarExtraPageSessionOverride===null)syncSidebarAutoExtraPageSetting().catch(()=>{});
      }
      if(changes[SIDEBAR_SOURCING_MODE_KEY]||changes[SIDEBAR_EXPLORATION_KEY]||changes[COLLECTION_PROFILE_KEY]){
        const incomingMode=normalizeSidebarSourcingMode(changes[SIDEBAR_SOURCING_MODE_KEY]?.newValue||'');
        const manualModeProtected=localManualScanActive===true||state.busy===true&&committedSidebarSourcingMode==='guided';
        if(manualModeProtected&&changes[SIDEBAR_SOURCING_MODE_KEY]&&incomingMode!=='guided'){
          chrome.storage.local.set({[SIDEBAR_SOURCING_MODE_KEY]:'guided'}).catch(()=>{});
          selectSidebarSourcingMode('guided',{persist:false,markDirty:false});
        }else{
          const sourcingModal=getUiElement('spx-sourcing-modal',{repair:false});
          loadCommittedSidebarSourcingSelection({apply:!sourcingModal||sourcingModal.hidden}).catch(()=>{});
        }
      }
      /* 관리표에서 상태 색인을 갱신하면 10초 캐시를 기다리지 않고 현재 화면 키워드 색상을 즉시 다시 읽습니다. */
      if(changes.spxServerKeywordLocalIndexV30718){sidebarServerKeywordPresence.checkedAt=0;syncSidebarServerKeywordPresence(true).catch(()=>{});}
      if(changes[SIDEBAR_WING_VIEW_METRIC_KEY]||changes[SIDEBAR_WING_VIEW_QUEUE_KEY])scheduleSidebarWinnerViewMetricsRefreshV426(80);
      /* v1.2.8: 최종 저장 요청 안에서 네이버/서버 단계가 길어질 때 실제 진행 원인을 표시합니다. */
      if(changes['spxPipelineEvents']){
        const events=Array.isArray(changes['spxPipelineEvents']?.newValue)?changes['spxPipelineEvents'].newValue:[];
        const event=events[0]||null;
        const currentKey=canonicalVisibleKeyword(state.lockedKeyword||state.keyword||currentKeyword()||'');
        const eventKey=canonicalVisibleKeyword(event?.keyword||'');
        if(activeRunId&&event&&eventKey&&eventKey===currentKey){
          const stage=String(event.stage||'');
          if(stage==='naver_enriching'){setText('spx-status','네이버 자료 확인 중');setProgress(89,`${event.keyword} · 최종 집계 후 네이버 자료 확인 중`);}
          else if(['naver_enriched','naver_grace_complete','naver_prefetch_reused'].includes(stage)){setText('spx-status','네이버 자료 확인 완료');setProgress(90,`${event.keyword} 자료 확인 완료 · 쿠팡 최종 저장 계속`);}
          else if(stage==='naver_deferred'||stage==='naver_grace_timeout'){setText('spx-status','네이버 후속 수집 전환');setProgress(90,`${event.keyword} 응답 대기 종료 · 쿠팡 저장 계속는 후속 수집`);}
          else if(stage==='uploading'){setText('spx-status','서버 업로드 중');setProgress(92,`${event.keyword} · 서버 업로드 전송 중 · 완료 즉시 하단 집계 반영`);}
          else if(stage==='server_uploaded'){setText('spx-status','서버 업로드 완료');setProgress(96,`${event.keyword} · 서버 업로드 완료 · 최종 상태 동기화 중`);}
          else if(stage==='upload_failed'){setText('spx-status','서버 업로드 지연');setProgress(94,`${event.keyword} · 서버 업로드 지연/실패 · Local 안전보존 처리 중`);}
          else if(stage==='local_saved'&&/업로드 대기/.test(String(event.message||''))){setText('spx-status','업로드 대기 저장 완료');setProgress(96,`${event.keyword} · Local 업로드 대기 저장 완료 · 목록 동기화 중`);}
        }
      }
      /* v1.2.8: 88% 한 문구로 오래 멈춘 것처럼 보이지 않게 실제 업로드 transport 단계를 즉시 표시합니다. */
      if(changes['spxUploadDiagnosticV118']){
        const diagnostic=changes['spxUploadDiagnosticV118']?.newValue||{};
        const currentKey=canonicalVisibleKeyword(state.lockedKeyword||state.keyword||currentKeyword()||'');
        const diagnosticKey=canonicalVisibleKeyword(diagnostic.keyword||'');
        if(activeRunId&&diagnosticKey&&diagnosticKey===currentKey){
          const stage=String(diagnostic.stage||''),status=String(diagnostic.status||'');
          if(stage==='UPLOAD_STAGE_PREPARE'){setText('spx-status','서버 업로드 준비');setProgress(90,`${diagnostic.keyword} · Local 안전보존 확인 · 서버 payload 준비`);}
          else if(stage==='UPLOAD_STAGE_FETCH_START'&&status==='running'){setText('spx-status','서버 업로드 중');setProgress(92,`${diagnostic.keyword} · 서버 전송 중 · 결과 확정 즉시 집계에 반영`);}
          else if(stage==='UPLOAD_STAGE_SERVER_ACK'&&status==='success'){setText('spx-status','서버 업로드 완료');setProgress(96,`${diagnostic.keyword} · 서버 업로드 완료 · 최종 상태 동기화 중`);}
          else if(status==='failed'){setText('spx-status','서버 응답 지연 · Local 보존');setProgress(94,`${diagnostic.keyword} · ${diagnostic.userMessage||'서버 업로드 확인 실패'} · 업로드 대기 저장 확인 중`);}
        }
      }
      if (!changes[AUTO_KEY]) return;
      const next = changes[AUTO_KEY].newValue || {};
      const previous=changes[AUTO_KEY].oldValue||{};if(next.explicitSelectionOnly===true&&next.lastCompletedKeyword&&next.lastCompletedKeyword!==previous.lastCompletedKeyword&&['saved','excluded','requeued'].includes(String(next.lastCollectionOutcome||'')))removeCompletedSpecifiedKeyword(next.lastCompletedKeyword).catch(()=>{});if((next.managerQueueOnly===true||String(committedSidebarExploration?.queueBucket||'')==='manager')&&next.lastCompletedKeyword!==previous.lastCompletedKeyword)refreshManagerQueuePreview({silent:true}).catch(()=>{});
      if(next.running===true){const live=liveAutomationSummaryFromState(next);if(live){const hasVisible=live._historyVisibleActivity!==false&&(Array.isArray(live.history)&&live.history.length>0);currentAutomationSummary=hasVisible?live:null;if(hasVisible){syncFooterRunSummaryV129(live);if(next.lastCompletedKeyword!==previous.lastCompletedKeyword)void syncFooterRunUploadStatesV129(live);}const historyOpen=getUiElement('spx-stop-summary-open',{repair:false});if(historyOpen)historyOpen.hidden=!hasVisible;const modal=getUiElement('spx-stop-summary-modal',{repair:false});if(hasVisible&&modal&&!modal.hidden){renderStopSummaryHistory(live);setText('spx-stop-summary-reason','수집 진행 중 · 실시간 반영');setText('spx-stop-count-success',Number(live.savedCount||0).toLocaleString('ko-KR'));setText('spx-stop-count-requeued',Number(live.requeuedCount||0).toLocaleString('ko-KR'));setText('spx-stop-count-below-criteria',Number(live.belowCriteriaCount||0).toLocaleString('ko-KR'));setText('spx-stop-count-excluded',Number(live.excludedCount||0).toLocaleString('ko-KR'));setText('spx-stop-count-failed',Number(live.failedCount||0).toLocaleString('ko-KR'));setText('spx-stop-count-skipped',Number(live.skippedCount||0).toLocaleString('ko-KR'));setText('spx-stop-summary-meta',`처리 ${Number(live.processedCount||0).toLocaleString('ko-KR')}개 · 상품 ${Number(live.collectedProductCount||0).toLocaleString('ko-KR')}개${live.currentKeyword?` · 현재 ${live.currentKeyword}`:''} · ${formatStopDuration(live.durationMs)}`);const now=Date.now();if(now-recentHistoryPendingRefreshAtV124>=1500){recentHistoryPendingRefreshAtV124=now;void refreshPendingSelectionListV10154().catch(()=>{});}}}}
      else if(next.lastRunSummary){const completed=normalizeAutomationSummaryForHistoryReset(next.lastRunSummary);const hasVisible=completed&&completed._historyVisibleActivity!==false&&(Boolean(completed.interruptedKeyword)||(Array.isArray(completed.history)&&completed.history.length>0));currentAutomationSummary=hasVisible?completed:null;if(hasVisible){syncFooterRunSummaryV129(completed);if(next.lastRunSummary!==previous.lastRunSummary||next.lastCompletedKeyword!==previous.lastCompletedKeyword)void syncFooterRunUploadStatesV129(completed);}const historyOpen=getUiElement('spx-stop-summary-open',{repair:false});if(historyOpen)historyOpen.hidden=!hasVisible;}
      refreshSidebarRunButton(next).catch(() => {});
      if(next.running&&next.networkRecoveryPaused===true){
        /* 비행기모드/IP 복구가 시작된 순간 진행 중인 DOM 분석·상세상품 루프를 같이 멈춥니다.
           runId는 보존해 복구 후 같은 검색 화면을 우선 재사용하고, 실제 차단 화면이면 현재 페이지만 한 번 복구 요청할 수 있게 합니다. */
        cancelAutomationWork('',{updateUi:false,keepRunId:true});recoveryUiOwner=true;startRecoveryCountdownMonitor();return;
      }
      if (!next.running) {
        if (String(next?.pageLoopPhase || '') === 'manual_complete' && isRecentlyRenderedCompletion(next)) {
          setDisplay('spx-auto', 'flex');
          setText('spx-status', '단건 분석 완료');
          setText('spx-auto-text', next.lastMessage || '단건 분석 결과 반영 완료');
          return;
        }
        /* [v2.6.2] 단건 N페이지의 마지막 저장에서는 백그라운드가 응답을 보내기 직전에
           manual_complete 상태를 storage에 기록합니다. 이 정상 완료 변경을 즉시 '자동 중단'으로
           처리하면 activeRunId/epoch가 무효화되어, 이미 계산된 aggregate 응답을 화면에 그리지
           못하고 88% '최종 분석·서버 업로드 중...'에서 멈춥니다. 같은 runId의 페이지 저장 응답이
           진행 중이면 해당 응답이 UI를 100% 완료할 때까지 중단 처리를 보류합니다. */
        if (shouldDeferTerminalStateChange(next)) {
          setDisplay('spx-auto', 'flex');
          setText('spx-status', '최종 결과 반영 중');
          setText('spx-auto-text', next.lastMessage || '전체 페이지 합산 결과를 화면에 반영하고 있습니다.');
          return;
        }
        cancelAutomationWork(next.lastMessage || '자동수집이 중단되었습니다.');
        return;
      }
      const nextRunId=String(next.runId||'');
      if (!activeRunId || nextRunId !== String(activeRunId)) {
        if(activeRunId)cancelAutomationWork('새 자동수집 실행이 시작되어 이전 작업을 취소했습니다.', { updateUi: false });
        activeRunId=nextRunId;
        armAutomationKickWatchdog(nextRunId,next.currentKeyword||'','새 실행 상태 감지');
        scheduleAutoRun(0);
      }
    };
    ;

    try {
      if (!SPX.util.runtimeAlive?.()) throw contextEndError();
      globalThis.chrome.storage.onChanged.addListener(storageChangeHandler);
      globalThis.chrome.runtime.onMessage.addListener(runtimeStopHandler);
    } catch (error) {
      shutdownInvalidatedContext();
      return;
    }

    window.addEventListener('pagehide', () => cancelAutomationWork('페이지 종료', { updateUi: false }), { once: true });
    window.addEventListener('beforeunload', () => {
      clearNavigationTimer();
      clearAutoRunTimer();
      stopRecoveryCountdownMonitorV1518()
      automationEpoch += 1;
    }, { once: true });
  }

  async function startRoutedCollectionPayloadIfNeededV10156(){
    const payload=dedicatedCollectionPayload;
    if(payload?.kind!=='selected-mode'||!payload?.message||typeof payload.message!=='object')return false;
    const payloadId=String(payload.createdAt||'route');
    if(sessionStorage.getItem(SPX_DEDICATED_COLLECTION_STARTED_KEY)===payloadId)return false;
    sessionStorage.setItem(SPX_DEDICATED_COLLECTION_STARTED_KEY,payloadId);
    try{
      const media=await runtimeMessage({type:'SPX_ENSURE_LOW_BANDWIDTH_COLLECTION_TAB',purpose:'route-handoff'});
      if(!media?.ok)throw new Error(media?.error||'이미지·영상·폰트 차단을 적용하지 못했습니다.');
      setLowBandwidthVisualModeV10156(true);
      const routedTarget=collectionNetworkTargetForSettingsV135(payload.message?.settingsOverride||{});
      const message={...payload.message,routeHandoffAccepted:true,networkTarget:routedTarget,dedicatedCurrentTab:routedTarget==='window'&&IS_SELECTED_NETWORK_DEDICATED_TAB===true};
      if(!['SPX_START_SELECTED_MODE','SPX_QUEUE_COLLECT_SELECTED_NOW'].includes(String(message.type||'')))throw new Error('지원하지 않는 수집 이어받기 요청입니다.');
      const response=await runtimeMessage(message);
      if(!response?.ok)throw new Error(response?.error||'네트워크 전환 후 수집 시작 실패');
      activeRunId=String(response?.state?.runId||response?.runId||'');
      setDisplay('spx-auto','flex');setText('spx-auto-text',`${IS_SELECTED_NETWORK_DEDICATED_TAB?'전용':'기본'} 네트워크 수집창에서 이전 요청을 이어서 시작했습니다.`);
      scheduleAutoRun(jitterMs(180,360));return true;
    }catch(error){sessionStorage.removeItem(SPX_DEDICATED_COLLECTION_STARTED_KEY);setText('spx-auto-text',`네트워크 전환 후 수집 시작 실패 · ${error?.message||String(error)}`);return false;}
  }

  async function startDedicatedCollectionPayloadIfNeeded(){
    if(!IS_SELECTED_NETWORK_DEDICATED_TAB||!dedicatedCollectionPayload?.rows?.length)return false;
    const payloadId=String(dedicatedCollectionPayload.createdAt||'legacy');
    if(sessionStorage.getItem(SPX_DEDICATED_COLLECTION_STARTED_KEY)===payloadId)return false;
    sessionStorage.setItem(SPX_DEDICATED_COLLECTION_STARTED_KEY,payloadId);
    const rows=dedicatedCollectionPayload.rows.map((row)=>({keyword:String(row?.keyword||'').trim(),marketplace:row?.marketplace||'coupang',source:row?.source||'선택망 전용창 선택 수집'})).filter((row)=>row.keyword);
    if(!rows.length)return false;
    setDisplay('spx-auto','flex');setText('spx-auto-text',`선택 네트워크 전용창 · 관리표 선택 ${rows.length}개 수집을 준비합니다.`);
    try{
      const response=await runtimeMessage({type:'SPX_QUEUE_COLLECT_SELECTED_NOW',rows,refreshType:'full',filterLabel:'DB 관리표 Ctrl+수집 선택망 전용창',sourceLabel:'DB 관리표 선택망 전용 수집',collectionChecklist:dedicatedCollectionPayload.collectionChecklist||null,collectionProfile:dedicatedCollectionPayload.collectionProfile||'lite',settingsOverride:dedicatedCollectionPayload.settingsOverride||null,networkTarget:'window',dedicatedCurrentTab:true,stepOnce:false,requestOrigin:String(dedicatedCollectionPayload.requestOrigin||'db_manager_direct')});
      if(!response?.ok)throw new Error(response?.error||'선택망 전용 수집 시작 실패');
      activeRunId=String(response?.state?.runId||'');setText('spx-auto-text',`선택 네트워크 전용창에서 ${rows.length}개를 순서대로 수집합니다. 다른 Chrome 탭은 기존 네트워크를 유지합니다.`);scheduleAutoRun(jitterMs(250,520));return true;
    }catch(error){sessionStorage.removeItem(SPX_DEDICATED_COLLECTION_STARTED_KEY);setText('spx-auto-text',`선택망 전용 수집 시작 실패 · ${error?.message||String(error)}`);return false;}
  }

  async function boot() {
    if (!sidebarContextAvailableV103()) return;
    if (!SPX.util.runtimeAlive?.()) { shutdownInvalidatedContext(); return; }
    try{if(!await ensureRuntimeBuildAligned({repair:true}))return;}catch(error){console.warn('[SPX] 런타임 정렬 대기',error);showReloadNotice(error?.message||String(error));return;}
    await restoreDedicatedNetworkProfileMarker();
    bindAutomationStateWatch();
    // 쿠팡이 body를 다시 만드는 동안에도 감시기가 먼저 살아 있어야 UI를 재삽입할 수 있습니다.
    startLifecycleWatch();
    if (!(await waitForUi(12000))) {
      console.info('[SPX] UI 생성 대기 · 자동 재삽입을 계속합니다.');
      state.autoStarting = false;
      state.autoStarted = false;
      queueUiRepair(jitterMs(140,240));
      scheduleBootRetry(jitterMs(560,900));
      return;
    }
    detect();
    renderIdle();
    renderDiscoveredKeywords([], []);
    refreshDbInfo();
    refreshSidebarRunButton().catch(() => {});
    const recoveryActive=await renderRecoveryCountdownOnce({autoStart:false}).catch(()=>false);if(recoveryActive)startRecoveryCountdownMonitor();
    const routedStarted=recoveryActive?false:await startRoutedCollectionPayloadIfNeededV10156();
    const dedicatedStarted=(recoveryActive||routedStarted)?false:await startDedicatedCollectionPayloadIfNeeded();
    const bootAutomation=(await readAutomationState().catch(()=>null))?.state||null;
    /* v1.0.7: 이전 탭의 업로드 실패가 로컬 pending으로 남아 있으면 그 상태부터 복원하고,
       같은 키워드의 새 상품 수집을 자동으로 시작하지 않습니다. */
    const pendingUploadRestored=(!recoveryActive&&!routedStarted&&!dedicatedStarted&&!bootAutomation?.running)
      ? await restorePendingUploadForVisibleKeywordV107().catch(()=>false)
      : false;
    if(!routedStarted&&!dedicatedStarted&&!pendingUploadRestored)resumeStepAnalysisIfNeeded().catch((error)=>{setDisplay('spx-auto','flex');setText('spx-auto-text',error?.message||String(error));});
    if(bootAutomation?.running&&bootAutomation?.runId){
      activeRunId=String(bootAutomation.runId||'');
      armAutomationKickWatchdog(activeRunId,bootAutomation.currentKeyword||'','페이지 준비 완료');
      scheduleAutoRun(0);
    }else if(!pendingUploadRestored&&(currentKeyword()||FORCE_SIDEBAR_MODE))scheduleAutoRun(SPX.util.randomInt?.(620,1380)||910);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
  ;
  ;
})();
