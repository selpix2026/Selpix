﻿$ErrorActionPreference='Stop'
$Root=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
while($true){
  Clear-Host
  Write-Host 'SmartPage Sourcing Collector 1.6.9' -ForegroundColor Cyan
  Write-Host '1. 크롬 수집창 실행 / 덮어쓴 새 버전 적용'
  Write-Host '2. 웨일 수집창 실행 / 덮어쓴 새 버전 적용'
  Write-Host '3. 수집기 설정 열기 (최근 선택한 브라우저)'
  Write-Host '4. 새 PC 최초 설치 - 크롬'
  Write-Host '5. 새 PC 최초 설치 - 웨일'
  Write-Host '6. WING 로그인 관리'
  Write-Host '7. 사용 안내 열기'
  Write-Host '0. 종료'
  $choice=Read-Host '번호 선택'
  if($choice -eq '0'){break}
  try{
    switch($choice){
      '1' { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot '02_OPEN_COLLECTOR.ps1') -BrowserFamily chrome }
      '2' { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot '02_OPEN_COLLECTOR.ps1') -BrowserFamily whale }
      '3' { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot '06_OPEN_SETTINGS.ps1') }
      '4' { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot '00_INSTALL_OTHER_PC.ps1') -BrowserFamily chrome }
      '5' { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot '00_INSTALL_OTHER_PC.ps1') -BrowserFamily whale }
      '6' { & (Join-Path $Root 'RUN_03_WING_SESSION_MANAGER.cmd') }
      '7' { Start-Process notepad.exe -ArgumentList ('"'+(Join-Path $Root '읽어보기\01_사용안내.txt')+'"') }
      default {Write-Host '0~7 중에서 선택하세요.'}
    }
  }catch{Write-Host $_.Exception.Message -ForegroundColor Red}
  [void](Read-Host 'Enter를 누르면 메뉴로 돌아갑니다')
}
