﻿$ErrorActionPreference='SilentlyContinue'
$InstallDir=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
try{& "$env:SystemRoot\System32\taskkill.exe" /IM SpxNetworkHost.exe /T /F 2>$null|Out-Null}catch{}
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue|Where-Object{([string]$_.CommandLine -like '*run-network-host.ps1*') -and ([string]$_.CommandLine -like '*-HttpServer*')}|ForEach-Object{try{Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue|Out-Null}catch{}}
@{enabled=$false;updatedAt=(Get-Date).ToUniversalTime().ToString('o')}|ConvertTo-Json -Compress|Set-Content (Join-Path $InstallDir 'coupang-window-proxy.json') -Encoding UTF8
Write-Host 'SmartPage Ex network helper stopped. Windows routing was not changed.' -ForegroundColor Green
