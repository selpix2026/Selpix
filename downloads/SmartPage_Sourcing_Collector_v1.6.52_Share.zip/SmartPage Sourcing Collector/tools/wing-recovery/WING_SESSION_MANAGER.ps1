﻿param([ValidateSet('Save','Restore','Status')][string]$Action='Status',[ValidateSet('chrome','whale')][string]$BrowserFamily='chrome')
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2
$UserData=if($BrowserFamily -eq 'whale'){'C:\SpxDedicatedProfile-Whale'}else{'C:\SpxDedicatedProfile'}
$BrowserExecutable=if($BrowserFamily -eq 'whale'){'whale.exe'}else{'chrome.exe'}
$ProfileName='Default'
$Profile=Join-Path $UserData $ProfileName
$RecoveryRoot=Join-Path $env:LOCALAPPDATA 'SmartPageEx\WING_Login_Recovery'
if($BrowserFamily -eq 'whale'){$RecoveryRoot=Join-Path $RecoveryRoot 'Whale'}
$ActiveDir=Join-Path $RecoveryRoot 'Active'
$ActiveZip=Join-Path $ActiveDir 'WING_Login_Backup_ACTIVE.zip'
function Get-DedicatedProcesses{
  try{@(Get-CimInstance Win32_Process -Filter ("Name='"+$BrowserExecutable+"'") -ErrorAction SilentlyContinue|Where-Object{([string]$_.CommandLine) -like ('*'+$UserData+'*')})}catch{@()}
}
function Assert-Closed{
  if(@(Get-DedicatedProcesses).Count -gt 0){throw '전용 Chrome이 실행 중입니다. 전용창만 정상 종료한 뒤 다시 실행하세요.'}
}
function Copy-IfExists([string]$Source,[string]$Destination){
  if(-not(Test-Path -LiteralPath $Source)){return}
  $parent=Split-Path -Parent $Destination
  if($parent -and -not(Test-Path -LiteralPath $parent)){New-Item -ItemType Directory -Path $parent -Force|Out-Null}
  Copy-Item -LiteralPath $Source -Destination $Destination -Recurse -Force
}
function New-MinimalBackup([string]$Destination,[string]$Purpose){
  Assert-Closed
  if(-not(Test-Path -LiteralPath $Profile -PathType Container)){throw ('전용 프로필이 없습니다: '+$Profile)}
  $stage=Join-Path $env:TEMP ('spx-wing-save-'+[guid]::NewGuid().ToString('N'))
  try{
    New-Item -ItemType Directory -Path $stage -Force|Out-Null
    Copy-IfExists (Join-Path $UserData 'Local State') (Join-Path $stage 'Root\Local State')
    Copy-IfExists (Join-Path $Profile 'Network\Cookies') (Join-Path $stage 'Profile\Network\Cookies')
    Copy-IfExists (Join-Path $Profile 'Network\Cookies-journal') (Join-Path $stage 'Profile\Network\Cookies-journal')
    Copy-IfExists (Join-Path $Profile 'Local Storage\leveldb') (Join-Path $stage 'Profile\Local Storage\leveldb')
    $srcIdx=Join-Path $Profile 'IndexedDB';$dstIdx=Join-Path $stage 'Profile\IndexedDB'
    if(Test-Path -LiteralPath $srcIdx){
      New-Item -ItemType Directory -Path $dstIdx -Force|Out-Null
      foreach($item in @(Get-ChildItem -LiteralPath $srcIdx -Force -ErrorAction SilentlyContinue|Where-Object{$_.Name -like '*coupang.com*'})){
        Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $dstIdx $item.Name) -Recurse -Force
      }
    }
    $meta=[ordered]@{version='CROSSPC_V134';purpose=$Purpose;created_at=(Get-Date).ToString('o');computer_name=$env:COMPUTERNAME;windows_user=$env:USERNAME;chrome_user_data=$UserData;profile_name=$ProfileName;portable=$false;note='Same-PC/session backup only. Never use this encrypted profile backup to bypass first login on another PC.'}
    [IO.File]::WriteAllText((Join-Path $stage 'backup-meta.json'),($meta|ConvertTo-Json -Depth 6),(New-Object Text.UTF8Encoding($true)))
    $cookie=Join-Path $stage 'Profile\Network\Cookies'
    if(-not(Test-Path -LiteralPath $cookie -PathType Leaf)){throw 'WING 백업에 필요한 Cookies DB가 없습니다. WING 로그인 후 Chrome을 정상 종료했는지 확인하세요.'}
    $localState=Join-Path $stage 'Root\Local State'
    if(-not(Test-Path -LiteralPath $localState -PathType Leaf)){throw 'Local State가 없습니다.'}
    $localStore=Join-Path $stage 'Profile\Local Storage\leveldb'
    if(-not(Test-Path -LiteralPath $localStore -PathType Container)){throw 'WING Local Storage 백업을 만들지 못했습니다.'}
    $coupangIndexedCount=0
    if(Test-Path -LiteralPath $dstIdx -PathType Container){$coupangIndexedCount=@(Get-ChildItem -LiteralPath $dstIdx -Force -ErrorAction SilentlyContinue|Where-Object{$_.Name -like '*coupang.com*'}).Count}
    if($coupangIndexedCount -le 0){throw 'WING/Coupang IndexedDB 백업을 만들지 못했습니다.'}
    $parent=Split-Path -Parent $Destination
    New-Item -ItemType Directory -Path $parent -Force|Out-Null
    if(Test-Path -LiteralPath $Destination){Remove-Item -LiteralPath $Destination -Force}
    Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $Destination -CompressionLevel Optimal -Force
  }finally{Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue}
}
function Restore-Backup([string]$Zip){
  Assert-Closed
  if(-not(Test-Path -LiteralPath $Zip -PathType Leaf)){throw '저장된 WING 로그인 백업이 없습니다. 최초 로그인 설정을 먼저 실행하세요.'}
  $stage=Join-Path $env:TEMP ('spx-wing-restore-'+[guid]::NewGuid().ToString('N'))
  try{
    New-Item -ItemType Directory -Path $stage -Force|Out-Null
    Expand-Archive -LiteralPath $Zip -DestinationPath $stage -Force
    $meta=Get-Content -LiteralPath (Join-Path $stage 'backup-meta.json') -Raw -Encoding UTF8|ConvertFrom-Json
    if([string]$meta.computer_name -ne [string]$env:COMPUTERNAME -or [string]$meta.windows_user -ne [string]$env:USERNAME){throw '이 백업은 다른 PC 또는 다른 Windows 사용자용입니다. 복구를 차단했습니다.'}
    # rollback current local session first
    $rb=Join-Path $RecoveryRoot ('Rollback\BeforeRestore_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.zip')
    try{New-MinimalBackup -Destination $rb -Purpose 'before_restore_rollback'}catch{}
    New-Item -ItemType Directory -Path $Profile -Force|Out-Null
    $srcState=Join-Path $stage 'Root\Local State';$dstState=Join-Path $UserData 'Local State'
    if(Test-Path -LiteralPath $srcState){
      if(Test-Path -LiteralPath $dstState){
        try{
          $src=Get-Content -LiteralPath $srcState -Raw -Encoding UTF8|ConvertFrom-Json
          $dst=Get-Content -LiteralPath $dstState -Raw -Encoding UTF8|ConvertFrom-Json
          if($src.os_crypt){
            if(-not $dst.os_crypt){$dst|Add-Member -NotePropertyName os_crypt -NotePropertyValue ([pscustomobject]@{}) -Force}
            foreach($prop in $src.os_crypt.PSObject.Properties){
              if($dst.os_crypt.PSObject.Properties.Name -contains $prop.Name){$dst.os_crypt.($prop.Name)=$prop.Value}
              else{$dst.os_crypt|Add-Member -NotePropertyName $prop.Name -NotePropertyValue $prop.Value -Force}
            }
            [IO.File]::WriteAllText($dstState,($dst|ConvertTo-Json -Depth 100),(New-Object Text.UTF8Encoding($false)))
          }
        }catch{Copy-Item -LiteralPath $srcState -Destination $dstState -Force}
      }else{Copy-Item -LiteralPath $srcState -Destination $dstState -Force}
    }
    $network=Join-Path $Profile 'Network';New-Item -ItemType Directory -Path $network -Force|Out-Null
    Copy-IfExists (Join-Path $stage 'Profile\Network\Cookies') (Join-Path $network 'Cookies')
    Copy-IfExists (Join-Path $stage 'Profile\Network\Cookies-journal') (Join-Path $network 'Cookies-journal')
    $lsDst=Join-Path $Profile 'Local Storage\leveldb';if(Test-Path -LiteralPath $lsDst){Remove-Item -LiteralPath $lsDst -Recurse -Force}
    Copy-IfExists (Join-Path $stage 'Profile\Local Storage\leveldb') $lsDst
    $idxDst=Join-Path $Profile 'IndexedDB';New-Item -ItemType Directory -Path $idxDst -Force|Out-Null
    $idxSrc=Join-Path $stage 'Profile\IndexedDB'
    if(Test-Path -LiteralPath $idxSrc){
      foreach($item in @(Get-ChildItem -LiteralPath $idxSrc -Force -ErrorAction SilentlyContinue|Where-Object{$_.Name -like '*coupang.com*'})){
        $dest=Join-Path $idxDst $item.Name;if(Test-Path -LiteralPath $dest){Remove-Item -LiteralPath $dest -Recurse -Force}
        Copy-Item -LiteralPath $item.FullName -Destination $dest -Recurse -Force
      }
    }
  }finally{Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue}
}
New-Item -ItemType Directory -Path $ActiveDir -Force|Out-Null
switch($Action){
 'Save'{New-MinimalBackup -Destination $ActiveZip -Purpose 'active_after_first_login';Write-Host ('SAVE PASS: '+$ActiveZip) -ForegroundColor Green}
 'Restore'{Restore-Backup -Zip $ActiveZip;Write-Host 'RESTORE PASS' -ForegroundColor Green}
 'Status'{
   Write-Host ('ActiveBackup='+$ActiveZip)
   Write-Host ('Exists='+(Test-Path -LiteralPath $ActiveZip))
   if(Test-Path -LiteralPath $ActiveZip){Write-Host ('Bytes='+(Get-Item -LiteralPath $ActiveZip).Length)}
 }
}
