﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "manifest.json" (echo 수집기 폴더에서 실행하세요. & pause & exit /b 1)
if exist "src\background\naver-only-collection.js" del /q "src\background\naver-only-collection.js"
if exist "src\lib\naver-seasonality.js" del /q "src\lib\naver-seasonality.js"
if exist "src\lib\naver-category-tree.js" del /q "src\lib\naver-category-tree.js"
echo 더 이상 사용하지 않는 네이버 수집 전용 3개 파일을 정리했습니다.
echo WING, IP복구, 서버 데이터와 네이버 기존 수집 데이터는 변경하지 않았습니다.
pause
