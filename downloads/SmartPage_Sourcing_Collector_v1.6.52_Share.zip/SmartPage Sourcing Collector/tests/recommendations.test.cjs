const test=require('node:test'),assert=require('node:assert/strict');
const {runtime,relatedHtml,detailHtml}=require('./helpers.cjs');

test('related recommendations are extracted from their own bottom section',()=>{
  const ctx=runtime();
  const doc=new ctx.DOMParser().parseFromString(relatedHtml('연관 추천 상품'),'text/html');
  const rows=ctx.SPX.extractComparisonProducts(doc,'https://www.coupang.com/vp/products/1',{comparison:false,related:true});
  assert.equal(rows.length,2);assert.equal(rows[0].recommendationLabel,'연관 추천 상품');
  assert.equal(rows[0].vendorItemId,'200');
});

test('unchecked related section is not scanned',()=>{
  const ctx=runtime();
  const doc=new ctx.DOMParser().parseFromString(relatedHtml('연관 추천 상품'),'text/html');
  assert.equal(ctx.SPX.extractComparisonProducts(doc,'https://www.coupang.com/vp/products/1',{enabled:false}).length,0);
});

test('changing recommendation headings does not hide first-level product groups',()=>{
  const ctx=runtime();
  for(const heading of ['리뷰가 좋은 상품','이런 상품도 있어요','다른 고객이 함께 본 상품']){
    const doc=new ctx.DOMParser().parseFromString(relatedHtml(heading),'text/html');
    assert.equal(ctx.SPX.extractComparisonProducts(doc,'https://www.coupang.com/vp/products/1',{enabled:true}).length,2);
  }
});

test('first-level titles are reported once and candidate details never expand recommendations',async()=>{
  const requests=[],discovered=[];
  const ctx=runtime({fetch:async url=>{requests.push(url);const pid=String(url).match(/products\/(\d+)/)?.[1];return{ok:true,status:200,url,text:async()=>pid==='1'?relatedHtml('리뷰가 좋은 상품'):detailHtml(pid)+relatedHtml('추천의 추천')};}});
  const result=await ctx.SPX.enrichProductDetails([{pid:'1',name:'텀블러',rocketType:'일반배송',price:10000}],{
    keyword:'텀블러',onRecommendationCandidates:rows=>discovered.push(...rows),recommendationSections:{enabled:true}});
  assert.equal(requests.length,3);assert.equal(discovered.length,2);
  assert.equal(result.filter(row=>row.recommendationVerified).every(row=>row.comparisonProducts.length===0),true);
});

test('complete search cards still provide a bounded recommendation seed',async()=>{
  const requests=[];
  const ctx=runtime({fetch:async url=>{requests.push(String(url));return{ok:true,status:200,url:String(url),text:async()=>String(url).includes('/1')?relatedHtml('연관 추천 상품'):detailHtml(String(url).match(/products\/(\d+)/)?.[1])};}});
  const rows=await ctx.SPX.enrichProductDetails([{pid:'1',name:'텀블러',rocketType:'일반배송',reviews:30,price:12000,rating:4.5,observed_monthly_sales:300,imageUrl:'https://img.test/a.jpg'}],
    {keyword:'텀블러',priorityPids:['1'],recommendationSections:{comparison:false,related:true}});
  assert.equal(requests.length,3);assert.equal(rows.filter(r=>r.recommendationVerified).length,2);
});

test('recommendation option also applies to markets with three ordinary sellers',async()=>{
  const requests=[];
  const ctx=runtime({fetch:async url=>{requests.push(url);return{ok:true,status:200,url,text:async()=>detailHtml(String(url).match(/products\/(\d+)/)?.[1])};}});
  const items=Array.from({length:3},(_,i)=>({pid:String(10+i),name:'텀블러',rocketType:'일반배송',reviews:30,price:12000,
    comparisonProducts:i===0?[{pid:'2',name:'텀블러',rocketType:'일반배송',reviews:30,productUrl:'https://www.coupang.com/vp/products/2'}]:[]}));
  const rows=await ctx.SPX.enrichProductDetails(items,{keyword:'텀블러',comparisonSeedLimit:0});
  assert.equal(rows.filter(r=>r.recommendationVerified).length,1);
});

test('a redirect to a different product cannot verify the requested recommendation',async()=>{
  const ctx=runtime({fetch:async()=>({ok:true,status:200,url:'https://www.coupang.com/vp/products/999',text:async()=>detailHtml(999)})});
  const rows=await ctx.SPX.enrichProductDetails([{pid:'1',rocketType:'일반배송',price:10000,comparisonProducts:[{pid:'2',name:'텀블러',rocketType:'일반배송',reviews:30,productUrl:'https://www.coupang.com/vp/products/2'}]}],{keyword:'텀블러',comparisonSeedLimit:0});
  assert.equal(rows.filter(r=>r.recommendationVerified).length,0);
});

test('same catalog redirected to a different seller offer is not verified as the original offer',async()=>{
  const ctx=runtime({fetch:async()=>({ok:true,status:200,url:'https://www.coupang.com/vp/products/2?itemId=20&vendorItemId=999',text:async()=>detailHtml(2)})});
  const rows=await ctx.SPX.enrichProductDetails([{pid:'1',rocketType:'일반배송',price:10000,comparisonProducts:[{pid:'2',itemId:'20',vendorItemId:'200',name:'텀블러',rocketType:'일반배송',reviews:30,productUrl:'https://www.coupang.com/vp/products/2?itemId=20&vendorItemId=200'}]}],{keyword:'텀블러',comparisonSeedLimit:0});
  assert.equal(rows.filter(row=>row.recommendationVerified).length,0);
});

test('a recommendation resolving to an existing search offer is not added twice',async()=>{
  const ctx=runtime({fetch:async url=>({ok:true,status:200,url,text:async()=>detailHtml(2)})});
  const items=[{pid:'2',vendorItemId:'200',itemId:'20',name:'텀블러',rocketType:'일반배송',reviews:30,price:10000},
    {pid:'1',name:'텀블러',rocketType:'일반배송',price:10000,comparisonProducts:[{pid:'2',vendorItemId:'200',itemId:'20',name:'텀블러',rocketType:'배송유형 미확인',reviews:30,productUrl:'https://www.coupang.com/vp/products/2?itemId=20&vendorItemId=200'}]}];
  const rows=await ctx.SPX.enrichProductDetails(items,{keyword:'텀블러',comparisonSeedLimit:0});
  assert.equal(rows.filter(row=>row.pid==='2').length,1);
});

test('relevance is checked against the fresh detail title rather than the stale card',async()=>{
  const ctx=runtime({fetch:async url=>({ok:true,status:200,url,text:async()=>detailHtml(2,'여름 우산')})});
  const rows=await ctx.SPX.enrichProductDetails([{pid:'1',rocketType:'일반배송',price:10000,comparisonProducts:[{pid:'2',name:'텀블러',rocketType:'일반배송',reviews:30,productUrl:'https://www.coupang.com/vp/products/2'}]}],{keyword:'텀블러',comparisonSeedLimit:0});
  assert.equal(rows.filter(r=>r.recommendationVerified).length,0);
});

test('disabled recommendation discovery and cancelled work cause no extra requests',async()=>{
  let calls=0;const ctx=runtime({fetch:async()=>{calls++;throw new Error('should not request');}});
  await ctx.SPX.enrichProductDetails([{pid:'1',rocketType:'일반배송',price:10000}],{keyword:'텀블러',collectComparisonCandidates:false});
  await ctx.SPX.enrichProductDetails([{pid:'1',rocketType:'일반배송',price:10000}],{keyword:'텀블러',shouldContinue:()=>false});
  assert.equal(calls,0);
});
