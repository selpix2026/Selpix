﻿$ErrorActionPreference='Stop'
Set-StrictMode -Version 2
$PackageRoot=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Source=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33\integration-secrets.json'
$DestinationDir=Join-Path $PackageRoot 'PORTABLE_CONFIG'
$Destination=Join-Path $DestinationDir 'integration-secrets.json'
$Meta=Join-Path $DestinationDir 'settings-export-meta.json'
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host ' SmartPage 다른 PC 연동설정 내보내기' -ForegroundColor Green
Write-Host '============================================================' -ForegroundColor Cyan
if(-not(Test-Path -LiteralPath $Source -PathType Leaf)){
  throw ('현재 PC에서 integration-secrets.json을 찾지 못했습니다: '+$Source)
}
$raw=Get-Content -LiteralPath $Source -Raw -Encoding UTF8
try{$parsed=$raw|ConvertFrom-Json}catch{throw 'integration-secrets.json JSON 형식이 올바르지 않습니다.'}
New-Item -ItemType Directory -Path $DestinationDir -Force|Out-Null
Copy-Item -LiteralPath $Source -Destination $Destination -Force
$meta=[ordered]@{
  exportedAt=(Get-Date).ToString('o')
  sourceComputer=$env:COMPUTERNAME
  sourceWindowsUser=$env:USERNAME
  containsSensitiveCredentials=$true
  wingSessionIncluded=$false
  note='API integration settings only. WING Chrome session is intentionally excluded.'
}
[IO.File]::WriteAllText($Meta,($meta|ConvertTo-Json -Depth 5),(New-Object Text.UTF8Encoding($false)))
Write-Host ('EXPORT PASS: '+$Destination) -ForegroundColor Green
Write-Host '주의: 이 파일에는 API Key/Secret이 포함될 수 있습니다. 본인 PC 사이에서만 사용하세요.' -ForegroundColor Yellow
