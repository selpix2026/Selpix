@echo off
chcp 65001 >nul
setlocal
title SmartPage - Export Current PC Integration Settings
set "PS=%~dp0tools\crosspc\05_EXPORT_CURRENT_PC_INTEGRATION_SETTINGS.ps1"
if not exist "%PS%" (
  echo [ERROR] Export PowerShell file not found.
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS%"
set "RC=%ERRORLEVEL%"
echo.
echo ExitCode=%RC%
pause
exit /b %RC%
