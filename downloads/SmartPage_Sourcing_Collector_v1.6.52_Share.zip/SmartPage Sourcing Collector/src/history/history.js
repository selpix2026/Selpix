 'use strict';
/* v1.6.47 · local history completion timestamps and sidebar-consistent grade text. */
(() => {
  const $=id=>document.getElementById(id),fmt=n=>Math.max(0,Number(n)||0).toLocaleString('ko-KR');
  let snapshot=null,busy=false,view='completed',offset=0,limit=60,rows=[],hasMore=false,pagePending=false,pageErrorV1634='',lastFetch=0,inflight=null,refreshAgainV1634=false,requestEpoch=0;
  // v1.6.46: a committed history reset must never be reported as a failed reset
  // merely because its subsequent optional UI refresh is delayed.
  let resetSuccessNoticeV1646='',resetRefreshTimerV1646=null;
  const selected=new Set();
  const version=chrome.runtime.getManifest()?.version||'';document.title=`최근 수집내역 · SmartPage ${version}`;const versionLabel=document.querySelector('.eyebrow');if(versionLabel)versionLabel.textContent=`SMARTPAGE SOURCING COLLECTOR · v${version}`;
  const msg=async(type,data={},timeoutMs=12000)=>{
    let timer;
    try{
      /* v1.6.46: The service worker automatically transports responses >384KB
         via chrome.storage.local. The history window previously read the small
         transport ENVELOPE as if it were a full response and falsely reported
         "data 없음". Resolve through the same SPX.util helper used elsewhere.
         This is read-only; it neither retries server writes nor mutates IDB. */
      const response=await Promise.race([
        (async()=>{
          const raw=await chrome.runtime.sendMessage({type,...data});
          if(typeof globalThis.SPX?.util?.resolveRuntimeResponse!=='function')
            throw new Error('대용량 응답 처리 모듈이 로드되지 않았습니다. 원본 DB는 변경되지 않았습니다.');
          return globalThis.SPX.util.resolveRuntimeResponse(raw);
        })(),
        new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(`${type} 응답 지연 (${Math.round(timeoutMs/1000)}초 초과) · 원본 데이터는 변경하지 않았습니다.`)),timeoutMs);})
      ]);
      if(response?.ok!==true)throw new Error(response?.error||`${type} 로컬 DB 요청 실패`);
      if(!response.data||typeof response.data!=='object')throw new Error(`${type} 응답 형식 오류 · data 없음 (대용량 응답 복원 후)`);
      return response.data;
    }finally{clearTimeout(timer);}
  };
  const feedback=(message='',error=false)=>{const e=$('feedback');e.textContent=String(message);e.classList.toggle('err',error);e.title=String(message);};
  const append=(node,tag,value)=>{const e=document.createElement(tag);e.textContent=String(value??'');node.append(e);return e;};
  const searchTerm=()=>String($(view==='pending'?'pendingSearch':'search').value||'').trim();
  const downloadBlob=(name,parts,mime)=>{const blob=new Blob(parts,{type:mime}),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=name;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);return blob.size;};

  /* v1.6.44: A history keyword is a non-destructive action. First copy its
     exact text, then preview that SAME stored run in a live Coupang sidebar.
     No collect/navigation/upload/server requests are initiated here. */
  async function copyAndPreviewHistoryKeywordV1644(row={}){
    const keyword=String(row.keyword||'').trim();if(!keyword)return;
    let copied=false;
    try{await navigator.clipboard.writeText(keyword);copied=true;}catch(_){
      const input=document.createElement('textarea');input.value=keyword;input.style.cssText='position:fixed;left:-9999px;top:0;opacity:0';
      document.body.append(input);input.select();try{copied=document.execCommand('copy')===true;}catch(_){}input.remove();
    }
    const searchPage=/^\/(?:np\/search|search)(?:\/|$)/;
    let tabs=[];
    try{tabs=(await chrome.tabs.query({url:['https://www.coupang.com/*']}))
      .filter(t=>t?.id&&t?.url&&searchPage.test(new URL(t.url).pathname))
      .sort((a,b)=>Number(b.active===true)-Number(a.active===true)||(Number(b.lastAccessed)||0)-(Number(a.lastAccessed)||0));
    }catch(error){feedback(`키워드 ${copied?'복사 완료':'복사 실패'} · 사이드바 검색 실패: ${error?.message||error}`,true);return;}
    if(!tabs.length){feedback(`${copied?'키워드 복사 완료':'키워드 복사 실패'} · 열린 쿠팡 검색 탭이 없어 사이드바 표시를 생략했습니다.`,!copied);return;}
    const payload={type:'SPX_HISTORY_VIEW_IN_SIDEBAR_V1644',keyword,runKey:String(row.runKey||row.collection_run_key||'').trim(),aggregateKey:String(row.k||'').trim()};
    try{const response=await chrome.tabs.sendMessage(tabs[0].id,payload);
      if(response?.ok!==true)throw new Error(response?.error||'해당 수집 회차의 로컬 자료를 찾지 못했습니다.');
      feedback(`${copied?'키워드 복사 완료':'키워드 복사 실패'} · ${keyword} · 쿠팡 사이드바에 로컬 수집내역 표시${payload.runKey?' (회차 일치 확인)':''}`,!copied);
    }catch(error){feedback(`${copied?'키워드 복사 완료':'키워드 복사 실패'} · 사이드바 표시 불가: ${error?.message||error}`,true);}
  }

  const csv=v=>`"${String(v??'').replaceAll('"','""')}"`;
  /* v1.6.47: `at` on collection_history rows marks the actual recorded
     completion/event time, NOT an upload timestamp. Uploaded rows have an
     independent collectedAt field when available. Pending key-only pages
     intentionally do not deserialize large aggregates just to get a clock. */
  function validTimeV1647(value){
    if(value==null||value==='')return null;
    const n=typeof value==='number'?value:(typeof value==='string'&&/^\d{12,}$/.test(value.trim())?Number(value):NaN);
    const d=Number.isFinite(n)?new Date(n):new Date(String(value));
    return Number.isFinite(d.getTime())&&d.getTime()>0?d:null;
  }
  function koDateTimeV1647(value){const d=validTimeV1647(value);return d?d.toLocaleString('ko-KR',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}):'';}
  function rowTimeLabelV1647(row={},isPending=false){
    const direct=koDateTimeV1647(row.collectedAt||row.collection_completed_at||row.completedAt);
    if(direct)return `수집 완료 ${direct}`;
    if(isPending)return '수집 완료 시각 미기록';
    const eventTime=koDateTimeV1647(row.at);
    if(!eventTime)return '기록 시각 미확인';
    if(row._state==='uploaded')return `업로드 기록 ${eventTime}`;
    return ['saved','requeued'].includes(String(row.status||''))?`수집 완료 ${eventTime}`:`처리 시각 ${eventTime}`;
  }
  /* Keep exactly the same colors as src/content/coupang-search.js gradeColor(). */
  const GRADE_CLASS_V1647={'S+':'splus','S':'s','A':'a','B':'b'};
  const tagFor=r=>{if(r.status==='failed')return ['실패·기술오류','failed'];if(r.status==='below_criteria')return ['기준미달','below'];if(r.status==='excluded')return ['제외','excluded'];if(r.status==='skipped')return ['건너뜀',''];if(r._state==='pending')return ['로컬 대기','pending'];if(r._state==='uploaded')return ['업로드','uploaded'];return ['수집완료',''];};
  function decorate(data){const statusMap=new Map((data?.statuses||[]).map(s=>[String(s.keyword||''),String(s.upload_state||'')]));return (data?.rows||[]).map(r=>({...r,_state:r._state||statusMap.get(String(r.keyword||''))||''}));}
  function renderCounts(){if(!snapshot)return;const c=snapshot.counts||{};
    for(const key of ['completed','uploaded','pending','failed','below_criteria','excluded','skipped']){const node=$(key);if(node)node.textContent=fmt(c[key]);}
    $('statusInfo').textContent=`로컬 상태 기록 · 수집완료 ${fmt(c.completed)} = 업로드 ${fmt(c.uploaded)} + 로컬 대기 상태 ${fmt(c.pending)} (원본 무결성 미확인)`;
    $('statusInfo').title='업로드는 로컬 DB에서 업로드 완료 상태로 기록한 키워드 수입니다. 서버를 실시간 검증한 수치는 아닙니다.';
    $('heartbeat').textContent=`최종 확인 ${new Date(snapshot.at||Date.now()).toLocaleTimeString('ko-KR')}`;
    $('collecting').textContent=snapshot.running?'● 자동 수집 중':'● 자동 수집 대기/종료';
    $('runningKeyword').textContent=snapshot.currentKeyword?`현재 ${snapshot.currentKeyword}`:'';
    $('countScope').textContent=`누적 상세 ${fmt(c.historyTotal)}회차 · 동일 키워드의 다른 회차는 별도 보관`;
  }
  function updateSelected(){const el=$('selectedCount');if(el)el.textContent=`선택 ${fmt(selected.size)}건`;const b=$('exportJson');if(b)b.textContent=view==='pending'&&selected.size?`선택 대기 JSON 저장 (${fmt(selected.size)})`:'JSON 저장';}
  function renderRows(){const pending=view==='pending';$('historySection').hidden=pending;$('pendingSection').hidden=!pending;
    const list=$(pending?'pendingList':'historyList');list.replaceChildren();
    if(pending){$('pendingMeta').textContent=`로컬 대기 상태 ${fmt(snapshot?.counts?.pending)}건 · 현재 페이지 ${fmt(rows.length)}건 · 원본 미검증`;
    }else{$('historyMeta').textContent=`현재 페이지 ${fmt(rows.length)}건 · 누적 상세 ${fmt(snapshot?.counts?.historyTotal)}회차`;}
    const fragment=document.createDocumentFragment();
    for(const r of rows){const item=document.createElement(pending?'label':'div');item.className='item';
      if(pending){const check=document.createElement('input');check.type='checkbox';check.value=String(r.k||'');check.checked=selected.has(check.value);check.disabled=r.upload_selectable===false||!check.value;
        check.addEventListener('change',()=>{if(check.checked)selected.add(check.value);else selected.delete(check.value);updateSelected();});item.append(check);
      }else{const [label,tone]=tagFor(r),tag=append(item,'span',label);tag.className=`tag ${tone}`;}
      const body=document.createElement('div');body.className='body';
      const keywordButton=document.createElement('button');keywordButton.type='button';keywordButton.className='spx-history-keyword-v1644';keywordButton.textContent=String(r.keyword||'(키워드 없음)');
      keywordButton.title='키워드 복사 · 저장된 수집 회차를 쿠팡 사이드바에 표시 (수집 실행 없음)';
      keywordButton.addEventListener('click',event=>{event.preventDefault();event.stopPropagation();void copyAndPreviewHistoryKeywordV1644(r);});
      body.append(keywordButton);
      const meta=document.createElement('small');meta.className='spx-history-meta-v1647';
      const addField=(value,gradeClass='')=>{if(!value)return;if(meta.childNodes.length)meta.append(document.createTextNode(' · '));
        const node=document.createElement('span');node.textContent=String(value);
        if(gradeClass)node.className=`spx-history-grade-v1647 spx-grade-${gradeClass}`;
        meta.append(node);
      };
      addField(rowTimeLabelV1647(r,pending));
      if(r.date&&!validTimeV1647(r.collectedAt)&&pending)addField(`수집일 ${String(r.date)}`);
      const grade=String(r.grade||'').trim().toUpperCase();
      if(grade)addField(`등급 ${grade}`,GRADE_CLASS_V1647[grade]||'');
      if(Number(r.productCount)>0)addField(`상품 ${fmt(r.productCount)}개`);
      if(r.durationMs!=null&&Number.isFinite(Number(r.durationMs)))addField(`소요 ${(Number(r.durationMs)/1000).toFixed(1)}초`);
      if(r.reason)addField(String(r.reason));
      if(r.selection_reason)addField(String(r.selection_reason));
      if(r.upload_repair_hold_reason)addField(String(r.upload_repair_hold_reason));
      body.append(meta);item.append(body);fragment.append(item);
    }
    if(!rows.length){
      const countMismatch=pending&&Number(snapshot?.counts?.pending)>0&&!searchTerm()&&offset===0;
      const hint=pagePending?'로컬 수집자료에서 목록을 조회하고 있습니다.':pageErrorV1634?`목록 조회 실패 · ${pageErrorV1634}`:countMismatch?'로컬 대기 집계는 존재하지만 현재 상세 목록 0건입니다. 잠시 후 새로고침하여 다시 확인하세요.':'조건에 해당하는 수집내역이 없습니다. 키워드 검색 또는 페이지 범위를 확인하세요.';
      append(fragment,'p',hint).className='empty';
    }
    list.append(fragment);
    $('prevPage').disabled=pagePending||offset===0;$('nextPage').disabled=pagePending||!hasMore;
    $('pageInfo').textContent=pagePending?'목록 조회 중':`${fmt(offset+ (rows.length?1:0))}~${fmt(offset+rows.length)}건 표시${hasMore?' · 다음 페이지 있음':''}`;
    updateSelected();
  }
  async function loadPage(){
    const epoch=++requestEpoch,viewAtRequest=view,offsetAtRequest=offset,term=searchTerm();
    pagePending=true;pageErrorV1634='';renderRows();
    try{
      const data=await msg('SPX_HISTORY_PAGE_V1633',{view:viewAtRequest,offset:offsetAtRequest,limit,search:term});
      if(epoch!==requestEpoch||viewAtRequest!==view||offsetAtRequest!==offset)return false;
      rows=decorate(data);hasMore=data.hasMore===true;
      const countMismatch=viewAtRequest==='pending'&&!term&&offsetAtRequest===0&&rows.length===0&&Number(snapshot?.counts?.pending)>0;
      if(countMismatch)feedback(`로컬 대기 ${fmt(snapshot.counts.pending)}건과 상세 0건 불일치 · 새로고침하여 다시 확인하세요.`,true);
      else feedback('');
      return !countMismatch;
    }catch(e){
      if(epoch===requestEpoch){pageErrorV1634=String(e?.message||e);feedback(`상세 페이지 조회 실패 · ${pageErrorV1634}`,true);}
      return false;
    }finally{if(epoch===requestEpoch){pagePending=false;renderRows();}}
  }
  function setView(next,{load=true}={}){view=next;offset=0;rows=[];hasMore=false;requestEpoch++;pagePending=true;pageErrorV1634='';
    document.querySelectorAll('.stat[data-filter]').forEach(b=>{const on=b.dataset.filter===view;b.classList.toggle('is-active',on);b.setAttribute('aria-pressed',on?'true':'false');});
    $('search').value='';$('pendingSearch').value='';renderRows();if(load)void loadPage();}
  // Count polling is cheap and never reloads the page. Only a DB commit,
  // explicit user refresh, or filter/page change reloads the visible page.
  async function refresh(force=false,reloadPage=false){
    if(inflight){if(force){refreshAgainV1634=true;if(reloadPage)reloadRequestedV1635=true;}return inflight;}
    if(!force&&Date.now()-lastFetch<6500)return;
    inflight=(async()=>{
      try{
        // History aggregates may be locked while large raw backups complete.
        // This timeout only changes UI read tolerance; no server call or DB write.
        const data=await msg('SPX_HISTORY_SNAPSHOT_V1631',{},30000);
        snapshot=data;lastFetch=Date.now();renderCounts();
        if(reloadPage)await loadPage();
        if(resetSuccessNoticeV1646){feedback(resetSuccessNoticeV1646);resetSuccessNoticeV1646='';}
        return true;
      }catch(e){
        if(resetSuccessNoticeV1646){
          feedback(`${resetSuccessNoticeV1646} · 화면 집계 갱신 지연: ${e?.message||e} · [새로고침]으로 다시 조회하세요.`,true);
          resetSuccessNoticeV1646='';
        }else feedback(`로컬 집계 조회 실패 · 기존 표시 유지 · ${e?.message||e}`,true);
        $('heartbeat').textContent='조회 지연 · 다시 시도 가능';
        return false;
      }
      finally{
        inflight=null;
        if(refreshAgainV1634){const rp=reloadRequestedV1635;refreshAgainV1634=false;reloadRequestedV1635=false;setTimeout(()=>void refresh(true,rp),400);}
      }
    })();
    return inflight;
  }
  let reloadRequestedV1635=false;
  async function eachFilteredRow(action){const filter={view,search:searchTerm()};let cursor=0,total=0;for(;;){const data=await msg('SPX_HISTORY_PAGE_V1633',{...filter,offset:cursor,limit:100});const chunk=decorate(data);for(const row of chunk)await action(row);total+=chunk.length;cursor+=chunk.length;if(!data.hasMore||!chunk.length)break;if(total>1000000)throw new Error('내보내기 범위가 너무 큽니다. 키워드를 필터링하세요.');await new Promise(resolve=>setTimeout(resolve,0));}return total;}
  $('exportCsv').addEventListener('click',async()=>{if(busy)return;busy=true;$('exportCsv').disabled=true;try{
    const parts=['\ufeff','키워드,수집상태,업로드상태,등급,상품수,소요초,사유\r\n'];
    const count=await eachFilteredRow(async r=>{parts.push([r.keyword,r.status,r._state,r.grade,r.productCount,r.durationMs==null?'':(Number(r.durationMs)/1000).toFixed(1),r.reason].map(csv).join(',')+'\r\n');});
    downloadBlob(`SmartPage_누적수집이력_${new Date().toISOString().slice(0,10)}.csv`,parts,'text/csv;charset=utf-8');feedback(`${fmt(count)}건 CSV 저장 완료`);
  }catch(e){feedback(e?.message||e,true);}finally{busy=false;$('exportCsv').disabled=false;}});
  /* v1.6.41: The working v1.6.27 popup used two legacy SW routes:
     SPX_PENDING_UPLOAD_EXPORT_SELECTED_V117 (direct aggregate keys) and
     SPX_HISTORY_FILTER_EXPORT_PACKAGE_V133 (history descriptors).
     The history window must preserve these contracts, and isolate failed
     multi-row responses into single-row retries before recording errors.
     Transport/protocol errors are NOT evidence that a source was deleted. */
  async function fetchLegacyExportV1639(type,selection,usingPending){
    const args=items=>usingPending?{keys:items}:{rows:items};
    const keyOf=item=>usingPending?String(item||''):String(item?.runKey||item?.collection_run_key||item?.keyword||'');
    async function attempt(items){
      try{
        const response=await msg(type,args(items),items.length===1?60000:30000);
        if(!Array.isArray(response?.rows)||!Array.isArray(response?.errors))throw new Error('응답에 rows/errors 배열 없음');
        const received=response.rows.length+response.errors.length;
        if(received<items.length){
          if(items.length>1)throw new Error(`요청 ${items.length}건 중 응답 ${received}건 · 개별 재조회 필요`);
          return{rows:response.rows,errors:[...response.errors,{key:keyOf(items[0]),code:'INCOMPLETE_RESPONSE',error:'요청 1건의 성공/실패 결과가 완전하게 반환되지 않았습니다.'}],warnings:Array.isArray(response.warnings)?response.warnings:[]};
        }
        return{rows:response.rows,errors:response.errors,warnings:Array.isArray(response.warnings)?response.warnings:[]};
      }catch(error){
        if(items.length>1){
          const half=Math.ceil(items.length/2);
          const a=await attempt(items.slice(0,half)),b=await attempt(items.slice(half));
          return{rows:[...a.rows,...b.rows],errors:[...a.errors,...b.errors],warnings:[...(a.warnings||[]),...(b.warnings||[])]};
        }
        const detail=String(error?.message||error);
        return{rows:[],errors:[{key:keyOf(items[0]),keyword:usingPending?'':String(items[0]?.keyword||''),
          code:'EXPORT_RESPONSE_FAILED',error:`서비스워커/로컬DB 내보내기 응답 실패 (원본 없음으로 확정하지 않음): ${detail}`}]};
      }
    }
    return attempt(selection);
  }
  async function exportJson(){
    const usingPending=view==='pending';const keys=usingPending?[...selected]:[];
    let descriptors=[];if(!usingPending){await eachFilteredRow(async row=>{if(['saved','requeued'].includes(String(row.status||'')))descriptors.push(row);});}
    if(usingPending&&!keys.length)throw new Error('로컬 대기 상태 키워드를 선택하세요. 「전체 선택」은 모든 페이지를 포함하며 실제 원본은 저장 과정에서 검사합니다.');
    if(!usingPending&&!descriptors.length)throw new Error('선택한 필터에서 수집완료 원본이 없습니다. 업로드 원본은 저장 번들이 존재하는 회차만 내보냅니다.');
    const total=usingPending?keys.length:descriptors.length,batch=usingPending?8:6,parts=['{'],errors=[],warnings=[];let written=0;
    const metadata={schema:'smartpage-manager-upload-package-v2',collectorVersion:chrome.runtime.getManifest()?.version||'1.6.48',exportedAt:new Date().toISOString(),source:usingPending?'selected-local-pending':'filtered-collection-history',selectedCount:total,serverRequestsDuringExport:0,hashMode:'deferred-on-import',localStructureChecked:true,serverVerified:false};
    for(const [i,[k,v]] of Object.entries(metadata).entries())parts.push(`${i?',':''}${JSON.stringify(k)}:${JSON.stringify(v)}`);parts.push(',"rows":[');
    for(let i=0;i<total;i+=batch){
      const selection=usingPending?keys.slice(i,i+batch):descriptors.slice(i,i+batch);
      const type=usingPending?'SPX_PENDING_UPLOAD_EXPORT_SELECTED_V117':'SPX_HISTORY_FILTER_EXPORT_PACKAGE_V133';
      const data=await fetchLegacyExportV1639(type,selection,usingPending);
      for(const row of data.rows){if(written)parts.push(',');parts.push(JSON.stringify(row));written++;}
      errors.push(...data.errors.map(item=>({...item,code:item.code||(String(item.error||'').startsWith('RUN_')?'RUN_SOURCE_UNAVAILABLE':'SOURCE_UNAVAILABLE_OR_INVALID')})));
      if(Array.isArray(data.warnings))warnings.push(...data.warnings);
      const missing=Math.max(0,selection.length-data.rows.length-data.errors.length);
      for(let j=0;j<missing;j++)errors.push({batch:i,offset:j,code:'INCOMPLETE_RESPONSE',error:'원본 응답 개수가 부족합니다. 해당 묶음을 별도로 확인하세요.'});
      feedback(`Manager용 구조 검사 ${fmt(Math.min(i+batch,total))}/${fmt(total)} · 통과 ${fmt(written)} · 누락/오류 ${fmt(errors.length)}`);
      await new Promise(resolve=>setTimeout(resolve,0));
    }
    // Single download: Chrome can block multiple downloads from one gesture.
    // Selpix Manager reads only the top-level rows array; errors remain available
    // for read-only diagnosis, without a second automatic download.
    parts.push(`],"exportedCount":${written},"unavailableCount":${errors.length},"errors":${JSON.stringify(errors)},"warnings":${JSON.stringify(warnings)},"serverVerified":false}`);
    const stamp=new Date().toISOString().replace(/[:.]/g,'-');
    if(!written){
      downloadBlob(`SmartPage_진단전용_원본누락${total}건_${stamp}.json`,parts,'application/json;charset=utf-8');
      throw new Error(`선택 ${fmt(total)}건의 Manager 업로드 행 0건. 진단 파일은 Manager에 넣지 마세요. 통신 응답 실패와 실제 원본 누락을 errors에서 구분하세요.`);
    }
    const name=`SmartPage_Manager복구용_구조검사통과${written}건_누락${errors.length}건_${stamp}.json`;
    downloadBlob(name,parts,'application/json;charset=utf-8');
    feedback(`Manager 복구용 구조 검사 통과 ${fmt(written)}/${fmt(total)}건 저장 · 누락 ${fmt(errors.length)}건의 사유는 동일 파일 errors에 보관 · 서버 업로드 성공은 Manager 확인 필요`);

  }
  $('exportJson').addEventListener('click',async()=>{if(busy)return;busy=true;const b=$('exportJson');b.disabled=true;try{await exportJson();}catch(e){feedback(e?.message||String(e),true);}finally{busy=false;b.disabled=false;}});
  async function uploadVerifiedHistoryRows(keys){
    const succeeded=new Set();let requested=0,lastError='';
    for(let i=0;i<keys.length;i+=4){
      const part=keys.slice(i,i+4);requested+=part.length;
      let data;try{data=await msg('SPX_PENDING_UPLOAD_REPAIR_SELECTED_BATCH',{keys:part},60000);}catch(error){lastError=String(error?.message||error);break;}
      const results=Array.isArray(data?.results)?data.results:[];
      for(const row of results)if(part.includes(row.key)&&row.ok===true&&!['needs_repair','blocked','conflict'].includes(row.action))succeeded.add(row.key);
      if(results.some(row=>row.transient===true))break;
    }
    return{succeeded:[...succeeded],deferred:keys.filter(key=>!succeeded.has(key)),unattempted:Math.max(0,keys.length-requested),error:lastError};
  }
  $('repairSelected').addEventListener('click',async()=>{
    const keys=[...selected];if(busy){feedback('현재 진행 중인 원본 검사 또는 저장 작업이 끝난 후 실행하세요.',true);return;}
    if(!keys.length){feedback('선택된 로컬 대기 항목이 없습니다.',true);return;}
    if(keys.length>100){feedback(`안전장치: ${fmt(keys.length)}건 일괄 업로드를 차단했습니다. 원본 진단 후 검색/페이지별로 최대 100건씩 선택하세요. 데이터는 변경하지 않았습니다.`,true);return;}
    if(!confirm(`선택 ${fmt(keys.length)}건에 대해 일치 회차 원본 검사 후 서버 업로드를 시도할까요? 원본이 없는 건은 보류되며 데이터는 삭제하지 않습니다.`))return;
    const b=$('repairSelected');b.disabled=true;busy=true;let ok=0,fail=0,verified=[],unverified=[];
    try{
      for(let i=0;i<keys.length;i+=20){
        const data=await msg('SPX_PENDING_DIAGNOSE_SELECTED_V1636',{keys:keys.slice(i,i+20)},60000);
        if(!Array.isArray(data?.rows))throw new Error('업로드 전 원본 진단 응답 오류');
        for(const row of data.rows){if(row.canAttemptExport===true)verified.push(row.key);else unverified.push({key:row.key,category:row.category,reason:row.reason});}
      }
      if(!verified.length){feedback(`원본 검증 통과 0건 · 보류 ${fmt(unverified.length)}건. 선택 원본 진단으로 누락 사유를 확인하세요.`,true);return;}
      const result=await uploadVerifiedHistoryRows([...new Set(verified)]);
      ok=result.succeeded.length;fail=keys.length-ok;
      for(const key of result.succeeded)selected.delete(key);
      if(ok>0)await refresh(true,true);
      updateSelected();
      feedback(`업로드 요청 결과 · 성공 ${fmt(ok)} · 보류 ${fmt(fail)} (미요청 ${fmt(result.unattempted)} 포함)${result.error?' · '+result.error:''}`,fail>0);

    }catch(e){feedback(e?.message||String(e),true);}finally{busy=false;b.disabled=false;}
  });
  /* v1.6.43: one confirmation per operation; history-only is non-destructive.
     The old reset refreshed counts but not the visible page, leaving ghost rows. */
  function clearRenderedHistoryV1643(scope='history'){
    selected.clear();offset=0;rows=[];hasMore=false;pagePending=false;pageErrorV1634='';requestEpoch++;
    const previous=snapshot||{},prev=previous.counts||{};
    // The reset action returned after IndexedDB confirmed collection_history=0.
    // Publish that ACK immediately; pending aggregate/bundle counts are untouched.
    snapshot={...previous,at:Date.now(),counts:scope==='all'
      ?{...prev,completed:0,uploaded:0,pending:0,failed:0,below_criteria:0,excluded:0,skipped:0,historyTotal:0,historyCompleted:0}
      :{...prev,failed:0,below_criteria:0,excluded:0,skipped:0,historyTotal:0,historyCompleted:0}};
    lastFetch=Date.now();renderCounts();renderRows();
  }
  function scheduleHistoryResetRefreshV1646(notice){
    resetSuccessNoticeV1646=notice;feedback(notice);
    if(resetRefreshTimerV1646)clearTimeout(resetRefreshTimerV1646);
    resetRefreshTimerV1646=setTimeout(()=>{resetRefreshTimerV1646=null;void refresh(true,true);},1200);
  }
  $('reset').addEventListener('click',async()=>{
    if(busy)return feedback('현재 작업이 끝난 뒤 초기화하세요.',true);
    if(snapshot?.running)return feedback('수집 중에는 초기화하지 않습니다.',true);
    if(!confirm('수집 완료/실패 등 최근 수집 이력만 초기화할까요?\n\n로컬 업로드 대기, 원본 상품, 저장 번들 및 서버 기록은 삭제하지 않습니다.'))return;
    busy=true;$('reset').disabled=true;let successNotice='';
    try{const data=await msg('SPX_HISTORY_RESET_ONLY_V1643',{},60000);
      if(Number(data?.remaining)!==0)throw new Error(`DB 초기화 확인 실패 · 남은 이력 ${data?.remaining}`);
      clearRenderedHistoryV1643('history');
      successNotice=`수집 이력 ${fmt(data.deleted)}건 초기화 완료 · 대기 원본과 업로드 기록 보존`;
      feedback(successNotice);
    }catch(e){feedback(`이력 초기화 실패 · ${e?.message||e}`,true);}
    finally{busy=false;$('reset').disabled=false;if(successNotice)scheduleHistoryResetRefreshV1646(successNotice);}
  });
  $('resetAll').addEventListener('click',async()=>{
    if(busy)return feedback('현재 작업 종료 후 전체 삭제를 실행하세요.',true);
    if(snapshot?.running)return feedback('수집 중 전체 삭제는 불가능합니다.',true);
    try{const check=await msg('SPX_LOCAL_RESET_PRECHECK_V1637',{},12000);
      if(check.blocked)return feedback(`전체 삭제 불가 · ${check.reason||'진행 중 작업'}`,true);
    }catch(error){return feedback(`전체 삭제 사전 검사 실패 · ${error?.message||error}`,true);}
    const pending=Number(snapshot?.counts?.pending)||0;
    if(!confirm(`전체 로컬 DB를 완전히 삭제하시겠습니까?\n\n업로드 대기 ${fmt(pending)}건, 수집 원본, 저장 번들, 이력, 재시도 대기열까지 삭제됩니다. 서버 데이터는 유지됩니다.\n복구할 수 없습니다. 이 작업은 권장하지 않습니다.`))return;
    busy=true;$('resetAll').disabled=true;let successNotice='';
    try{const data=await msg('SPX_RESET_ALL_LOCAL_COLLECTION_V1627',{},60000);
      clearRenderedHistoryV1643('all');
      const sum=Object.values(data?.deleted||{}).reduce((n,v)=>n+(Number(v)||0),0);
      successNotice=`전체 로컬 DB 삭제 완료 · ${fmt(sum)}건 · 서버 데이터 유지`;
      feedback(successNotice);
    }catch(e){feedback(`전체 로컬 DB 삭제 실패 · ${e?.message||e}`,true);}
    finally{busy=false;$('resetAll').disabled=false;if(successNotice)scheduleHistoryResetRefreshV1646(successNotice);}
  });
  /* v1.6.46: Best-effort read-only snapshot across every selected key.
     Preserve each successful record even when a later message/IDB read fails;
     failed keys are clearly tagged as diagnostics, never fabricated originals. */
  $('backupPending').addEventListener('click',async()=>{
    if(busy)return;
    const keys=[...selected];
    if(!keys.length)return feedback('먼저 로컬 대기 키워드를 선택하세요. 전체 백업은 「전체 선택」 후 실행하세요.',true);
    busy=true;const button=$('backupPending');button.disabled=true;
    const parts=[`{"schema":"smartpage-local-original-backup-v1","collectorVersion":${JSON.stringify(chrome.runtime.getManifest()?.version||'1.6.48')},"readOnly":true,"managerImportable":false,"serverVerified":false,"records":[`];
    let recorded=0,backedUp=0,missingAggregate=0,responseErrors=0;
    try{
      for(let i=0;i<keys.length;i++){
        let record;
        try{
          const data=await msg('SPX_PENDING_ORIGINAL_BACKUP_V1643',{keys:[keys[i]]},60000);
          if(!Array.isArray(data?.rows)||data.rows.length!==1||String(data.rows[0]?.key||'')!==keys[i])
            throw new Error(`백업 응답 건수·키 불일치: ${keys[i]}`);
          record=data.rows[0];
          if(record?.error==='AGGREGATE_NOT_FOUND')missingAggregate++;
          else if(record?.error)responseErrors++;
          else backedUp++;
        }catch(error){
          /* A transport failure is not evidence of missing data. */
          responseErrors++;
          record={key:keys[i],error:'BACKUP_RESPONSE_FAILED',originalAvailability:'unknown',
            diagnostic:String(error?.message||error),readOnly:true};
        }
        if(recorded)parts.push(',');
        parts.push(JSON.stringify(record));recorded++;
        if(i%10===0||i===keys.length-1)feedback(`로컬 원본 백업 ${fmt(i+1)}/${fmt(keys.length)} · 원본 보존 ${fmt(backedUp)} · 기록 부재 ${fmt(missingAggregate)} · 응답 오류 ${fmt(responseErrors)}`);
        if(i%8===0)await new Promise(resolve=>setTimeout(resolve,0));
      }
      parts.push(`],"requested":${keys.length},"recorded":${recorded},"backedUp":${backedUp},"missingAggregate":${missingAggregate},"responseErrors":${responseErrors}}`);
      const stamp=new Date().toISOString().replace(/[:.]/g,'-');
      const name=backedUp?`SmartPage_로컬원본그대로_${backedUp}건_미확인${missingAggregate+responseErrors}건_${stamp}.json`:`SmartPage_로컬원본진단전용_${keys.length}건_${stamp}.json`;
      downloadBlob(name,parts,'application/json;charset=utf-8');
      feedback(`로컬 원본 ${fmt(backedUp)}/${fmt(keys.length)}건 백업 · DB 기록 부재 ${fmt(missingAggregate)}건 · 응답 실패 ${fmt(responseErrors)}건 · Manager 업로드용 아님`,missingAggregate>0||responseErrors>0||!backedUp);
    }catch(error){feedback(`백업 파일 생성 실패 · ${error?.message||error} · 원본 DB 변경 없음`,true);}
    finally{busy=false;button.disabled=false;}
  });

  /* v1.6.37: User-initiated, read-only, 100-row batches. The initial window
     never scans all pending rows. Avoid relying on 5,000-key select-all cap. */
  function showAuditV1636(message){const node=$('auditSummary');if(node)node.textContent=message;}
  const DIAG_LABEL_V1636={bundle_present:'일치 회차 번들 존재',raw_present:'원천상품만 존재',no_source:'원천자료 위치 미발견',status_conflict:'상태 충돌',durable_structure_ok:'번들 구조 통과',embedded_structure_ok:'내장 번들 구조 통과',raw_present_needs_build:'원천상품으로 재구성 필요',durable_invalid:'번들 구조·회차 불일치',source_missing:'원천자료 누락',aggregate_missing:'기본 기록 누락'};
  $('auditPending').addEventListener('click',async()=>{
    if(busy)return;
    if(snapshot?.running){feedback('정확한 대기 건수 진단을 위해 현재 수집을 안전하게 중지한 뒤 실행하세요. 로컬 자료는 변경하지 않았습니다.',true);return;}
    busy=true;const button=$('auditPending');button.disabled=true;
    const list=[],totals={};let next='',batches=0;
    try{
      for(;;){
        const data=await msg('SPX_PENDING_AUDIT_BATCH_V1636',{afterKey:next,limit:40},30000);
        if(!Array.isArray(data?.rows))throw new Error('진단 응답 rows 형식 오류');
        for(const row of data.rows){list.push(row);totals[row.category]=(totals[row.category]||0)+1;}
        batches++;showAuditV1636(`상태 대기 원본 검사 ${fmt(list.length)}건 · 번들 ${fmt(totals.bundle_present||0)} · raw ${fmt(totals.raw_present||0)} · 위치 미발견 ${fmt(totals.no_source||0)} · 상태 충돌 ${fmt(totals.status_conflict||0)}`);
        if(data.done===true)break;
        if(!data.nextKey||data.nextKey===next||batches>100000)throw new Error('진단 커서가 진행하지 않습니다. 중복 검사를 중단했습니다.');
        next=String(data.nextKey);
        await new Promise(resolve=>setTimeout(resolve,0));
      }
      const report={schema:'smartpage-pending-readonly-audit-v1',collectorVersion:'1.6.37',createdAt:new Date().toISOString(),scope:'current-extension-local-IndexedDB',readOnly:true,serverVerified:false,sourceIntegrityVerified:false,inspected:list.length,totals,rows:list};
      downloadBlob(`SmartPage_로컬대기_원본위치진단_${list.length}건_${new Date().toISOString().replace(/[:.]/g,'-')}.json`,[JSON.stringify(report)],'application/json;charset=utf-8');
      showAuditV1636(`진단 완료 ${fmt(list.length)}건 · 번들 ${fmt(totals.bundle_present||0)} · raw ${fmt(totals.raw_present||0)} · 위치 미발견 ${fmt(totals.no_source||0)} · 상태 충돌 ${fmt(totals.status_conflict||0)} · JSON 보고서 저장 (원본 삭제/변경 없음)`);
    }catch(error){showAuditV1636(`원본 진단 중단 · 검사 ${fmt(list.length)}건 · ${String(error?.message||error)} · 기존 DB 무변경`);feedback(String(error?.message||error),true);}
    finally{button.disabled=false;busy=false;}
  });
  $('diagnoseSelected').addEventListener('click',async()=>{
    if(busy)return;
    if(snapshot?.running){feedback('수집 중에는 선택 원본 진단을 진행하지 않습니다. 안전하게 중지한 뒤 실행하세요.',true);return;}
    const keys=[...selected];if(!keys.length){feedback('먼저 로컬 대기 항목을 선택하세요.',true);return;}
    busy=true;const button=$('diagnoseSelected');button.disabled=true;let checked=0;const list=[];
    try{
      for(let i=0;i<keys.length;i+=20){const data=await msg('SPX_PENDING_DIAGNOSE_SELECTED_V1636',{keys:keys.slice(i,i+20)},60000);
        if(!Array.isArray(data?.rows))throw new Error('선택 원본 진단 응답 형식 오류');list.push(...data.rows);checked+=data.rows.length;
        showAuditV1636(`선택 원본 구조 진단 ${fmt(checked)}/${fmt(keys.length)} · 서버/원본 변경 없음`);
      }
      const totals={};for(const r of list)totals[r.category]=(totals[r.category]||0)+1;
      downloadBlob(`SmartPage_선택원본_구조진단_${checked}건_${new Date().toISOString().replace(/[:.]/g,'-')}.json`,[JSON.stringify({schema:'smartpage-selected-source-diagnosis-v1',collectorVersion:'1.6.37',readOnly:true,sourceIntegrityVerified:false,serverVerified:false,totals,rows:list})],'application/json;charset=utf-8');
      showAuditV1636(`선택 ${fmt(checked)}건 진단 완료 · ${Object.entries(totals).map(([key,n])=>`${DIAG_LABEL_V1636[key]||key} ${fmt(n)}`).join(' · ')} · 진단 JSON 저장 (Manager 업로드용 아님)`);
    }catch(error){feedback(`원본 진단 오류 · ${error?.message||error}`,true);}
    finally{button.disabled=false;busy=false;}
  });

  $('selectAll').addEventListener('click',async()=>{if(busy){feedback('이전 작업 종료 후 전체 선택을 실행하세요.',true);return;}busy=true;$('selectAll').disabled=true;try{const data=await msg('SPX_HISTORY_PENDING_KEYS_V1633',{search:searchTerm()});if(data.truncated)throw new Error('전체 선택 안전 상한(25,000건)을 초과했습니다. 검색 조건을 나눠서 선택하세요.');for(const key of data.keys||[])selected.add(String(key));renderRows();feedback(`검색 조건 일치 대기 ${fmt(selected.size)}건 선택`);}catch(e){feedback(e?.message||e,true);}finally{busy=false;$('selectAll').disabled=false;}});
  $('selectNone').addEventListener('click',()=>{selected.clear();renderRows();});
  let searchTimer=null;for(const id of ['search','pendingSearch'])$(id).addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{offset=0;void loadPage();},260);});
  $('prevPage').addEventListener('click',()=>{if(pagePending||!offset)return;offset=Math.max(0,offset-limit);void loadPage();});
  $('nextPage').addEventListener('click',()=>{if(pagePending||!hasMore)return;offset+=limit;void loadPage();});
  $('reload').addEventListener('click',()=>void refresh(true,true));document.querySelectorAll('.stat[data-filter]').forEach(el=>el.addEventListener('click',()=>setView(el.dataset.filter)));
  let eventTimer=0;chrome.storage.onChanged.addListener((changes,area)=>{
    if(area!=='local'||!changes.spxLocalCollectionRevisionV1633)return;
    // Never compete with an active history reset over IndexedDB reads.
    if(busy)return;
    clearTimeout(eventTimer);eventTimer=setTimeout(()=>{if(!busy)void refresh(true,true);},900);
  });
  setView('completed',{load:false});void refresh(true);void loadPage();setInterval(()=>{if(!document.hidden&&!busy)void refresh();},9000);
})();
