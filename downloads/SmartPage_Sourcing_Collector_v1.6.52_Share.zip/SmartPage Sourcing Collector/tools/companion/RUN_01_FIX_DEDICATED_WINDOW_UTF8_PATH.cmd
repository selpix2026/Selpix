@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp001_FIX_DEDICATED_WINDOW_UTF8_PATH.ps1"
set RC=%ERRORLEVEL%
echo ExitCode=%RC%
pause
exit /b %RC%
