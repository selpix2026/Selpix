﻿$ErrorActionPreference = 'SilentlyContinue'

function Test-Administrator {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Administrator)) {
  $process = Start-Process "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Verb RunAs -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"') -Wait -PassThru
  exit $process.ExitCode
}

$InstallDir = Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
function Restore-StoredNetworkMetrics([string]$StatePath){
  if(-not(Test-Path -LiteralPath $StatePath)){return}
  try{
    $state=Get-Content -LiteralPath $StatePath -Raw -ErrorAction Stop|ConvertFrom-Json -ErrorAction Stop
    $changes=@()
    if($null-ne$state.changes){$changes=@($state.changes)}
    elseif($null-ne$state.interfaceIndex){$changes=@([pscustomobject]@{interfaceIndex=[int]$state.interfaceIndex;originalAutomaticMetric=[string]$state.originalAutomaticMetric;originalInterfaceMetric=[int]$state.originalInterfaceMetric})}
    foreach($change in $changes){
      $index=[int]$change.interfaceIndex;if($index-le0){continue}
      $iface=Get-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $index -ErrorAction SilentlyContinue|Select-Object -First 1
      if($null-eq$iface){continue}
      $auto=[string]$change.originalAutomaticMetric
      if($auto-match'Enabled|True' -or [string]::IsNullOrWhiteSpace($auto)){
        Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $index -AutomaticMetric Enabled -ErrorAction SilentlyContinue
      }else{
        Set-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $index -AutomaticMetric Disabled -InterfaceMetric ([Math]::Max(1,[int]$change.originalInterfaceMetric)) -ErrorAction SilentlyContinue
      }
    }
  }catch{}finally{Remove-Item -LiteralPath $StatePath -Force -ErrorAction SilentlyContinue}
}
Restore-StoredNetworkMetrics (Join-Path $InstallDir 'selected-route-guard.json')
Restore-StoredNetworkMetrics (Join-Path $InstallDir 'system-route-pin.json')
foreach ($taskName in @('SmartPageEx Open Dedicated Browser','SmartPageEx Network Local Bridge','SmartPageEx Network Bridge Recovery','SmartPageEx Network Switch')) {
  Stop-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
}

Get-CimInstance Win32_Process -Filter "Name='SpxNetworkHost.exe'" -ErrorAction SilentlyContinue | ForEach-Object {
  try { Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue | Out-Null } catch { }
}

try {
  $interactiveName = [string](Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue).UserName
  if ([string]::IsNullOrWhiteSpace($interactiveName)) { $interactiveName = [Security.Principal.WindowsIdentity]::GetCurrent().Name }
  $interactiveSid = (New-Object Security.Principal.NTAccount($interactiveName)).Translate([Security.Principal.SecurityIdentifier]).Value
  Remove-ItemProperty -Path "Registry::HKEY_USERS\$interactiveSid\Software\Microsoft\Windows\CurrentVersion\Run" -Name 'SmartPageExNetworkBridge' -Force -ErrorAction SilentlyContinue
  Remove-ItemProperty -Path "Registry::HKEY_USERS\$interactiveSid\Software\Microsoft\Windows\CurrentVersion\Run" -Name 'SmartPageExNetworkHelper' -Force -ErrorAction SilentlyContinue
  $startupShortcut = Join-Path (Get-CimInstance Win32_UserProfile -ErrorAction SilentlyContinue | Where-Object { $_.SID -eq $interactiveSid } | Select-Object -First 1 -ExpandProperty LocalPath) 'AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\SmartPageEx Network Bridge.lnk'
  Remove-Item -LiteralPath $startupShortcut -Force -ErrorAction SilentlyContinue
} catch { }

$hostNames = @('com.smartpage.spx_network_v7','com.smartpage.spx_network_v6','com.smartpage.spx_network_v5','com.smartpage.spx_network_v4','com.smartpage.spx_network_v3','com.smartpage.spx_network_v2','com.smartpage.spx_network')
$interactiveSidValue = $null
try { $interactiveSidValue = $interactiveSid } catch { }
foreach ($name in $hostNames) {
  Remove-Item "HKLM:\Software\Google\Chrome\NativeMessagingHosts\$name" -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item "HKLM:\Software\WOW6432Node\Google\Chrome\NativeMessagingHosts\$name" -Recurse -Force -ErrorAction SilentlyContinue
  if ($interactiveSidValue) {
    Remove-Item "Registry::HKEY_USERS\$interactiveSidValue\Software\Google\Chrome\NativeMessagingHosts\$name" -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item "Registry::HKEY_USERS\$interactiveSidValue\Software\WOW6432Node\Google\Chrome\NativeMessagingHosts\$name" -Recurse -Force -ErrorAction SilentlyContinue
  }
}

Remove-Item $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'SmartPage Ex network helper was removed. Saved adapter metrics were restored.' -ForegroundColor Green
Read-Host 'Press Enter to close'

Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue|Where-Object{([string]$_.CommandLine -like '*run-network-host.ps1*') -and ([string]$_.CommandLine -like '*-HttpServer*')}|ForEach-Object{try{Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue|Out-Null}catch{}}
