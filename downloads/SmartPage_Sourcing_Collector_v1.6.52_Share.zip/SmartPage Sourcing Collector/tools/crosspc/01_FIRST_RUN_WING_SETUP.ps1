﻿param([ValidateSet('','chrome','whale')][string]$BrowserFamily='')
$ErrorActionPreference='Stop'
$Root=Join-Path $env:ProgramData 'SmartPageEx\SmartPage Sourcing Collector'
. (Join-Path $PSScriptRoot 'browser-launch-common.ps1')
$BrowserFamily=Resolve-SpxBrowserFamily $BrowserFamily
$Profile=if($BrowserFamily -eq 'whale'){'C:\SpxDedicatedProfile-Whale'}else{'C:\SpxDedicatedProfile'}
$BrowserExecutable=if($BrowserFamily -eq 'whale'){'whale.exe'}else{'chrome.exe'}
$Manager=Join-Path $Root 'tools\wing-recovery\WING_SESSION_MANAGER.ps1'
$NetBase=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$RequestPath=Join-Path $NetBase 'dedicated-window-request.json'
$ResultPath=Join-Path $NetBase 'dedicated-window-result.json'
$ReadyPath=Join-Path $NetBase 'dedicated-window-launcher.ready'
$BrowserTaskName='SmartPageEx Open Dedicated Browser'
function Write-JsonUtf8Atomic([string]$Path,[object]$Value){
  $tmp=$Path+'.tmp.'+[Guid]::NewGuid().ToString('N')
  [IO.File]::WriteAllText($tmp,($Value|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
  Move-Item -LiteralPath $tmp -Destination $Path -Force
}
function Get-DedicatedProcesses{
  try{@(Get-CimInstance Win32_Process -Filter ("Name='"+$BrowserExecutable+"'") -ErrorAction SilentlyContinue|Where-Object{([string]$_.CommandLine) -like ('*'+$Profile+'*')})}catch{@()}
}
function Ensure-InteractiveLauncher{
  $ready=$null
  if(Test-Path -LiteralPath $ReadyPath){try{$ready=Get-Content -LiteralPath $ReadyPath -Raw|ConvertFrom-Json}catch{$ready=$null}}
  $alive=$false
  if($null-ne$ready -and [int]$ready.pid -gt0){try{$null=Get-Process -Id ([int]$ready.pid) -ErrorAction Stop;$alive=$true}catch{$alive=$false}}
  if(-not$alive){
    try{Start-ScheduledTask -TaskName $BrowserTaskName -ErrorAction Stop}catch{throw '현재 사용자용 전용창 launcher를 시작하지 못했습니다. RUN_00_INSTALL_OTHER_PC.cmd를 관리자 권한으로 다시 실행하세요.'}
    for($i=0;$i-lt40;$i++){
      Start-Sleep -Milliseconds 250
      if(Test-Path -LiteralPath $ReadyPath){try{$ready=Get-Content -LiteralPath $ReadyPath -Raw|ConvertFrom-Json}catch{$ready=$null}}
      if($null-ne$ready -and [int]$ready.pid -gt0){try{$null=Get-Process -Id ([int]$ready.pid) -ErrorAction Stop;$alive=$true;break}catch{$alive=$false}}
    }
  }
  if(-not$alive){throw '현재 로그인 사용자 세션의 전용창 launcher가 준비되지 않았습니다.'}
  return $ready
}
function Request-InteractiveWindow([string]$LaunchMode,[string]$StartUrl){
  $null=Ensure-InteractiveLauncher
  $manifest=Get-Content -LiteralPath (Join-Path $Root 'manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
  $requestId=[Guid]::NewGuid().ToString('N')
  Remove-Item -LiteralPath $ResultPath -Force -ErrorAction SilentlyContinue
  $payload=[ordered]@{
    requestId=$requestId;browserFamily=$BrowserFamily;launchMode=$LaunchMode;startUrl=$StartUrl;extensionRoot=$Root;extensionVersion=[string]$manifest.version;
    forceRuntimeRestart=$true;requestedAt=(Get-Date).ToUniversalTime().ToString('o')
  }
  Write-JsonUtf8Atomic $RequestPath $payload
  $result=$null
  for($i=0;$i-lt80;$i++){
    Start-Sleep -Milliseconds 250
    if(-not(Test-Path -LiteralPath $ResultPath)){continue}
    try{$candidate=Get-Content -LiteralPath $ResultPath -Raw|ConvertFrom-Json}catch{continue}
    if([string]$candidate.requestId -ne $requestId){continue}
    $result=$candidate;break
  }
  if($null-eq$result){throw '전용창 launcher가 20초 안에 실행 결과를 반환하지 않았습니다. NetworkHostV33\dedicated-window-launch.log를 확인하세요.'}
  if($result.ok-ne$true){throw ('전용창 실행 실패: '+[string]$result.error)}
  for($i=0;$i-lt40;$i++){if(@(Get-DedicatedProcesses).Count-gt0){return $result};Start-Sleep -Milliseconds 250}
  throw '전용 Chrome 프로세스가 실행 확인되지 않았습니다.'
}
if(-not(Test-Path -LiteralPath (Join-Path $Root 'manifest.json') -PathType Leaf)){throw 'Collector 설치본이 없습니다.'}
if(@(Get-DedicatedProcesses).Count -gt 0){throw '전용창이 이미 실행 중입니다. 전용창만 닫고 다시 실행하세요.'}
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host ' WING 최초 로그인 설정' -ForegroundColor Green
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host '새 PC에서는 WING 인증을 1회 완료해야 합니다.' -ForegroundColor Yellow
Write-Host '현재 로그인 사용자 바탕화면에 WING 전용창을 엽니다. WING/auth는 Windows 기본망 DIRECT를 사용합니다.' -ForegroundColor Cyan
$wingResult=Request-InteractiveWindow -LaunchMode 'wing-direct' -StartUrl 'https://wing.coupang.com/'
Write-Host ('WING 전용창 열기 완료 · PID '+[string]$wingResult.pid) -ForegroundColor Green
Write-Host '열린 전용 브라우저에서 WING 로그인을 완료한 뒤 브라우저를 정상 종료하세요.'
[void](Read-Host 'WING 로그인 완료 후 전용 브라우저를 모두 닫고 Enter')
$deadline=(Get-Date).AddSeconds(60)
while(@(Get-DedicatedProcesses).Count -gt 0 -and (Get-Date)-lt$deadline){Start-Sleep -Milliseconds 500}
if(@(Get-DedicatedProcesses).Count -gt 0){throw '전용 브라우저가 아직 실행 중입니다. 모두 닫고 다시 시도하세요.'}
& "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $Manager -Action Save -BrowserFamily $BrowserFamily
$saveRc=$LASTEXITCODE
if($saveRc -ne 0){exit $saveRc}
Write-Host ''
Write-Host 'WING 로컬 백업 완료. 이어서 전용망/연동 설정 화면을 엽니다.' -ForegroundColor Green
$optionsUrl='chrome-extension://olmpllofoggohefbdkgkjjnlanfnaocd/src/options/options.html'
$optionsResult=Request-InteractiveWindow -LaunchMode 'options-direct' -StartUrl $optionsUrl
Write-Host ('설정 화면 열기 완료 · PID '+[string]$optionsResult.pid) -ForegroundColor Green
Write-Host '새 PC의 USB 테더링/전용망 어댑터는 PC마다 장치 ID가 달라질 수 있으므로 여기에서 1회 확인하세요.' -ForegroundColor Yellow
exit 0
