const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const {root}=require('./helpers.cjs');
async function worker(){
  const errors=[],listeners=[],storage={},event={addListener:()=>{},removeListener:()=>{}},noop=async()=>({});
  const storageArea={get:async keys=>typeof keys==='string'?{[keys]:storage[keys]}:{...storage},set:async value=>Object.assign(storage,value),remove:async keys=>{for(const key of Array.isArray(keys)?keys:[keys])delete storage[key];},getBytesInUse:async()=>0};
  const api=new Proxy({}, {get:(target,key)=>String(key).startsWith('on')?event:noop});
  const chrome={storage:{local:storageArea,session:storageArea,onChanged:event},runtime:{id:'test',getManifest:()=>({version:'1.6.52'}),getURL:p=>'chrome-extension://test/'+p,onInstalled:event,onStartup:event,onMessage:{addListener:f=>listeners.push(f)},onMessageExternal:event,sendMessage:async()=>({ok:true}),getPlatformInfo:async()=>({os:'linux'})},
    tabs:api,alarms:{...api,onAlarm:event,create:async()=>{},clear:async()=>true,getAll:async()=>[]},webRequest:api,windows:api,proxy:{settings:api},scripting:api,cookies:api,declarativeNetRequest:api,notifications:api};
  const ctx=vm.createContext({chrome,console:{log:()=>{},info:()=>{},debug:()=>{},warn:()=>{},error:(...args)=>errors.push(args.map(String).join(' '))},
    URL,URLSearchParams,TextEncoder,TextDecoder,AbortController,Response,Request,Headers,Blob,structuredClone,crypto:require('node:crypto').webcrypto,
    indexedDB:new (require('fake-indexeddb').IDBFactory)(),IDBKeyRange:require('fake-indexeddb').IDBKeyRange,performance,atob,btoa,navigator:{userAgent:'local-test'},setTimeout:()=>1,clearTimeout:()=>{},setInterval:()=>1,clearInterval:()=>{},fetch:async()=>new Response('{}',{status:503})});
  ctx.self=ctx;ctx.addEventListener=()=>{};
  ctx.importScripts=(...files)=>{for(const file of files){const full=path.resolve(root,'src/background',file);vm.runInContext(fs.readFileSync(full,'utf8'),ctx,{filename:file});}};
  vm.runInContext(fs.readFileSync(root+'/src/background/service-worker.js','utf8'),ctx,{filename:'service-worker.js'});
  await new Promise(resolve=>setImmediate(resolve));
  assert.deepEqual(errors,[]);return ctx;
}
test('worker prepares source evidence and persists a collected result in real IndexedDB',async()=>{
 const ctx=await worker();
 const products=Array.from({length:12},(_,i)=>({pid:String(i+1),name:'스테인리스 보온 텀블러',price:15000+i*100,rank:i+1,rating:4.5,reviews:30,detailMonthlyPurchaseCount:300,isAd:false,rocketType:'일반배송'}));
 const aggregate=ctx.SPX.aggregate('텀블러',products,'coupang',8,{});
 assert.ok(aggregate);
 const bundle=await ctx.prepareSourceData('텀블러',products,aggregate,{settings:{},state:{runId:'test-run'},manualOneShot:true});
 assert.equal(bundle.snapshots.length,12);
 assert.ok(bundle.runRow.run_key);
 await ctx.SPX.db.saveRaw('텀블러',products);
 const payload=ctx.prepareCompleteMetricPayload(aggregate);
 const saved=await ctx.SPX.db.saveAggregate({...payload,status:'pending'},{markPending:true});
 assert.ok(saved?.k,JSON.stringify({grade:aggregate.grade,reasons:aggregate.grade_block_reasons}));
 const restored=await ctx.SPX.db.getAggregate(saved.k);
 assert.equal(restored.status,'pending');
 assert.equal(restored.collection_run_key,bundle.runRow.run_key);
 assert.equal(restored.winner_count,12);
 assert.equal((await ctx.SPX.db.getRawHistory('텀블러','coupang',50000)).length,12);
});
