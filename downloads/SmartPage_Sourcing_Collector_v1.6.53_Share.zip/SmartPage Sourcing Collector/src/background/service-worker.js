/* service-worker.js — v1.6.41 lightweight bootstrap only.
 * Chrome MV3가 최초 등록 시 가져오는 진입 파일을 작게 유지합니다.
 * 실제 Collector 런타임은 service-worker-core.js에 있으며 초기 등록만 경량 bootstrap으로 분리합니다.
 */
const SPX_SW_BOOTSTRAP_BUILD='1.6.53';
const SPX_SW_BOOT_SCRIPTS_V143=[
  '../lib/util.js',
  '../lib/keyword-filter.js',
  '../lib/discovery.js',
  '../lib/coupang-seed-catalog.js',
  '../lib/prompt-keywords-v1610.js',
  '../lib/explore.js',
  '../lib/aggregate.js',
  '../lib/local-compute.js',
  '../lib/db.js',
  '../lib/pending-repair.js',
  '../lib/util-sw.js',
  './wing-recovery-snapshot.js',
  './service-worker-core.js',
  './wing-actual-v1620.js'
];
for(const spxBootScriptV143 of SPX_SW_BOOT_SCRIPTS_V143){
  try{importScripts(spxBootScriptV143);}
  catch(error){
    console.error('[SPX v1.6.41] Service Worker import failed:',spxBootScriptV143,error);
    throw new Error(`SPX_SW_BOOT_IMPORT_FAILED ${spxBootScriptV143}: ${String(error?.message||error||'unknown')}`);
  }
}
