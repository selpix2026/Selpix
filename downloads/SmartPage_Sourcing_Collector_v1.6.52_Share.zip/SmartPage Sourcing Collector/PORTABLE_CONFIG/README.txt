PORTABLE_CONFIG

다른 PC로 Supabase/Naver/AI 연동 설정도 함께 옮길 때만 사용합니다.

현재 PC에서 RUN_05_EXPORT_CURRENT_PC_INTEGRATION_SETTINGS.cmd를 실행하면
C:\ProgramData\SmartPageEx\NetworkHostV33\integration-secrets.json 이 폴더로 복사됩니다.

주의:
- integration-secrets.json에는 API Key/Secret 및 설정에 따라 WING ID/비밀번호가 포함될 수 있습니다.
- 이 폴더가 채워진 ZIP은 본인 PC 사이에서만 보관/전달하세요.
- WING 로그인 세션(Cookies/IndexedDB)은 절대 이 폴더에 넣지 않습니다.
- WING 세션은 Windows/Chrome 암호화 때문에 다른 PC로 이식하지 않습니다.
