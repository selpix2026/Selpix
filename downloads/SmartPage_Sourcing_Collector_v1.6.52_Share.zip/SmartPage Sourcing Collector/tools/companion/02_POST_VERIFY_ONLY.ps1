﻿$ErrorActionPreference = 'Stop'
$ExpectedId = 'olmpllofoggohefbdkgkjjnlanfnaocd'
$ManagerId = 'cikfdcalhneenfppkcplacnheaecfnai'
$ExpectedCollectorRoot = 'D:\01. Work In Process\쿠팡 수집기\SmartPage Sourcing Collector'
$ActualCollectorRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Root = $ExpectedCollectorRoot
$InstallDir = Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$ConfigPath = Join-Path $InstallDir 'network-host-config.json'
$NativeManifestPath = Join-Path $InstallDir 'com.smartpage.spx_network_v7.json'
$LauncherPath = Join-Path $InstallDir 'open-dedicated-window.ps1'
$ReadyPath = Join-Path $InstallDir 'dedicated-window-launcher.ready'
$TaskName = 'SmartPageEx Open Dedicated Browser'
function Read-Utf8Text([string]$Path) { if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }; return [IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8) }
function Read-Utf8Json([string]$Path) { $text=Read-Utf8Text $Path; if ($null -eq $text) { return $null }; return ($text | ConvertFrom-Json -ErrorAction Stop) }
function Has-Utf8Bom([string]$Path) { if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }; $b = [IO.File]::ReadAllBytes($Path); return ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF) }
function Eq-Path([string]$A, [string]$B) { try { return ([IO.Path]::GetFullPath($A).TrimEnd([char]'\') -eq [IO.Path]::GetFullPath($B).TrimEnd([char]'\')) } catch { return $false } }
if (-not (Eq-Path $ActualCollectorRoot $ExpectedCollectorRoot)) {
  throw ('Collector 경로가 고정 경로와 다릅니다. 현재=' + $ActualCollectorRoot + ' / 필요=' + $ExpectedCollectorRoot)
}

$config = Read-Utf8Json $ConfigPath
$native = Read-Utf8Json $NativeManifestPath
$launcher = Read-Utf8Text $LauncherPath
$ready = Read-Utf8Json $ReadyPath
$task = Get-ScheduledTask -TaskName $TaskName -ErrorAction Stop
$action = @($task.Actions)[0]
$origin = 'chrome-extension://' + $ExpectedId + '/'
$managerOrigin = 'chrome-extension://' + $ManagerId + '/'
$checks = [ordered]@{
  ConfigUtf8Bom = (Has-Utf8Bom $ConfigPath)
  ConfigActiveId = ([string]$config.extensionId -eq $ExpectedId)
  ConfigCollectorId = (@($config.extensionIds) -contains $ExpectedId)
  ConfigManagerId = (@($config.extensionIds) -contains $ManagerId)
  ConfigCollectorOrigin = (@($config.allowedOrigins) -contains $origin)
  ConfigManagerOrigin = (@($config.allowedOrigins) -contains $managerOrigin)
  ConfigRootExact = (Eq-Path ([string]$config.extensionRoot) $Root)
  ConfigRootExists = (Test-Path -LiteralPath ([string]$config.extensionRoot) -PathType Container)
  NativeCollectorOrigin = (@($native.allowed_origins) -contains $origin)
  LauncherRequestUtf8 = ($launcher -match '\[IO\.File\]::ReadAllText\(\$RequestPath\s*,\s*\[Text\.Encoding\]::UTF8\)')
  LauncherReady = ($null -ne $ready -and $ready.ready -eq $true)
  TaskRunning = ([string]$task.State -eq 'Running')
  TaskPointsToV33Launcher = ([string]$action.Arguments).Contains($LauncherPath)
}
$checks.GetEnumerator() | ForEach-Object { Write-Host ($_.Key + '=' + $_.Value) }
$failed = @($checks.GetEnumerator() | Where-Object { $_.Value -ne $true })
if ($failed.Count -gt 0) { throw ('Dedicated-window UTF-8/path FIX5 post verify failed: ' + (($failed | ForEach-Object { $_.Key }) -join ', ')) }
Write-Host 'WRITE=0 TASK_RUN=0 TASK_CHANGE=0 ROUTE_CHANGE=0 ADAPTER_CHANGE=0 CHROME_STOP=0 NETWORKHOST_RESTART=0'
Write-Host 'FINAL=DEDICATED_WINDOW_UTF8_PATH_FIX5_POST_VERIFY_PASS'
