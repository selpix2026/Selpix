SmartPage Ex v4.2.01 / Helper 3.0.45 수집 네트워크 보조도구

핵심 구조
- Chrome 확장프로그램만으로 Windows 네트워크 어댑터를 프로세스별 지정할 수 없으므로 127.0.0.1:30765 로컬 브리지와 30766~30769 프록시 뱅크를 사용합니다. Native Messaging은 브리지 상태조회·복구 경로로 함께 사용합니다.
- Windows 기본 인터넷(Wi-Fi/유선)은 운영체제가 그대로 관리하고, Collector에서는 쿠팡 전용창이 사용할 USB 테더링 어댑터만 선택합니다.
- 선택 네트워크 전용 Chrome은 C:\SpxDedicatedProfile 프로필과 PAC를 사용합니다.
- PAC는 coupang.com / www.coupang.com 메인 쇼핑 origin만 현재 준비된 127.0.0.1:30766~30769 로컬 프록시로 보냅니다. 쿠팡 CDN/static/보조 호스트는 Windows 기본 인터넷을 사용합니다.
- 로컬 프록시는 메인 쇼핑 origin 연결 소켓만 선택한 USB 테더링 어댑터에 바인딩합니다.
- USB/RNDIS DNS가 없거나 UDP 53을 막으면 도메인 이름만 Windows DNS로 보조 해석하고, 실제 쿠팡 TCP 연결은 계속 선택 어댑터에 바인딩합니다.
- Supabase·일반 웹사이트는 DIRECT로 Windows 기본 인터넷을 사용합니다.

Windows 기본 인터넷 · OS 관리
- Helper 3.0.44부터 Windows 기본 인터넷은 운영체제에 맡기며 Wi-Fi/유선 InterfaceMetric·AutomaticMetric·기본 경로를 정상 동작 중 변경하지 않습니다.
- 쿠팡 전용 트래픽만 선택한 휴대폰 테더링 IP/인터페이스에 소켓 Bind합니다.
- 선택 테더링이 Windows 기본 인터넷이면 일반 트래픽 누수를 막기 위해 전용창 실행과 수집을 Fail-Closed합니다.
- 이전 버전이 남긴 selected-route-guard.json / system-route-pin.json이 있으면 원래 metric으로 1회 복원하고, 이후 다시 기본망 고정을 적용하지 않습니다.
- Wi-Fi가 USB 테더링 연결 시 운영체제/OEM 정책으로 비활성화되는 경우 Collector가 강제로 켜거나 metric을 조정하지 않습니다. Windows에서 Wi-Fi/유선 기본 인터넷이 정상화되면 전용망을 다시 선택합니다.

전용창 수집망 설정
1. Windows의 Wi-Fi 또는 유선 기본 인터넷이 정상 연결되어 있는지 확인합니다. Collector는 이 기본 경로를 변경하지 않습니다.
2. 휴대폰 USB 테더링을 연결합니다.
3. 설정 > 수집 네트워크에서 [전용 네트워크 (휴대폰 테더링)]만 선택합니다.
4. [전용 네트워크 연결] 또는 [전용창 열기]를 누릅니다.
5. 보조도구는 선택 USB 어댑터가 Windows 기본 경로인지 확인하고, 기본 경로라면 Fail-Closed합니다. 기본 경로가 아니면 쿠팡 소켓만 해당 어댑터에 Bind합니다.
6. 일반 Chrome·Windows·WING·Supabase는 Windows 기본 인터넷을 사용하고, 전용창의 coupang.com / www.coupang.com 메인 쇼핑 origin만 USB 테더링을 사용합니다.

중요: 데이터 누수 방지 조건
- USB 테더링만 켜고 다른 인터넷 어댑터를 모두 끄면 Windows 전체가 테더링을 사용할 수 있으므로 전용망 분리가 성립하지 않습니다.
- 선택한 테더링이 Windows 기본 인터넷으로 확인되면 Collector는 기본 경로를 고치려 하지 않고 전용창 실행/수집을 중단합니다.
- WING·Supabase·일반 웹사이트는 전용 프록시 대상에서 제외되어 Windows 기본 인터넷을 사용합니다.
- 레거시 metric 원복 외에는 Collector가 PC 전체 라우팅 우선순위를 변경하지 않습니다.

IP 변경·네트워크 안정화 버튼
- 설정 화면의 [IP 변경·정리]와 사이드바 [IP↻] 버튼은 같은 파이프라인을 실행합니다.
- 현재 수집 중이면 실행 상태와 현재 전용창 쿠팡 탭을 유지한 채 수집을 일시정지합니다. 키워드·페이지 체크포인트 URL은 탭 복원 실패 시 fallback으로만 사용합니다.
- 리셋 전 선택망 공인 IP를 기록합니다.
- Android ADB로 비행기 모드 ON → 설정 시간 유지 → OFF를 실행합니다.
- 1차 후 공인 IP가 같으면 2차에서 모바일 데이터 OFF/ON까지 추가 실행합니다.
- 새 공인 IP가 실제로 확인된 경우에만 성공으로 처리합니다.
- 새 공인 IP 확인 후 추가 안정화 대기 없이 ♻ 임시 리소스 정리 → 🧹 쿠팡 사이트 데이터 정리 → 현재 쿠팡 탭 새로고침 → 즉시 재수집합니다. 탭이 없거나 reload가 실패한 경우에만 저장 URL을 fallback으로 사용합니다.
- 두 번 모두 IP가 같거나 IP 비교가 불가능하면 자동 재개하지 않고 로그·알림으로 실패를 표시합니다.

설치·재설치
- install-network-host.cmd 설치 자체에는 휴대전화/USB 테더링 연결이 필요하지 않습니다. 휴대전화는 실제 전용망 선택·쿠팡 수집·IP 변경을 사용할 때 연결하면 됩니다.
1. Chrome에서 새 spx-collector 폴더를 압축해제된 확장프로그램으로 불러옵니다.
2. 기존 선택망 전용창을 모두 닫습니다.
3. tools\network-host\install-network-host.cmd를 관리자 권한으로 실행합니다.
4. 설치가 끝나면 chrome://extensions에서 SmartPage Ex를 새로고침합니다.
5. Windows 기본 인터넷은 OS 설정 그대로 두고, Collector 설정에서는 USB 테더링 전용 네트워크만 선택합니다.

ADB 준비
1. Android SDK Platform-Tools를 설치하고 adb.exe가 실행되게 합니다.
2. 휴대전화 개발자 옵션에서 USB 디버깅을 켭니다.
3. 휴대전화 화면에서 이 컴퓨터의 USB 디버깅을 허용합니다.
4. adb devices에서 기기 한 대가 device 상태인지 확인합니다.
5. 기기가 여러 대면 설치 폴더 network-host-config.json의 adbSerial에 대상 기기 일련번호를 지정합니다.

주의
- 통신사 CGNAT 정책에 따라 비행기 모드와 모바일 데이터 재연결 후에도 같은 공인 IP가 다시 배정될 수 있습니다.
- Android 제조사 정책에 따라 ADB 비행기 모드 제어가 제한될 수 있습니다.
- 공인 IP가 바뀌지 않으면 프로그램은 성공으로 가장하지 않고 수집 재개를 막습니다.
- v4.1.69은 v4.1.67과 동일한 Helper 3.0.33 / NetworkHostV33 / 30765 / 30766~30769를 그대로 유지합니다. 새 Helper/포트를 만들지 않습니다. v4.1.67에서 전용창이 이미 연결된다면 install-network-host.cmd 재실행은 불필요합니다. 이번 수정은 확장 설정 화면의 proxyReady/bridgeRecoveryPending 판정과 상태 재확인 루프만 안정화합니다.
- 선택한 휴대폰 USB/RNDIS가 아직 IPv4를 받지 못했으면 DHCP 사용 어댑터에만 임대 갱신을 한 번 요청하고 최대 30초간 자동 확인합니다. 일반 Ethernet/Wi-Fi와 고정 IP는 변경하지 않습니다.
- DB SQL 실행은 필요하지 않습니다.

[v3.0.8.3]
- 기본망 고정과 전용창 안전가드 정리를 하나의 관리자 작업으로 합쳐 메트릭 복원 경합을 막았습니다.
- 관리자 명령 파일과 Mutex를 v3.0.8.3 전용으로 분리해 이전 요청 잠금이 남는 문제를 차단했습니다.
- 선택 적용과 전용창 열기에서 같은 네트워크 변경 명령을 두 번 실행하지 않도록 단순화했습니다.
- 기본망 고정 성공 후에는 전용창 프록시 상태를 해제하고 실제 기본 경로 일치 상태를 다시 보고합니다.

[v3.0.7.28]
- Windows 기본 인터넷 어댑터를 사용자가 명시적으로 선택·고정하는 기능을 추가했습니다.
- USB 테더링 연결 시 Windows 기본 경로가 테더링으로 바뀌는 문제를 메트릭 고정으로 방지합니다.
- 기본망 고정 상태와 전용창 선택망 상태를 별도 파일로 저장·복원합니다.
- 설정 화면과 사이드바에 수동 IP 변경·정리 버튼을 추가했습니다.
- 수동 IP 변경도 기존 403 자동복구와 동일한 IP 검증·안정화·쿠팡 데이터 정리·자동 재개 흐름을 사용합니다.


[v3.0.8.3 관리자 명령 멈춤 복구]
- 전역 명령 Mutex와 단일 command/result 파일을 제거했습니다.
- 클릭마다 독립 요청 파일을 만들고 SYSTEM 데몬이 순서대로 처리합니다.
- worker가 35초 이상 멈추면 자동 종료하고 다음 요청을 처리하므로 “이전 요청 처리 중”이 반복되지 않습니다.
- 설치기는 구버전 daemon/worker/Native Host를 먼저 종료한 뒤 저장된 네트워크 메트릭을 복원합니다.


[v3.0.8.3 관리자 네트워크 작업 구조]
- 로그인 내내 실행되는 SYSTEM 데몬과 heartbeat 판정을 제거했습니다.
- 선택 적용/해제 때만 고유 요청 파일을 만들고 단발 예약 작업을 실행합니다.
- 예약 작업이 이미 실행 중이라는 Windows 문구는 오류로 판정하지 않고 기존 실행기가 현재 요청을 처리하도록 기다립니다.
- 큐가 비면 약 2초 후 작업이 종료되어 다음 클릭은 항상 새 작업으로 시작할 수 있습니다.

[v3.0.8.5 설치 인코딩 복구]
- install-network-host.cmd는 BOM 없는 ASCII/CRLF로 저장해 cmd.exe가 @echo off를 정상 인식합니다.
- PowerShell 스크립트는 Windows PowerShell 5.1 호환 UTF-8 BOM/CRLF로 저장합니다.
- SpxNetworkHost.cs의 한글은 Unicode escape로 저장하고 설치기가 UTF-8로 명시 로드합니다.


[v3.0.8.5 전용창 런타임·수동 IP 변경 복구]
- 전용창이 이전 확장 Service Worker를 유지한 경우, 확장 버전/경로 표식을 비교해 C:\SpxDedicatedProfile Chrome만 종료한 뒤 현재 폴더로 다시 엽니다.
- IP↻ 버튼은 새 요청명과 이전 요청명을 순서대로 호환하며, 둘 다 미지원이면 확장 런타임을 한 번 자동 새로고침합니다.
- 일반 Chrome 프로필과 다른 Windows 프로그램은 종료하지 않습니다.


[v3.0.8.7 전용창 강제 최신화]
- 전용창 열기 요청마다 C:\SpxDedicatedProfile Chrome만 안전하게 종료한 뒤 현재 확장 폴더로 다시 실행합니다.
- 이전 Service Worker의 ProxyRestore-OnStart 및 SPX_MANUAL_IP_CHANGE 미지원 오류가 남지 않도록 합니다.
- 이 변경을 설치 위치에 복사하려면 install-network-host.cmd를 관리자 권한으로 한 번 다시 실행해야 합니다.


[v3.0.8.24 ADB 자동 설치와 SYSTEM 공용 인증]
- install-network-host.cmd는 ProgramData 보조도구 폴더에서 adb.exe를 먼저 확인합니다.
- PC에 ADB가 없으면 Google 공식 고정 주소에서 Windows SDK Platform-Tools를 내려받아 ProgramData\SmartPageEx\NetworkHostV33\platform-tools에 설치합니다.
- SYSTEM 보조도구와 설치 관리자가 같은 ADB 인증키를 사용하도록 ProgramData\SmartPageEx\NetworkHostV33\adb-home\.android\adbkey를 사용합니다.
- 설치 결과의 ADB executable ready와 ADB device state를 확인하세요. unauthorized이면 휴대폰 잠금을 해제하고 USB 디버깅 허용 창에서 이 컴퓨터를 항상 허용해야 합니다.


v3.0.8.24 ADB 인증키 복구
- v3.0.8.10에서 adbkey 파일 경로를 폴더로 만들 수 있던 오류를 자동 정리합니다.
- 사용자 프로필의 기존 승인 키가 있으면 전용 ADB 홈으로 복사하고, 없으면 임시 파일에서 생성한 뒤 원자적으로 이동합니다.
- ADB_TRACE 및 외부 ADB 서버 환경 변수를 정리해 키 생성 로그를 오류로 오인하지 않습니다.

[v3.0.8.24 ADB 5037 복구]
- adb start-server가 5037 포트를 열지 못하면 숨김 nodaemon server 방식으로 한 번 더 시작합니다.
- 설치 결과의 ADB daemon port 5037 ready가 True인지 확인합니다.
