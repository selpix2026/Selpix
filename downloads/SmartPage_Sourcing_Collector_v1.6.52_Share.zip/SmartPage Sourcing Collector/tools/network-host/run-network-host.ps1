﻿param([switch]$HttpServer)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try {
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  [Console]::InputEncoding = $utf8
  [Console]::OutputEncoding = $utf8
  $OutputEncoding = $utf8
} catch { }

$BaseDir = if(-not [string]::IsNullOrWhiteSpace($env:SPX_NETWORK_HOST_DIR)) { [string]$env:SPX_NETWORK_HOST_DIR } else { Split-Path -Parent $PSCommandPath }
# SPX_V160_DLL_LOCK_SAFE_SLOT: the installer writes a unique versioned DLL filename to config.
# This avoids overwriting an older DLL that a dying PowerShell-hosted helper still has mapped.
$DllPath = $null
$ConfigPath = Join-Path $BaseDir 'network-host-config.json'
try {
  if(Test-Path -LiteralPath $ConfigPath -PathType Leaf) {
    $cfg = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
    $dllName = [string]$cfg.helperDll
    if((-not [string]::IsNullOrWhiteSpace($dllName)) -and ([IO.Path]::GetFileName($dllName) -eq $dllName) -and ($dllName -like 'SpxNetworkHost.v3037.*.dll')) {
      $candidate = Join-Path $BaseDir $dllName
      if(Test-Path -LiteralPath $candidate -PathType Leaf) { $DllPath = $candidate }
    }
  }
} catch { }
if([string]::IsNullOrWhiteSpace([string]$DllPath)) {
  $legacy = Join-Path $BaseDir 'SpxNetworkHost.dll'
  if(Test-Path -LiteralPath $legacy -PathType Leaf) { $DllPath = $legacy }
}
if([string]::IsNullOrWhiteSpace([string]$DllPath) -or -not (Test-Path -LiteralPath $DllPath -PathType Leaf)) { exit 124 }
$env:SPX_NETWORK_HOST_DIR = $BaseDir

$forwardArgs = if($HttpServer) { @('--http-server') } else { @() }
try {
  if((-not $HttpServer) -and (-not [string]::IsNullOrWhiteSpace($env:SPX_NETWORK_HOST_ARGS_B64))) {
    $jsonBytes = [Convert]::FromBase64String([string]$env:SPX_NETWORK_HOST_ARGS_B64)
    $json = [Text.Encoding]::UTF8.GetString($jsonBytes)
    $parsed = $json | ConvertFrom-Json -ErrorAction Stop
    if($null -ne $parsed) { $forwardArgs = @($parsed | ForEach-Object { [string]$_ }) }
  }
} catch { exit 125 }

try {
  [Reflection.Assembly]::LoadFrom($DllPath) | Out-Null
  $rc = [SpxNetworkHost]::Main([string[]]$forwardArgs)
  exit [int]$rc
} catch {
  try {
    $log = Join-Path $BaseDir 'local-bridge.log'
    [IO.File]::AppendAllText($log, ((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff') + ' RuntimeHost fatal: ' + ($_ | Out-String).Trim() + [Environment]::NewLine), (New-Object Text.UTF8Encoding($false)))
  } catch { }
  exit 126
}
