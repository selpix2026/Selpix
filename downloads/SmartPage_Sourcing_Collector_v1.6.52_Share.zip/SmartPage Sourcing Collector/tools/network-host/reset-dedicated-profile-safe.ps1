﻿$ErrorActionPreference = 'Stop'
$Profile = 'C:\SpxDedicatedProfile'
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$Backup = "C:\SpxDedicatedProfile_BACKUP_$Stamp"

Write-Host '============================================================'
Write-Host ' SmartPage Collector - dedicated profile safe reset'
Write-Host '============================================================'
Write-Host "Profile : $Profile"

# Stop only Chrome processes that were launched with this dedicated user-data-dir.
Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" -ErrorAction SilentlyContinue |
  Where-Object { $_.CommandLine -and $_.CommandLine -like "*$Profile*" } |
  ForEach-Object {
    Write-Host "Stopping dedicated Chrome PID $($_.ProcessId)"
    Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
  }
Start-Sleep -Milliseconds 700

if (Test-Path -LiteralPath $Profile) {
  if (Test-Path -LiteralPath $Backup) { throw "Backup path already exists: $Backup" }
  Move-Item -LiteralPath $Profile -Destination $Backup
  Write-Host "[BACKUP] Existing dedicated profile moved to: $Backup"
} else {
  Write-Host '[INFO] Dedicated profile does not exist. A clean profile will be created.'
}

New-Item -ItemType Directory -Path $Profile -Force | Out-Null
Write-Host '[OK] Clean dedicated profile directory is ready.'
Write-Host '[SAFE] NetworkHostV33, integration settings, Supabase data, and Collector source were not deleted.'

$Register = Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'RUN_08_REGISTER_COLLECTOR_NORMAL_CHROME.cmd'
if (Test-Path -LiteralPath $Register) {
  Write-Host '[NEXT] Registering Collector into the clean dedicated profile...'
  & $Register
  if ($LASTEXITCODE -ne 0) { throw "RUN_08 registration failed with code $LASTEXITCODE" }
} else {
  Write-Host '[WARN] RUN_08_REGISTER_COLLECTOR_NORMAL_CHROME.cmd was not found. Run it manually.'
}
