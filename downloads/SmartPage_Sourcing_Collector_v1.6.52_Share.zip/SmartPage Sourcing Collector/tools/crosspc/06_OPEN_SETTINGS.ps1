﻿param([ValidateSet('','chrome','whale')][string]$BrowserFamily='')
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'browser-launch-common.ps1')
$result=Invoke-SpxDedicatedRequest -LaunchMode 'options-direct' -StartUrl 'chrome-extension://olmpllofoggohefbdkgkjjnlanfnaocd/src/options/options.html' -BrowserFamily $BrowserFamily
if($result.registrationRequired -eq $true){Write-Host ('Load unpacked once in this dedicated browser profile: '+[string]$result.expectedExtensionRoot) -ForegroundColor Yellow}
