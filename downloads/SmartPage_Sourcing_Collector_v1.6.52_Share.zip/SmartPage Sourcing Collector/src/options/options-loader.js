(()=>{
  const started=performance.now();
  const witness={loaderStartedMs:started,firstFrameMs:0,scriptsStartedMs:0,scriptsReadyMs:0,scriptCount:0,error:''};globalThis.__SPX_OPTIONS_COLD_PAINT_V432=witness;
  const sources=['../lib/util.js','../lib/keyword-filter.js','../lib/discovery.js','../lib/explore.js','../lib/db.js','options.js'];
  const load=(src)=>new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=src;script.async=false;script.onload=()=>{witness.scriptCount++;resolve();};script.onerror=()=>reject(new Error('script load failed: '+src));document.body.appendChild(script);});
  const boot=async()=>{witness.scriptsStartedMs=performance.now();for(const src of sources)await load(src);witness.scriptsReadyMs=performance.now();};
  const start=()=>requestAnimationFrame(()=>{witness.firstFrameMs=performance.now();setTimeout(()=>{void boot().catch((error)=>{witness.error=String(error?.message||error);const el=document.getElementById('msg');if(el){el.textContent='설정 스크립트 로드 실패 · '+String(error?.message||error);el.className='bad';}});},0);});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
