/* Same-profile, incident-scoped WING recovery. Never exports browser HTTP cache.
 * Snapshot values stay in extension session storage (survives MV3 worker restarts,
 * disappears when the browser closes); losing the browser ends the live recovery.
 * A type is deletable only after its complete bounded snapshot has been persisted.
 */
(function installWingRecovery(root){
  'use strict';
  const PREFIX='spxWingRecoverySnapshotV163:';
  const LIMIT_BYTES=6*1024*1024, TIMEOUT_MS=4500;
  const RETAIN=['httpCache','serviceWorkers','fileSystems','webSQL'];
  const originOf=url=>{try{const u=new URL(url);return /^https?:$/.test(u.protocol)&&u.hostname==='wing.coupang.com'?u.origin:'';}catch(_){return '';}};
  const cookieIdentity=c=>JSON.stringify([c.storeId||'',c.domain||'',c.path||'/',c.name||'',c.partitionKey||null]);
  const wingCookie=c=>{const d=String(c.domain||'').replace(/^\./,'').toLowerCase();return d==='wing.coupang.com'||(c.hostOnly===false&&d==='coupang.com');};
  const bounded=(promise,ms=TIMEOUT_MS)=>new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(new Error('snapshot-operation-timeout')),ms);Promise.resolve(promise).then(v=>{clearTimeout(t);resolve(v);},e=>{clearTimeout(t);reject(e);});});
  const safePlan=()=>({cookies:false,origins:{},retain:[...RETAIN],warnings:[]});

  // This function is self-contained because Chrome serializes it into the page.
  async function pageOperation(action,expectedOrigin,payload={},limitBytes=6291456){
    if(location.origin!==expectedOrigin||location.hostname!=='wing.coupang.com')return {ok:false,error:'wing-origin-mismatch'};
    const retained=[],errors=[];
    const request=req=>new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(new Error('indexeddb-request-failed'));});
    const transaction=tx=>new Promise((resolve,reject)=>{tx.oncomplete=resolve;tx.onabort=tx.onerror=()=>reject(new Error('indexeddb-transaction-failed'));});
    const plain=value=>{
      if(value===null||typeof value==='string'||typeof value==='boolean')return value;
      if(typeof value==='number'&&Number.isFinite(value)&&!Object.is(value,-0))return value;
      if(Array.isArray(value)){for(let i=0;i<value.length;i++)if(!Object.prototype.hasOwnProperty.call(value,i))throw new Error('indexeddb-sparse-array-retained');return value.map(plain);}
      if(value&&typeof value==='object'&&(Object.getPrototypeOf(value)===Object.prototype||Object.getPrototypeOf(value)===null)){
        const output=Object.create(null);for(const key of Object.keys(value))output[key]=plain(value[key]);return output;
      }
      throw new Error('indexeddb-non-json-value-retained');
    };
    const sizeCheck=value=>{if(new TextEncoder().encode(JSON.stringify(value)).length>limitBytes)throw new Error('snapshot-size-limit');return value;};
    const captureStorage=storage=>{const pairs=[];for(let i=0;i<storage.length;i++){const key=storage.key(i);if(key!==null)pairs.push([key,storage.getItem(key)]);}return sizeCheck(pairs);};
    const captureDB=async()=>{
      if(typeof indexedDB?.databases!=='function')throw new Error('indexeddb-enumeration-unavailable');
      const specs=await indexedDB.databases(), databases=[];
      for(const spec of specs){
        if(!spec.name||!spec.version)throw new Error('indexeddb-schema-unavailable');
        const opening=indexedDB.open(spec.name,spec.version);
        opening.onupgradeneeded=()=>opening.transaction.abort(); // Never create while capturing.
        const db=await request(opening);
        try{
          const names=Array.from(db.objectStoreNames),stores=[];
          if(names.length){
            const tx=db.transaction(names,'readonly'),done=transaction(tx);
            const pending=names.map(async name=>{
              const store=tx.objectStore(name);
              // Auto-increment generator state cannot be exported exactly.
              if(store.autoIncrement)throw new Error('indexeddb-auto-increment-retained');
              const indexes=Array.from(store.indexNames).map(indexName=>{const i=store.index(indexName);return {name:i.name,keyPath:i.keyPath,unique:i.unique,multiEntry:i.multiEntry};});
              const keysRequest=store.getAllKeys(),valuesRequest=store.getAll();
              const [keys,values]=await Promise.all([request(keysRequest),request(valuesRequest)]);
              return {name,keyPath:store.keyPath,autoIncrement:false,indexes,keys:plain(keys),values:plain(values)};
            });
            try{stores.push(...await Promise.all(pending));await done;}catch(error){try{tx.abort();}catch(_){}await done.catch(()=>{});throw error;}
          }
          databases.push({name:db.name,version:db.version,stores});sizeCheck(databases);
        }finally{db.close();}
      }
      return databases;
    };
    const captureCaches=async()=>{
      if(!globalThis.caches?.keys)throw new Error('cache-api-unavailable');
      const result=[];
      for(const name of await caches.keys()){
        const cache=await caches.open(name),entries=[];
        for(const req of await cache.keys()){
          const response=await cache.match(req);
          if(!response)throw new Error('cache-entry-changed');
          // Opaque bodies and original URL/redirect metadata cannot be reconstructed
          // by new Response(). Retain the entire type instead of a partial backup.
          if(response.type==='opaque'||response.type==='opaqueredirect'||response.url||response.redirected||response.status===0)throw new Error('cache-response-metadata-retained');
          if(req.method!=='GET'||req.mode==='navigate'||req.destination)throw new Error('cache-request-retained');
          const body=new Uint8Array(await response.clone().arrayBuffer());
          if(body.byteLength>limitBytes)throw new Error('snapshot-size-limit');
          let binary='';for(let offset=0;offset<body.length;offset+=16384)binary+=String.fromCharCode(...body.subarray(offset,offset+16384));
          entries.push({url:req.url,requestOptions:{headers:Array.from(req.headers),mode:req.mode,credentials:req.credentials,cache:req.cache,redirect:req.redirect,referrer:req.referrer,referrerPolicy:req.referrerPolicy,integrity:req.integrity},status:response.status,statusText:response.statusText,responseHeaders:Array.from(response.headers),body:btoa(binary)});
          sizeCheck(entries);
        }
        result.push({name,entries});sizeCheck(result);
      }
      return result;
    };
    if(action==='capture'){
      const data={},canDelete={localStorage:false,sessionStorage:false,indexedDB:false,cacheStorage:false};
      for(const type of ['localStorage','sessionStorage']){
        try{data[type]=captureStorage(globalThis[type]);canDelete[type]=true;}catch(_){retained.push(type);}
      }
      if(payload.sessionOnly!==true){
        for(const [type,capture] of [['indexedDB',captureDB],['cacheStorage',captureCaches]]){
          try{data[type]=await capture();canDelete[type]=true;}catch(_){retained.push(type);}
        }
      }
      try{sizeCheck(data);}catch(_){return {ok:false,error:'snapshot-size-limit',retained:Object.keys(canDelete)};}
      return {ok:true,data,canDelete,retained};
    }
    if(action==='delete'){
      const deleted={localStorage:[],sessionStorage:[],indexedDB:[],cacheStorage:[]};
      for(const type of ['localStorage','sessionStorage']){
        if(payload.allowed?.[type]!==true)continue;
        try{for(const [key,value] of payload.data?.[type]||[]){if(globalThis[type].getItem(key)===value){globalThis[type].removeItem(key);deleted[type].push(key);}}}catch(_){errors.push(type);}
      }
      if(payload.allowed?.indexedDB===true){
        try{const current=await captureDB();for(const spec of payload.data?.indexedDB||[]){
          if(JSON.stringify(current.find(db=>db.name===spec.name))!==JSON.stringify(spec))continue;
          const deletion=indexedDB.deleteDatabase(spec.name);await request(deletion);deleted.indexedDB.push(spec.name);
        }}catch(_){errors.push('indexedDB');}
      }
      if(payload.allowed?.cacheStorage===true){
        try{const current=await captureCaches();for(const spec of payload.data?.cacheStorage||[]){
          if(JSON.stringify(current.find(cache=>cache.name===spec.name))!==JSON.stringify(spec))continue;
          if(await caches.delete(spec.name))deleted.cacheStorage.push(spec.name);
        }}catch(_){errors.push('cacheStorage');}
      }
      return {ok:errors.length===0,deleted,errors};
    }
    if(action!=='restore')return {ok:false,error:'unknown-operation'};
    const restored={localStorage:0,sessionStorage:0,indexedDB:0,cacheStorage:0},skipped={localStorage:0,sessionStorage:0,indexedDB:0,cacheStorage:0};
    for(const type of ['localStorage','sessionStorage']){
      if(payload.deleted?.[type]!==true&&!Array.isArray(payload.deleted?.[type]))continue;
      try{for(const [key,value] of payload.data?.[type]||[]){if(Array.isArray(payload.deleted[type])&&!payload.deleted[type].includes(key))continue;if(globalThis[type].getItem(key)===null){globalThis[type].setItem(key,value);restored[type]++;}else skipped[type]++;}}catch(_){errors.push(type);}
    }
    if(payload.deleted?.indexedDB===true||Array.isArray(payload.deleted?.indexedDB)){
      try{
        if(typeof indexedDB?.databases!=='function')throw new Error('indexeddb-enumeration-unavailable');
        for(const spec of payload.data?.indexedDB||[]){
          if(Array.isArray(payload.deleted.indexedDB)&&!payload.deleted.indexedDB.includes(spec.name))continue;
          if((await indexedDB.databases()).some(db=>db.name===spec.name)){skipped.indexedDB++;continue;}
          const opening=indexedDB.open(spec.name,spec.version);let created=false;
          opening.onupgradeneeded=event=>{
            if(event.oldVersion!==0){opening.transaction.abort();return;}
            created=true;
            for(const s of spec.stores){const store=opening.result.createObjectStore(s.name,{keyPath:s.keyPath,autoIncrement:false});for(const i of s.indexes)store.createIndex(i.name,i.keyPath,{unique:i.unique,multiEntry:i.multiEntry});
              // Populate in the exclusive creation transaction, before any page can regenerate rows.
              for(let n=0;n<s.values.length;n++){if(s.keyPath===null)store.add(s.values[n],s.keys[n]);else store.add(s.values[n]);}
            }
          };
          let db;try{db=await request(opening);}catch(_){errors.push('indexedDB');continue;}
          db.close();if(created)restored.indexedDB++;else skipped.indexedDB++;
        }
      }catch(_){errors.push('indexedDB');}
    }
    if(payload.deleted?.cacheStorage===true||Array.isArray(payload.deleted?.cacheStorage)){
      try{for(const saved of payload.data?.cacheStorage||[]){
        if(Array.isArray(payload.deleted.cacheStorage)&&!payload.deleted.cacheStorage.includes(saved.name))continue;
        if((await caches.keys()).includes(saved.name)){skipped.cacheStorage++;continue;}
        const cache=await caches.open(saved.name);
        for(const e of saved.entries){const req=new Request(e.url,e.requestOptions);if(await cache.match(req)){skipped.cacheStorage++;continue;}
          const bytes=Uint8Array.from(atob(e.body),c=>c.charCodeAt(0));await cache.put(req,new Response([204,205,304].includes(e.status)?null:bytes,{status:e.status,statusText:e.statusText,headers:e.responseHeaders}));restored.cacheStorage++;
        }
      }}catch(_){errors.push('cacheStorage');}
    }
    return {ok:errors.length===0,restored,skipped,errors};
  }

  async function snapshotBeforeCleanup({incidentId,deleteWingData=false}={}){
    const plan=safePlan();
    if(deleteWingData!==true)return {snapshotId:null,plan,disabled:true};
    // Session storage keeps live cookies out of durable profile exports. Never fall
    // back to page storage, disk files, synced storage or a different profile.
    if(!root.chrome?.storage?.session||!root.chrome?.scripting?.executeScript){plan.warnings.push('snapshot-storage-or-scripting-unavailable');return {snapshotId:null,plan};}
    const snapshotId=PREFIX+String(incidentId||crypto.randomUUID());
    const snapshot={version:1,createdAt:Date.now(),cookies:[],origins:{},tabs:[],plan};
    try{
      if(root.chrome.cookies?.getAll){snapshot.cookies=(await bounded(root.chrome.cookies.getAll({domain:'coupang.com'}))).filter(wingCookie);plan.cookies=true;}
      else plan.warnings.push('cookies-api-unavailable');
    }catch(_){plan.warnings.push('cookie-snapshot-failed');}
    try{
      const tabs=await bounded(root.chrome.tabs.query({url:['https://wing.coupang.com/*','http://wing.coupang.com/*']}));
      const seen=new Set();
      for(const tab of tabs){
        const origin=originOf(tab.url);if(!origin||!Number.isInteger(tab.id))continue;
        try{
          const first=!seen.has(origin),reply=await bounded(root.chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:false},world:'MAIN',func:pageOperation,args:['capture',origin,{sessionOnly:!first},LIMIT_BYTES]}));
          const value=reply?.[0]?.result;if(value?.ok!==true)throw new Error('capture-failed');
          snapshot.tabs.push({tabId:tab.id,origin,sessionStorage:value.data.sessionStorage||[]});
          if(first){snapshot.origins[origin]={...value.data};delete snapshot.origins[origin].sessionStorage;plan.origins[origin]={...value.canDelete};seen.add(origin);}
          else plan.origins[origin].sessionStorage=plan.origins[origin].sessionStorage&&value.canDelete.sessionStorage===true;
          if(value.retained?.length)plan.warnings.push(...value.retained.map(type=>origin+':'+type+'-retained'));
        }catch(_){
          // An inaccessible tab may contain unique session data. Preserve this
          // origin, including data also visible through another WING tab.
          plan.origins[origin]={localStorage:false,sessionStorage:false,indexedDB:false,cacheStorage:false};seen.add(origin);plan.warnings.push(origin+':capture-failed-retained');
        }
      }
      if(!tabs.length)plan.warnings.push('no-existing-wing-tab-origin-retained');
      if(new TextEncoder().encode(JSON.stringify(snapshot)).length>LIMIT_BYTES)throw new Error('snapshot-size-limit');
      await bounded(root.chrome.storage.session.set({[snapshotId]:snapshot}));
      return {snapshotId,plan};
    }catch(_){await root.chrome.storage.session.remove(snapshotId).catch(()=>{});const retained=safePlan();retained.warnings.push('complete-snapshot-unavailable-all-wing-data-retained');return {snapshotId:null,plan:retained};}
  }

  async function cleanupBackedUpData({snapshotId}={}){
    const result={ok:true,deleted:{cookies:[],origins:{},tabs:{}},errors:[]};
    if(!snapshotId)return result;
    const saved=(await bounded(root.chrome.storage.session.get(snapshotId)))?.[snapshotId];
    if(!saved)return {ok:false,deleted:result.deleted,errors:['snapshot-unavailable']};
    if(saved.cleanupFinished===true)return {ok:true,deleted:saved.deleted||result.deleted,alreadyCompleted:true};
    if(saved.cleanupStarted===true)return {ok:false,deleted:saved.deleted||result.deleted,errors:['cleanup-interrupted']};
    saved.cleanupStarted=true;saved.deleted=result.deleted;
    const persist=()=>bounded(root.chrome.storage.session.set({[snapshotId]:saved}));
    await persist();
    const cleanedOrigins=new Set();
    for(const tab of saved.tabs){
      try{
        const current=await bounded(root.chrome.tabs.get(tab.tabId));if(originOf(current.url)!==tab.origin)continue;
        const allowed={...(saved.plan.origins[tab.origin]||{})};if(cleanedOrigins.has(tab.origin)){allowed.localStorage=false;allowed.indexedDB=false;allowed.cacheStorage=false;}
        const data={...(saved.origins[tab.origin]||{}),sessionStorage:tab.sessionStorage};
        const reply=await bounded(root.chrome.scripting.executeScript({target:{tabId:tab.tabId,allFrames:false},world:'MAIN',func:pageOperation,args:['delete',tab.origin,{data,allowed},LIMIT_BYTES]}));
        const value=reply?.[0]?.result;if(!value?.deleted)throw new Error('cleanup-result-missing');
        const receipt=result.deleted.origins[tab.origin]||{};for(const [type,removed] of Object.entries(value.deleted)){if(type!=='sessionStorage')receipt[type]=[...new Set([...(receipt[type]||[]),...(removed||[])])];}
        result.deleted.tabs[tab.tabId]={sessionStorage:value.deleted.sessionStorage||[]};
        result.deleted.origins[tab.origin]=receipt;await persist();cleanedOrigins.add(tab.origin);
        if(value.ok!==true)result.errors.push('wing-origin-cleanup-incomplete');
      }catch(_){result.errors.push('wing-origin-cleanup-failed');}
    }
    if(saved.plan.cookies===true){
      for(const cookie of saved.cookies.filter(wingCookie)){
        try{
          const current=(await bounded(root.chrome.cookies.getAll({domain:'coupang.com'}))).find(c=>cookieIdentity(c)===cookieIdentity(cookie));
          if(!current||current.value!==cookie.value||current.expirationDate!==cookie.expirationDate)continue;
          const url=`${cookie.secure?'https':'http'}://${String(cookie.domain).replace(/^\./,'')}${cookie.path||'/'}`;
          const details={url,name:cookie.name,storeId:cookie.storeId};if(cookie.partitionKey)details.partitionKey=cookie.partitionKey;
          if(await bounded(root.chrome.cookies.remove(details))){result.deleted.cookies.push(cookieIdentity(cookie));await persist();}
          else result.errors.push('wing-cookie-cleanup-incomplete');
        }catch(_){result.errors.push('wing-cookie-cleanup-failed');}
      }
    }
    result.ok=result.errors.length===0;saved.cleanupFinished=result.ok;await persist();return result;
  }
  async function restoreAfterVerified({snapshotId,normalConfirmed=false,deleted}={}){
    if(normalConfirmed!==true)return {ok:false,deferred:true,reason:'normal-page-not-verified'};
    if(!snapshotId)return {ok:true,skipped:true,reason:'no-deletion-snapshot'};
    if(!String(snapshotId).startsWith(PREFIX))return {ok:false,reason:'invalid-snapshot-id'};
    const saved=(await bounded(root.chrome.storage.session.get(snapshotId)))?.[snapshotId];
    if(!saved)return {ok:false,reason:'snapshot-unavailable'};
    if(saved.cleanupStarted===true&&saved.cleanupFinished!==true)return {ok:false,reason:'cleanup-interrupted'};
    deleted=deleted||saved.deleted||{};
    const result={ok:true,cookiesRestored:0,cookiesSkipped:0,origins:[],errors:[],retained:[...RETAIN]};
    if(saved.plan.cookies===true&&(deleted.cookies===true||Array.isArray(deleted.cookies))){
      try{
        for(const cookie of saved.cookies.filter(wingCookie)){
          const identity=cookieIdentity(cookie);
          if(Array.isArray(deleted.cookies)&&!deleted.cookies.includes(identity))continue;
          if(cookie.expirationDate&&cookie.expirationDate<=Date.now()/1000){result.cookiesSkipped++;continue;}
          const current=(await bounded(root.chrome.cookies.getAll({domain:'coupang.com'}))).filter(wingCookie);
          if(current.some(value=>cookieIdentity(value)===identity)){result.cookiesSkipped++;continue;}
          const url=`${cookie.secure?'https':'http'}://${String(cookie.domain).replace(/^\./,'')}${cookie.path||'/'}`;
          const details={url,name:cookie.name,value:cookie.value,path:cookie.path||'/',secure:cookie.secure===true,httpOnly:cookie.httpOnly===true,storeId:cookie.storeId};
          if(cookie.hostOnly===false)details.domain=cookie.domain;
          if(cookie.sameSite)details.sameSite=cookie.sameSite;
          if(cookie.expirationDate)details.expirationDate=cookie.expirationDate;
          if(cookie.partitionKey)details.partitionKey=cookie.partitionKey;
          if(await bounded(root.chrome.cookies.set(details)))result.cookiesRestored++;else result.errors.push('cookie-restore-failed');
        }
      }catch(_){result.errors.push('cookie-restore-failed');}
    }
    const restoredOrigins=new Set();
    for(const tab of saved.tabs){
      const originReceipt=deleted.origins?.[tab.origin],tabReceipt=deleted.tabs?.[tab.tabId];if(!originReceipt&&!tabReceipt)continue;
      const requested={...(originReceipt||{}),...(tabReceipt||{})};
      if(!Object.values(requested).some(value=>value===true||(Array.isArray(value)&&value.length)))continue;
      try{
        const current=await bounded(root.chrome.tabs.get(tab.tabId));if(originOf(current.url)!==tab.origin){result.errors.push('wing-tab-missing-or-navigated');continue;}
        const allowed=saved.plan.origins[tab.origin]||{},types={};for(const type of ['localStorage','sessionStorage','indexedDB','cacheStorage'])types[type]=allowed[type]===true&&(type==='sessionStorage'||!restoredOrigins.has(tab.origin))?(requested[type]||false):false;
        const data={...(saved.origins[tab.origin]||{}),sessionStorage:tab.sessionStorage};
        const reply=await bounded(root.chrome.scripting.executeScript({target:{tabId:tab.tabId,allFrames:false},world:'MAIN',func:pageOperation,args:['restore',tab.origin,{data,deleted:types},LIMIT_BYTES]}));
        const value=reply?.[0]?.result;if(value?.ok!==true){result.errors.push('wing-origin-restore-incomplete');continue;}
        restoredOrigins.add(tab.origin);result.origins.push({origin:tab.origin,tabId:tab.tabId,restored:value.restored,skipped:value.skipped});
      }catch(_){result.errors.push('wing-origin-restore-failed');}
    }
    result.ok=result.errors.length===0;
    if(result.ok)await bounded(root.chrome.storage.session.remove(snapshotId));
    return result;
  }
  root.SPXWingRecovery=Object.freeze({snapshotBeforeCleanup,cleanupBackedUpData,restoreAfterVerified,cookieIdentity,isWingCookie:wingCookie});
})(globalThis);
