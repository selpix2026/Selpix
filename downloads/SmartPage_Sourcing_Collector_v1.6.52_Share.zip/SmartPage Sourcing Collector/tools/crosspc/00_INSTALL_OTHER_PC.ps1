﻿param(
  [switch]$Elevated,
  [ValidateSet('','chrome','whale')][string]$BrowserFamily=''
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2
try{
  $utf8=New-Object System.Text.UTF8Encoding($false)
  [Console]::InputEncoding=$utf8
  [Console]::OutputEncoding=$utf8
  $OutputEncoding=$utf8
}catch{}

$ExtensionId='olmpllofoggohefbdkgkjjnlanfnaocd'
$SourceRoot=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$ManifestPath=Join-Path $SourceRoot 'manifest.json'
if(-not(Test-Path -LiteralPath $ManifestPath -PathType Leaf)){throw '설치 패키지 manifest.json을 찾지 못했습니다.'}
try{
  $Manifest=Get-Content -LiteralPath $ManifestPath -Raw -Encoding UTF8|ConvertFrom-Json
}catch{
  throw ('manifest.json 읽기 실패: '+$_.Exception.Message)
}
$Version=[string]$Manifest.version
if([string]::IsNullOrWhiteSpace($Version)){throw 'manifest.json version 값이 없습니다.'}
$VersionName=[string]$Manifest.version_name
if((-not [string]::IsNullOrWhiteSpace($VersionName)) -and $VersionName -ne $Version){throw ('manifest version/version_name 불일치: '+$Version+' / '+$VersionName)}
$VersionSafe=($Version -replace '[^0-9A-Za-z._-]','_')
$TargetRoot=Join-Path $env:ProgramData 'SmartPageEx\SmartPage Sourcing Collector'
$NetworkSource=Join-Path $TargetRoot 'tools\network-host'
$NetworkInstaller=Join-Path $NetworkSource 'install-network-host.ps1'
$InstallReport=Join-Path $env:ProgramData ('SmartPageEx\crosspc-install-v'+$VersionSafe+'.json')

function Test-Admin{
  $id=[Security.Principal.WindowsIdentity]::GetCurrent()
  $p=New-Object Security.Principal.WindowsPrincipal($id)
  return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Write-JsonUtf8([string]$Path,$Value){
  $parent=Split-Path -Parent $Path
  if($parent -and -not(Test-Path -LiteralPath $parent)){New-Item -ItemType Directory -Path $parent -Force|Out-Null}
  [IO.File]::WriteAllText($Path,($Value|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
}
function Copy-Tree([string]$Source,[string]$Destination){
  if(Test-Path -LiteralPath $Destination){Remove-Item -LiteralPath $Destination -Recurse -Force}
  New-Item -ItemType Directory -Path $Destination -Force|Out-Null
  foreach($item in @(Get-ChildItem -LiteralPath $Source -Force -ErrorAction Stop)){
    Copy-Item -LiteralPath $item.FullName -Destination $Destination -Recurse -Force
  }
}
function Find-NormalChromePath{
  # NORMAL_CHROME_V1514: SmartPage dedicated window uses the user's installed Google Chrome.
  # The dedicated profile remains completely separate at C:\SpxDedicatedProfile.
  $candidates=New-Object System.Collections.Generic.List[string]
  foreach($key in @(
    'HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',
    'HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',
    'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe'
  )){
    try{$value=[string](Get-Item -LiteralPath $key -ErrorAction Stop).GetValue('');if(-not[string]::IsNullOrWhiteSpace($value)){$candidates.Add($value)}}catch{}
  }
  foreach($candidate in @(
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
    $(if(${env:ProgramFiles(x86)}){Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'}else{$null})
  )){if(-not[string]::IsNullOrWhiteSpace([string]$candidate)){$candidates.Add([string]$candidate)}}
  try{$cmd=Get-Command chrome.exe -ErrorAction Stop;if($cmd.Source){$candidates.Add([string]$cmd.Source)}}catch{}
  foreach($candidate in $candidates){
    try{if(Test-Path -LiteralPath $candidate -PathType Leaf){return [IO.Path]::GetFullPath($candidate)}}catch{}
  }
  return $null
}
# SMARTPAGE_CFT_REMAINDER_CLEANUP_V1514: remove only the browser copy previously installed under SmartPageEx.
function Remove-SmartPageChromeForTestingV1514{
  $ownedRoot=Join-Path $env:ProgramData 'SmartPageEx\ChromeForTesting'
  if(-not(Test-Path -LiteralPath $ownedRoot)){return $false}
  try{
    $dedicated='C:\SpxDedicatedProfile'
    $targets=@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe' OR Name='whale.exe'" -ErrorAction SilentlyContinue|Where-Object{
      -not[string]::IsNullOrWhiteSpace([string]$_.CommandLine) -and [string]$_.CommandLine -like ('*'+$dedicated+'*') -and [string]$_.CommandLine -like ('*SmartPageEx*ChromeForTesting*')
    })
    foreach($proc in $targets){try{Stop-Process -Id ([int]$proc.ProcessId) -Force -ErrorAction Stop}catch{}}
    if($targets.Count){Start-Sleep -Milliseconds 700}
    Remove-Item -LiteralPath $ownedRoot -Recurse -Force -ErrorAction Stop
    Write-Host '이전 SmartPage 테스트용 Chrome 설치 흔적을 정리했습니다. 전용 프로필/WING 데이터는 그대로 유지합니다.' -ForegroundColor Yellow
    return $true
  }catch{
    Write-Host ('이전 테스트용 Chrome 자동 정리 보류 · '+$_.Exception.Message+' · 필요하면 RUN_07_REPAIR_RESTORE_NORMAL_CHROME.cmd를 실행하세요.') -ForegroundColor DarkYellow
    return $false
  }
}


# Stop only the isolated SmartPage Chrome profile before replacing unpacked extension files.
# Personal/default Chrome profiles are never touched.
function Stop-SmartPageDedicatedChromeForUpdateV1518{
  $dedicated='C:\SpxDedicatedProfile'
  try{
    $targets=@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe' OR Name='whale.exe'" -ErrorAction SilentlyContinue|Where-Object{
      $cmd=[string]$_.CommandLine
      -not[string]::IsNullOrWhiteSpace($cmd) -and $cmd -match '(?i)(?:^|\s)--user-data-dir=(?:"C:\\SpxDedicatedProfile(?:-Whale)?"|C:\\SpxDedicatedProfile(?:-Whale)?)(?:\s|$)'
    })
    foreach($proc in $targets){try{Stop-Process -Id ([int]$proc.ProcessId) -Force -ErrorAction Stop}catch{}}
    if($targets.Count){Start-Sleep -Milliseconds 900;Write-Host ('업데이트 전 SmartPage 전용 Chrome '+$targets.Count+'개 종료 · 개인 Chrome은 유지') -ForegroundColor DarkYellow}
    return $targets.Count
  }catch{
    Write-Host ('SmartPage 전용 Chrome 종료 확인 경고 · '+$_.Exception.Message) -ForegroundColor DarkYellow
    return 0
  }
}

function New-Shortcut([string]$Name,[string]$Command){
  try{
    $desktop=[Environment]::GetFolderPath('Desktop')
    if([string]::IsNullOrWhiteSpace($desktop)){return}
    $shell=New-Object -ComObject WScript.Shell
    $lnk=$shell.CreateShortcut((Join-Path $desktop $Name))
    $lnk.TargetPath=$Command
    $lnk.Arguments=''
    $lnk.WorkingDirectory=$TargetRoot
    $chrome=Find-NormalChromePath
    if($chrome){$lnk.IconLocation=$chrome+',0'}
    $lnk.Save()
  }catch{Write-Host ('바로가기 생성 경고: '+$_.Exception.Message) -ForegroundColor DarkYellow}
}


# v1.6.5: Windows default Internet is OS-managed. Installer never pins Wi-Fi/Ethernet metrics.

if(-not(Test-Admin)){
  $args='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath.Replace('"','""')+'" -Elevated'
  if($BrowserFamily){$args+=' -BrowserFamily '+$BrowserFamily}
  $p=Start-Process "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Verb RunAs -ArgumentList $args -Wait -PassThru
  exit $p.ExitCode
}

Write-Host '============================================================' -ForegroundColor Cyan
Write-Host (' SmartPage Sourcing Collector '+$Version+' - 다른 PC 통합 설치') -ForegroundColor Green
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host ('Source='+$SourceRoot)
Write-Host ('Target='+$TargetRoot)

# Version source of truth is manifest.json loaded above.
# No hard-coded Collector version is used by this installer.

# Clean source installation with rollback of only the prior source tree.
# SPX_UPDATE_RUNTIME_ALIGNMENT_V1518: old dedicated-profile Chrome must not keep the previous unpacked service worker alive.
$stoppedDedicatedChrome=Stop-SmartPageDedicatedChromeForUpdateV1518
if(-not([IO.Path]::GetFullPath($SourceRoot).TrimEnd('\') -eq [IO.Path]::GetFullPath($TargetRoot).TrimEnd('\'))){
  if(Test-Path -LiteralPath $TargetRoot){
    $backupBase=Join-Path $env:ProgramData 'SmartPageEx\CollectorSourceBackup'
    New-Item -ItemType Directory -Path $backupBase -Force|Out-Null
    $backup=Join-Path $backupBase ('before-install-v'+$VersionSafe+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
    Move-Item -LiteralPath $TargetRoot -Destination $backup -Force
    Write-Host ('Previous source backup='+$backup) -ForegroundColor DarkYellow
  }
  Copy-Tree -Source $SourceRoot -Destination $TargetRoot
}

$installedManifestPath=Join-Path $TargetRoot 'manifest.json'
if(-not(Test-Path -LiteralPath $installedManifestPath -PathType Leaf)){throw '설치 대상 manifest.json 복사 확인 실패'}
$installedManifest=Get-Content -LiteralPath $installedManifestPath -Raw -Encoding UTF8|ConvertFrom-Json
if([string]$installedManifest.version -ne $Version){throw ('설치 대상 버전 검증 실패: expected '+$Version+' / actual '+[string]$installedManifest.version)}
Write-Host ('Package version verified from manifest: '+$Version) -ForegroundColor Green

. (Join-Path $PSScriptRoot 'browser-launch-common.ps1')
$InstallBrowserFamily=Resolve-SpxBrowserFamily $BrowserFamily
$NormalChromeExe=Find-SpxInstalledBrowser $InstallBrowserFamily
if([string]::IsNullOrWhiteSpace($NormalChromeExe)){throw '선택한 Chrome 또는 Whale을 찾지 못했습니다. 브라우저를 설치한 뒤 다시 실행하세요.'}
Write-Host ('일반 Google Chrome 확인: '+$NormalChromeExe) -ForegroundColor Green
$oldTestChromeRemoved=Remove-SmartPageChromeForTestingV1514

if(-not(Test-Path -LiteralPath $NetworkInstaller -PathType Leaf)){throw 'NetworkHost installer가 패키지에 없습니다.'}
Write-Host 'NetworkHostV33 설치/등록 중...' -ForegroundColor Cyan
& "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $NetworkInstaller -Elevated -ExtensionId $ExtensionId -ExtensionRootOverride $TargetRoot
$networkRc=$LASTEXITCODE
if($networkRc -ne 0){throw ('NetworkHost 설치 실패. ExitCode='+$networkRc)}

# NORMAL_CHROME_LAUNCHER_REFRESH_V1516: refresh only the browser support plane.
# This does not alter the v1.5.6 mobile/IP recovery scripts or Helper 3.0.33 core.
$refreshLauncher=Join-Path $TargetRoot 'tools\crosspc\09_REFRESH_NORMAL_CHROME_LAUNCHER.ps1'
if(-not(Test-Path -LiteralPath $refreshLauncher -PathType Leaf)){throw '일반 Chrome launcher 복구 도구가 없습니다.'}
& "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $refreshLauncher -Elevated -Quiet
$refreshRc=$LASTEXITCODE
if($refreshRc -ne 0){throw ('일반 Chrome launcher 복구 실패. ExitCode='+$refreshRc)}
Write-Host '일반 Chrome 전용창 launcher 정리 완료 · 구형 --load-extension 경로 사용 안 함' -ForegroundColor Green

$baseNetworkAutoPinned=$false # legacy report field only; v1.6.5 never pins the Windows default Internet.


# NORMAL_CHROME_EXTENSION_GATE_V1516: Chrome 137+ ignores --load-extension in branded Chrome.
# Register the unpacked Collector once in the isolated normal-Chrome profile and verify it before install completes.
$registerScript=Join-Path $TargetRoot 'tools\crosspc\08_REGISTER_COLLECTOR_NORMAL_CHROME.ps1'
if(-not(Test-Path -LiteralPath $registerScript -PathType Leaf)){throw '일반 Chrome 전용 프로필 확장 등록 도구가 없습니다.'}
Write-Host ''
Write-Host 'Collector 확장 등록 확인 중 · WING 로그인과는 별개입니다.' -ForegroundColor Cyan
& "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $registerScript -InstallGate -BrowserFamily $InstallBrowserFamily
$registerRc=$LASTEXITCODE
if($registerRc -ne 0){throw ('Collector 전용 프로필 확장 등록이 완료되지 않았습니다. ExitCode='+$registerRc+' · RUN_08_REGISTER_COLLECTOR_NORMAL_CHROME.cmd로 이어서 완료하세요.')}
Write-Host 'Collector 확장 등록 확인 완료 · 설치 후 RUN_02_OPEN_COLLECTOR.cmd로 바로 실행할 수 있습니다.' -ForegroundColor Green

# Optional portable API integration settings. WING Chrome session is never imported cross-PC.
$portableSecrets=Join-Path $TargetRoot 'integration-secrets.json'
if(-not(Test-Path -LiteralPath $portableSecrets -PathType Leaf)){$portableSecrets=Join-Path $TargetRoot 'PORTABLE_CONFIG\integration-secrets.json'}
$installedSecrets=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33\integration-secrets.json'
$portableSettingsImported=$false
if(Test-Path -LiteralPath $portableSecrets -PathType Leaf){
  try{
    $null=Get-Content -LiteralPath $portableSecrets -Raw -Encoding UTF8|ConvertFrom-Json
    Copy-Item -LiteralPath $portableSecrets -Destination $installedSecrets -Force
    $portableSettingsImported=$true
    Write-Host ('Portable integration settings imported: '+$installedSecrets) -ForegroundColor Green
  }catch{throw ('PORTABLE_CONFIG\integration-secrets.json 적용 실패: '+$_.Exception.Message)}
}else{
  Write-Host 'PORTABLE_CONFIG 연동설정 없음 · 새 PC에서 필요하면 설정 화면에서 ID/Key를 입력하세요.' -ForegroundColor DarkYellow
}

$launcher=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33\open-dedicated-window.ps1'
if(-not(Test-Path -LiteralPath $launcher -PathType Leaf)){throw 'NetworkHost 전용창 launcher가 설치되지 않았습니다.'}
$launcherText=Get-Content -LiteralPath $launcher -Raw -Encoding UTF8
if($launcherText -notmatch 'NORMAL_CHROME_V1514'){
  throw '설치된 전용창 launcher가 일반 Google Chrome 전용프로필 구성과 일치하지 않습니다.'
}

# Desktop shortcuts.
$openCmd=Join-Path $TargetRoot 'RUN_02_OPEN_COLLECTOR.cmd'
$wingCmd=Join-Path $TargetRoot 'RUN_03_WING_SESSION_MANAGER.cmd'
New-Shortcut -Name 'SmartPage Collector 전용창.lnk' -Command $openCmd
New-Shortcut -Name 'SmartPage WING 로그인 관리.lnk' -Command $wingCmd

$report=[ordered]@{
  ok=$true;version=$Version;extensionId=$ExtensionId;collectorRoot=$TargetRoot;normalChromeExe=$NormalChromeExe
  networkHost='C:\ProgramData\SmartPageEx\NetworkHostV33';dedicatedProfile='C:\SpxDedicatedProfile'
  installedAt=(Get-Date).ToString('o');windowsUser=$env:USERNAME;computerName=$env:COMPUTERNAME
  wingPortableLogin=$false;wingLoginRequiredForInstall=$false;wingSetupSeparate=$true;extensionRegistrationRequiredForInstall=$true;extensionRegistrationVerified=$true;oldSmartPageTestChromeRemoved=$oldTestChromeRemoved;dedicatedChromeStoppedBeforeUpdate=$stoppedDedicatedChrome;baseNetworkAutoPinned=$baseNetworkAutoPinned;portableIntegrationSettingsImported=$portableSettingsImported
}
Write-JsonUtf8 $InstallReport $report

Write-Host ''
Write-Host 'INSTALL CORE PASS' -ForegroundColor Green
Write-Host ('Collector='+$TargetRoot)
Write-Host ('GoogleChrome='+$NormalChromeExe)
Write-Host 'DedicatedProfile=C:\SpxDedicatedProfile'
Write-Host '설치 완료 · Collector 확장 등록까지 확인했습니다. WING 로그인은 설치 완료 조건과 별개입니다.' -ForegroundColor Green
Write-Host 'WING이 필요할 때만 RUN_01_FIRST_RUN_WING_LOGIN.cmd를 별도로 실행하세요.' -ForegroundColor Cyan

Write-Host ''
Write-Host 'FINAL=CROSS_PC_INSTALL_PASS' -ForegroundColor Green
exit 0
