현재 PC에서 만든 WING 로그인 백업은 Windows/Chrome 암호화에 묶여 있으므로 다른 PC에 배포하지 않습니다.
새 PC에서는 최초 1회 WING 로그인 후 RUN_01_FIRST_RUN_WING_LOGIN.cmd가 그 PC 전용 최소 백업을 생성합니다.
