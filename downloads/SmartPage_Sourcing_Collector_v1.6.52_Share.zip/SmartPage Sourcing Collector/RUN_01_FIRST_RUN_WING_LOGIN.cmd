@echo off
chcp 65001 >nul
setlocal
title SmartPage WING First Login Setup
set "PS=%~dp0tools\crosspc\01_FIRST_RUN_WING_SETUP.ps1"
if not exist "%PS%" (
  echo [ERROR] WING setup PowerShell file not found.
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS%"
set "RC=%ERRORLEVEL%"
echo.
echo ExitCode=%RC%
pause
exit /b %RC%
