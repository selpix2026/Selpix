@echo off
chcp 65001 >nul
setlocal
set "PS=%~dp0tools\crosspc\03_VERIFY_INSTALL.ps1"
if not exist "%PS%" (
  echo [ERROR] Verify PowerShell file not found.
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS%"
set "RC=%ERRORLEVEL%"
echo.
echo ExitCode=%RC%
pause
exit /b %RC%
