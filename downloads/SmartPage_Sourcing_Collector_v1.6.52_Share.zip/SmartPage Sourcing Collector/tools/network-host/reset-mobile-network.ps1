﻿param(
  [string]$DeviceSerial = '',
  [string]$AdbPath = '',
  [string]$AdbVendorKeysPath = '',
  [ValidateRange(4,300)][int]$AirplaneHoldSeconds = 20,
  [ValidateRange(15,180)][int]$ReconnectTimeoutSeconds = 75,
  [ValidateSet('','status','on','off','toggle')][string]$AirplaneOnly = '',
  [switch]$ForceDisableOnly,
  [switch]$ForceMobileDataCycle
)

$ErrorActionPreference = 'Stop'
try {
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  [Console]::InputEncoding = $utf8
  [Console]::OutputEncoding = $utf8
  $OutputEncoding = $utf8
} catch { }
$startedAt = (Get-Date).ToUniversalTime()
$result = [ordered]@{
  ok = $false
  completed = $false
  command = 'reset_mobile_network'
  scriptVersion = '3.0.26.0'
  startedAt = $startedAt.ToString('o')
  finishedAt = $null
  durationMs = 0
  deviceReady = $false
  adbReady = $false
  adbPath = ''
  adbVendorKeysPath = ''
  deviceSerial = ''
  airplaneModeVerified = $false
  airplaneHoldSeconds = $AirplaneHoldSeconds
  reconnectTimeoutSeconds = $ReconnectTimeoutSeconds
  initialUsbFunctions = ''
  usbFunctions = ''
  usbTetheringRestored = $null
  mobileDataCycleAttempted = $false
  mobileDataCycleCompleted = $false
  wifiInitiallyEnabled = $null
  wifiDisableAttempted = $false
  wifiDisabledVerified = $false
  wifiRecheckDisabled = $false
  message = ''
  error = ''
}
$script:AdbPath = ''
$script:SelectedSerial = ''
$airplaneEnableAttempted = $false
$script:ResetStatePath = Join-Path $PSScriptRoot 'mobile-reset-state.json'

function Write-ResetPhase([string]$Phase,[string]$Label,[object]$HoldUntil=$null,[string]$ErrorText='') {
  if (-not [string]::IsNullOrWhiteSpace($AirplaneOnly)) { return }
  try {
    $now = (Get-Date).ToUniversalTime()
    $initialPublicIp = ''
    try {
      if (Test-Path -LiteralPath $script:ResetStatePath -PathType Leaf) {
        $existing = Get-Content -LiteralPath $script:ResetStatePath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($existing -and $existing.initialPublicIp) { $initialPublicIp = [string]$existing.initialPublicIp }
      }
    } catch { }
    $failed = $Phase -eq 'failed'
    $state = [ordered]@{
      status = if ($failed) { 'failed' } else { 'running' }
      running = (-not $failed)
      inProgress = (-not $failed)
      completed = $failed
      resetOk = $false
      phase = $Phase
      phaseLabel = $Label
      startedAt = $startedAt.ToString('o')
      phaseStartedAt = $now.ToString('o')
      updatedAt = $now.ToString('o')
      heartbeatAt = $now.ToString('o')
      initialPublicIp = $initialPublicIp
      airplaneHoldSeconds = $AirplaneHoldSeconds
      holdUntil = if ($null -ne $HoldUntil) { ([datetime]$HoldUntil).ToUniversalTime().ToString('o') } else { '' }
      deviceSerial = [string]$script:SelectedSerial
      lastError = $ErrorText
      scriptVersion = '3.0.26.0'
    }
    [IO.File]::WriteAllText($script:ResetStatePath,($state | ConvertTo-Json -Depth 5 -Compress),(New-Object Text.UTF8Encoding($false)))
  } catch { }
}

function Read-NetworkHostConfig {
  $configPath = Join-Path $PSScriptRoot 'network-host-config.json'
  if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) { return $null }
  try { return (Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { return $null }
}

function Find-AdbPath {
  $config = Read-NetworkHostConfig
  $candidates = New-Object System.Collections.Generic.List[string]
  if (-not [string]::IsNullOrWhiteSpace($AdbPath)) { $candidates.Add($AdbPath) }
  if ($config -and -not [string]::IsNullOrWhiteSpace([string]$config.adbPath)) { $candidates.Add([string]$config.adbPath) }
  if (-not [string]::IsNullOrWhiteSpace($env:SPX_ADB_PATH)) { $candidates.Add($env:SPX_ADB_PATH) }
  $candidates.Add((Join-Path $PSScriptRoot 'platform-tools\adb.exe'))
  $candidates.Add((Join-Path $PSScriptRoot 'adb.exe'))
  if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) { $candidates.Add((Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe')) }
  if (-not [string]::IsNullOrWhiteSpace($env:ProgramFiles)) { $candidates.Add((Join-Path $env:ProgramFiles 'Android\android-sdk\platform-tools\adb.exe')) }
  foreach ($candidate in $candidates) {
    if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
      return [IO.Path]::GetFullPath($candidate)
    }
  }
  $command = Get-Command adb.exe -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($command -and $command.Source) { return [string]$command.Source }
  return ''
}

function Initialize-AdbEnvironment {
  $config = Read-NetworkHostConfig
  $configured = $AdbVendorKeysPath
  if ([string]::IsNullOrWhiteSpace($configured) -and $config) { $configured = [string]$config.adbVendorKeysPath }
  # PowerShell의 자동 변수 $HOME은 읽기 전용입니다. 대소문자를 구분하지 않으므로
  # 로컬 변수 $home도 같은 변수로 취급됩니다. 전용 이름을 사용해야 합니다.
  $adbHomeDir = Join-Path $PSScriptRoot 'adb-home'
  $androidDir = Join-Path $adbHomeDir '.android'
  $keyPath = Join-Path $androidDir 'adbkey'
  $publicKeyPath = $keyPath + '.pub'
  New-Item -ItemType Directory -Path $androidDir -Force | Out-Null

  # v3.0.8.12에서 adbkey를 폴더로 잘못 만든 흔적을 자동 삭제합니다.
  foreach ($collision in @($keyPath,$publicKeyPath,(Join-Path $PSScriptRoot 'adb-keys\adbkey'))) {
    if (Test-Path -LiteralPath $collision -PathType Container) { Remove-Item -LiteralPath $collision -Recurse -Force -ErrorAction SilentlyContinue }
  }

  # 이전 설정의 키 파일이 있으면 전용 ADB 홈의 표준 위치로 이전합니다.
  $sourceKey = ''
  if (-not [string]::IsNullOrWhiteSpace($configured)) {
    try {
      $fullConfigured = [IO.Path]::GetFullPath($configured)
      if (Test-Path -LiteralPath $fullConfigured -PathType Leaf) { $sourceKey = $fullConfigured }
      elseif (Test-Path -LiteralPath $fullConfigured -PathType Container) {
        $candidate = Join-Path $fullConfigured 'adbkey'
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { $sourceKey = $candidate }
      }
    } catch { }
  }
  if (-not (Test-Path -LiteralPath $keyPath -PathType Leaf) -and -not [string]::IsNullOrWhiteSpace($sourceKey)) {
    Copy-Item -LiteralPath $sourceKey -Destination $keyPath -Force
    if (Test-Path -LiteralPath ($sourceKey + '.pub') -PathType Leaf) { Copy-Item -LiteralPath ($sourceKey + '.pub') -Destination $publicKeyPath -Force }
  }

  $resolvedAdbHome = [IO.Path]::GetFullPath($adbHomeDir)
  $env:ANDROID_USER_HOME = $resolvedAdbHome
  $env:USERPROFILE = $resolvedAdbHome
  $env:ADB_TRACE = $null
  $env:ADB_SERVER_SOCKET = $null
  $env:ANDROID_ADB_SERVER_ADDRESS = $null
  $env:ANDROID_ADB_SERVER_PORT = $null

  if (-not (Test-Path -LiteralPath $keyPath -PathType Leaf)) {
    $tempKey = Join-Path $androidDir ('adbkey-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $keygen = @(& $script:AdbPath keygen $tempKey 2>&1 | ForEach-Object { [string]$_ })
    $keyExit = [int]$LASTEXITCODE
    if ($keyExit -ne 0 -or -not (Test-Path -LiteralPath $tempKey -PathType Leaf)) {
      throw ('ADB 공유 인증키 생성 실패 (exit ' + $keyExit + '): ' + (($keygen -join "`n").Trim()))
    }
    Move-Item -LiteralPath $tempKey -Destination $keyPath -Force
    if (Test-Path -LiteralPath ($tempKey + '.pub') -PathType Leaf) { Move-Item -LiteralPath ($tempKey + '.pub') -Destination $publicKeyPath -Force }
  }
  $env:ADB_VENDOR_KEYS = [IO.Path]::GetFullPath($keyPath)
  $result.adbVendorKeysPath = $env:ADB_VENDOR_KEYS
}
function Quote-ProcessArgument([string]$Value) {
  if ($null -eq $Value) { return '""' }
  return '"' + ($Value -replace '"','\"') + '"'
}
function Invoke-Adb([string[]]$Arguments,[int]$TimeoutSeconds=12) {
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $script:AdbPath
  $psi.Arguments = (($Arguments | ForEach-Object { Quote-ProcessArgument ([string]$_) }) -join ' ')
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $process = New-Object System.Diagnostics.Process
  $process.StartInfo = $psi
  [void]$process.Start()
  $stdoutTask = $process.StandardOutput.ReadToEndAsync()
  $stderrTask = $process.StandardError.ReadToEndAsync()
  $timeoutMs = [math]::Max(2000,[math]::Min(30000,$TimeoutSeconds * 1000))
  $finished = $process.WaitForExit($timeoutMs)
  if (-not $finished) {
    try { $process.Kill() } catch { }
    try { [void]$process.WaitForExit(2000) } catch { }
    $stdout = ''; $stderr = ''
    try { $stdout = [string]$stdoutTask.Result } catch { }
    try { $stderr = [string]$stderrTask.Result } catch { }
    $lines = @((($stdout + "`n" + $stderr) -split "`r?`n") | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | ForEach-Object { [string]$_ })
    $text = ($lines -join "`n").Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { $text = 'ADB 명령 응답 제한시간 초과 (' + $TimeoutSeconds + '초)' }
    return [pscustomobject]@{ ExitCode = 124; Output = $lines; Text = $text; TimedOut = $true }
  }
  $stdout = ''; $stderr = ''
  try { $stdout = [string]$stdoutTask.Result } catch { }
  try { $stderr = [string]$stderrTask.Result } catch { }
  $lines = @((($stdout + "`n" + $stderr) -split "`r?`n") | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | ForEach-Object { [string]$_ })
  return [pscustomobject]@{ ExitCode = [int]$process.ExitCode; Output = $lines; Text = ($lines -join "`n").Trim(); TimedOut = $false }
}

function Test-AdbPort([int]$TimeoutMilliseconds=350) {
  $client=New-Object Net.Sockets.TcpClient
  try{$ar=$client.BeginConnect('127.0.0.1',5037,$null,$null);if(-not$ar.AsyncWaitHandle.WaitOne($TimeoutMilliseconds)){return $false};$client.EndConnect($ar);return $true}catch{return $false}finally{try{$client.Close()}catch{}}
}
function Ensure-AdbServer {
  if(Test-AdbPort){return 'existing'}
  $normal=Invoke-Adb @('start-server') 12
  for($i=0;$i -lt 20;$i++){if(Test-AdbPort){return 'start-server'};Start-Sleep -Milliseconds 250}
  $logDir=Join-Path $PSScriptRoot 'logs';New-Item -ItemType Directory -Path $logDir -Force|Out-Null
  $stdout=Join-Path $logDir 'adb-server.stdout.log';$stderr=Join-Path $logDir 'adb-server.stderr.log'
  Remove-Item -LiteralPath $stdout,$stderr -Force -ErrorAction SilentlyContinue
  $proc=Start-Process -FilePath $script:AdbPath -ArgumentList @('nodaemon','server') -WorkingDirectory (Split-Path -Parent $script:AdbPath) -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
  for($i=0;$i -lt 32;$i++){if(Test-AdbPort){return 'nodaemon'};if($proc.HasExited){break};Start-Sleep -Milliseconds 250}
  $detail=$normal.Text
  foreach($log in @($stdout,$stderr)){if(Test-Path -LiteralPath $log){$value=(Get-Content -LiteralPath $log -Raw -Encoding UTF8 -ErrorAction SilentlyContinue).Trim();if($value){$detail+=(' | '+$value)}}}
  throw ('ADB 서버 5037 포트를 열지 못했습니다. '+$detail.Trim())
}

function Get-AirplaneMode {
  $read = Invoke-Adb @('-s',$script:SelectedSerial,'shell','settings','get','global','airplane_mode_on') 5
  if ($read.ExitCode -ne 0) { return '' }
  $value = ([string]$read.Text).Trim()
  if ($value -match '^[01]$') { return $value }
  return ''
}

function Wait-AirplaneMode([bool]$Enabled,[int]$TimeoutSeconds = 8) {
  $wanted = if ($Enabled) { '1' } else { '0' }
  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  do {
    if ((Get-AirplaneMode) -eq $wanted) { return $true }
    Start-Sleep -Milliseconds 500
  } while ((Get-Date) -lt $deadline)
  return $false
}

function Get-WifiMode {
  $cmd = Invoke-Adb @('-s',$script:SelectedSerial,'shell','cmd','wifi','status') 6
  if ($cmd.ExitCode -eq 0) {
    $text = ([string]$cmd.Text).Trim().ToLowerInvariant()
    if ($text -match 'wi-?fi is enabled|wifi is enabled') { return '1' }
    if ($text -match 'wi-?fi is disabled|wifi is disabled') { return '0' }
  }
  $read = Invoke-Adb @('-s',$script:SelectedSerial,'shell','settings','get','global','wifi_on') 5
  if ($read.ExitCode -eq 0) {
    $value = ([string]$read.Text).Trim()
    if ($value -match '^[01]$') { return $value }
  }
  return ''
}

function Wait-WifiDisabled([int]$TimeoutSeconds = 10) {
  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  do {
    if ((Get-WifiMode) -eq '0') { return $true }
    Start-Sleep -Milliseconds 500
  } while ((Get-Date) -lt $deadline)
  return $false
}

function Disable-WifiIfNeeded([string]$PhasePrefix = 'wifi-off') {
  $current = Get-WifiMode
  if ($current -eq '0') {
    $result.wifiDisabledVerified = $true
    Write-ResetPhase ($PhasePrefix + '-verified') '휴대폰 Wi-Fi OFF 확인 완료 · 모바일 데이터 IP 변경 준비'
    return $true
  }
  $result.wifiDisableAttempted = $true
  Write-ResetPhase ($PhasePrefix + '-command') '휴대폰 Wi-Fi가 켜져 있어 OFF 명령 전송 중'
  $disable = Invoke-Adb @('-s',$script:SelectedSerial,'shell','svc','wifi','disable') 8
  if ($disable.ExitCode -eq 0 -and (Wait-WifiDisabled 10)) {
    $result.wifiDisabledVerified = $true
    Write-ResetPhase ($PhasePrefix + '-verified') '휴대폰 Wi-Fi OFF 확인 완료 · 모바일 데이터 IP 변경 준비'
    return $true
  }
  $fallback = Invoke-Adb @('-s',$script:SelectedSerial,'shell','cmd','wifi','set-wifi-enabled','disabled') 8
  if ($fallback.ExitCode -eq 0 -and (Wait-WifiDisabled 10)) {
    $result.wifiDisabledVerified = $true
    Write-ResetPhase ($PhasePrefix + '-verified') '휴대폰 Wi-Fi OFF 확인 완료 · 모바일 데이터 IP 변경 준비'
    return $true
  }
  throw '휴대폰 Wi-Fi OFF 확인에 실패했습니다. 휴대폰 Wi-Fi를 직접 끄고 다시 시도하세요.'
}

function Set-AirplaneMode([bool]$Enabled) {
  $mode = if ($Enabled) { 'enable' } else { 'disable' }
  $state = if ($Enabled) { 'true' } else { 'false' }
  $numeric = if ($Enabled) { '1' } else { '0' }

  $primary = Invoke-Adb @('-s',$script:SelectedSerial,'shell','cmd','connectivity','airplane-mode',$mode) 8
  if ($primary.ExitCode -eq 0 -and (Wait-AirplaneMode $Enabled 6)) { return $true }

  $settings = Invoke-Adb @('-s',$script:SelectedSerial,'shell','settings','put','global','airplane_mode_on',$numeric) 8
  $broadcast = Invoke-Adb @('-s',$script:SelectedSerial,'shell','am','broadcast','-a','android.intent.action.AIRPLANE_MODE','--ez','state',$state) 8
  if ($settings.ExitCode -ne 0 -and $broadcast.ExitCode -ne 0) { return $false }
  return (Wait-AirplaneMode $Enabled 8)
}

function Wait-AdbDevice([int]$TimeoutSeconds) {
  $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
  do {
    try {
      $state = Invoke-Adb @('-s',$script:SelectedSerial,'get-state') 5
      if ($state.ExitCode -eq 0 -and ([string]$state.Text).Trim() -eq 'device') { return $true }
    } catch { }
    Start-Sleep -Seconds 1
  } while ((Get-Date) -lt $deadline)
  return $false
}

try {
  Write-ResetPhase 'adb-preparing' '모바일 네트워크 복구 시작 · ADB 실행환경 확인 중'
  $script:AdbPath = Find-AdbPath
  if ([string]::IsNullOrWhiteSpace($script:AdbPath)) {
    throw 'ADB를 찾을 수 없습니다. 최신 install-network-host.cmd를 관리자 권한으로 실행해 Google Android SDK Platform-Tools 자동 설치를 완료하세요.'
  }
  $result.adbPath = $script:AdbPath
  Initialize-AdbEnvironment
  Write-ResetPhase 'adb-server' 'ADB 서버 연결 상태 확인 중'
  $result.adbServerMode = Ensure-AdbServer
  Write-ResetPhase 'adb-device-check' 'USB 디버깅 Android 기기 연결 상태 확인 중'
  $devices = Invoke-Adb @('devices') 8
  if ($devices.ExitCode -ne 0) { throw ('ADB 기기 조회 실패: ' + $devices.Text) }

  $ready = @($devices.Output | Where-Object { $_ -match '^\S+\s+device$' } | ForEach-Object { ($_ -split '\s+')[0] })
  $blocked = @($devices.Output | Where-Object { $_ -match '^\S+\s+(?:unauthorized|offline)$' })
  if ($blocked.Count -gt 0) { throw 'USB 디버깅 승인 대기 또는 오프라인 기기가 있습니다. 휴대폰 잠금을 해제하고 이 컴퓨터의 USB 디버깅을 항상 허용한 뒤 다시 시도하세요.' }
  if (-not [string]::IsNullOrWhiteSpace($DeviceSerial)) {
    if ($ready -notcontains $DeviceSerial) { throw '지정한 ADB 기기가 연결되어 있지 않습니다.' }
    $script:SelectedSerial = $DeviceSerial
  } else {
    if ($ready.Count -eq 0) { throw 'ADB로 연결된 Android 기기가 없습니다. USB 디버깅과 USB 연결을 확인하세요.' }
    if ($ready.Count -gt 1) { throw 'ADB 기기가 여러 대 연결되어 있습니다. network-host-config.json의 adbSerial 또는 요청의 deviceSerial로 한 대를 지정하세요.' }
    $script:SelectedSerial = [string]$ready[0]
  }
  $result.adbReady = $true
  $result.deviceSerial = $script:SelectedSerial
  Write-ResetPhase 'device-ready' ('ADB 기기 연결 확인 · ' + $script:SelectedSerial)

  if (-not [string]::IsNullOrWhiteSpace($AirplaneOnly)) {
    $currentMode = Get-AirplaneMode
    if ($currentMode -notin @('0','1')) { throw '비행기 모드 현재 상태를 확인하지 못했습니다.' }
    $result.command = 'airplane_mode'
    $result.previousAirplaneMode = ($currentMode -eq '1')
    if ($AirplaneOnly -eq 'status') {
      $result.airplaneMode = ($currentMode -eq '1')
      $result.airplaneModeVerified = $true
      $result.deviceReady = $true
      $result.ok = $true
      $result.completed = $true
      $result.message = if ($result.airplaneMode) { '휴대폰 비행기 모드가 켜져 있습니다.' } else { '휴대폰 비행기 모드가 꺼져 있습니다.' }
    } else {
      $targetEnabled = if ($AirplaneOnly -eq 'on') { $true } elseif ($AirplaneOnly -eq 'off') { $false } else { -not ($currentMode -eq '1') }
      Write-ResetPhase 'airplane-manual-command' ('비행기 모드 수동 전환 · ' + $(if ($targetEnabled) { 'ON' } else { 'OFF' }) + ' 요청 중')
      if (-not (Set-AirplaneMode $targetEnabled)) { throw ('비행기 모드 ' + $(if ($targetEnabled) { 'ON' } else { 'OFF' }) + ' 확인에 실패했습니다.') }
      $verifiedMode = Get-AirplaneMode
      $result.airplaneMode = ($verifiedMode -eq '1')
      $result.airplaneModeVerified = ($verifiedMode -eq $(if ($targetEnabled) { '1' } else { '0' }))
      if (-not $result.airplaneModeVerified) { throw '비행기 모드 전환 후 상태 검증에 실패했습니다.' }
      $result.deviceReady = $true
      $result.ok = $true
      $result.completed = $true
      $result.message = if ($targetEnabled) { '휴대폰 비행기 모드 ON 확인 완료' } else { '휴대폰 비행기 모드 OFF 확인 완료' }
    }
    $finishedAt = (Get-Date).ToUniversalTime()
    $result.finishedAt = $finishedAt.ToString('o')
    $result.durationMs = [math]::Max(0,[int64]($finishedAt - $startedAt).TotalMilliseconds)
    $result | ConvertTo-Json -Depth 6 -Compress
    if ($result.ok) { exit 0 }
    exit 1
  }

  $initialUsb = Invoke-Adb @('-s',$script:SelectedSerial,'shell','svc','usb','getFunctions') 6
  if ($initialUsb.ExitCode -eq 0) { $result.initialUsbFunctions = ([string]$initialUsb.Text).Trim() }
  $usbTetheringWasActive = ([string]$result.initialUsbFunctions) -match 'rndis'

  if (-not $ForceDisableOnly) {
    Write-ResetPhase 'wifi-precheck' '휴대폰 Wi-Fi 상태 확인 중'
    $wifiBefore = Get-WifiMode
    if ($wifiBefore -eq '1') { $result.wifiInitiallyEnabled = $true }
    elseif ($wifiBefore -eq '0') { $result.wifiInitiallyEnabled = $false }
    [void](Disable-WifiIfNeeded 'wifi-off')
  }

  if ($ForceDisableOnly) {
    Write-ResetPhase 'airplane-off-command' '비행기 모드 긴급 OFF 요청 중'
    if (-not (Set-AirplaneMode $false)) { throw '비행기 모드 긴급 OFF 확인에 실패했습니다. 휴대폰에서 비행기 모드를 직접 꺼주세요.' }
  } else {
    $airplaneEnableAttempted = $true
    Write-ResetPhase 'airplane-on-command' '휴대폰 비행기 모드 ON 명령 전송·확인 중'
    if (-not (Set-AirplaneMode $true)) { throw '비행기 모드 ON 확인에 실패했습니다. 기기 제조사 정책 또는 ADB 권한을 확인하세요.' }
    $holdUntil = (Get-Date).ToUniversalTime().AddSeconds($AirplaneHoldSeconds)
    Write-ResetPhase 'airplane-on' ('비행기 모드 ON 확인 · ' + $AirplaneHoldSeconds + '초 유지') $holdUntil
    Start-Sleep -Seconds $AirplaneHoldSeconds
    Write-ResetPhase 'airplane-off-command' '비행기 모드 유지 완료 · OFF 명령 전송·확인 중'
    if (-not (Set-AirplaneMode $false)) { throw '비행기 모드 OFF 확인에 실패했습니다. 휴대폰에서 비행기 모드를 직접 꺼주세요.' }
    $airplaneEnableAttempted = $false
    Write-ResetPhase 'wifi-recheck' '비행기 모드 OFF 확인 · 휴대폰 Wi-Fi 재확인 중'
    if ((Get-WifiMode) -ne '0') {
      [void](Disable-WifiIfNeeded 'wifi-reoff')
      $result.wifiRecheckDisabled = $true
    } else {
      $result.wifiDisabledVerified = $true
      Write-ResetPhase 'wifi-reoff-verified' '휴대폰 Wi-Fi OFF 유지 확인 · 모바일 데이터/USB 연결 복구로 진행'
    }
    Write-ResetPhase 'reconnecting' '비행기 모드 OFF·Wi-Fi OFF 확인 · 모바일 데이터/USB 연결 복구 중'
    if ($ForceMobileDataCycle) {
      $result.mobileDataCycleAttempted = $true
      $disableData = Invoke-Adb @('-s',$script:SelectedSerial,'shell','svc','data','disable') 8
      if ($disableData.ExitCode -ne 0) { throw ('모바일 데이터 OFF 명령 실패: ' + $disableData.Text) }
      Start-Sleep -Seconds ([math]::Max(4,[math]::Min(30,$AirplaneHoldSeconds)))
      $enableData = Invoke-Adb @('-s',$script:SelectedSerial,'shell','svc','data','enable') 8
      if ($enableData.ExitCode -ne 0) { throw ('모바일 데이터 ON 명령 실패: ' + $enableData.Text) }
      $result.mobileDataCycleCompleted = $true
      Start-Sleep -Seconds 3
    }
  }

  Write-ResetPhase 'device-reconnect' 'Android 기기 재연결 확인 중'
  if (-not (Wait-AdbDevice $ReconnectTimeoutSeconds)) { throw '비행기 모드 해제 후 ADB 기기가 제한 시간 안에 준비되지 않았습니다.' }
  if (-not (Wait-AirplaneMode $false 8)) { throw '비행기 모드 해제 상태를 최종 확인하지 못했습니다.' }

  Write-ResetPhase 'tethering-check' 'USB 테더링(RNDIS) 복구 상태 확인 중'
  $usb = Invoke-Adb @('-s',$script:SelectedSerial,'shell','svc','usb','getFunctions') 6
  if ($usb.ExitCode -eq 0) { $result.usbFunctions = ([string]$usb.Text).Trim() }
  if ($usbTetheringWasActive -and ([string]$result.usbFunctions) -notmatch 'rndis') {
    $restoreUsb = Invoke-Adb @('-s',$script:SelectedSerial,'shell','svc','usb','setFunctions','rndis,adb') 10
    Start-Sleep -Seconds 3
    if (-not (Wait-AdbDevice ([math]::Min(20,$ReconnectTimeoutSeconds)))) { throw '비행기 모드 해제 후 USB 테더링(RNDIS) 재연결에 실패했습니다.' }
    $usb = Invoke-Adb @('-s',$script:SelectedSerial,'shell','svc','usb','getFunctions') 6
    if ($usb.ExitCode -eq 0) { $result.usbFunctions = ([string]$usb.Text).Trim() }
    if ($restoreUsb.ExitCode -ne 0 -or ([string]$result.usbFunctions) -notmatch 'rndis') { throw 'USB 테더링(RNDIS)이 자동 복구되지 않았습니다. 휴대폰의 USB 테더링을 다시 켜주세요.' }
    $result.usbTetheringRestored = $true
  } elseif ($usbTetheringWasActive) {
    $result.usbTetheringRestored = $true
  }
  Write-ResetPhase 'android-device-restored' '비행기 모드 OFF·Android·RNDIS 복구 확인 · Windows 어댑터 재연결 확인으로 전환'
  $result.deviceReady = $true
  $result.airplaneModeVerified = $true
  $result.ok = $true
  $result.completed = $true
  $result.message = if ($ForceDisableOnly) { '비행기 모드 긴급 OFF 확인을 완료했습니다.' } elseif ($ForceMobileDataCycle) { '비행기 모드 ON/OFF와 모바일 데이터 OFF/ON, Android 기기 재연결을 확인했습니다.' } else { '휴대폰 Wi-Fi OFF, 비행기 모드 ON/OFF와 Android 기기 재연결 확인을 완료했습니다.' }
} catch {
  $result.error = ([string]$_.Exception.Message).Trim()
  Write-ResetPhase 'failed' ('모바일 네트워크 자동 복구 실패 · ' + $result.error) $null $result.error
  $result.message = '모바일 네트워크 자동 복구를 완료하지 못했습니다.'
} finally {
  if ($airplaneEnableAttempted -and -not [string]::IsNullOrWhiteSpace($script:AdbPath) -and -not [string]::IsNullOrWhiteSpace($script:SelectedSerial)) {
    try {
      [void](Set-AirplaneMode $false)
      [void](Wait-AirplaneMode $false 8)
    } catch { }
  }
  $finishedAt = (Get-Date).ToUniversalTime()
  $result.finishedAt = $finishedAt.ToString('o')
  $result.durationMs = [math]::Max(0,[int64]($finishedAt - $startedAt).TotalMilliseconds)
}

$result | ConvertTo-Json -Depth 6 -Compress
if ($result.ok) { exit 0 }
exit 1
