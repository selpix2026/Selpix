﻿param([switch]$Elevated)
$ErrorActionPreference='Stop'
try{$utf8=New-Object Text.UTF8Encoding($false);[Console]::InputEncoding=$utf8;[Console]::OutputEncoding=$utf8;$OutputEncoding=$utf8}catch{}
$SourceRoot=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$TargetRoot=Join-Path $env:ProgramData 'SmartPageEx\SmartPage Sourcing Collector'
$ChromeForTestingRoot=Join-Path $env:ProgramData 'SmartPageEx\ChromeForTesting'
$DedicatedProfile='C:\SpxDedicatedProfile'
$ExtensionId='olmpllofoggohefbdkgkjjnlanfnaocd'
function Test-Admin{$id=[Security.Principal.WindowsIdentity]::GetCurrent();$p=New-Object Security.Principal.WindowsPrincipal($id);$p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}
function Find-NormalChromePath{
  $candidates=New-Object System.Collections.Generic.List[string]
  foreach($key in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe','HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe')){try{$v=[string](Get-Item -LiteralPath $key -ErrorAction Stop).GetValue('');if($v){$candidates.Add($v)}}catch{}}
  foreach($candidate in @((Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'),(Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),$(if(${env:ProgramFiles(x86)}){Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'}else{$null}))){if($candidate){$candidates.Add([string]$candidate)}}
  foreach($candidate in $candidates){if($candidate -and(Test-Path -LiteralPath $candidate -PathType Leaf)){return [IO.Path]::GetFullPath($candidate)}}
  return $null
}
if(-not(Test-Admin)){$args='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath.Replace('"','""')+'" -Elevated';$p=Start-Process "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Verb RunAs -ArgumentList $args -Wait -PassThru;exit $p.ExitCode}
$Chrome=Find-NormalChromePath
if([string]::IsNullOrWhiteSpace($Chrome)){throw '일반 Google Chrome을 찾지 못했습니다. Google Chrome 설치 후 다시 실행하세요.'}
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host ' SmartPage 전용창 · 일반 Chrome 복구' -ForegroundColor Green
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host ('Google Chrome='+$Chrome)
Write-Host ('전용 프로필 보존='+$DedicatedProfile) -ForegroundColor Green
Write-Host 'WING 로그인/쿠키/전용 프로필은 삭제하지 않습니다. (preserve WING/session/profile)' -ForegroundColor Green
# Close only Chrome processes that use the SmartPage dedicated profile; personal Chrome is untouched.
try{
  $targets=@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" -ErrorAction SilentlyContinue|Where-Object{[string]$_.CommandLine -like ('*'+$DedicatedProfile+'*')})
  foreach($proc in $targets){try{Stop-Process -Id ([int]$proc.ProcessId) -Force -ErrorAction Stop}catch{}}
  if($targets.Count){Start-Sleep -Milliseconds 800}
}catch{}
if(Test-Path -LiteralPath $ChromeForTestingRoot){
  Remove-Item -LiteralPath $ChromeForTestingRoot -Recurse -Force
  Write-Host 'SmartPage가 설치했던 테스트용 Chrome만 제거했습니다.' -ForegroundColor Yellow
}else{Write-Host 'SmartPage 테스트용 Chrome 설치 폴더 없음 · 건너뜀' -ForegroundColor DarkGray}
if(-not(Test-Path -LiteralPath (Join-Path $TargetRoot 'manifest.json') -PathType Leaf)){throw '설치된 Collector를 찾지 못했습니다. 먼저 현재 패키지의 RUN_00_INSTALL_OTHER_PC.cmd를 실행하세요.'}
$refreshScript=Join-Path $SourceRoot 'tools\crosspc\09_REFRESH_NORMAL_CHROME_LAUNCHER.ps1'
if(-not(Test-Path -LiteralPath $refreshScript -PathType Leaf)){$refreshScript=Join-Path $TargetRoot 'tools\crosspc\09_REFRESH_NORMAL_CHROME_LAUNCHER.ps1'}
if(-not(Test-Path -LiteralPath $refreshScript -PathType Leaf)){throw '전용창 launcher 집중 복구 도구를 찾지 못했습니다.'}
Write-Host '전용창 launcher만 일반 Chrome 기준으로 복구하는 중... (IP/테더링 Helper core는 변경하지 않음)' -ForegroundColor Cyan
& "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $refreshScript -Elevated -Quiet
if($LASTEXITCODE -ne 0){throw ('전용창 launcher 집중 복구 실패. ExitCode='+$LASTEXITCODE)}
$launcher=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33\open-dedicated-window.ps1'
if(-not(Test-Path -LiteralPath $launcher -PathType Leaf)){throw '복구된 전용창 launcher를 찾지 못했습니다.'}
$text=Get-Content -LiteralPath $launcher -Raw -Encoding UTF8
if($text -notmatch 'NORMAL_CHROME_V1514' -or $text -match 'ChromeForTesting' -or $text -match '--load-extension=' -or $text -match '--disable-extensions-except='){throw '전용창 launcher가 일반 Chrome 기준으로 복구되지 않았습니다.'}
$registerScript=Join-Path $TargetRoot 'tools\crosspc\08_REGISTER_COLLECTOR_NORMAL_CHROME.ps1'
if(-not(Test-Path -LiteralPath $registerScript -PathType Leaf)){throw 'Collector 확장 등록 복구 도구를 찾지 못했습니다.'}
Write-Host '일반 Chrome 전용 프로필의 Collector 등록 상태를 확인합니다...' -ForegroundColor Cyan
& "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $registerScript -InstallGate
if($LASTEXITCODE -ne 0){throw '일반 Chrome 전용 프로필 확장 등록이 완료되지 않았습니다. RUN_08_REGISTER_COLLECTOR_NORMAL_CHROME.cmd를 이어서 실행하세요.'}
Write-Host ''
Write-Host '복구 완료 · 개인 Chrome은 건드리지 않았고 SmartPage 전용 프로필/WING 데이터는 보존했습니다.' -ForegroundColor Green
Write-Host 'Collector 확장 등록까지 확인했습니다. 이제 RUN_02_OPEN_COLLECTOR.cmd 또는 수집기의 전용창 열기를 사용하세요.' -ForegroundColor Cyan
exit 0
