﻿$ErrorActionPreference = 'Stop'
$ExpectedId = 'olmpllofoggohefbdkgkjjnlanfnaocd'
$ExpectedCollectorRoot = 'D:\01. Work In Process\쿠팡 수집기\SmartPage Sourcing Collector'
$ActualCollectorRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Root = $ExpectedCollectorRoot
$InstallDir = Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$ConfigPath = Join-Path $InstallDir 'network-host-config.json'
$NativeManifestPath = Join-Path $InstallDir 'com.smartpage.spx_network_v7.json'
$LauncherPath = Join-Path $InstallDir 'open-dedicated-window.ps1'
$ReadyPath = Join-Path $InstallDir 'dedicated-window-launcher.ready'
$RequestPath = Join-Path $InstallDir 'dedicated-window-request.json'
$ResultPath = Join-Path $InstallDir 'dedicated-window-result.json'
$TaskName = 'SmartPageEx Open Dedicated Browser'
function Read-Utf8Text([string]$Path) { if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }; return [IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8) }
function Read-Utf8Json([string]$Path) { $text = Read-Utf8Text $Path; if ($null -eq $text) { return $null }; return ($text | ConvertFrom-Json -ErrorAction Stop) }
function Has-Utf8Bom([string]$Path) { if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }; $b = [IO.File]::ReadAllBytes($Path); return ($b.Length -ge 3 -and $b[0] -eq 0xEF -and $b[1] -eq 0xBB -and $b[2] -eq 0xBF) }
function Eq-Path([string]$A, [string]$B) { try { return ([IO.Path]::GetFullPath($A).TrimEnd([char]'\') -eq [IO.Path]::GetFullPath($B).TrimEnd([char]'\')) } catch { return $false } }
if (-not (Eq-Path $ActualCollectorRoot $ExpectedCollectorRoot)) {
  throw ('Collector 경로가 고정 경로와 다릅니다. 현재=' + $ActualCollectorRoot + ' / 필요=' + $ExpectedCollectorRoot)
}

function Get-ManifestId([string]$Path) { $m = Read-Utf8Json $Path; $bytes = [Convert]::FromBase64String([string]$m.key); $sha = [Security.Cryptography.SHA256]::Create(); try { $h = $sha.ComputeHash($bytes) } finally { $sha.Dispose() }; $b = New-Object Text.StringBuilder; for ($i = 0; $i -lt 16; $i++) { [void]$b.Append([char]([int][char]'a' + (($h[$i] -shr 4) -band 15))); [void]$b.Append([char]([int][char]'a' + ($h[$i] -band 15))) }; return $b.ToString() }
function Show-Json([string]$Label, [string]$Path) { Write-Host ('[' + $Label + '] Exists=' + (Test-Path -LiteralPath $Path)); if (Test-Path -LiteralPath $Path -PathType Leaf) { try { $x = Read-Utf8Json $Path; Write-Host (($x | ConvertTo-Json -Depth 5 -Compress)) } catch { Write-Host ('READ_ERROR=' + $_.Exception.Message) } } }
function Get-WatcherCount { try { return @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $cmd=[string]$_.CommandLine; -not [string]::IsNullOrWhiteSpace($cmd) -and $cmd.IndexOf($LauncherPath,[StringComparison]::OrdinalIgnoreCase)-ge 0 -and $cmd -match '(?i)(?:^|\s)-Watch(?:\s|$)' }).Count } catch { return 0 } }
Write-Host 'SmartPage Sourcing Collector dedicated-window UTF-8/path FIX5 - VERIFY ONLY'
Write-Host 'WRITE=0 TASK_RUN=0 TASK_CHANGE=0 CHROME_STOP=0 ROUTE_CHANGE=0 ADAPTER_CHANGE=0'
Write-Host ('CollectorRoot=' + $Root)
$ManifestPath = Join-Path $Root 'manifest.json'
$manifest = Read-Utf8Json $ManifestPath
$actualId = Get-ManifestId $ManifestPath
Write-Host ('ManifestVersion=' + [string]$manifest.version)
Write-Host ('ManifestId=' + $actualId)
Write-Host ('ManifestIdMatch=' + ($actualId -eq $ExpectedId))
$config = $null; $native = $null; $launcher = ''
if (Test-Path -LiteralPath $ConfigPath -PathType Leaf) { try { $config = Read-Utf8Json $ConfigPath } catch {} }
if (Test-Path -LiteralPath $NativeManifestPath -PathType Leaf) { try { $native = Read-Utf8Json $NativeManifestPath } catch {} }
if (Test-Path -LiteralPath $LauncherPath -PathType Leaf) { $launcher = Read-Utf8Text $LauncherPath }
$origin = 'chrome-extension://' + $ExpectedId + '/'
$explicitUtf8 = $launcher -match '\[IO\.File\]::ReadAllText\(\$RequestPath\s*,\s*\[Text\.Encoding\]::UTF8\)'
Write-Host ('ConfigUtf8Bom=' + (Has-Utf8Bom $ConfigPath))
Write-Host ('ConfigExtensionId=' + [string]$config.extensionId)
Write-Host ('ConfigExtensionRoot=' + [string]$config.extensionRoot)
Write-Host ('ConfigRootExact=' + (Eq-Path ([string]$config.extensionRoot) $Root))
Write-Host ('ConfigCollectorId=' + (@($config.extensionIds) -contains $ExpectedId))
Write-Host ('NativeCollectorOrigin=' + (@($native.allowed_origins) -contains $origin))
Write-Host ('LauncherRequestExplicitUtf8=' + $explicitUtf8)
$taskOk = $false
try { $task = Get-ScheduledTask -TaskName $TaskName -ErrorAction Stop; $a = @($task.Actions)[0]; $taskOk = ([string]$a.Arguments).Contains($LauncherPath); $ti=Get-ScheduledTaskInfo -TaskName $TaskName -ErrorAction SilentlyContinue; Write-Host 'TaskExists=True'; Write-Host ('TaskState=' + [string]$task.State); Write-Host ('TaskLastResult=' + [string]$ti.LastTaskResult); Write-Host ('TaskPointsToV33Launcher=' + $taskOk) } catch { Write-Host 'TaskExists=False'; Write-Host ('TaskError=' + $_.Exception.Message) }
Write-Host ('WatcherProcessCount=' + (Get-WatcherCount))
Show-Json 'READY' $ReadyPath
Show-Json 'LAST_REQUEST' $RequestPath
Show-Json 'LAST_RESULT' $ResultPath
$needFix = (-not ($actualId -eq $ExpectedId)) -or (-not ([string]$manifest.version -eq '1.0.4')) -or (-not (Eq-Path ([string]$config.extensionRoot) $Root)) -or (-not ([string]$config.extensionId -eq $ExpectedId)) -or (-not (@($config.extensionIds) -contains $ExpectedId)) -or (-not (@($native.allowed_origins) -contains $origin)) -or (-not (Has-Utf8Bom $ConfigPath)) -or (-not $explicitUtf8) -or (-not $taskOk)
Write-Host ('FIX_REQUIRED=' + $needFix)
if ($needFix) { Write-Host 'FINAL=DEDICATED_WINDOW_UTF8_PATH_FIX5_REQUIRED' } else { Write-Host 'FINAL=DEDICATED_WINDOW_UTF8_PATH_FIX5_VERIFY_PASS' }
