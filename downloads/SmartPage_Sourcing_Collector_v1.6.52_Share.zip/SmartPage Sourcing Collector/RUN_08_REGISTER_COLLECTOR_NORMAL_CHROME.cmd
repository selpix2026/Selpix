@echo off
chcp 65001 >nul
setlocal
set "PS=%~dp0tools\crosspc\08_REGISTER_COLLECTOR_NORMAL_CHROME.ps1"
if not exist "%PS%" (
  echo [ERROR] Collector registration PowerShell file not found.
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS%"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo [ERROR] Collector registration was not completed. Check the message above.
if "%RC%"=="0" echo [OK] Collector registration is ready.
pause
exit /b %RC%
