@echo off
chcp 65001 >nul
setlocal
title SmartPage Collector - Other PC Install
set "PS=%~dp0tools\crosspc\00_INSTALL_OTHER_PC.ps1"
if not exist "%PS%" (
  echo [ERROR] Installer PowerShell file not found.
  echo %PS%
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS%"
set "RC=%ERRORLEVEL%"
echo.
echo ExitCode=%RC%
if not "%RC%"=="0" echo [ERROR] Install did not complete. Check the PowerShell message above.
pause
exit /b %RC%
