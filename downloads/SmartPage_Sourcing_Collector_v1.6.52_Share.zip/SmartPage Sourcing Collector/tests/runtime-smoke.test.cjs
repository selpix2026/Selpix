const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs'),path=require('node:path');
const {root,sourceFunction,runtime}=require('./helpers.cjs');

test('legacy provider requests are rejected before collection while Coupang requests remain supported',()=>{
  const ctx=vm.createContext({});vm.runInContext(sourceFunction('src/background/service-worker-core.js','retiredProviderResponse'),ctx);
  for(const msg of [{type:'SPX_NAVER_LOOKUP'},{type:'SPX_START_SELECTED_MODE',naverOnly:true},{mode:'naver'}])assert.equal(ctx.retiredProviderResponse(msg).code,'PROVIDER_RETIRED');
  assert.equal(ctx.retiredProviderResponse({type:'SPX_START_SELECTED_MODE',mode:'guided'}),null);
});

test('real worker imports complete with browser boundary APIs and no configured services',async()=>{
  const errors=[],listeners=[],storage={},event={addListener:()=>{},removeListener:()=>{}},noop=async()=>({});
  const storageArea={get:async keys=>typeof keys==='string'?{[keys]:storage[keys]}:{...storage},set:async value=>Object.assign(storage,value),remove:async keys=>{for(const key of Array.isArray(keys)?keys:[keys])delete storage[key];},getBytesInUse:async()=>0};
  const api=new Proxy({}, {get:(target,key)=>String(key).startsWith('on')?event:noop});
  const chrome={storage:{local:storageArea,session:storageArea,onChanged:event},runtime:{id:'test',getManifest:()=>({version:'1.6.52'}),getURL:p=>'chrome-extension://test/'+p,onInstalled:event,onStartup:event,onMessage:{addListener:f=>listeners.push(f)},onMessageExternal:event,sendMessage:async()=>({ok:true}),getPlatformInfo:async()=>({os:'linux'})},
    tabs:api,alarms:{...api,onAlarm:event,create:async()=>{},clear:async()=>true,getAll:async()=>[]},webRequest:api,windows:api,proxy:{settings:api},scripting:api,cookies:api,declarativeNetRequest:api,notifications:api};
  const ctx=vm.createContext({chrome,console:{log:()=>{},info:()=>{},debug:()=>{},warn:()=>{},error:(...args)=>errors.push(args.map(String).join(' '))},
    URL,URLSearchParams,TextEncoder,TextDecoder,AbortController,Response,Request,Headers,Blob,structuredClone,crypto:require('node:crypto').webcrypto,
    performance,atob,btoa,navigator:{userAgent:'local-test'},setTimeout:()=>1,clearTimeout:()=>{},setInterval:()=>1,clearInterval:()=>{},fetch:async()=>new Response('{}',{status:503})});
  ctx.self=ctx;ctx.addEventListener=()=>{};
  ctx.importScripts=(...files)=>{for(const file of files){const full=path.resolve(root,'src/background',file);vm.runInContext(fs.readFileSync(full,'utf8'),ctx,{filename:file});}};
  vm.runInContext(fs.readFileSync(root+'/src/background/service-worker.js','utf8'),ctx,{filename:'service-worker.js'});
  await new Promise(resolve=>setImmediate(resolve));
  assert.ok(listeners.length>0);assert.deepEqual(errors,[]);
});

test('sidebar creates its actual settings DOM without retired provider controls',async()=>{
  const ctx=runtime();
  ctx.queueMicrotask=queueMicrotask;ctx.requestAnimationFrame=()=>1;ctx.cancelAnimationFrame=()=>{};ctx.setInterval=()=>1;ctx.clearInterval=()=>{};
  ctx.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};ctx.sessionStorage=ctx.localStorage;
  ctx.MutationObserver=ctx.window.MutationObserver;ctx.getComputedStyle=()=>({display:'block',visibility:'visible',position:'static'});
  ctx.window.matchMedia=()=>({matches:false,addEventListener:()=>{}});ctx.window.location=ctx.location;
  ctx.SPX.util.runtimeAlive=()=>true;ctx.chrome.runtime.id='test';ctx.chrome.runtime.getURL=p=>'chrome-extension://test/'+p;
  ctx.chrome.runtime.onMessage={addListener:()=>{},removeListener:()=>{}};ctx.chrome.runtime.sendMessage=async()=>({ok:true,data:{extensionVersion:'1.6.52',runtimeBuild:'1.6.52'},state:{running:false}});
  for(const file of ['keyword-filter','discovery','prompt-keywords-v1610','coupang-seed-catalog'])vm.runInContext(fs.readFileSync(root+'/src/lib/'+file+'.js','utf8'),ctx);
  let source=fs.readFileSync(root+'/src/content/coupang-search.js','utf8');
  // Expose the original UI factory only inside this test VM; skip autonomous boot.
  source=source.replace("  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });\n  else boot();",'  globalThis.__sidebar={ensureUi,detect,prepareCategoryKeywordSelection,refreshSidebarRunButton};');
  vm.runInContext(source,ctx,{filename:'coupang-search.js'});
  assert.ok(ctx.__sidebar);assert.equal(ctx.__sidebar.ensureUi(),true);
  const dom=ctx.document;
  assert.ok(dom.getElementById('spx-scan'));
  assert.equal(dom.querySelectorAll('[data-toggle-field="collectDetailRecommendations"]').length,1);
  assert.equal(dom.querySelectorAll('#spx-naver-card,[data-common-field="naverTrendEnabled"]').length,0);
  ctx.SPX.parseSearchPage=()=>({items:[{pid:'1',name:'스테인리스 보온 텀블러'}]});
  ctx.SPX.parseSearchCategoryContext=()=>({categoryPath:'주방 > 물병'});
  await ctx.__sidebar.prepareCategoryKeywordSelection();
  assert.equal(dom.getElementById('spx-sourcing-modal').hidden,false);
  assert.equal(dom.getElementById('spx-sourcing-specified-enabled').checked,true);
  assert.ok(dom.getElementById('spx-sourcing-seed-keyword').value.includes('텀블러'));
  await ctx.__sidebar.refreshSidebarRunButton({running:true,runId:'r',networkRecoveryPaused:true,waitKind:'network-reset-failed',currentKeyword:'텀블러'});
  assert.equal(dom.getElementById('spx-change-ip').disabled,false,'a failed recovery must leave the manual IP button available');
});
