@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp002_POST_VERIFY_ONLY.ps1"
set RC=%ERRORLEVEL%
echo ExitCode=%RC%
pause
exit /b %RC%
