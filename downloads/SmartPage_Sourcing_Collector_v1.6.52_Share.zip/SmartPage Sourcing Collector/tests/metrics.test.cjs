const test=require('node:test'),assert=require('node:assert/strict');
const {runtime}=require('./helpers.cjs');
const product=(pid,rank,extras={})=>({pid:String(pid),rank,exposureRank:rank,organicRank:rank,name:'텀블러',rocketType:'일반배송',reviews:30,price:10000,detailMonthlyPurchaseCount:300,...extras});

test('full search sample never evicts a verified recommendation snapshot',()=>{
  const ctx=runtime();
  const primary=Array.from({length:200},(_,i)=>product(i+1,i+1));
  const extra=product(999,null,{sourceType:'detail_comparison_verified',recommendationVerified:true,keywordRelevanceScore:100});
  const snapshots=ctx.SPX.buildProductSnapshots([...primary,extra],[],{maxProducts:200});
  assert.equal(snapshots.length,201);assert.equal(snapshots.at(-1).pid,'999');
  assert.equal(snapshots.at(-1).organic_rank,null);
});

test('recommendation winners do not increase search coverage or source totals',()=>{
  const ctx=runtime();
  const main={pid:'1',rocket_type:'일반배송',cumulative_reviews:30,recent_reviews:2,monthly_purchase_count:300,estimated_monthly_sales:300,price:10000};
  const extra={...main,pid:'2',source_type:'detail_comparison_verified',recommendation_verified:true,keyword_relevance_score:100};
  const before=ctx.SPX.computeWinnerMetrics([main],{targetOrganic:60});
  const after=ctx.SPX.computeWinnerMetrics([main,extra],{targetOrganic:60});
  assert.equal(after.winner_count,2);assert.equal(after.market_coverage_ratio,before.market_coverage_ratio);
  assert.equal(after.organic_snapshot_count,1);assert.equal(after.source_total_monthly_sales,300);
});

test('different offers survive the shared product identity',()=>{
  const ctx=runtime();
  const rows=[product(1,1,{vendorItemId:'10'}),product(1,2,{vendorItemId:'20'}),product(1,3,{vendorItemId:'10',rocketType:'판매자로켓'})];
  const snapshots=ctx.SPX.buildProductSnapshots(rows);
  const metrics=ctx.SPX.computeWinnerMetrics(snapshots);
  assert.equal(metrics.market_product_identity_count,3);
});

test('duplicate recommendation evidence never replaces original search provenance',()=>{
  const ctx=runtime();
  const main={pid:'1',vendor_item_id:'10',rocket_type:'일반배송',cumulative_reviews:30,recent_reviews:2,monthly_purchase_count:300,estimated_monthly_sales:300,price:10000,sales_estimate_confidence:10};
  const extra={...main,source_type:'detail_comparison_verified',recommendation_verified:true,keyword_relevance_score:100,sales_estimate_confidence:95};
  const result=ctx.SPX.computeWinnerMetrics([main,extra]);
  assert.equal(result.organic_snapshot_count,1);assert.equal(result.winner_count,1);
});
