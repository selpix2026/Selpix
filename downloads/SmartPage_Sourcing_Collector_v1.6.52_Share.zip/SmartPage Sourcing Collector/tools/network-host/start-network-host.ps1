﻿param([switch]$Silent)
$ErrorActionPreference='Stop'
$BridgePort=30765
$ProxyPorts=@(30766,30767,30768,30769)
$BridgeTaskName='SmartPageEx Network Local Bridge'
$ExpectedHelperVersion='3.0.45'
$ExpectedBuildMarker='v3.0.45-v1651-coupang-only'
$InstallDir=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$ExePath=Join-Path $InstallDir 'SpxNetworkHost.exe'
$LogPath=Join-Path $InstallDir 'local-bridge.log'

function Ensure-LogUtf8Bom{
  try{
    $bom=[Text.Encoding]::UTF8.GetPreamble()
    if(-not(Test-Path -LiteralPath $LogPath -PathType Leaf)){[IO.File]::WriteAllBytes($LogPath,$bom);return}
    $bytes=[IO.File]::ReadAllBytes($LogPath)
    $has=$bytes.Length-ge$bom.Length
    for($i=0;$has-and$i-lt$bom.Length;$i++){if($bytes[$i]-ne$bom[$i]){$has=$false}}
    if(-not$has){
      $combined=New-Object byte[] ($bom.Length+$bytes.Length)
      [Array]::Copy($bom,0,$combined,0,$bom.Length)
      [Array]::Copy($bytes,0,$combined,$bom.Length,$bytes.Length)
      [IO.File]::WriteAllBytes($LogPath,$combined)
    }
  }catch{}
}
function Write-WatchdogLog([string]$Text){
  try{Ensure-LogUtf8Bom;[IO.File]::AppendAllText($LogPath,((Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff')+' Watchdog: '+$Text+[Environment]::NewLine),(New-Object Text.UTF8Encoding($false)))}catch{}
}
function Test-Port([int]$Port,[int]$Timeout=350){
  $c=New-Object Net.Sockets.TcpClient
  try{
    $r=$c.BeginConnect('127.0.0.1',$Port,$null,$null)
    if(-not$r.AsyncWaitHandle.WaitOne([Math]::Max(100,$Timeout))){return $false}
    $c.EndConnect($r);return $true
  }catch{return $false}finally{try{$c.Close()}catch{}}
}
function Get-ReadyProxyPort{
  foreach($p in $ProxyPorts){if(Test-Port $p 150){return [int]$p}}
  return 0
}
function Get-BridgeHealth([int]$TimeoutMs=1400){
  $client=New-Object Net.Sockets.TcpClient
  try{
    $async=$client.BeginConnect('127.0.0.1',$BridgePort,$null,$null)
    if(-not$async.AsyncWaitHandle.WaitOne([Math]::Max(300,$TimeoutMs))){return $null}
    $client.EndConnect($async)
    $client.ReceiveTimeout=[Math]::Max(500,$TimeoutMs)
    $client.SendTimeout=[Math]::Max(500,$TimeoutMs)
    $stream=$client.GetStream()
    $request="GET /health HTTP/1.1`r`nHost: 127.0.0.1:$BridgePort`r`nConnection: close`r`n`r`n"
    $requestBytes=[Text.Encoding]::ASCII.GetBytes($request)
    $stream.Write($requestBytes,0,$requestBytes.Length);$stream.Flush()
    $ms=New-Object IO.MemoryStream
    $buffer=New-Object byte[] 4096
    while($ms.Length-lt65536){
      try{$read=$stream.Read($buffer,0,$buffer.Length)}catch{break}
      if($read-le0){break}
      $ms.Write($buffer,0,$read)
    }
    $text=[Text.Encoding]::UTF8.GetString($ms.ToArray())
    $split=$text.IndexOf("`r`n`r`n")
    if($split-lt0){return $null}
    $head=$text.Substring(0,$split)
    if($head-notmatch '^HTTP/1\.[01]\s+200\b'){return $null}
    $body=$text.Substring($split+4).Trim()
    if([string]::IsNullOrWhiteSpace($body)){return $null}
    return ($body|ConvertFrom-Json -ErrorAction Stop)
  }catch{return $null}finally{try{$client.Close()}catch{}}
}
function Test-ExpectedHealth($Health){
  if($null-eq$Health){return $false}
  if($Health.ok-ne$true){return $false}
  if([string]$Health.helperVersion-ne$ExpectedHelperVersion){return $false}
  if([string]$Health.buildMarker-ne$ExpectedBuildMarker){return $false}
  $proxy=0;try{$proxy=[int]$Health.proxyPort}catch{}
  if($proxy-lt30766-or$proxy-gt30769){return $false}
  if($Health.proxyReady-ne$true){return $false}
  return (Test-Port $proxy 180)
}
function Test-CompatibleLegacyHealth($Health){
  if($null-eq$Health -or $Health.ok-ne$true -or $Health.proxyReady-ne$true){return $false}
  $proxy=0;try{$proxy=[int]$Health.proxyPort}catch{}
  if(($proxy -lt 30766) -or ($proxy -gt 30769) -or (-not(Test-Port $proxy 180))){return $false}
  try{$version=[version]([string]$Health.helperVersion)}catch{return $false}
  return ($version -gt [version]$ExpectedHelperVersion)
}
function Get-ListenerPids([int]$Port){
  $found=New-Object System.Collections.Generic.List[int]
  try{
    $rows=@(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)
    foreach($row in $rows){
      $pidValue=[int]$row.OwningProcess
      if($pidValue-gt0 -and -not$found.Contains($pidValue)){$found.Add($pidValue)}
    }
  }catch{}
  try{
    foreach($line in @(& "$env:SystemRoot\System32\netstat.exe" -ano -p tcp 2>$null)){
      $m=[regex]::Match([string]$line,'^\s*TCP\s+\S+:'+([regex]::Escape([string]$Port))+'\s+\S+\s+LISTENING\s+(\d+)\s*$','IgnoreCase')
      if($m.Success){
        $pidValue=[int]$m.Groups[1].Value
        if($pidValue-gt0 -and -not$found.Contains($pidValue)){$found.Add($pidValue)}
      }
    }
  }catch{}
  return @($found|Sort-Object -Unique)
}
function Test-AnyDedicatedPortOpen{
  if(@(Get-ListenerPids $BridgePort).Count-gt0){return $true}
  foreach($p in $ProxyPorts){if(@(Get-ListenerPids $p).Count-gt0){return $true}}
  return $false
}
function Wait-AllDedicatedPortsClosed([int]$Milliseconds=10000){
  $deadline=(Get-Date).AddMilliseconds([Math]::Max(1000,$Milliseconds))
  while((Get-Date)-lt$deadline){if(-not(Test-AnyDedicatedPortOpen)){return $true};Start-Sleep -Milliseconds 120}
  return (-not(Test-AnyDedicatedPortOpen))
}
function Stop-BridgeProcesses{
  Get-CimInstance Win32_Process -Filter "Name='SpxNetworkHost.exe'" -ErrorAction SilentlyContinue|ForEach-Object{
    try{Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue|Out-Null}catch{}
  }
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue|Where-Object{
    ([string]$_.CommandLine -like '*run-network-host.ps1*') -and ([string]$_.CommandLine -like '*-HttpServer*')
  }|ForEach-Object{try{Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue|Out-Null}catch{}}
}
function Stop-BridgeTaskAndWait{
  try{Stop-ScheduledTask -TaskName $BridgeTaskName -ErrorAction SilentlyContinue}catch{}
  if(Wait-AllDedicatedPortsClosed 7000){return $true}
  Stop-BridgeProcesses
  return (Wait-AllDedicatedPortsClosed 4000)
}
function Test-RunningAsSystem{
  try{return ([Security.Principal.WindowsIdentity]::GetCurrent().User.Value -eq 'S-1-5-18')}catch{return $false}
}
function Start-BridgeSingle{
  $scheduledStarted=$false
  try{
    $task=Get-ScheduledTask -TaskName $BridgeTaskName -ErrorAction Stop
    Start-ScheduledTask -TaskName $BridgeTaskName -ErrorAction Stop
    $scheduledStarted=$true
    # v4.1.80: 오래된/깨진 BridgeTask가 /Run 자체는 성공하지만 실제 30765 프로세스를
    # 열지 않는 경우가 있었습니다. SYSTEM recovery task 안에서는 1.8초만 실제 포트를 확인하고
    # 현재 설치된 exe를 직접 1회 기동합니다. 동시에 늦게 뜬 task 인스턴스는 Global mutex가 차단합니다.
    $quickDeadline=(Get-Date).AddMilliseconds(1800)
    while((Get-Date)-lt$quickDeadline){
      Start-Sleep -Milliseconds 180
      $health=Get-BridgeHealth 650
      if(Test-ExpectedHealth $health){return 'scheduled-task'}
      if(Test-AnyDedicatedPortOpen){return 'scheduled-task-ports-opening'}
    }
  }catch{}
  if(Test-RunningAsSystem){
    Start-Process -FilePath $ExePath -ArgumentList '--http-server' -WorkingDirectory $InstallDir -WindowStyle Hidden|Out-Null
    return $(if($scheduledStarted){'scheduled-task+system-direct-fallback'}else{'system-direct-fallback'})
  }
  if($scheduledStarted){return 'scheduled-task-pending'}
  throw 'SYSTEM 브리지 예약작업을 시작하지 못했고 현재 프로세스도 SYSTEM이 아니어서 직접 기동을 중단했습니다.'
}

if(-not(Test-Path $ExePath)){throw 'SmartPage Ex network helper is not installed. Run install-network-host.cmd first.'}

$health=Get-BridgeHealth 1800
if(-not(Test-ExpectedHealth $health)){
  # USB/RNDIS 재연결 중 Windows가 순간적으로 바빠도 한 번의 health 지연만으로 helper를 죽이지 않습니다.
  foreach($delay in @(450,900)){Start-Sleep -Milliseconds $delay;$health=Get-BridgeHealth 1800;if(Test-ExpectedHealth $health){break}}
}
if(Test-ExpectedHealth $health){
  if(-not$Silent){Write-Host ('Network helper is healthy. PID '+[string]$health.pid+' · Proxy '+[string]$health.proxyPort) -ForegroundColor Green}
  exit 0
}
if(Test-CompatibleLegacyHealth $health){
  Write-WatchdogLog ('compatible legacy bridge retained; helper='+[string]$health.helperVersion+'/'+[string]$health.buildMarker+'; deferred installer will upgrade after Windows restart')
  if(-not$Silent){Write-Host ('Compatible older network helper '+[string]$health.helperVersion+' is still serving the dedicated proxy. Forced restart was skipped; restart Windows once to finish the 3.0.45 bridge update.') -ForegroundColor Yellow}
  exit 0
}

$portsOpen=Test-AnyDedicatedPortOpen
if($portsOpen){
  $version=if($null-ne$health){[string]$health.helperVersion}else{'no-health'}
  $marker=if($null-ne$health){[string]$health.buildMarker}else{'no-health'}
  Write-WatchdogLog ('unhealthy bridge detected; health='+$version+'/'+$marker+'; stopping SYSTEM bridge task before restart')
  if(-not(Stop-BridgeTaskAndWait)){
    Write-WatchdogLog 'restart deferred: old bridge ports are still occupied after scheduled-task stop and process cleanup; duplicate startup blocked'
    if(-not$Silent){Write-Host 'Network helper is unresponsive, but its ports are still occupied. Duplicate startup was blocked. Restart Windows if this state persists.' -ForegroundColor Yellow}
    exit 2
  }
}
else{Stop-BridgeProcesses|Out-Null}

$startMode=Start-BridgeSingle
$deadline=(Get-Date).AddSeconds(12)
do{
  Start-Sleep -Milliseconds 180
  $health=Get-BridgeHealth 1200
  if(Test-ExpectedHealth $health){
    Write-WatchdogLog ('bridge recovered; start='+$startMode+'; pid='+[string]$health.pid+'; proxy='+[string]$health.proxyPort)
    if(-not$Silent){Write-Host ('Network helper recovered. PID '+[string]$health.pid+' · Proxy '+[string]$health.proxyPort) -ForegroundColor Green}
    exit 0
  }
}while((Get-Date)-lt$deadline)

if(Test-AnyDedicatedPortOpen){Write-WatchdogLog 'restart started ports but expected /health did not recover; no duplicate retry attempted'}
else{Write-WatchdogLog 'restart failed to open bridge ports; no duplicate retry attempted'}
throw ('Network helper recovery did not reach the expected '+$ExpectedHelperVersion+' / '+$ExpectedBuildMarker+' /health state. No duplicate retry was attempted.')
