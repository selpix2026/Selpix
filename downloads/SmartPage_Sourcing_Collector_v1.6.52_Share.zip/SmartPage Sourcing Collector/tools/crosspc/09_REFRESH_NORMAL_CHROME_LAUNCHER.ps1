﻿param([switch]$Elevated,[switch]$Quiet)
$ErrorActionPreference='Stop'
try{$utf8=New-Object Text.UTF8Encoding($false);[Console]::InputEncoding=$utf8;[Console]::OutputEncoding=$utf8;$OutputEncoding=$utf8}catch{}
$TargetRoot=Join-Path $env:ProgramData 'SmartPageEx\SmartPage Sourcing Collector'
$ScriptCollectorRoot=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$CollectorRoot=if((Test-Path -LiteralPath (Join-Path $ScriptCollectorRoot 'manifest.json') -PathType Leaf) -and (Test-Path -LiteralPath (Join-Path $ScriptCollectorRoot 'tools\network-host\open-dedicated-window.ps1') -PathType Leaf)){$ScriptCollectorRoot}else{$TargetRoot}
$InstallDir=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$SourceLauncher=Join-Path $CollectorRoot 'tools\network-host\open-dedicated-window.ps1'
$InstalledLauncher=Join-Path $InstallDir 'open-dedicated-window.ps1'
$BrowserTaskName='SmartPageEx Open Dedicated Browser'
$Profile='C:\SpxDedicatedProfile'
$ReadyPath=Join-Path $InstallDir 'dedicated-window-launcher.ready'
$RequestPath=Join-Path $InstallDir 'dedicated-window-request.json'
$ResultPath=Join-Path $InstallDir 'dedicated-window-result.json'
function Test-Admin{$id=[Security.Principal.WindowsIdentity]::GetCurrent();$p=New-Object Security.Principal.WindowsPrincipal($id);return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}
function Get-Sha([string]$Path){return (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()}
if(-not(Test-Admin)){
  $args='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath.Replace('"','""')+'" -Elevated'+$(if($Quiet){' -Quiet'}else{''})
  $p=Start-Process "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Verb RunAs -ArgumentList $args -Wait -PassThru
  exit $p.ExitCode
}
if(-not(Test-Path -LiteralPath $SourceLauncher -PathType Leaf)){throw '현재 설치된 Collector의 전용창 launcher 원본을 찾지 못했습니다. RUN_00_INSTALL_OTHER_PC.cmd를 먼저 실행하세요.'}
if(-not(Test-Path -LiteralPath $InstallDir -PathType Container)){throw 'NetworkHostV33 설치 폴더를 찾지 못했습니다. RUN_00_INSTALL_OTHER_PC.cmd를 먼저 실행하세요.'}
$sourceText=Get-Content -LiteralPath $SourceLauncher -Raw -Encoding UTF8
if($sourceText -match '--load-extension=' -or $sourceText -match '--disable-extensions-except='){throw '현재 패키지의 일반 Chrome launcher에 더 이상 사용하면 안 되는 확장 자동로드 옵션이 남아 있습니다.'}
if($sourceText -notmatch 'NORMAL_CHROME_V1514'){throw '현재 패키지의 일반 Chrome launcher 표식을 확인하지 못했습니다.'}
if(-not$Quiet){Write-Host '일반 Chrome 전용창 launcher를 현재 패키지 기준으로 복구합니다.' -ForegroundColor Cyan}
# Close only SmartPage dedicated Chrome. Personal Chrome stays open.
try{
  $targets=@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" -ErrorAction SilentlyContinue|Where-Object{[string]$_.CommandLine -like ('*'+$Profile+'*')})
  foreach($proc in $targets){try{Stop-Process -Id ([int]$proc.ProcessId) -Force -ErrorAction Stop}catch{}}
  if($targets.Count){Start-Sleep -Milliseconds 700}
}catch{}
# Stop and remove any already-running old watcher process before replacing its script.
try{Stop-ScheduledTask -TaskName $BrowserTaskName -ErrorAction SilentlyContinue}catch{}
try{
  $installPattern=[regex]::Escape($InstallDir)
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue|Where-Object{
    $_.ProcessId-ne$PID -and [string]$_.CommandLine-match$installPattern -and [string]$_.CommandLine-match'open-dedicated-window\.ps1'
  }|ForEach-Object{try{Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue}catch{}}
}catch{}
Start-Sleep -Milliseconds 250
Copy-Item -LiteralPath $SourceLauncher -Destination $InstalledLauncher -Force
if((Get-Sha $SourceLauncher)-ne(Get-Sha $InstalledLauncher)){throw 'ProgramData 전용창 launcher 파일 동기화 검증에 실패했습니다.'}
$installedText=Get-Content -LiteralPath $InstalledLauncher -Raw -Encoding UTF8
if($installedText -match '--load-extension=' -or $installedText -match '--disable-extensions-except='){throw 'ProgramData 전용창 launcher에 구형 확장 자동로드 옵션이 남아 있습니다.'}
foreach($p in @($ReadyPath,$RequestPath,$ResultPath)){Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue}
$task=Get-ScheduledTask -TaskName $BrowserTaskName -ErrorAction SilentlyContinue
if($null-eq$task){throw '전용창 launcher 예약작업이 없습니다. RUN_00_INSTALL_OTHER_PC.cmd를 다시 실행하세요.'}
$action=$task.Actions|Select-Object -First 1
$arg=[string]$action.Arguments
if($arg -notmatch '(?i)open-dedicated-window\.ps1' -or $arg -notmatch '(?i)(^|\s)-Watch(\s|$)'){throw '전용창 launcher 예약작업이 현재 구조와 맞지 않습니다. RUN_00_INSTALL_OTHER_PC.cmd를 다시 실행하세요.'}
Start-ScheduledTask -TaskName $BrowserTaskName -ErrorAction Stop
$ready=$null
for($i=0;$i-lt40;$i++){
  Start-Sleep -Milliseconds 250
  if(Test-Path -LiteralPath $ReadyPath){try{$ready=Get-Content -LiteralPath $ReadyPath -Raw|ConvertFrom-Json}catch{$ready=$null}}
  if($null-ne$ready -and [int]$ready.pid -gt0){try{$null=Get-Process -Id ([int]$ready.pid) -ErrorAction Stop;break}catch{$ready=$null}}
}
if($null-eq$ready -or [int]$ready.pid -le0){throw '새 일반 Chrome 전용창 launcher watcher가 시작되지 않았습니다.'}
if(-not$Quiet){Write-Host ('✅ 일반 Chrome 전용창 launcher 복구 완료 · PID '+[string]$ready.pid) -ForegroundColor Green}
exit 0
