// Read-only regression probes: evaluate original functions with fake browser/native APIs.
// No extension is installed, no remote request is sent, no mobile command is executed.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const test = require('node:test');
const acorn = require('acorn');
const root = require('node:path').resolve(__dirname,'..') + '/';
const cache = new Map();
function original(file, name) {
  if (!cache.has(file)) {
    const source = fs.readFileSync(root + file, 'utf8');
    const tree = acorn.parse(source, {ecmaVersion:'latest', sourceType:'script'});
    const functions = new Map();
    function walk(node) {
      if (!node || typeof node !== 'object') return;
      if (node.type === 'FunctionDeclaration' && node.id) functions.set(node.id.name, source.slice(node.start,node.end));
      for (const [key,value] of Object.entries(node)) {
        if (key === 'start' || key === 'end') continue;
        if (Array.isArray(value)) value.forEach(walk); else if (value && typeof value === 'object') walk(value);
      }
    }
    walk(tree); cache.set(file, functions);
  }
  const result=cache.get(file).get(name); assert.ok(result, name); return result;
}
const core='src/background/service-worker-core.js';
const content='src/content/coupang-search.js';
function context(functions, stubs={}) {
  const ctx=vm.createContext({console,URL,...stubs});
  for (const [file,name] of functions) vm.runInContext(original(file,name),ctx);
  return ctx;
}

test('ordinary connectivity failures never request an IP change',async()=>{
  let resetCalls=0;
  const ctx=context([[core,'recordConnectivityFailure']],{
    isRecoverableConnectivityError:()=>true,connectivityErrorCode:()=> 'NETWORK_TIMEOUT',
    getAuto:async()=>({running:true,runId:'r',currentKeyword:'텀블러',collectionNetworkTarget:'window'}),
    activeCollectionNetworkTargetV135:async()=> 'window',
    readConnectivityRecoveryState:async()=>({}),writeConnectivityRecoveryState:async()=>({}),
    spxConnectivityRecoveryPromise:null,connectivityRecoveryStatusActive:()=>false,
    spxConnectivityFailureTimes:[Date.now(),Date.now()],
    SPX_CONNECTIVITY_FAILURE_WINDOW_MS:120000,SPX_CONNECTIVITY_FAILURE_THRESHOLD:3,
    searchUrl:()=> 'https://www.coupang.com/np/search?q=test',
    startCoupangBlockConnectivityResetRequest:async()=>{resetCalls++;return{ok:true};},
  });
  const result=await ctx.recordConnectivityFailure(new Error('timeout'),{url:'https://www.coupang.com/np/search?q=test'});
  assert.equal(resetCalls,0);assert.equal(result.networkReset,false);
});

test('block detection enters the same manual IP request function', async()=>{
  const calls=[];
  const ctx=context([[core,'startCoupangBlockConnectivityResetRequest']],{
    getAuto:async()=>({runId:'r',currentKeyword:'텀블러'}),
    readConnectivityRecoveryState:async()=>({}), connectivityRecoveryStatusActive:()=>false,
    startManualIpChangeRequest:async(message)=>{calls.push(message);return{ok:true};},
  });
  const result=await ctx.startCoupangBlockConnectivityResetRequest({keyword:'텀블러'},{});
  assert.equal(result.ok,true); assert.equal(calls.length,1);
  assert.equal(calls[0].type,'SPX_NETWORK_MANUAL_IP_CHANGE');
  assert.equal(calls[0].autoTriggeredByBlock,true);
});

function manualRequestContext(overrides={}){
  let stored={status:'completed',hostPhase:'public-ip-confirmed',publicIp:'old',holdUntil:999,siteCleanup:{pendingWingRecovery:['wing-journal']}};
  const starts=[];
  const ctx=context([[core,'startManualIpChangeRequest']],{
    crypto:require('node:crypto').webcrypto,spxManualIpRequestPromise:null,spxConnectivityRecoveryPromise:null,spxConnectivityRecoveryEpoch:0,
    getAuto:async()=>({running:true,runId:'r',currentKeyword:'텀블러',currentPage:1,automationTabId:7}),
    readConnectivityRecoveryState:async()=>({...stored}),
    writeConnectivityRecoveryState:async(patch,options={})=>{stored={...(options.replace?{}:stored),...patch};return stored;},
    activeCollectionNetworkTargetV135:async()=> 'window',connectivityRecoveryStatusActive:s=>['resetting','finalizing'].includes(s),
    getCollectionNetworkStatus:async()=>({strictIsolationOk:true,publicIp:'before'}),dedicatedBlockNetworkEligible:()=>true,
    norm:s=>s,triggerMobileConnectivityReset:async(...args)=>{starts.push(args);},errorText:e=>String(e),
    chrome:{runtime:{getManifest:()=>({version:'1.6.51'})}},...overrides,
  });
  return{ctx,starts,state:()=>stored};
}

test('concurrent block and button requests acquire one owner and clear stale telemetry',async()=>{
  const {ctx,starts,state}=manualRequestContext();
  const [a,b]=await Promise.all([
    ctx.startManualIpChangeRequest({keyword:'텀블러',autoTriggeredByBlock:true}),
    ctx.startManualIpChangeRequest({keyword:'텀블러'}),
  ]);
  assert.equal(a.started,true);assert.equal(b.started,true);assert.equal(starts.length,1);
  assert.equal(state().hostPhase,'');assert.equal(state().publicIp,'');assert.equal(state().holdUntil,0);
  assert.deepEqual(state().siteCleanup.pendingWingRecovery,['wing-journal']);
});

test('same failed block requires a manual click, never another automatic attempt',async()=>{
  const {ctx,starts}=manualRequestContext({readConnectivityRecoveryState:async()=>({status:'failed',incidentIdentity:'r|텀블러|1|7',blockAttempted:true})});
  const response=await ctx.startManualIpChangeRequest({keyword:'텀블러',autoTriggeredByBlock:true});
  assert.equal(response.recoveryGuarded,true);assert.equal(response.autoResume,false);assert.equal(starts.length,0);
});

test('stop while network readiness awaits cancels the manual request before side effects',async()=>{
  let release;
  const gate=new Promise(resolve=>{release=resolve;});
  const {ctx,starts}=manualRequestContext({getCollectionNetworkStatus:()=>gate});
  const response=ctx.startManualIpChangeRequest({keyword:'텀블러'});
  await new Promise(resolve=>setImmediate(resolve));
  ctx.spxConnectivityRecoveryEpoch++;
  release({strictIsolationOk:true});
  assert.equal((await response).cancelled,true);assert.equal(starts.length,0);
});

test('an old native completed state cannot certify a new recovery incident',()=>{
  const ctx=context([[core,'mobileResetTimeMs'],[core,'nativeStatusMatchesRecovery']]);
  assert.equal(ctx.nativeStatusMatchesRecovery({status:'completed',ipChanged:true,startedAt:'2026-11-05T12:00:00Z'},{nativeRequestedAt:Date.parse('2026-11-05T12:01:00Z')}),false);
  assert.equal(ctx.nativeStatusMatchesRecovery({status:'completed',ipChanged:true,startedAt:'2026-11-05T12:01:01Z'},{nativeRequestedAt:Date.parse('2026-11-05T12:01:00Z')}),true);
});

test('new recovery stages must override telemetry left by previous IP recovery',()=>{
  const ctx=context([[content,'recoveryStepIndexV102']]);
  const expected={'block-detected':0,'stopped':1,'memory-cleanup':2,'site-cleanup':3,'airplane-prepare':4};
  const actual=Object.fromEntries(Object.keys(expected).map(phase=>[phase,ctx.recoveryStepIndexV102({status:'resetting',phase,hostPhase:'public-ip-confirmed'})]));
  assert.deepEqual(actual,expected);
});

test('inactive block retry loop must not schedule itself again',async()=>{
  const queued=[];
  const ctx=context([[core,'runBlockRetryLoopV125R1']],{
    spxBlockRetryInFlightV1650:null,spxConnectivityRecoveryPromise:null,
    readBlockRetryLoopV125R1:async()=>({active:false}),
    queueBlockRetryWhenIdleV1650:(...args)=>queued.push(args),
  });
  const result=await ctx.runBlockRetryLoopV125R1('probe');
  assert.equal(result.reason,'inactive'); assert.equal(queued.length,0);
});

test('stop during retry preflight must prevent the pending IP retry dispatch',async()=>{
  const dispatched=[];
  let liveAuto={running:true,runId:'r',currentKeyword:'텀블러',automationTabId:7};
  const loop={active:true,identity:'r|텀블러',runId:'r',keyword:'텀블러',tabId:7,page:1};
  const ctx=context([[core,'runBlockRetryLoopV125R1']],{
    spxBlockRetryInFlightV1650:null,spxConnectivityRecoveryPromise:null,
    readBlockRetryLoopV125R1:async()=>loop,
    getAuto:async()=>({...liveAuto}),
    blockRetryIdentityV125R1:({runId,keyword})=>`${runId}|${keyword}`,
    activeCollectionNetworkTargetV135:async()=> 'window',
    clearBlockRetryLoopV125R1:async()=>{},
    readConnectivityRecoveryState:async()=>({status:'idle'}),connectivityRecoveryStatusActive:()=>false,
    sendNetworkNativeMessage:async()=>{
      // The user stops while the native status request is outstanding.
      // automationStop invalidates runId and clears currentKeyword in the real source.
      liveAuto={running:false,runId:'invalidated-r',currentKeyword:'',automationTabId:null};
      return{ok:true,running:false};
    },
    probeAutomationTabForSameDocumentRecovery:async()=>({reusable:false,response:{blocked:true}}),
    getCollectionNetworkStatus:async()=>({mode:'window',proxyReady:true}),
    dedicatedBlockNetworkEligible:()=>true,
    writeBlockRetryLoopV125R1:async value=>value,
    startManualIpChangeRequest:async value=>{dispatched.push(value);return{ok:true};},
    queueBlockRetryWhenIdleV1650:()=>{},
  });
  await ctx.runBlockRetryLoopV125R1('probe');
  assert.equal(dispatched.length,0);
});

test('a failed recommendation detail fetch must never mark card data as verified',async()=>{
  const ctx=vm.createContext({
    console,URL,URLSearchParams,AbortController,setTimeout,clearTimeout,
    location:{href:'https://www.coupang.com/np/search?q=텀블러',origin:'https://www.coupang.com'},
    SPX:{util:{parseNum:v=>Number(String(v??'').replace(/[^0-9.]/g,'')),getSettings:async()=>({humanDelayEnabled:false})}},
    fetch:async()=>({ok:false,status:500}),
  });
  vm.runInContext(fs.readFileSync(root+'src/content/coupang-parser.js','utf8'),ctx);
  const input=[{pid:'1',name:'텀블러',rocketType:'일반배송',price:10000,reviews:20,
    comparisonProducts:[{pid:'2',name:'텀블러',rocketType:'일반배송',price:10000,reviews:20,productUrl:'https://www.coupang.com/vp/products/2'}]}];
  const result=await ctx.SPX.enrichProductDetails(input,{keyword:'텀블러',collectComparisonCandidates:true});
  assert.equal(result.filter(r=>r.recommendationVerified===true).length,0);
});

test('missing normal-page response alone must not be treated as confirmed repeated blocking',async()=>{
  let clock=100000;const scheduled=[];
  const checkpoint={wasRunning:true,runId:'r',keyword:'텀블러',page:1,automationTabId:7,searchUrl:'https://www.coupang.com/np/search?q=텀블러'};
  const ctx=context([[core,'triggerMobileConnectivityReset']],{
    Date:{now:()=>clock},spxConnectivityRecoveryPromise:null,spxConnectivityRecoveryEpoch:0,
    spxConnectivityFailureTimes:[],readConnectivityRecoveryState:async()=>({}),
    writeConnectivityRecoveryState:async patch=>patch,
    pauseAutomationForConnectivityReset:async()=>checkpoint,
    spxSharedManualAirplaneTimingV1649:async()=>({airplaneHoldMs:20000,airplaneHoldSeconds:20}),
    performMemoryCleanup:async()=>({ok:true}),
    clearTargetSiteStorage:async()=>({verified:true,wingRecoveryCleanup:{ok:true}}),
    setAutoForRun:async()=>({}),
    runMobileResetWithVerifiedStart:async()=>({ok:true,completed:true,ipChanged:true}),
    isMobileResetAlreadyRunningResponse:()=>false,
    chrome:{alarms:{clear:async()=>true}},SPX_LEGACY_CONNECTIVITY_RESUME_ALARM:'legacy',
    reloadAutomationTabAfterConnectivityRecovery:async()=>({tabId:7,url:checkpoint.searchUrl}),
    probeAutomationTabForSameDocumentRecovery:async()=>({ok:false,reusable:false,error:'content script not ready'}),
    spxSleep:async ms=>{clock+=ms;},
    scheduleBlockRetryLoopV125R1:async data=>{scheduled.push(data);return{retryAt:clock};},
    queueBlockRetryWhenIdleV1650:()=>{},errorText:error=>String(error?.message||error),
  });
  const result=await ctx.triggerMobileConnectivityReset('MANUAL_IP_CHANGE',checkpoint,{manual:true});
  assert.equal(result.blockedAfterRefresh,false);
  assert.equal(scheduled.length,0);
});

test('history export must retain the initial filter throughout pagination',async()=>{
  let view='completed',term='텀블러'; const requests=[];
  const ctx=context([['src/history/history.js','eachFilteredRow']],{
    view,searchTerm:()=>term,decorate:data=>data.rows,setTimeout:fn=>{fn();return 1;},
    msg:async(type,args)=>{
      requests.push({...args});
      if(requests.length===1){ctx.view='failed';term='우산';return{rows:[{keyword:'텀블러'}],hasMore:true};}
      return{rows:[{keyword:'우산'}],hasMore:false};
    },
  });
  await ctx.eachFilteredRow(async()=>{});
  assert.equal(requests.length,2);
  assert.deepEqual(requests.map(r=>({view:r.view,search:r.search})),[
    {view:'completed',search:'텀블러'},{view:'completed',search:'텀블러'},
  ]);
});
