﻿param(
  [switch]$Watch,
  [string]$RequestFile = ''
)

$ErrorActionPreference = 'Stop'

$BaseDir = if ([string]::IsNullOrWhiteSpace($RequestFile)) { Split-Path -Parent $PSCommandPath } else { Split-Path -Parent ([IO.Path]::GetFullPath($RequestFile)) }
$RequestPath = Join-Path $BaseDir 'dedicated-window-request.json'
$ResultPath = Join-Path $BaseDir 'dedicated-window-result.json'
$ReadyPath = Join-Path $BaseDir 'dedicated-window-launcher.ready'
$LogPath = Join-Path $BaseDir 'dedicated-window-launch.log'

function Write-LaunchLog {
  param([string]$Message)
  try {
    Add-Content -LiteralPath $LogPath -Encoding UTF8 -Value ((Get-Date).ToString('o') + ' ' + $Message)
  } catch { }
}

function Write-JsonAtomic {
  param([string]$Path, [object]$Value)
  $temp = $Path + '.tmp'
  $json = $Value | ConvertTo-Json -Depth 8 -Compress
  [System.IO.File]::WriteAllText($temp, $json, (New-Object System.Text.UTF8Encoding($false)))
  Move-Item -LiteralPath $temp -Destination $Path -Force
}

function Quote-Argument {
  param([string]$Value)
  if ($null -eq $Value) { $Value = '' }
  return '"' + ($Value -replace '"', '\"') + '"'
}

function Resolve-BrowserLaunch {
  param([object]$Request)
  # NORMAL_CHROME_V1514 compatibility: use the installed browser, never testing builds.
  $family = ([string]$Request.browserFamily).Trim().ToLowerInvariant()
  if ([string]::IsNullOrWhiteSpace($family)) { $family = 'chrome' }
  if ($family -notin @('chrome','whale')) { throw ('Unsupported browser family: ' + $family) }
  $exe = if ($family -eq 'whale') { 'whale.exe' } else { 'chrome.exe' }
  $relative = if ($family -eq 'whale') { 'Naver\Naver Whale\Application\whale.exe' } else { 'Google\Chrome\Application\chrome.exe' }
  $profile = if ($family -eq 'whale') { 'C:\SpxDedicatedProfile-Whale' } else { 'C:\SpxDedicatedProfile' }
  $userDataRelative = if ($family -eq 'whale') { 'Naver\Naver Whale\User Data' } else { 'Google\Chrome\User Data' }
  $candidates = New-Object System.Collections.Generic.List[string]
  foreach ($prefix in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\','HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\')) {
    try { $value=[string](Get-Item -LiteralPath ($prefix+$exe) -ErrorAction Stop).GetValue(''); if($value){$candidates.Add($value.Trim('"'))} } catch { }
  }
  foreach ($base in @($env:LOCALAPPDATA,$env:ProgramFiles,${env:ProgramFiles(x86)})) {
    if (-not [string]::IsNullOrWhiteSpace($base)) { $candidates.Add((Join-Path $base $relative)) }
  }
  try { $cmd=Get-Command $exe -ErrorAction Stop; if($cmd.Source){$candidates.Add([string]$cmd.Source)} } catch { }
  foreach ($candidate in $candidates) {
    if ((Test-Path -LiteralPath $candidate -PathType Leaf) -and [string]::Equals([IO.Path]::GetFileName($candidate),$exe,[StringComparison]::OrdinalIgnoreCase)) {
      return [pscustomobject]@{Family=$family;Executable=$exe;Path=[IO.Path]::GetFullPath($candidate);Profile=$profile;UserData=(Join-Path $env:LOCALAPPDATA $userDataRelative)}
    }
  }
  throw ($family + ' executable was not found. Install or repair that browser; no other browser was substituted.')
}

function Get-ExtensionFingerprint {
  param([string]$ExtensionRoot)
  if ([string]::IsNullOrWhiteSpace($ExtensionRoot)) { return '' }
  # Content hashes detect overwritten files even when a repaired package keeps its version.
  $rows = New-Object System.Collections.Generic.List[string]
  foreach ($relative in @('manifest.json','src','tools\network-host\open-dedicated-window.ps1')) {
    $target=Join-Path $ExtensionRoot $relative
    if (-not (Test-Path -LiteralPath $target)) { continue }
    foreach ($file in @(Get-ChildItem -LiteralPath $target -File -Recurse -ErrorAction Stop | Sort-Object FullName)) {
      $rows.Add($file.FullName.Substring($ExtensionRoot.Length) + ':' + (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash)
    }
  }
  $sha=[Security.Cryptography.SHA256]::Create()
  try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes(($rows -join "`n"))))).Replace('-','').ToLowerInvariant() } finally { $sha.Dispose() }
}

function Test-TcpPort {
  param([int]$Port, [int]$Timeout = 1000)
  $client = New-Object System.Net.Sockets.TcpClient
  try {
    $result = $client.BeginConnect('127.0.0.1', $Port, $null, $null)
    if (-not $result.AsyncWaitHandle.WaitOne($Timeout)) { return $false }
    $client.EndConnect($result)
    return $true
  }
  catch { return $false }
  finally { try { $client.Close() } catch { } }
}

function Resolve-CandidateExtensionPath {
  param([string]$PathValue, [string]$BasePath)
  if ([string]::IsNullOrWhiteSpace($PathValue)) { return $null }
  try {
    $candidate = [Environment]::ExpandEnvironmentVariables($PathValue.Trim().Trim('"'))
    if (-not [IO.Path]::IsPathRooted($candidate) -and -not [string]::IsNullOrWhiteSpace($BasePath)) {
      $candidate = Join-Path $BasePath $candidate
    }
    $candidate = [IO.Path]::GetFullPath($candidate)
    if (Test-Path -LiteralPath (Join-Path $candidate 'manifest.json')) { return $candidate }
  } catch { }
  return $null
}

function Get-ExtensionPathFromPreferenceFile {
  param([string]$PreferencePath, [string]$ExtensionId)
  if ([string]::IsNullOrWhiteSpace($PreferencePath) -or -not (Test-Path -LiteralPath $PreferencePath)) { return $null }
  try {
    $preference = Get-Content -LiteralPath $PreferencePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    $settings = $preference.extensions.settings
    if ($null -eq $settings) { return $null }
    $property = $settings.PSObject.Properties[$ExtensionId]
    if ($null -eq $property -or $null -eq $property.Value) { return $null }
    $storedPath = [string]$property.Value.path
    if ([string]::IsNullOrWhiteSpace($storedPath)) { return $null }
    return Resolve-CandidateExtensionPath -PathValue $storedPath -BasePath (Split-Path -Parent $PreferencePath)
  } catch { return $null }
}

function Resolve-DedicatedProfileExtensionRoot {
  param([string]$ProfileDir, [string]$ExtensionId)
  if ([string]::IsNullOrWhiteSpace($ProfileDir) -or [string]::IsNullOrWhiteSpace($ExtensionId)) { return $null }
  foreach ($fileName in @('Secure Preferences','Preferences')) {
    $preferencePath = Join-Path $ProfileDir ('Default\' + $fileName)
    if (-not (Test-Path -LiteralPath $preferencePath -PathType Leaf)) { continue }
    try {
      $preference = Get-Content -LiteralPath $preferencePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
      $settings = $preference.extensions.settings
      if ($null -eq $settings) { continue }
      $property = $settings.PSObject.Properties[$ExtensionId]
      if ($null -eq $property -or $null -eq $property.Value) { continue }
      $entry = $property.Value
      $state = 0; $disableReasons = 0
      try { $state = [int]$entry.state } catch { $state = 0 }
      try { $disableReasons = [int64]$entry.disable_reasons } catch { $disableReasons = 0 }
      if ($state -ne 1 -or $disableReasons -ne 0) { continue }
      $found = Get-ExtensionPathFromPreferenceFile -PreferencePath $preferencePath -ExtensionId $ExtensionId
      if (-not [string]::IsNullOrWhiteSpace($found)) { return $found }
    } catch { }
  }
  return $null
}

function Resolve-SmartPageExtensionRoot {
  param([object]$Request, [object]$Browser)
  $candidates = New-Object System.Collections.Generic.List[string]
  $requestedRoot = [string]$Request.extensionRoot
  if (-not [string]::IsNullOrWhiteSpace($requestedRoot)) { $candidates.Add($requestedRoot) }

  $extensionId = ([string]$Request.extensionId).Trim().ToLowerInvariant()
  if ($extensionId -match '^[a-p]{32}$') {
    $chromeUserData = [string]$Browser.UserData
    if (Test-Path -LiteralPath $chromeUserData) {
      $profileDirs = @()
      $defaultProfile = Join-Path $chromeUserData 'Default'
      if (Test-Path -LiteralPath $defaultProfile) { $profileDirs += Get-Item -LiteralPath $defaultProfile }
      $profileDirs += Get-ChildItem -LiteralPath $chromeUserData -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'Profile *' }
      foreach ($profile in $profileDirs) {
        foreach ($fileName in @('Secure Preferences','Preferences')) {
          $found = Get-ExtensionPathFromPreferenceFile -PreferencePath (Join-Path $profile.FullName $fileName) -ExtensionId $extensionId
          if (-not [string]::IsNullOrWhiteSpace($found)) { $candidates.Add($found) }
        }
      }
    }
  }

  foreach ($candidate in $candidates) {
    $resolved = Resolve-CandidateExtensionPath -PathValue $candidate -BasePath $null
    if (-not [string]::IsNullOrWhiteSpace($resolved)) { return $resolved }
  }
  return $null
}

function Add-SelectedNetworkMarker {
  param([string]$Url)
  try {
    $builder = New-Object System.UriBuilder -ArgumentList $Url
    $fragment = ([string]$builder.Fragment).TrimStart('#')
    if ($fragment -notmatch '(^|&)spx-selected-network(=1)?(&|$)') {
      $fragment = if ([string]::IsNullOrWhiteSpace($fragment)) { 'spx-selected-network=1' } else { $fragment + '&spx-selected-network=1' }
    }
    $builder.Fragment = $fragment
    return $builder.Uri.AbsoluteUri
  } catch { return $Url }
}

function Get-DedicatedChromeProcesses {
  param([string]$ProfileDir)
  if ([string]::IsNullOrWhiteSpace($ProfileDir)) { return @() }
  try {
    return @(Get-CimInstance Win32_Process -Filter ("Name='" + $script:BrowserExecutable + "'") -ErrorAction SilentlyContinue | Where-Object {
      -not [string]::IsNullOrWhiteSpace([string]$_.CommandLine) -and [string]$_.CommandLine -match ('(?i)(?:^|\s)--user-data-dir=(?:"' + [regex]::Escape($ProfileDir) + '"|' + [regex]::Escape($ProfileDir) + ')(?:\s|$)')
    })
  } catch { return @() }
}

function Stop-DedicatedChromeProcesses {
  param([string]$ProfileDir, [string]$Reason)
  $processes = @(Get-DedicatedChromeProcesses -ProfileDir $ProfileDir)
  if ($processes.Count -eq 0) { return $false }
  Write-LaunchLog ("Restarting stale dedicated Chrome runtime. Reason={0}; PIDs={1}" -f $Reason, (($processes | ForEach-Object { [string]$_.ProcessId }) -join ','))
  foreach ($process in $processes) {
    try { Stop-Process -Id ([int]$process.ProcessId) -ErrorAction SilentlyContinue } catch { }
  }
  for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Milliseconds 200
    if (@(Get-DedicatedChromeProcesses -ProfileDir $ProfileDir).Count -eq 0) { return $true }
  }
  foreach ($process in @(Get-DedicatedChromeProcesses -ProfileDir $ProfileDir)) {
    try { Stop-Process -Id ([int]$process.ProcessId) -Force -ErrorAction SilentlyContinue } catch { }
  }
  Start-Sleep -Milliseconds 500
  if (@(Get-DedicatedChromeProcesses -ProfileDir $ProfileDir).Count -gt 0) {
    throw 'The previous dedicated Chrome runtime could not be closed. Close the C:\SpxDedicatedProfile Chrome window and try again.'
  }
  return $true
}


function Clear-DedicatedRuntimeCaches {
  param([string]$ProfileDir)
  if ([string]::IsNullOrWhiteSpace($ProfileDir) -or -not (Test-Path -LiteralPath $ProfileDir)) { return }
  $targets = @(
    (Join-Path $ProfileDir 'Default\Service Worker'),
    (Join-Path $ProfileDir 'Default\Code Cache\js'),
    (Join-Path $ProfileDir 'Default\Code Cache\wasm'),
    (Join-Path $ProfileDir 'Default\GPUCache')
  )
  foreach ($target in $targets) {
    try { if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction Stop } } catch { Write-LaunchLog ('Runtime cache cleanup warning: ' + $_.Exception.Message) }
  }
  Write-LaunchLog 'Dedicated profile extension/service-worker runtime cache cleared.'
}

function Read-RuntimeMarker {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
  try { return Get-Content -LiteralPath $Path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop }
  catch { return $null }
}

function Resolve-ExtensionVersion {
  param([object]$Request, [string]$ExtensionRoot)
  # The overwritten package is authoritative, even when the caller has an older worker.
  if (-not [string]::IsNullOrWhiteSpace($ExtensionRoot)) {
    try {
      $manifest = Get-Content -LiteralPath (Join-Path $ExtensionRoot 'manifest.json') -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
      return ([string]$manifest.version).Trim()
    } catch { }
  }
  return ([string]$Request.extensionVersion).Trim()
}


function Test-DedicatedExtensionRegistered {
  param([string]$ProfileDir, [string]$ExtensionId, [string]$ExpectedRoot)
  if ([string]::IsNullOrWhiteSpace($ProfileDir) -or [string]::IsNullOrWhiteSpace($ExtensionId)) { return $false }
  foreach ($fileName in @('Secure Preferences','Preferences')) {
    $preferencePath = Join-Path $ProfileDir ('Default\' + $fileName)
    if (-not (Test-Path -LiteralPath $preferencePath -PathType Leaf)) { continue }
    try {
      $preference = Get-Content -LiteralPath $preferencePath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
      $settings = $preference.extensions.settings
      if ($null -eq $settings) { continue }
      $property = $settings.PSObject.Properties[$ExtensionId]
      if ($null -eq $property -or $null -eq $property.Value) { continue }
      $entry = $property.Value
      $state = 0; $disableReasons = 0
      try { $state = [int]$entry.state } catch { $state = 0 }
      try { $disableReasons = [int64]$entry.disable_reasons } catch { $disableReasons = 0 }
      if ($state -ne 1 -or $disableReasons -ne 0) { continue }
      $storedPath = [string]$entry.path
      # An enabled registration must refer to the canonical source root; never report an old copy as current.
      if ([string]::IsNullOrWhiteSpace($storedPath)) { continue }
      $resolved = Resolve-CandidateExtensionPath -PathValue $storedPath -BasePath (Split-Path -Parent $preferencePath)
      if (-not [string]::IsNullOrWhiteSpace($resolved) -and [string]::Equals($resolved.TrimEnd('\'),$ExpectedRoot.TrimEnd('\'),[StringComparison]::OrdinalIgnoreCase)) { return $true }
    } catch { }
  }
  return $false
}

function Invoke-LaunchRequest {
  param([object]$Request)

  $requestId = [string]$Request.requestId
  if ([string]::IsNullOrWhiteSpace($requestId)) { throw 'Launch request ID is missing.' }
  $launchMode = ([string]$Request.launchMode).Trim().ToLowerInvariant()
  $registerMode = $launchMode -eq 'register-direct'
  $directDefaultNetwork = $launchMode -eq 'wing-direct' -or $launchMode -eq 'options-direct' -or $registerMode

  try {
    $browser = Resolve-BrowserLaunch -Request $Request
    $script:BrowserExecutable = $browser.Executable
    $extensionRoot = Resolve-SmartPageExtensionRoot -Request $Request -Browser $browser

    $profileDir = $browser.Profile
    New-Item -ItemType Directory -Path $profileDir -Force | Out-Null
    $extensionId = ([string]$Request.extensionId).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($extensionId)) { $extensionId = 'olmpllofoggohefbdkgkjjnlanfnaocd' }

    # Canonical package root wins. A legacy registration is reported, never silently adopted.
    $registeredProfileRoot = Resolve-DedicatedProfileExtensionRoot -ProfileDir $profileDir -ExtensionId $extensionId
    if ($registeredProfileRoot -and $extensionRoot -and -not [string]::Equals($registeredProfileRoot.TrimEnd('\'),$extensionRoot.TrimEnd('\'),[StringComparison]::OrdinalIgnoreCase)) {
      Write-LaunchLog ('Legacy unpacked registration needs one-time migration. Registered=' + $registeredProfileRoot + '; Expected=' + $extensionRoot)
    }
    $extensionSourceAvailable = -not [string]::IsNullOrWhiteSpace($extensionRoot)
    $extensionRegistered = Test-DedicatedExtensionRegistered -ProfileDir $profileDir -ExtensionId $extensionId -ExpectedRoot $extensionRoot
    $extensionLoaded = $extensionRegistered
    if (-not $registerMode -and $launchMode -ne 'wing-direct' -and -not $extensionRegistered) {
      # v1.5.29: Chrome may not flush a just-loaded unpacked extension to Secure Preferences immediately.
      # Treat the disk registration probe as advisory so a stale Preferences file cannot block the dedicated window.
      # PAC/route isolation remains fail-closed below; if Collector is truly absent the window still opens safely and
      # the missing extension becomes visible in Chrome instead of entering a false RUN_08 loop.
      Write-LaunchLog ('Collector registration check was not confirmed on disk; continuing dedicated launch with profile registration treated as pending. ExtensionId=' + $extensionId + '; Root=' + [string]$extensionRoot)
    }
    if (-not $extensionSourceAvailable) {
      Write-LaunchLog 'SmartPage Ex extension source folder could not be resolved.'
    }

    $proxyPort = [int]$Request.proxyPort
    if ($proxyPort -le 0) { $proxyPort = 30766 }
    # SPX_V160_PROXY_STATE_PREFLIGHT: never start a PAC-selected Coupang window when the
    # installer/helper has no enabled adapter state. This turns an opaque Chrome
    # ERR_TUNNEL_CONNECTION_FAILED into an actionable local-helper error.
    if (-not $directDefaultNetwork) {
      $proxyStatePath = Join-Path $BaseDir 'coupang-window-proxy.json'
      $proxyState = $null
      try { if(Test-Path -LiteralPath $proxyStatePath -PathType Leaf){$proxyState=Get-Content -LiteralPath $proxyStatePath -Raw|ConvertFrom-Json} } catch { $proxyState=$null }
      if($null-eq$proxyState -or $proxyState.enabled -ne $true){ throw 'Selected-network adapter state is not enabled. Apply the USB tethering adapter in Collector before opening the Coupang dedicated window.' }
    }
    if (-not $directDefaultNetwork -and -not (Test-TcpPort -Port $proxyPort -Timeout 1500)) { throw "Selected-network proxy is not running on 127.0.0.1:$proxyPort." }

    $startUrl = [string]$Request.startUrl
    $validHttpUrl = -not [string]::IsNullOrWhiteSpace($startUrl) -and $startUrl -match '^https?://'
    $validOptionsUrl = $launchMode -eq 'options-direct' -and -not [string]::IsNullOrWhiteSpace($startUrl) -and $startUrl -match '^chrome-extension://[a-p]{32}/'
    $validRegisterUrl = $registerMode -and $startUrl -in @('chrome://extensions/','whale://extensions/')
    if ($registerMode -and $browser.Family -eq 'whale') { $startUrl = 'whale://extensions/'; $validRegisterUrl = $true }
    if (-not $validHttpUrl -and -not $validOptionsUrl -and -not $validRegisterUrl) {
      $startUrl = if($registerMode){'chrome://extensions/'}elseif($launchMode -eq 'wing-direct'){'https://wing.coupang.com/'}else{'https://www.coupang.com/'}
    }


    $chromePath = $browser.Path

    if (-not $directDefaultNetwork) { $startUrl = Add-SelectedNetworkMarker -Url $startUrl }

    # v3.0.8.7: unpacked extension files can be replaced while the dedicated Chrome process keeps an
    # older service worker alive. A version/root marker closes only the C:\SpxDedicatedProfile browser
    # when its loaded build is stale, then restarts the normal-Chrome dedicated profile so the persisted unpacked extension reloads from the current folder.
    $extensionVersion = Resolve-ExtensionVersion -Request $Request -ExtensionRoot $extensionRoot
    $packageFingerprint = Get-ExtensionFingerprint -ExtensionRoot $extensionRoot
    $routingKey = if ($directDefaultNetwork) { $browser.Family + ':direct' } else { $browser.Family + ':selected-main-v163:' + [string]$proxyPort }
    $runtimeMarkerPath = Join-Path $profileDir 'SmartPageEx-extension-runtime.json'
    $runtimeMarker = Read-RuntimeMarker -Path $runtimeMarkerPath
    $existingDedicated = @(Get-DedicatedChromeProcesses -ProfileDir $profileDir)
    $runtimeRestarted = $false
    # Reuse a current dedicated runtime unless its route/package changed or restart was explicitly requested.
    $forceRuntimeRestart = $false
    try {
      $forceProp = $Request.PSObject.Properties['forceRuntimeRestart']
      if ($null -ne $forceProp) { $forceRuntimeRestart = $Request.forceRuntimeRestart -eq $true }
    } catch { $forceRuntimeRestart = $false }
    if ($existingDedicated.Count -gt 0) {
      if ($forceRuntimeRestart) {
        $runtimeRestarted = Stop-DedicatedChromeProcesses -ProfileDir $profileDir -Reason 'extension requested a clean dedicated runtime restart'
        $existingDedicated = @()
      }
      $markerVersion = if ($null -ne $runtimeMarker) { ([string]$runtimeMarker.extensionVersion).Trim() } else { '' }
      $markerRoot = if ($null -ne $runtimeMarker) { ([string]$runtimeMarker.extensionRoot).Trim() } else { '' }
      $requestedRoot = if ([string]::IsNullOrWhiteSpace($extensionRoot)) { '' } else { [IO.Path]::GetFullPath($extensionRoot).TrimEnd('\') }
      $knownRoot = if ([string]::IsNullOrWhiteSpace($markerRoot)) { '' } else { try { [IO.Path]::GetFullPath($markerRoot).TrimEnd('\') } catch { $markerRoot.TrimEnd('\') } }
      $versionMismatch = -not [string]::IsNullOrWhiteSpace($extensionVersion) -and -not [string]::Equals($markerVersion,$extensionVersion,[StringComparison]::OrdinalIgnoreCase)
      $rootMismatch = -not [string]::IsNullOrWhiteSpace($requestedRoot) -and -not [string]::Equals($knownRoot,$requestedRoot,[StringComparison]::OrdinalIgnoreCase)
      $routingMismatch = $null -eq $runtimeMarker -or [string]$runtimeMarker.routingKey -ne $routingKey
      $fingerprintMismatch = $null -eq $runtimeMarker -or [string]$runtimeMarker.packageFingerprint -ne $packageFingerprint
      $markerMissing = $null -eq $runtimeMarker
      if ($existingDedicated.Count -gt 0 -and ($markerMissing -or $versionMismatch -or $rootMismatch -or $routingMismatch -or $fingerprintMismatch)) {
        $reason = if ($markerMissing) { 'runtime marker missing' } elseif ($versionMismatch) { 'extension version changed from ' + $markerVersion + ' to ' + $extensionVersion } elseif ($rootMismatch) { 'extension root changed' } else { 'routing or package content changed' }
        $runtimeRestarted = Stop-DedicatedChromeProcesses -ProfileDir $profileDir -Reason $reason
      }
    }

    if ($runtimeRestarted -or $forceRuntimeRestart) { Clear-DedicatedRuntimeCaches -ProfileDir $profileDir }

    $argumentParts = @(
      '--user-data-dir=' + (Quote-Argument $profileDir),
      '--profile-directory=Default',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-quic',
      '--disable-session-crashed-bubble',
      '--disable-features=InfiniteSessionRestore'
    )
    if ($directDefaultNetwork) { $argumentParts += '--no-proxy-server' }
    if (-not $directDefaultNetwork) {
      # SPX_WING_DEFAULT_NETWORK_PAC_V1 + CROSSPC_V134
      # Normal dedicated collection keeps the selected-network fail-closed PAC.
      # WING/auth/Naver/Supabase/general traffic remains DIRECT inside that PAC.
      $spxWingDirectPacPath = Join-Path $BaseDir ('coupang-proxy-' + $browser.Family + '.pac')
      $spxWingDirectPac = @"
function FindProxyForURL(url, host) {
  host = (host || '').toLowerCase();
  if (host === 'wing.coupang.com' || dnsDomainIs(host, '.wing.coupang.com') ||
      host === 'xauth.coupang.com' || host === 'auth.coupang.com' ||
      host === 'login.coupang.com' || host === 'idp.coupang.com' || host === 'idpp.coupang.com') return 'DIRECT';
  if (host === 'localhost' || host === '127.0.0.1' || host === '::1' ||
      host === 'supabase.co' || dnsDomainIs(host, '.supabase.co') ||
      host === 'supabase.in' || dnsDomainIs(host, '.supabase.in') ||
      host === 'naver.com' || dnsDomainIs(host, '.naver.com') ||
      host === 'naver.net' || dnsDomainIs(host, '.naver.net') ||
      host === 'api.openai.com' || dnsDomainIs(host, '.openai.com') ||
      host === 'generativelanguage.googleapis.com' || dnsDomainIs(host, '.googleapis.com') ||
      host === 'smartpage-ai.vercel.app' || dnsDomainIs(host, '.vercel.app')) return 'DIRECT';
  // v1.6.2: only the Coupang main shopping origin is eligible for the selected adapter.
  // CDN/static/auxiliary Coupang hosts stay on Windows default internet; image/media/font bytes are
  // separately suppressed by the extension DNR policy. This prevents profile-wide Coupang traffic
  // from silently consuming USB tethering data.
  if (host === 'coupang.com' || host === 'www.coupang.com')
    return 'PROXY 127.0.0.1:$proxyPort';
  return 'DIRECT';
}
"@
      [IO.File]::WriteAllText($spxWingDirectPacPath,$spxWingDirectPac,(New-Object System.Text.UTF8Encoding($false)))
      $spxWingDirectPacUrl = 'file:///' + ($spxWingDirectPacPath -replace '\\','/')
      $argumentParts += '--proxy-pac-url=' + (Quote-Argument $spxWingDirectPacUrl)
      $argumentParts += '--force-webrtc-ip-handling-policy=disable_non_proxied_udp'
    }
    $argumentParts += '--new-window'
    $argumentParts += (Quote-Argument $startUrl)
    $arguments = $argumentParts -join ' '

    $networkLabel = if($directDefaultNetwork){'DIRECT-default-network'}else{'PAC-selected-network proxy 127.0.0.1:'+([string]$proxyPort)}
    Write-LaunchLog ("Launching Chrome. User={0}; Session={1}; Chrome={2}; Profile={3}; Network={4}; ExtensionRegistered={5}; ExtensionRoot={6}; LaunchMode={7}" -f [Security.Principal.WindowsIdentity]::GetCurrent().Name, (Get-Process -Id $PID).SessionId, $chromePath, $profileDir, $networkLabel, $extensionLoaded, $extensionRoot, $launchMode)
    $process = Start-Process -FilePath $chromePath -ArgumentList $arguments -PassThru
    $browserProcessId = 0
    for ($i = 0; $i -lt 40; $i++) {
      Start-Sleep -Milliseconds 250
      $candidate = Get-CimInstance Win32_Process -Filter ("Name='" + $script:BrowserExecutable + "'") -ErrorAction SilentlyContinue | Where-Object {
        -not [string]::IsNullOrWhiteSpace([string]$_.CommandLine) -and [string]$_.CommandLine -match ('(?i)(?:^|\s)--user-data-dir=(?:"' + [regex]::Escape($profileDir) + '"|' + [regex]::Escape($profileDir) + ')(?:\s|$)')
      } | Select-Object -First 1
      if ($null -ne $candidate -and [int]$candidate.ProcessId -gt 0) {
        $browserProcessId = [int]$candidate.ProcessId
        break
      }
      if ($i -ge 5 -and $process.HasExited) { continue }
    }
    if ($browserProcessId -le 0) { throw 'Chrome dedicated-window process was not detected after launch.' }

    $resolvedExtensionRoot = if ($extensionLoaded) { $extensionRoot } else { '' }
    Write-JsonAtomic -Path $runtimeMarkerPath -Value ([ordered]@{
        packageFingerprint = $packageFingerprint
        routingKey = $routingKey
        browserFamily = $browser.Family
        extensionVersion = $extensionVersion
        extensionRoot = $extensionRoot
        browserPid = $browserProcessId
        loadedAt = (Get-Date).ToUniversalTime().ToString('o')
    })
    $result = [ordered]@{
      ok = $true
      requestId = $requestId
      pid = $browserProcessId
      profileDir = $profileDir
      proxyPort = $proxyPort
      selectedAdapterName = [string]$Request.selectedAdapterName
      launchMode = $launchMode
      directDefaultNetwork = $directDefaultNetwork
      browserFamily = $browser.Family
      browserExecutable = $browser.Path
      registrationRequired = -not $extensionRegistered
      expectedExtensionRoot = $extensionRoot
      extensionLoaded = $extensionLoaded
      extensionRoot = $resolvedExtensionRoot
      extensionVersion = $extensionVersion
      runtimeRestarted = $runtimeRestarted
      launchedAt = (Get-Date).ToUniversalTime().ToString('o')
    }
    Write-JsonAtomic -Path (Join-Path $BaseDir 'browser-launch-preference.json') -Value @{browserFamily=$browser.Family;extensionRoot=$extensionRoot}
    Write-JsonAtomic -Path $ResultPath -Value $result
    Write-LaunchLog ("Dedicated browser opened. RequestId={0}; PID={1}; Adapter={2}" -f $requestId, $browserProcessId, [string]$Request.selectedAdapterName)
    return $true
  }
  catch {
    $message = $_.Exception.Message
    Write-JsonAtomic -Path $ResultPath -Value ([ordered]@{
      ok = $false
      requestId = $requestId
      error = $message
      failedAt = (Get-Date).ToUniversalTime().ToString('o')
    })
    Write-LaunchLog ('Launch failed. RequestId=' + $requestId + '; ' + $_.Exception.ToString())
    return $false
  }
}

function Invoke-CurrentSourceRequest {
  param([object]$Request)
  # The installed watcher dispatches each request to the current source package.
  # Once installed, overwriting that root updates the launcher without RUN_08.
  $root=[string]$Request.extensionRoot
  if ([string]::IsNullOrWhiteSpace($root)) {
    try { $config=Get-Content -LiteralPath (Join-Path $BaseDir 'network-host-config.json') -Raw | ConvertFrom-Json; $root=[string]$config.extensionRoot } catch { }
  }
  $sourceLauncher=''
  if (-not [string]::IsNullOrWhiteSpace($root)) { $sourceLauncher=Join-Path $root 'tools\network-host\open-dedicated-window.ps1' }
  if ($sourceLauncher -and (Test-Path -LiteralPath $sourceLauncher -PathType Leaf) -and -not [string]::Equals([IO.Path]::GetFullPath($sourceLauncher),[IO.Path]::GetFullPath($PSCommandPath),[StringComparison]::OrdinalIgnoreCase)) {
    & "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $sourceLauncher -RequestFile $RequestPath
    if ($LASTEXITCODE -ne 0) { Write-LaunchLog ('Current source launcher returned ' + $LASTEXITCODE) }
  } else { [void](Invoke-LaunchRequest -Request $Request) }
}

function Process-PendingRequest {
  param([string]$LastRequestId)
  if (-not (Test-Path -LiteralPath $RequestPath)) { return $LastRequestId }
  try {
    $request = Get-Content -LiteralPath $RequestPath -Raw -ErrorAction Stop | ConvertFrom-Json
    $requestId = [string]$request.requestId
    if ([string]::IsNullOrWhiteSpace($requestId) -or $requestId -eq $LastRequestId) { return $LastRequestId }
    Invoke-CurrentSourceRequest -Request $request
    return $requestId
  }
  catch {
    Write-LaunchLog ('Unable to read pending launch request: ' + $_.Exception.ToString())
    return $LastRequestId
  }
}

if (-not [string]::IsNullOrWhiteSpace($RequestFile)) {
  $request=Get-Content -LiteralPath $RequestFile -Raw -Encoding UTF8 | ConvertFrom-Json
  if (Invoke-LaunchRequest -Request $request) { exit 0 } else { exit 1 }
}

try {
  Write-JsonAtomic -Path $ReadyPath -Value ([ordered]@{
    ready = $true
    user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    sessionId = (Get-Process -Id $PID).SessionId
    pid = $PID
    mode = $(if($Watch.IsPresent){'patch8-watch'}else{'one-shot'})
    startedAt = (Get-Date).ToUniversalTime().ToString('o')
  })
  Write-LaunchLog ("Interactive launcher PATCH8 watcher ready. Watch={0}; User={1}; Session={2}; PID={3}" -f $Watch.IsPresent, [Security.Principal.WindowsIdentity]::GetCurrent().Name, (Get-Process -Id $PID).SessionId, $PID)

  $lastRequestId = ''
  if (Test-Path -LiteralPath $ResultPath) {
    try { $lastRequestId = [string](Get-Content -LiteralPath $ResultPath -Raw | ConvertFrom-Json).requestId } catch { }
  }

  if (-not $Watch.IsPresent) {
    $newId = Process-PendingRequest -LastRequestId $lastRequestId
    if ($newId -eq $lastRequestId) { throw 'No new dedicated-window request was found.' }
    exit 0
  }

  while ($true) {
    $lastRequestId = Process-PendingRequest -LastRequestId $lastRequestId
    Start-Sleep -Milliseconds 500
  }
}
catch {
  Write-LaunchLog ('Launcher fatal error: ' + $_.Exception.ToString())
  exit 1
}
