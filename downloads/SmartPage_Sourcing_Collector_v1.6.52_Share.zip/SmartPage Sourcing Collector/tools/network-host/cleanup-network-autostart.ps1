﻿$ErrorActionPreference='SilentlyContinue'
function IsAdmin{$i=[Security.Principal.WindowsIdentity]::GetCurrent();$p=New-Object Security.Principal.WindowsPrincipal($i);$p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)}
if(-not(IsAdmin)){$p=Start-Process "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Verb RunAs -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'"') -Wait -PassThru;exit $p.ExitCode}
foreach($task in @('SmartPageEx Network Local Bridge','SmartPageEx Network Bridge Recovery','SmartPageEx Open Dedicated Browser','SmartPageEx Network Switch')){Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue;Unregister-ScheduledTask -TaskName $task -Confirm:$false -ErrorAction SilentlyContinue}
& "$env:SystemRoot\System32\sc.exe" stop SmartPageExNetworkBridge 2>$null|Out-Null;& "$env:SystemRoot\System32\sc.exe" delete SmartPageExNetworkBridge 2>$null|Out-Null
Get-CimInstance Win32_Process -Filter "Name='SpxNetworkHost.exe'" -ErrorAction SilentlyContinue|ForEach-Object{try{Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue|Out-Null}catch{}}
try{$name=[string](Get-CimInstance Win32_ComputerSystem).UserName;$sid=(New-Object Security.Principal.NTAccount($name)).Translate([Security.Principal.SecurityIdentifier]).Value;foreach($v in @('SmartPageExNetworkHelper','SmartPageExNetworkBridge')){Remove-ItemProperty -Path "Registry::HKEY_USERS\$sid\Software\Microsoft\Windows\CurrentVersion\Run" -Name $v -Force -ErrorAction SilentlyContinue}}catch{}
Write-Host 'Legacy SmartPage Ex automatic network tasks were removed.' -ForegroundColor Green
Read-Host 'Press Enter to close'

Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue|Where-Object{([string]$_.CommandLine -like '*run-network-host.ps1*') -and ([string]$_.CommandLine -like '*-HttpServer*')}|ForEach-Object{try{Invoke-CimMethod -InputObject $_ -MethodName Terminate -ErrorAction SilentlyContinue|Out-Null}catch{}}
