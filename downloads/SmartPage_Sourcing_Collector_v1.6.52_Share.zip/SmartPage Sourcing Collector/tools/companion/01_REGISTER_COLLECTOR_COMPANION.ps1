﻿$ErrorActionPreference = 'Stop'
$FixScript = Join-Path $PSScriptRoot '01_FIX_DEDICATED_WINDOW_UTF8_PATH.ps1'
if (-not (Test-Path -LiteralPath $FixScript -PathType Leaf)) { throw 'UTF-8/path FIX3 repair script not found.' }
& $FixScript
if (-not $?) { exit 1 }
