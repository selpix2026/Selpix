/* v1.6.20 — WING verified winner metrics (separate from legacy review-based estimates).
   Only an exact product-ID match and explicit numeric salesLast28d may update
   public.winner_products.estimated_monthly_sales. Does not modify IP recovery. */
(function(){
'use strict';
const KEY='spxWingActualQueueV1620', MODE='spxWinnerMetricModeV1620', ALARM='spx:wing-actual:resume-v1620';
let running=false;
const validId=x=>/^[0-9]{5,20}$/.test(String(x||''));
const parseNum=(value)=>{
  if(value===null||value===undefined||value==='')return null;
  const n=typeof value==='string'?Number(value.replace(/,/g,'').trim()):Number(value);
  return Number.isFinite(n)&&n>=0?n:null;
};
async function mode(){return 'new';} // v1.6.41: verified actual WING mode only
async function load(){const v=(await chrome.storage.local.get(KEY))?.[KEY];return v&&typeof v==='object'?v:{pending:[],results:[],last_message:'대기',saved:0,failed:0};}
async function store(v){await chrome.storage.local.set({[KEY]:v});}
async function schedule(delayMinutes=1){await chrome.alarms.create(ALARM,{delayInMinutes:Math.max(0.1,delayMinutes)});}
async function enqueueWinners(winners=[],source='collection-upload'){
 if(await mode()!=='new')return{queued:0,mode:'old'};
 const rows=(Array.isArray(winners)?winners:[]).map(w=>String(w?.product_id??w?.productId??'').replace(/\D/g,''))
   .filter(validId);
 if(!rows.length)return{queued:0,mode:'new'};
 const q=await load(),seen=new Set([...(q.pending||[]).map(v=>v.product_id)]);
 let queued=0;
 for(const id of rows){if(seen.has(id))continue;seen.add(id);q.pending.push({product_id:id,source,attempt:0,queued_at:Date.now()});queued++;}
 q.last_message=`신규 WING 실측 ${queued}개 대기 · 총 ${q.pending.length}개`;
 await store(q);if(queued){await schedule(.12);void work();}return{queued,mode:'new'};
}
/* Executed in an authenticated wing.coupang.com MAIN world, not from Coupang shopping domain. */
async function fetchVerifiedWingItem(productId){
 const id=String(productId),at=new Date().toISOString();
 // Must be self-contained: this function is serialized into WING's MAIN world.
 const parseNum=value=>{if(value===null||value===undefined||value==='')return null;
   const n=typeof value==='string'?Number(value.replace(/,/g,'').trim()):Number(value);
   return Number.isFinite(n)&&n>=0?n:null;};
 try{
  const res=await fetch('/tenants/seller-web/pre-matching/search-product-items-v2',{
   method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({keyword:id,searchPage:0,searchPageSize:20,deliveryMethod:'DOMESTIC'})
  });
  if(res.status===401||res.status===403)return{ok:false,reason:'wing_auth_required',pause:true};
  if(res.status===429||res.status===503)return{ok:false,reason:'wing_rate_limit',pause:true};
  if(!res.ok)return{ok:false,reason:`http_${res.status}`};
  const data=await res.json();if(data?.code&&String(data.code)!=='200'&&!data.result)return{ok:false,reason:'wing_response_restricted',pause:true};
  const arr=Array.isArray(data?.result)?data.result:Array.isArray(data?.result?.items)?data.result.items:[];
  if(!arr.length)return{ok:false,reason:'no_product_result'};
  const exact=arr.filter(it=>[it?.productId,it?.product_id,it?.coupangProductId]
    .filter(v=>v!==null&&v!==undefined).some(v=>String(v).replace(/\D/g,'')===id));
  if(exact.length!==1)return{ok:false,reason:exact.length?'ambiguous_exact_id':'exact_product_id_not_found'};
  const it=exact[0],sales=parseNum(it.salesLast28d);
  if(sales===null||!Number.isInteger(sales))return{ok:false,reason:'sales_28d_missing'};
  const pv=parseNum(it.pvLast28Day),price=parseNum(it.itemWinnerPrice),reviews=parseNum(it.ratingCount),rating=parseNum(it.rating);
  return{ok:true,product_id:id,sales_28d:sales,view_count_28d:pv,
    item_winner_price:price,review_count:reviews,rating:rating!==null&&rating>0&&rating<=5?rating:null,
    collected_at:at,source:'wing_pre_matching_verified_v1620'};
 }catch(error){return{ok:false,reason:String(error?.message||error||'wing_fetch_error').slice(0,160)};}
}
async function work(){
 if(running||await mode()!=='new')return;
 running=true;
 try{
  let processed=0;
  while(processed<8){
   const q=await load(),current=q.pending?.[0];if(!current)break;
   const oldView=await wingReadQueueV426().catch(()=>({status:'idle'}));
   if(oldView?.running===true||oldView?.status==='running'){
    q.last_message='기존 WING 조회수 작업 종료 대기';await store(q);await schedule(1);return;
   }
   const ready=await wingEnsureWorkerTabV426().catch(e=>({status:'error',reason:String(e?.message||e)}));
   if(ready?.status!=='ready'){
    q.last_message=`WING 로그인/화면 준비 필요 · ${ready?.status||'unknown'}`;await store(q);await schedule(3);return;
   }
   const id=current.product_id;
   let out={ok:false,reason:'wing_injection_failure'};
   try{const result=await chrome.scripting.executeScript({target:{tabId:ready.tab.id},world:'MAIN',func:fetchVerifiedWingItem,args:[id]});out=result?.[0]?.result||out;}
   catch(e){out={ok:false,reason:String(e?.message||e||'wing_injection_failure')};}
   if(out.pause){q.last_message=`WING 일시 제한/로그인 · ${out.reason}`;await store(q);await schedule(3);return;}
   if(out.ok){
    try{
     const ack=await SUPA.rpc('spx_wing_verified_winner_apply_v1620',{
      p_product_id:id,p_sales_28d:out.sales_28d,p_view_count_28d:out.view_count_28d,
      p_item_winner_price:out.item_winner_price,p_review_count:out.review_count,
      p_rating:out.rating,p_collected_at:out.collected_at});
     if(ack?.ok!==true)throw new Error(String(ack?.reason||'server_rejected'));
     q.saved=(Number(q.saved)||0)+1;
     q.results=[...(q.results||[]),{product_id:id,status:'saved',sales:out.sales_28d,at:out.collected_at}].slice(-100);
     q.last_message=`WING 실측 ${id}: 판매 ${out.sales_28d}개 · 기존 월판매량 필드 반영`;
     q.pending.shift();
    }catch(e){out={ok:false,reason:`upload:${String(e?.message||e||'server_save_failed')}`};}
   }
   if(!out.ok){
    current.attempt=(Number(current.attempt)||0)+1;
    q.last_message=`WING ${id} 확인 실패: ${out.reason}`;
    if(current.attempt>=3){q.pending.shift();q.failed=(Number(q.failed)||0)+1;
     q.results=[...(q.results||[]),{product_id:id,status:'failed',reason:out.reason,at:new Date().toISOString()}].slice(-100);}
    else{q.pending.shift();q.pending.push(current);}
   }
   await store(q);processed++;
   if(q.pending?.length)await new Promise(r=>setTimeout(r,900));
  }
  const q=await load();if(q.pending?.length)await schedule(1);
 }catch(e){console.warn('[SPX WING 1.6.20] failed, preserving queue',String(e?.message||e));await schedule(2).catch(()=>{});}
 finally{running=false;}
}
chrome.alarms.onAlarm.addListener(a=>{if(a?.name===ALARM)void work();});
chrome.runtime.onStartup.addListener(()=>{void schedule(.3);});
void schedule(.4);
globalThis.__SPX_WING_ACTUAL_V1620__={enqueueWinners,work,load,mode,fetchVerifiedWingItem};
})();
