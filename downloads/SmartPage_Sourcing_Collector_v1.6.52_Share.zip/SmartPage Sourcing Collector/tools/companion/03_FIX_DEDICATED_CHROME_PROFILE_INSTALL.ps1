﻿$ErrorActionPreference='Stop'
Set-StrictMode -Version 2

$ExpectedCollectorRoot='D:\01. Work In Process\쿠팡 수집기\SmartPage Sourcing Collector'
$Base='C:\ProgramData\SmartPageEx\NetworkHostV33'
$Launcher=Join-Path $Base 'open-dedicated-window.ps1'
$TaskName='SmartPageEx Open Dedicated Browser'
$BackupRoot=Join-Path $Base 'collector-profile-install-fix10-backup'

function Assert-Admin {
  $id=[Security.Principal.WindowsIdentity]::GetCurrent()
  $p=New-Object Security.Principal.WindowsPrincipal($id)
  if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){
    throw '관리자 권한이 필요합니다. 이 CMD를 우클릭하여 관리자 권한으로 실행하세요.'
  }
}
function Read-Utf8([string]$Path){
  return [IO.File]::ReadAllText($Path,[Text.Encoding]::UTF8)
}
function Write-Utf8Bom([string]$Path,[string]$Text){
  [IO.File]::WriteAllText($Path,$Text,(New-Object Text.UTF8Encoding($true)))
}
function Get-WatcherProcesses {
  @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
    Where-Object {
      $c=[string]$_.CommandLine
      $c -like '*NetworkHostV33*open-dedicated-window.ps1*' -and $c -like '*-Watch*'
    })
}

Assert-Admin

if(-not (Test-Path -LiteralPath $ExpectedCollectorRoot -PathType Container)){
  throw ('Collector 고정 경로가 없습니다: '+$ExpectedCollectorRoot)
}
if(-not (Test-Path -LiteralPath (Join-Path $ExpectedCollectorRoot 'manifest.json') -PathType Leaf)){
  throw 'Collector manifest.json을 찾을 수 없습니다.'
}
if(-not (Test-Path -LiteralPath $Launcher -PathType Leaf)){
  throw ('전용창 launcher가 없습니다: '+$Launcher)
}

$manifest=Get-Content -LiteralPath (Join-Path $ExpectedCollectorRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if([string]$manifest.version -ne '1.0.4'){
  throw ('Collector 버전이 예상과 다릅니다: '+[string]$manifest.version)
}

$original=Read-Utf8 $Launcher
$patched=$original

# Chrome 137+ official builds no longer honor the legacy command-line
# extension auto-load switches. Remove only the two argument lines.
$sourceLines = @($patched -split '\r?\n')
$resultLines = New-Object 'System.Collections.Generic.List[string]'
$removedLoadExtension = 0
$removedDisableExcept = 0
foreach($line in $sourceLines){
  $isArgumentLine = $line -like '*$argumentParts*'
  if($isArgumentLine -and $line -like '*--load-extension=*'){
    $removedLoadExtension += 1
    continue
  }
  if($isArgumentLine -and $line -like '*--disable-extensions-except=*'){
    $removedDisableExcept += 1
    continue
  }
  [void]$resultLines.Add([string]$line)
}
$patched = [string]::Join("`r`n", $resultLines)

# Do not restart/clear the dedicated profile merely because an old caller
# omitted forceRuntimeRestart. The manually installed extension must persist.
$patched=$patched.Replace('$forceRuntimeRestart = $true','$forceRuntimeRestart = $false')
$patched=$patched.Replace('catch { $forceRuntimeRestart = $true }','catch { $forceRuntimeRestart = $false }')

# The launcher no longer installs the extension; make its result honest.
$oldBlock=@'
    $extensionRoot = Resolve-SmartPageExtensionRoot -Request $Request
    $extensionLoaded = -not [string]::IsNullOrWhiteSpace($extensionRoot)
    if (-not $extensionLoaded) {
      Write-LaunchLog 'SmartPage Ex extension folder could not be resolved. Opening the selected-network browser without loading the extension.'
    }
'@
$newBlock=@'
    $configuredExtensionRoot = Resolve-SmartPageExtensionRoot -Request $Request
    $extensionRoot = ''
    $extensionLoaded = $false
    if (-not [string]::IsNullOrWhiteSpace($configuredExtensionRoot)) {
      Write-LaunchLog 'Chrome 137+ profile-installed extension mode: command-line extension auto-load is disabled. Use the Collector installed in C:\SpxDedicatedProfile.'
    }
'@
if($patched.Contains($oldBlock)){
  $patched=$patched.Replace($oldBlock,$newBlock)
}else{
  # Flexible fallback for CRLF/spacing differences.
  $pattern='(?ms)^[ \t]*\$extensionRoot = Resolve-SmartPageExtensionRoot -Request \$Request\r?\n[ \t]*\$extensionLoaded = -not \[string\]::IsNullOrWhiteSpace\(\$extensionRoot\)\r?\n[ \t]*if \(-not \$extensionLoaded\) \{\r?\n.*?\r?\n[ \t]*\}\r?\n'
  $replacement="    `$configuredExtensionRoot = Resolve-SmartPageExtensionRoot -Request `$Request`r`n    `$extensionRoot = ''`r`n    `$extensionLoaded = `$false`r`n    if (-not [string]::IsNullOrWhiteSpace(`$configuredExtensionRoot)) {`r`n      Write-LaunchLog 'Chrome 137+ profile-installed extension mode: command-line extension auto-load is disabled. Use the Collector installed in C:\SpxDedicatedProfile.'`r`n    }`r`n"
  $patched=[regex]::Replace($patched,$pattern,$replacement,1)
}

if($patched -eq $original){
  throw 'launcher에서 수정할 legacy extension auto-load 항목을 찾지 못했습니다. STOP.'
}
if($patched -match '--load-extension=' -or $patched -match '--disable-extensions-except='){
  throw 'legacy extension command-line flag가 launcher에 남아 있습니다. STOP.'
}

# Syntax preflight before any write.
$tmp=Join-Path $env:TEMP ('spx-fix10-'+[guid]::NewGuid().ToString('N')+'.ps1')
try{
  Write-Utf8Bom $tmp $patched
  $parseErrors=$null
  [void][Management.Automation.Language.Parser]::ParseFile($tmp,[ref]$null,[ref]$parseErrors)
  if($parseErrors -and @($parseErrors).Count -gt 0){
    throw ('patched launcher PowerShell syntax error: '+(@($parseErrors)[0].Message))
  }
} finally {
  Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
}

$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$backup=Join-Path $BackupRoot $stamp
New-Item -ItemType Directory -Path $backup -Force | Out-Null
Copy-Item -LiteralPath $Launcher -Destination (Join-Path $backup 'open-dedicated-window.ps1') -Force

try{
  # Stop only the interactive launcher task/process, never Chrome/NetworkHost.
  try{ Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue }catch{}
  Start-Sleep -Milliseconds 700
  foreach($p in @(Get-WatcherProcesses)){
    try{ Stop-Process -Id ([int]$p.ProcessId) -Force -ErrorAction Stop }catch{}
  }

  Write-Utf8Bom $Launcher $patched

  # Restart watcher task.
  Start-ScheduledTask -TaskName $TaskName -ErrorAction Stop

  $ready=Join-Path $Base 'dedicated-window-launcher.ready'
  $deadline=(Get-Date).AddSeconds(15)
  $readyOk=$false
  while((Get-Date)-lt$deadline){
    Start-Sleep -Milliseconds 300
    if(Test-Path -LiteralPath $ready){
      try{
        $r=Get-Content -LiteralPath $ready -Raw -Encoding UTF8 | ConvertFrom-Json
        if($r.ready -eq $true){$readyOk=$true;break}
      }catch{}
    }
  }
  if(-not $readyOk){throw 'launcher watcher READY 확인 실패'}

  Write-Host ('BACKUP='+$backup)
  Write-Host 'LAUNCHER_MODE=PROFILE_INSTALLED_EXTENSION'
  Write-Host ('REMOVED_LOAD_EXTENSION_LINES='+$removedLoadExtension)
  Write-Host ('REMOVED_DISABLE_EXTENSIONS_EXCEPT_LINES='+$removedDisableExcept)
  Write-Host 'LOAD_EXTENSION_FLAG=REMOVED'
  Write-Host 'DISABLE_EXTENSIONS_EXCEPT_FLAG=REMOVED'
  Write-Host 'DEFAULT_FORCE_RUNTIME_RESTART=FALSE'
  Write-Host 'CHROME_STOP=0 CHROME_FORCE_KILL=0 NETWORKHOST_RESTART=0 ROUTE_CHANGE=0 ADAPTER_CHANGE=0'
  Write-Host 'FINAL=DEDICATED_CHROME_PROFILE_INSTALL_FIX10_PASS'
  exit 0
}
catch{
  $failure=$_.Exception.Message
  try{
    $bak=Join-Path $backup 'open-dedicated-window.ps1'
    if(Test-Path -LiteralPath $bak){
      Copy-Item -LiteralPath $bak -Destination $Launcher -Force
      try{ Start-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue }catch{}
    }
  }catch{}
  throw ('FIX10 rolled back: '+$failure)
}
