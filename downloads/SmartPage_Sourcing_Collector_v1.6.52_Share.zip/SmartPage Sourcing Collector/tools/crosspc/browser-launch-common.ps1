﻿# Shared interactive launcher contract. No profile-wide settings or Windows routes are changed here.
$SpxNetBase=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
function Resolve-SpxBrowserFamily([string]$Requested){
  $family=([string]$Requested).Trim().ToLowerInvariant()
  if(-not$family){try{$pref=Get-Content -LiteralPath (Join-Path $SpxNetBase 'browser-launch-preference.json') -Raw|ConvertFrom-Json;$family=[string]$pref.browserFamily}catch{}}
  if(-not$family){$family=if(Find-SpxInstalledBrowser 'chrome'){'chrome'}elseif(Find-SpxInstalledBrowser 'whale'){'whale'}else{'chrome'}}
  if($family -notin @('chrome','whale')){throw ('Unsupported browser family: '+$family)}
  return $family
}
function Get-SpxSourceRoot{
  try{$config=Get-Content -LiteralPath (Join-Path $SpxNetBase 'network-host-config.json') -Raw|ConvertFrom-Json;$root=[string]$config.extensionRoot;if($root -and (Test-Path -LiteralPath (Join-Path $root 'manifest.json') -PathType Leaf)){return [IO.Path]::GetFullPath($root)}}catch{}
  $root=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
  if(Test-Path -LiteralPath (Join-Path $root 'manifest.json') -PathType Leaf){return $root}
  throw 'Collector source folder is unavailable. Restore the configured SmartPage Sourcing Collector folder.'
}
function Invoke-SpxDedicatedRequest([string]$LaunchMode,[string]$StartUrl,[string]$BrowserFamily,[string]$SourceRoot=''){
  $family=Resolve-SpxBrowserFamily $BrowserFamily
  $root=if($SourceRoot){$SourceRoot}else{Get-SpxSourceRoot}
  $manifest=Get-Content -LiteralPath (Join-Path $root 'manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
  $payload=[ordered]@{requestId=[Guid]::NewGuid().ToString('N');launchMode=$LaunchMode;startUrl=$StartUrl;browserFamily=$family;extensionRoot=$root;extensionId='olmpllofoggohefbdkgkjjnlanfnaocd';extensionVersion=[string]$manifest.version;forceRuntimeRestart=$false;requestedAt=(Get-Date).ToUniversalTime().ToString('o')}
  if($LaunchMode -eq 'selected-network'){
    # Use the helper's connectivity/isolation checks and the one authoritative PAC launcher.
    $payload.command='open_coupang_window'
    $body=$payload|ConvertTo-Json -Depth 8 -Compress
    $result=Invoke-RestMethod -UseBasicParsing -Uri 'http://127.0.0.1:30765/api' -Method Post -Headers @{'X-SmartPageEx-Token'='spx-v7-8e3c0af4640b4a20a1d706a1fba5e6d7'} -ContentType 'application/json; charset=utf-8' -Body $body -TimeoutSec 60
    if($result.ok -ne $true){throw ([string]$result.error)}
    return $result
  }
  $requestPath=Join-Path $SpxNetBase 'dedicated-window-request.json'
  $resultPath=Join-Path $SpxNetBase 'dedicated-window-result.json'
  $temp=$requestPath+'.tmp.'+[Guid]::NewGuid().ToString('N')
  [IO.File]::WriteAllText($temp,($payload|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
  Move-Item -LiteralPath $temp -Destination $requestPath -Force
  try{Start-ScheduledTask -TaskName 'SmartPageEx Open Dedicated Browser' -ErrorAction Stop}catch{throw 'Dedicated launcher task is unavailable. Run the installer once to repair the helper.'}
  for($i=0;$i-lt200;$i++){
    Start-Sleep -Milliseconds 250
    try{$candidate=Get-Content -LiteralPath $resultPath -Raw -Encoding UTF8|ConvertFrom-Json}catch{continue}
    if([string]$candidate.requestId -ne [string]$payload.requestId){continue}
    if($candidate.ok -ne $true){throw ([string]$candidate.error)}
    return $candidate
  }
  throw 'Dedicated browser launch was not confirmed within 50 seconds.'
}

function Find-SpxInstalledBrowser([string]$Family){
  $exe=if($Family -eq 'whale'){'whale.exe'}else{'chrome.exe'}
  $relative=if($Family -eq 'whale'){'Naver\Naver Whale\Application\whale.exe'}else{'Google\Chrome\Application\chrome.exe'}
  $candidates=New-Object System.Collections.Generic.List[string]
  foreach($prefix in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\','HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\')){
    try{$value=[string](Get-Item -LiteralPath ($prefix+$exe) -ErrorAction Stop).GetValue('');if($value){$candidates.Add($value.Trim('"'))}}catch{}
  }
  foreach($base in @($env:LOCALAPPDATA,$env:ProgramFiles,${env:ProgramFiles(x86)})){if($base){$candidates.Add((Join-Path $base $relative))}}
  foreach($candidate in $candidates){if((Test-Path -LiteralPath $candidate -PathType Leaf) -and [string]::Equals([IO.Path]::GetFileName($candidate),$exe,[StringComparison]::OrdinalIgnoreCase)){return [IO.Path]::GetFullPath($candidate)}}
  return ''
}
