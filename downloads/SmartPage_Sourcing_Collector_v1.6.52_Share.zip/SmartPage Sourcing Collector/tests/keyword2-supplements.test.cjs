const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm');
const {runtime,sourceFunction,detailHtml,relatedHtml}=require('./helpers.cjs');
const sidebar='src/content/coupang-search.js';
const product=(pid,extra={})=>({pid:String(pid),name:'보온 텀블러',price:12000,reviews:30,rocketType:'일반배송',...extra});
function scanRuntime(controls={keyword2:true},overrides={}){
  const ctx=runtime({activeRunId:'run',contextInvalidated:false,promptKeywordSeenV1610:new Set(),promptKeywordSortCacheV1652:new Map(),appendLiveLog:()=>{},
    runtimeMessage:async()=>({ok:true,eligible:1,count:1,local:{added:1},server:{added:0}}),...overrides});
  ctx.SPX.promptKeywords={SETTINGS_KEY:'prompt-controls'};
  ctx.chrome.storage.local.get=async()=>({'prompt-controls':controls});
  for(const name of ['sourceProductsFromHtmlV1610','fetchKeywordSortV1610','collectPromptKeywordsForPageV1610'])vm.runInContext(sourceFunction(sidebar,name),ctx);
  return ctx;
}
const sortedHtml=(pid=2)=>`<li class="search-product" data-product-id="${pid}"><a href="/vp/products/${pid}?itemId=${pid}0&vendorItemId=${pid}00"><span class="name">보온 텀블러 상품</span><span class="price-value">12,000</span><span class="rating-total-count">(30)</span></a></li>`;

// Losing offer IDs here would merge different sellers and prevent reuse of an existing detail result.
test('sorted HTML retains exact offer URLs and does not invent ordinary delivery',()=>{
  const ctx=scanRuntime();const rows=ctx.sourceProductsFromHtmlV1610(sortedHtml(2)+sortedHtml(2).replace('200','201'));
  assert.equal(rows.length,2);assert.equal(rows[0].vendorItemId,'200');assert.equal(rows[1].vendorItemId,'201');
  assert.equal(rows[0].itemId,'20');assert.equal(rows[0].productUrl,'https://www.coupang.com/vp/products/2?itemId=20&vendorItemId=200');
  assert.equal(rows[0].rocketType,'배송유형 미확인');
});

test('keyword2 yields both first-page search sorts before title registration finishes',async()=>{
  let release;const pending=new Promise(resolve=>release=resolve),urls=[];let delivered;
  const ctx=scanRuntime({keyword2:true},{runtimeMessage:async()=>pending,fetch:async url=>{urls.push(String(url));return{ok:true,status:200,url:String(url),text:async()=>sortedHtml(String(url).includes('saleCountDesc')?2:3)};}});
  const running=ctx.collectPromptKeywordsForPageV1610([product(1)],'텀블러',1,rows=>{delivered=rows;});
  for(let i=0;i<20&&!delivered;i++)await new Promise(resolve=>setImmediate(resolve));
  try{
    assert.equal(urls.length,2);assert.equal(delivered.length,2);
    assert.deepEqual(urls.map(url=>new URL(url).searchParams.get('sorter')).sort(),['latestAsc','saleCountDesc']);
    assert.ok(urls.every(url=>new URL(url).pathname==='/np/search'&&new URL(url).searchParams.get('page')==='1'));
    assert.deepEqual(Array.from(delivered,row=>row.sourceSort),['saleCountDesc','latestAsc']);
  }finally{release({ok:true,eligible:1,local:{added:1},server:{added:0}});await running;}
});

test('keyword2 disabled or page two creates no supplemental sort requests',async()=>{
  let calls=0;const ctx=scanRuntime({keyword2:false},{fetch:async()=>{calls++;throw Error('unexpected');}});
  assert.equal(await ctx.collectPromptKeywordsForPageV1610([product(1)],'텀블러',1),undefined);
  ctx.chrome.storage.local.get=async()=>({'prompt-controls':{keyword2:true}});
  await ctx.collectPromptKeywordsForPageV1610([product(1)],'텀블러',2);
  assert.equal(calls,0);
});

test('shared verification deduplicates sorts, existing offers and detail recommendations without recursion',async()=>{
  const requested=[];
  const ctx=runtime({fetch:async url=>{requested.push(String(url));const pid=String(url).match(/products\/(\d+)/)[1];return{ok:true,status:200,url:String(url),text:async()=>detailHtml(pid)+relatedHtml('추천의 추천')};}});
  const rows=await ctx.SPX.enrichProductDetails([product(1,{vendorItemId:'100'}),product(9,{comparisonProducts:[product(2)]})],{
    keyword:'텀블러',comparisonSeedLimit:0,supplementaryCandidates:Promise.resolve([
      product(1,{vendorItemId:'100',rocketType:'배송유형 미확인',sourceSort:'saleCountDesc'}),
      product(2,{sourceSort:'saleCountDesc'}),product(3,{sourceSort:'latestAsc'}),product(3,{sourceSort:'saleCountDesc'})])});
  assert.deepEqual(requested.map(url=>url.match(/products\/(\d+)/)[1]).sort(),['2','3']);
  assert.equal(rows.filter(row=>row.pid==='3').length,1);
  const extra=rows.find(row=>row.pid==='3');assert.equal(extra.sourceType,'keyword_sort_verified');
  assert.equal(extra.sourceSort,'latestAsc');assert.equal(extra.rank,null);assert.equal(extra.comparisonProducts.length,0);
});

test('keyword2 verification works when detail recommendations are disabled and obeys its request cap',async()=>{
  let calls=0;const ctx=runtime({fetch:async url=>{calls++;return{ok:true,status:200,url:String(url),text:async()=>detailHtml(String(url).match(/products\/(\d+)/)[1])};}});
  const candidates=Array.from({length:12},(_,i)=>product(i+2,{sourceSort:i%2?'latestAsc':'saleCountDesc'}));
  const rows=await ctx.SPX.enrichProductDetails([product(1)],{keyword:'텀블러',collectComparisonCandidates:false,supplementaryCandidates:candidates});
  assert.equal(calls,8);assert.equal(rows.length,9);
});

test('supplemental detail requests stop on cancellation and propagate real blocking',async()=>{
  let calls=0;const ctx=runtime({fetch:async()=>{calls++;return{ok:false,status:403,url:'https://www.coupang.com/vp/products/2',text:async()=>''};}});
  await ctx.SPX.enrichProductDetails([product(1)],{keyword:'텀블러',collectComparisonCandidates:false,supplementaryCandidates:[product(2)],shouldContinue:()=>false});
  assert.equal(calls,0);
  await assert.rejects(()=>ctx.SPX.enrichProductDetails([product(1)],{keyword:'텀블러',collectComparisonCandidates:false,supplementaryCandidates:[product(2)]}),error=>error.code==='COUPANG_BLOCKED');
});

test('verified sort offers survive snapshot caps without changing primary search metrics',()=>{
  const ctx=runtime();const main={...product(1),rank:1,detailMonthlyPurchaseCount:300};
  const extra={...product(2),rank:1,sourceType:'keyword_sort_verified',sourceSort:'latestAsc',recommendationVerified:true,keywordRelevanceScore:100,detailMonthlyPurchaseCount:300};
  const snapshots=ctx.SPX.buildProductSnapshots([main,extra],[],{maxProducts:1});
  assert.equal(snapshots.length,2);assert.equal(snapshots[1].rank,null);assert.equal(snapshots[1].source_sort,'latestAsc');
  const before=ctx.SPX.computeWinnerMetrics([snapshots[0]]),after=ctx.SPX.computeWinnerMetrics(snapshots);
  assert.equal(after.organic_snapshot_count,1);assert.equal(after.source_total_monthly_sales,before.source_total_monthly_sales);
  assert.equal(after.winner_count,2);
});

test('worker page signals exclude sort offers from search seller counts',()=>{
  const ctx=runtime();vm.runInContext(sourceFunction('src/background/service-worker-core.js','computeWinnerPageSignal'),ctx);
  const main=product(1,{rank:1,detailMonthlyPurchaseCount:300});
  const extra=product(2,{sourceType:'keyword_sort_verified',sourceSort:'saleCountDesc',recommendationVerified:true,keywordRelevanceScore:100,detailMonthlyPurchaseCount:300});
  const signal=ctx.computeWinnerPageSignal([main,extra],1,{});
  assert.equal(signal.currentPageGeneralSellerCount,1);assert.equal(signal.currentWinnerCount,2);
});

test('collectPage hands ready sort offers to verification before final discovery and metrics',async()=>{
  const requests=[];const ctx=runtime({fetch:async url=>{requests.push(String(url));return{ok:true,status:200,url:String(url),text:async()=>detailHtml(2)+'<img itemprop="image" src="https://thumbnail.coupangcdn.com/a.jpg">'};}});
  Object.assign(ctx,{state:{lockedKeyword:'텀블러',keyword:'텀블러'},activeRunId:'run',contextInvalidated:false,localManualAbortRequested:false,
    networkRecoverySoftResumeRequested:false,IS_SELECTED_NETWORK_DEDICATED_TAB:false,
    retryEmptySearchIfNeeded:async()=>{},waitForUi:async()=>true,setProgress:()=>{},currentSearchPageNumber:()=>1,
    safeGetSettings:async()=>({autoScrollEnabled:false,collectDetailRecommendations:false}),rememberNetworkRecoveryPageSnapshot:()=>{},
    updateProgressiveFromProducts:()=>{},renderDiscoveredKeywords:()=>{},recordTabSessionEvent:async()=>{},
    collectPromptKeywordsForPageV1610:async(items,keyword,page,ready,scanOptions)=>{ready([product(scanOptions.fresh?2:3,{sourceSort:'saleCountDesc'})]);},
    runtimeMessage:async()=>({ok:true})});
  ctx.SPX.parseSearchPage=()=>({items:[product(1,{rating:4.5,imageUrl:'https://thumbnail.coupangcdn.com/primary.jpg',observed_monthly_sales:300,detailMonthlyPurchaseCount:300})]});
  ctx.SPX.discovery={extractRelatedTermsFromDom:()=>[],discoverFromProducts:(keyword,items)=>items.map(item=>({keyword:item.name}))};
  // Clear only the old final grace timer in the test process; do not alter parsing or aggregation.
  ctx.setTimeout=(fn,ms)=>{const timer=setTimeout(fn,ms);if(ms===25000)timer.unref();return timer;};
  vm.runInContext(sourceFunction(sidebar,'collectPage'),ctx);
  const result=await ctx.collectPage('',null,{manualMode:true});
  assert.equal(result.res.items.length,2);assert.equal(result.res.items[1].sourceType,'keyword_sort_verified');
  assert.equal(requests.length,1);assert.equal(result.candidates.length,2);
  const metrics=ctx.SPX.computeWinnerMetrics(ctx.SPX.buildProductSnapshots(result.res.items));
  assert.equal(metrics.organic_snapshot_count,1);assert.equal(metrics.winner_count,2);
  // Automatic collection also uses manual detail timing; it must still reuse its run's sort list.
  ctx.taskIsCurrent=()=>true;ctx.assertRunActive=async()=>{};
  ctx.fetch=async url=>({ok:true,status:200,url:String(url),text:async()=>detailHtml(String(url).match(/products\/(\d+)/)[1])});
  const resumed=await ctx.collectPage('',{touch:()=>{},assert:()=>{}},{manualMode:true});
  assert.equal(resumed.res.items[1].pid,'3');
});

test('same-run recovery reuses ready sorted offers without refetching or waiting for title ACK',async()=>{
  let release;const pending=new Promise(resolve=>release=resolve);let calls=0,first,second;
  const ctx=scanRuntime({keyword2:true},{runtimeMessage:async()=>pending,fetch:async url=>{calls++;return{ok:true,status:200,url:String(url),text:async()=>sortedHtml(2)};}});
  const original=ctx.collectPromptKeywordsForPageV1610([product(1)],'텀블러',1,rows=>first=rows);
  for(let i=0;i<20&&!first;i++)await new Promise(resolve=>setImmediate(resolve));
  const resumed=ctx.collectPromptKeywordsForPageV1610([product(1)],'텀블러',1,rows=>second=rows);
  for(let i=0;i<20&&!second;i++)await new Promise(resolve=>setImmediate(resolve));
  try{assert.equal(second?.length,2);assert.equal(calls,2);}
  finally{release({ok:true});await Promise.all([original,resumed]);}
});

test('keyword2 rejects a sorted response redirected to a different keyword or page',async()=>{
  const registered=[];const ctx=scanRuntime({keyword2:true},{runtimeMessage:async message=>{registered.push(message);return{ok:true};}});
  for(const target of ['https://www.coupang.com/np/search?q=우산&page=1&sorter=saleCountDesc','https://www.coupang.com/np/search?q=텀블러&page=2&sorter=saleCountDesc','https://www.coupang.com/np/categories/1?q=텀블러&page=1&sorter=saleCountDesc']){
    ctx.fetch=async()=>({ok:true,status:200,url:target,text:async()=>sortedHtml(2)});
    const result=await ctx.fetchKeywordSortV1610('https://www.coupang.com/np/search?q=텀블러&page=1&sorter=saleCountDesc','search','saleCountDesc','텀블러');
    assert.equal(result.ok,false);
  }
  assert.equal(registered.length,0);
});

test('structured sorted products preserve different offers and their actual links',()=>{
  const ctx=scanRuntime();
  const schema={"@type":"ItemList",itemListElement:[{item:{"@type":"Product",name:'보온 텀블러 상품',url:'https://www.coupang.com/vp/products/123456?itemId=20&vendorItemId=200',offers:{price:12000}}}]};
  const jsonRows=ctx.sourceProductsFromHtmlV1610(`<script type="application/ld+json">${JSON.stringify(schema)}</script>`);
  assert.equal(jsonRows[0].pid,'123456');assert.equal(jsonRows[0].vendorItemId,'200');
  const hydrated={props:{searchProducts:[{productId:123456,productName:'보온 텀블러 상품',salePrice:12000,itemId:20,vendorItemId:200},{productId:123456,productName:'보온 텀블러 상품',salePrice:12000,itemId:20,vendorItemId:201}]}};
  const rows=ctx.sourceProductsFromHtmlV1610(`<script id="__NEXT_DATA__" type="application/json">${JSON.stringify(hydrated)}</script>`);
  assert.equal(rows.length,2);assert.ok(rows[1].productUrl.endsWith('itemId=20&vendorItemId=201'));
});

test('canonical snapshot and winner transport keep supplemental provenance and eligibility',()=>{
  const ctx=runtime();const core='src/background/service-worker-core.js';
  for(const name of ['spxProductTransportImageV132','spxDefinedTransportRowV132','sanitizeProductSnapshotUploadRowV132','sanitizeWinnerProductUploadRowV132'])vm.runInContext(sourceFunction(core,name),ctx);
  const extra={...product(2),sourceType:'keyword_sort_verified',sourceSort:'latestAsc',recommendationVerified:true,keywordRelevanceScore:100,detailMonthlyPurchaseCount:300};
  const snapshot=ctx.SPX.buildProductSnapshots([extra])[0];
  for(const sanitize of [ctx.sanitizeProductSnapshotUploadRowV132,ctx.sanitizeWinnerProductUploadRowV132]){
    const wire=JSON.parse(JSON.stringify(sanitize(snapshot)));
    assert.equal(ctx.SPX.isSupplementaryProduct(wire),true);assert.equal(wire.source_sort,'latestAsc');
    assert.equal(wire.recommendation_verified,true);assert.equal(wire.keyword_relevance_score,100);
    assert.equal(ctx.SPX.winnerEligibility(wire).eligible,true);
    const restored={...wire,...wire.raw_payload};
    assert.equal(restored.source_type,'keyword_sort_verified');assert.equal(ctx.SPX.computeWinnerMetrics([restored]).organic_snapshot_count,0);
  }
});

test('fresh manual scans and an evicted recovery key fetch current sorted products',async()=>{
  let current=2,calls=0;const ctx=scanRuntime({keyword2:true},{activeRunId:'',fetch:async url=>{calls++;return{ok:true,status:200,url:String(url),text:async()=>sortedHtml(current)};}});
  let result;await ctx.collectPromptKeywordsForPageV1610([product(1)],'텀블러',1,rows=>result=rows);
  current=3;await ctx.collectPromptKeywordsForPageV1610([product(1)],'텀블러',1,rows=>result=rows);
  assert.equal(result[0].pid,'3');assert.equal(calls,4);
  ctx.activeRunId='run';await ctx.collectPromptKeywordsForPageV1610([product(1)],'텀블러',1);
  ctx.promptKeywordSortCacheV1652.clear();current=4;
  await ctx.collectPromptKeywordsForPageV1610([product(1)],'텀블러',1,rows=>result=rows);
  assert.equal(result[0].pid,'4');assert.equal(calls,8);
});

test('a blocked supplemental worker stops the whole pool before more requests start',async()=>{
  const requests=[];let release;
  const pending=new Promise(resolve=>release=resolve);
  const ctx=runtime({fetch:async url=>{const pid=String(url).match(/products\/(\d+)/)[1];requests.push(pid);
    if(pid==='2')return{ok:false,status:403,url:String(url)};
    if(pid==='3')await pending;
    return{ok:true,status:200,url:String(url),text:async()=>detailHtml(pid)};
  }});
  const running=ctx.SPX.enrichProductDetails([product(1)],{keyword:'텀블러',collectComparisonCandidates:false,supplementaryCandidates:[2,3,4,5].map(pid=>product(pid)),comparisonConcurrency:2});
  await assert.rejects(()=>running,error=>error.code==='COUPANG_BLOCKED');release();
  for(let i=0;i<10;i++)await new Promise(resolve=>setImmediate(resolve));
  assert.deepEqual(requests,['2','3']);
});

test('verified supplementary work is checkpointed before a later blocked candidate',async()=>{
  const checkpoints=[];const requests=[];
  const ctx=runtime({fetch:async url=>{const pid=String(url).match(/products\/(\d+)/)[1];requests.push(pid);return{ok:pid!=='3',status:pid==='3'?403:200,url:String(url),text:async()=>detailHtml(pid)};}});
  const options={keyword:'텀블러',collectComparisonCandidates:false,supplementaryCandidates:[product(2),product(3)],comparisonConcurrency:1,onCheckpoint:rows=>checkpoints.push(rows)};
  await assert.rejects(()=>ctx.SPX.enrichProductDetails([product(1)],options),error=>error.code==='COUPANG_BLOCKED');
  const last=checkpoints.at(-1);assert.equal(last?.find(row=>row.pid==='2')?.recommendationVerified,true);
  await ctx.SPX.enrichProductDetails(last,{...options,supplementaryCandidates:[product(2)]});
  assert.deepEqual(requests,['2','3']);
});
