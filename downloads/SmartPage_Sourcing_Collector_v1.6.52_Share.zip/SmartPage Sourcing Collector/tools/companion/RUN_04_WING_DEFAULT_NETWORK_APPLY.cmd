﻿@echo off
chcp 65001 >nul
title SmartPage WING Default Network Apply
net session >nul 2>&1
if not "%errorlevel%"=="0" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp004_APPLY_WING_DEFAULT_NETWORK.ps1"
echo.
echo ExitCode=%ERRORLEVEL%
pause
