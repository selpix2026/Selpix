﻿param(
  [int]$IdleExitMilliseconds = 1800,
  [int]$WorkerTimeoutSeconds = 45
)

$ErrorActionPreference = 'Continue'
try {
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  [Console]::InputEncoding = $utf8
  [Console]::OutputEncoding = $utf8
  $OutputEncoding = $utf8
} catch { }
$BaseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$WorkerPath = Join-Path $BaseDir 'network-worker.ps1'
$CommandQueueDir = Join-Path $BaseDir 'network-command-queue-v3083'
$ProcessingQueueDir = Join-Path $BaseDir 'network-processing-queue-v3083'
$ResultQueueDir = Join-Path $BaseDir 'network-result-queue-v3083'
$LogPath = Join-Path $BaseDir 'network-switch-runner.log'
$MutexName = 'Global\SmartPageExNetworkSwitchRunnerV3083'

function Write-JsonFile([string]$Path, $Value) {
  $parent = Split-Path -Parent $Path
  if (-not [string]::IsNullOrWhiteSpace($parent)) {
    New-Item -ItemType Directory -Path $parent -Force -ErrorAction SilentlyContinue | Out-Null
  }
  $temp = $Path + '.' + $PID + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
  try {
    $json = $Value | ConvertTo-Json -Depth 16 -Compress
    [IO.File]::WriteAllText($temp, $json, (New-Object Text.UTF8Encoding($false)))
    if (Test-Path -LiteralPath $Path) { Remove-Item -LiteralPath $Path -Force -ErrorAction Stop }
    [IO.File]::Move($temp, $Path)
  } catch {
    Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
    throw
  }
}

function Read-JsonFile([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) { return $null }
  try { return Get-Content -LiteralPath $Path -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop } catch { return $null }
}

function Write-RunnerLog([string]$Text) {
  try { Add-Content -LiteralPath $LogPath -Value ((Get-Date).ToString('s') + ' ' + $Text) -Encoding UTF8 } catch { }
}

function Write-FailureResult([string]$ResultPath,[string]$RequestId,[string]$Mode,[string]$Message,[string]$Code='NETWORK_WORKER_FAILED') {
  Write-JsonFile $ResultPath ([ordered]@{
    ok=$false
    requestId=$RequestId
    mode=$Mode
    error=$Message
    errorCode=$Code
    helperVersion='3.0.44'
    failedAt=(Get-Date).ToUniversalTime().ToString('o')
  })
}

function Restore-OrphanedProcessingRequests {
  foreach($file in @(Get-ChildItem -LiteralPath $ProcessingQueueDir -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
    $request = Read-JsonFile $file.FullName
    $requestId = if ($null -ne $request -and -not [string]::IsNullOrWhiteSpace([string]$request.requestId)) { [string]$request.requestId } else { [IO.Path]::GetFileNameWithoutExtension($file.Name) }
    $resultPath = Join-Path $ResultQueueDir ($requestId + '.json')
    if (Test-Path -LiteralPath $resultPath) {
      Remove-Item -LiteralPath $file.FullName -Force -ErrorAction SilentlyContinue
      continue
    }
    $queuePath = Join-Path $CommandQueueDir ($requestId + '.json')
    try { Move-Item -LiteralPath $file.FullName -Destination $queuePath -Force -ErrorAction Stop } catch { }
  }
}

function Cleanup-OldQueueFiles {
  $now=(Get-Date).ToUniversalTime()
  foreach($dir in @($ResultQueueDir,$ProcessingQueueDir,$CommandQueueDir)) {
    foreach($file in @(Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue)) {
      $age=($now-$file.LastWriteTimeUtc).TotalMinutes
      if($file.Extension -eq '.tmp' -and $age -gt 2){Remove-Item -LiteralPath $file.FullName -Force -ErrorAction SilentlyContinue;continue}
      if($age -gt 30){Remove-Item -LiteralPath $file.FullName -Force -ErrorAction SilentlyContinue}
    }
  }
}

function Process-OneRequest([IO.FileInfo]$NextFile) {
  $processingPath = Join-Path $ProcessingQueueDir $NextFile.Name
  try { Move-Item -LiteralPath $NextFile.FullName -Destination $processingPath -Force -ErrorAction Stop } catch { return $false }

  $request = Read-JsonFile $processingPath
  $requestId = if ($null -ne $request -and -not [string]::IsNullOrWhiteSpace([string]$request.requestId)) { [string]$request.requestId } else { [IO.Path]::GetFileNameWithoutExtension($NextFile.Name) }
  $mode = if ($null -ne $request) { [string]$request.mode } else { '' }
  $resultPath = Join-Path $ResultQueueDir ($requestId + '.json')

  try {
    if ($null -eq $request -or [string]::IsNullOrWhiteSpace($requestId)) { throw '네트워크 요청 파일을 읽지 못했습니다.' }
    $requestedAt=$null
    try{$requestedAt=[DateTime]::Parse([string]$request.requestedAt).ToUniversalTime()}catch{}
    if($null-ne$requestedAt -and (((Get-Date).ToUniversalTime()-$requestedAt).TotalMinutes -gt 2)){
      Write-FailureResult $resultPath $requestId $mode '오래된 네트워크 요청을 안전하게 폐기했습니다. 현재 선택으로 다시 한 번 적용하세요.' 'NETWORK_REQUEST_EXPIRED'
      Write-RunnerLog ('Discarded expired request ' + $requestId + ' mode=' + $mode)
      return $true
    }

    Write-RunnerLog ('Processing request ' + $requestId + ' mode=' + $mode)
    $powershell = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $arguments = '-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $WorkerPath + '" -RequestPath "' + $processingPath + '" -ResultPath "' + $resultPath + '"'
    # v4.1.76: worker가 PowerShell parse/start 단계에서 죽어 자체 결과 JSON을 못 쓰는 경우에도
    # 정확한 stderr를 보존해 더 이상 "결과 파일 없음 · 코드 1"만 보이지 않게 합니다.
    $stdoutPath=Join-Path $ResultQueueDir ($requestId+'.stdout.txt')
    $stderrPath=Join-Path $ResultQueueDir ($requestId+'.stderr.txt')
    Remove-Item -LiteralPath $stdoutPath,$stderrPath -Force -ErrorAction SilentlyContinue
    $process = Start-Process -FilePath $powershell -ArgumentList $arguments -WorkingDirectory $BaseDir -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath -ErrorAction Stop
    try {
      $deadline=(Get-Date).AddSeconds([Math]::Max(15,$WorkerTimeoutSeconds))
      while(-not $process.HasExited -and (Get-Date)-lt$deadline){Start-Sleep -Milliseconds 200;try{$process.Refresh()}catch{}}
      if(-not $process.HasExited){
        try{$process.Kill()}catch{}
        try{$process.WaitForExit(3000)|Out-Null}catch{}
        Write-FailureResult $resultPath $requestId $mode '관리자 네트워크 작업이 제한시간을 넘어 자동 종료되었습니다. 다음 요청은 새 작업으로 다시 실행됩니다.' 'NETWORK_WORKER_TIMEOUT'
      } elseif(-not (Test-Path -LiteralPath $resultPath)) {
        $stderr='';$stdout=''
        try{$stderr=(Get-Content -LiteralPath $stderrPath -Raw -Encoding UTF8 -ErrorAction SilentlyContinue).Trim()}catch{}
        try{$stdout=(Get-Content -LiteralPath $stdoutPath -Raw -Encoding UTF8 -ErrorAction SilentlyContinue).Trim()}catch{}
        $detail=if(-not[string]::IsNullOrWhiteSpace($stderr)){$stderr}elseif(-not[string]::IsNullOrWhiteSpace($stdout)){$stdout}else{'PowerShell 출력 없음'}
        if($detail.Length-gt900){$detail=$detail.Substring(0,900)}
        Write-FailureResult $resultPath $requestId $mode ('network-worker.ps1이 결과 파일을 만들지 않았습니다. 종료 코드 ' + [int]$process.ExitCode + ' · ' + $detail) 'NETWORK_WORKER_NO_RESULT'
        Write-RunnerLog ('Worker no-result request=' + $requestId + ' exit=' + [int]$process.ExitCode + ' detail=' + ($detail -replace '[\r\n]+',' '))
      }
    } finally {
      try{$process.Dispose()}catch{}
      Remove-Item -LiteralPath $stdoutPath,$stderrPath -Force -ErrorAction SilentlyContinue
    }
    Write-RunnerLog ('Completed request ' + $requestId + ' mode=' + $mode)
    return $true
  } catch {
    $message=$_.Exception.Message
    try { Write-FailureResult $resultPath $requestId $mode ('관리자 네트워크 작업 실행 실패: ' + $message) } catch { }
    Write-RunnerLog ('Request failed ' + $requestId + ' mode=' + $mode + ' error=' + $message)
    return $true
  } finally {
    Remove-Item -LiteralPath $processingPath -Force -ErrorAction SilentlyContinue
  }
}

$mutex = New-Object Threading.Mutex($false,$MutexName)
$hasMutex = $false
try {
  try { $hasMutex = $mutex.WaitOne(0) } catch [System.Threading.AbandonedMutexException] { $hasMutex = $true }
  if (-not $hasMutex) { exit 0 }
  if (-not (Test-Path -LiteralPath $WorkerPath)) { throw "Missing network worker: $WorkerPath" }
  foreach($dir in @($CommandQueueDir,$ProcessingQueueDir,$ResultQueueDir)){New-Item -ItemType Directory -Path $dir -Force|Out-Null}
  Restore-OrphanedProcessingRequests
  Cleanup-OldQueueFiles
  Write-RunnerLog ('SYSTEM one-shot routing queue runner started. PID=' + $PID)

  $idleSince=Get-Date
  while($true){
    $next = Get-ChildItem -LiteralPath $CommandQueueDir -Filter '*.json' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTimeUtc,Name | Select-Object -First 1
    if($null-eq$next){
      if(((Get-Date)-$idleSince).TotalMilliseconds -ge [Math]::Max(500,$IdleExitMilliseconds)){break}
      Start-Sleep -Milliseconds 120
      continue
    }
    $idleSince=Get-Date
    $null=Process-OneRequest $next
  }
  Write-RunnerLog ('SYSTEM one-shot routing queue runner stopped. PID=' + $PID)
  exit 0
} catch {
  Write-RunnerLog ('Fatal runner error: ' + $_.Exception.Message)
  exit 1
} finally {
  if ($hasMutex) { try { $mutex.ReleaseMutex() } catch { } }
  try { $mutex.Dispose() } catch { }
}
