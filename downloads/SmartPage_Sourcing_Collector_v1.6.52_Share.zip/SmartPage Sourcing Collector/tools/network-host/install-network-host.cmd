@echo off
chcp 65001 >nul
setlocal
set "PACKAGE_RELEASE=v4.2.01"
echo ============================================================
echo SmartPage Ex Network Host Installer - package %PACKAGE_RELEASE%
echo Restore model: native x64 launcher + PowerShell-hosted Helper DLL + same 30765/30766-30769 V33 bank
echo Old 29765/29766 listeners are not required or reused. Native Messaging remains registered to the current V33 helper.
echo Installer folder: %~dp0
echo ============================================================
rem PACKAGE_RELEASE validation is intentionally delegated to PowerShell.
rem Windows findstr can false-fail when %%~dp0 contains Korean/Unicode path characters.
rem install-network-host.ps1 validates PACKAGE_RELEASE.txt with Unicode-safe .NET file APIs.
set "STATUS_FILE=%TEMP%\SmartPageEx-network-install-status.txt"
del /q "%STATUS_FILE%" >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-network-host.ps1" -ExtensionId "olmpllofoggohefbdkgkjjnlanfnaocd" -ExtensionRootOverride "%~dp0..\.."
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo SmartPage Ex network helper was installed for the currently loaded extension ID.
  echo The detected and allowed extension IDs are shown in the report above.
  echo Hidden bridge and on-demand administrator routing task are installed. No routing process stays running.
) else (
  echo Installation failed. Error code: %RC%
  if exist "%STATUS_FILE%" type "%STATUS_FILE%"
)
pause
exit /b %RC%
