@echo off
chcp 65001 >nul
setlocal
echo ==============================================
echo  SmartPage WING Login Session Manager
echo ==============================================
echo [1] Save current dedicated WING session
echo [2] Restore saved dedicated WING session
echo [3] Status
echo [0] Exit
set /p "CHOICE=Select: "
if "%CHOICE%"=="1" set "ACT=Save"
if "%CHOICE%"=="2" set "ACT=Restore"
if "%CHOICE%"=="3" set "ACT=Status"
if "%CHOICE%"=="0" exit /b 0
if not defined ACT exit /b 1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\wing-recovery\WING_SESSION_MANAGER.ps1" -Action %ACT%
set "RC=%ERRORLEVEL%"
echo.
echo ExitCode=%RC%
pause
exit /b %RC%
