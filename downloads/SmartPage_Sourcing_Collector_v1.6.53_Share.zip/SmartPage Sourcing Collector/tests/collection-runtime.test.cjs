const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const {root,runtime}=require('./helpers.cjs');
function collectionRuntime(){
  const ctx=runtime();
  ctx.queueMicrotask=queueMicrotask;ctx.requestAnimationFrame=()=>1;ctx.cancelAnimationFrame=()=>{};ctx.setInterval=()=>1;ctx.clearInterval=()=>{};
  ctx.localStorage={getItem:()=>null,setItem:()=>{},removeItem:()=>{}};ctx.sessionStorage=ctx.localStorage;
  ctx.MutationObserver=ctx.window.MutationObserver;ctx.getComputedStyle=()=>({display:'block',visibility:'visible',position:'static'});
  ctx.window.matchMedia=()=>({matches:false,addEventListener:()=>{}});ctx.window.location=ctx.location;
  ctx.SPX.util.runtimeAlive=()=>true;ctx.chrome.runtime.id='test';ctx.chrome.runtime.getURL=p=>'chrome-extension://test/'+p;
  ctx.chrome.runtime.onMessage={addListener:()=>{},removeListener:()=>{}};ctx.chrome.runtime.sendMessage=async()=>({ok:true,data:{extensionVersion:'1.6.52',runtimeBuild:'1.6.52'},state:{running:false}});
  for(const file of ['keyword-filter','discovery','prompt-keywords-v1610','coupang-seed-catalog'])vm.runInContext(fs.readFileSync(root+'/src/lib/'+file+'.js','utf8'),ctx);
  ctx.SPX.util.getSettings=async()=>({autoScrollEnabled:false,collectDetailRecommendations:false,keyword1Enabled:false,keyword2Enabled:false});
  let source=fs.readFileSync(root+'/src/content/coupang-search.js','utf8');
  // Expose the original UI factory only inside this test VM; skip autonomous boot.
  source=source.replace("  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });\n  else boot();",'  globalThis.__sidebar={ensureUi,collectPage,runAutomationPage,runManualSinglePageScan,renderAgg,renderProgressiveAggregate,state};');
  vm.runInContext(source,ctx,{filename:'coupang-search.js'});

  ctx.performance=performance;
  ctx.setTimeout=(callback,ms,...args)=>{const timer=setTimeout(callback,ms,...args);timer.unref();return timer;};
  ctx.__sidebar.ensureUi();
  ctx.__sidebar.state.keyword='텀블러';
  ctx.document.body.insertAdjacentHTML('afterbegin', '<ul><li class="search-product"><a href="/vp/products/123456"><span class="name">스테인리스 보온 텀블러</span><span class="price-value">12,000</span><span class="rating-total-count">(30)</span></a></li></ul>');
  return ctx;
}

test('real collection parses product DOM and renders both progressive phases',async()=>{
 const ctx=collectionRuntime();
 const result=await ctx.__sidebar.collectPage('',null,{collectDetail:false});
 assert.equal(result.res.items.length,1);
 assert.equal(result.res.items[0].pid,'123456');
 assert.ok(ctx.__sidebar.state.agg);
 assert.match(ctx.document.getElementById('spx-body').textContent,/텀블러/);
});

test('final aggregate renderer keeps matching keyword state',()=>{
 const ctx=collectionRuntime();
 const aggregate=ctx.SPX.aggregate('텀블러',[{pid:'123456',name:'스테인리스 보온 텀블러',price:12000,reviews:30}], 'coupang',8,{});
 ctx.__sidebar.renderAgg(aggregate);
 assert.equal(ctx.__sidebar.state.agg,aggregate);
});

for(const renderer of ['renderAgg','renderProgressiveAggregate'])test(`${renderer} updates matching normalized keywords and preserves state for other keywords`,()=>{
 const ctx=collectionRuntime();
 ctx.__sidebar.state.lockedKeyword='보온 텀블러';
 const aggregate=ctx.SPX.aggregate('보온텀블러',[{pid:'123456',name:'보온 텀블러',price:12000,reviews:30}], 'coupang',8,{});
 ctx.__sidebar[renderer](aggregate);
 assert.equal(ctx.__sidebar.state.agg,aggregate);
 ctx.__sidebar[renderer]({...aggregate,keyword:'물병'});
 assert.equal(ctx.__sidebar.state.agg,aggregate);
});
