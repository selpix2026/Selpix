﻿param([switch]$InstallGate,[int]$TimeoutSeconds=300,[ValidateSet('','chrome','whale')][string]$BrowserFamily='')
$ErrorActionPreference='Stop'
try{$utf8=New-Object Text.UTF8Encoding($false);[Console]::InputEncoding=$utf8;[Console]::OutputEncoding=$utf8;$OutputEncoding=$utf8}catch{}
$InstalledRoot=Join-Path $env:ProgramData 'SmartPageEx\SmartPage Sourcing Collector'
$TargetRoot=$InstalledRoot
$SourceRoot=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
# v1.5.29: RUN_08 must not silently prefer an older ProgramData copy over the package the user actually ran.
# Mirror only the Collector source tree into the fixed install root; profiles, NetworkHost settings and server data are untouched.
$syncScript=Join-Path $SourceRoot 'tools\crosspc\10_SYNC_CURRENT_PACKAGE_TO_INSTALLED_ROOT.ps1'
if(-not(Test-Path -LiteralPath $syncScript -PathType Leaf)){throw '현재 패키지 고정경로 동기화 도구를 찾지 못했습니다.'}
& "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $syncScript -SourceRoot $SourceRoot -Quiet
if($LASTEXITCODE -ne 0){
  $syncErrorPath=Join-Path (Join-Path $env:ProgramData 'SmartPageEx') 'runtime-sync-last-error.txt'
  $syncDetail='';try{if(Test-Path -LiteralPath $syncErrorPath -PathType Leaf){$syncDetail=(Get-Content -LiteralPath $syncErrorPath -Raw -Encoding UTF8).Trim()}}catch{}
  if(-not[string]::IsNullOrWhiteSpace($syncDetail)){throw ('현재 패키지 → ProgramData 동기화 실패. ExitCode='+$LASTEXITCODE+' · '+$syncDetail)}
  throw ('현재 패키지 → ProgramData 동기화 실패. ExitCode='+$LASTEXITCODE)
}
$ExtensionRoot=$InstalledRoot
. (Join-Path $PSScriptRoot 'browser-launch-common.ps1')
$BrowserFamily=Resolve-SpxBrowserFamily $BrowserFamily
$Profile=if($BrowserFamily -eq 'whale'){'C:\SpxDedicatedProfile-Whale'}else{'C:\SpxDedicatedProfile'}
$BrowserExecutable=if($BrowserFamily -eq 'whale'){'whale.exe'}else{'chrome.exe'}
$ExtensionId='olmpllofoggohefbdkgkjjnlanfnaocd'
$NetBase=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$RequestPath=Join-Path $NetBase 'dedicated-window-request.json'
$ResultPath=Join-Path $NetBase 'dedicated-window-result.json'
$ReadyPath=Join-Path $NetBase 'dedicated-window-launcher.ready'
$BrowserTaskName='SmartPageEx Open Dedicated Browser'
$NetworkRestartRequiredFlag=Join-Path $NetBase 'v160-networkhost-restart-required.json'
function Write-JsonUtf8Atomic([string]$Path,[object]$Value){$tmp=$Path+'.tmp.'+[Guid]::NewGuid().ToString('N');[IO.File]::WriteAllText($tmp,($Value|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)));Move-Item -LiteralPath $tmp -Destination $Path -Force}
function Write-NetworkHostRestartNotice{
  if(Test-Path -LiteralPath $NetworkRestartRequiredFlag -PathType Leaf){
    Write-Host ''
    Write-Host '⚠ NetworkHost v1.6.2 적용이 안전하게 예약되었습니다. Windows를 1회 재시작해야 새 테더링 절감 정책/사용량 계측이 활성화됩니다.' -ForegroundColor Yellow
    Write-Host '재시작 전에는 기존 NetworkHost가 계속 동작할 수 있으므로 테더링 데이터 테스트를 하지 마세요.' -ForegroundColor DarkYellow
  }
}
function Test-Registered{
  foreach($name in @('Secure Preferences','Preferences')){
    $path=Join-Path $Profile ('Default\'+$name)
    if(-not(Test-Path -LiteralPath $path -PathType Leaf)){continue}
    try{
      $j=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json
      $settings=$j.extensions.settings
      if($null-eq$settings){continue}
      $prop=$settings.PSObject.Properties[$ExtensionId]
      if($null-eq$prop -or $null-eq$prop.Value){continue}
      $entry=$prop.Value
      $state=0;$reasons=0
      try{$state=[int]$entry.state}catch{}
      try{$reasons=[int64]$entry.disable_reasons}catch{}
      if($state-ne1 -or $reasons-ne0){continue}
      $stored=[string]$entry.path
      if([string]::IsNullOrWhiteSpace($stored)){continue}
      try{
        $candidate=[Environment]::ExpandEnvironmentVariables($stored.Trim().Trim('"'))
        if(-not[IO.Path]::IsPathRooted($candidate)){$candidate=Join-Path (Split-Path -Parent $path) $candidate}
        $candidate=[IO.Path]::GetFullPath($candidate)
        if((Test-Path -LiteralPath (Join-Path $candidate 'manifest.json') -PathType Leaf) -and [string]::Equals($candidate.TrimEnd('\'),$ExtensionRoot.TrimEnd('\'),[StringComparison]::OrdinalIgnoreCase)){return $true}
      }catch{}
    }catch{}
  }
  return $false
}
function Ensure-InteractiveLauncher{
  $ready=$null;$alive=$false
  if(Test-Path -LiteralPath $ReadyPath){try{$ready=Get-Content -LiteralPath $ReadyPath -Raw|ConvertFrom-Json}catch{$ready=$null}}
  if($null-ne$ready -and [int]$ready.pid -gt0){try{$null=Get-Process -Id ([int]$ready.pid) -ErrorAction Stop;$alive=$true}catch{$alive=$false}}
  if(-not$alive){try{Start-ScheduledTask -TaskName $BrowserTaskName -ErrorAction Stop}catch{throw '현재 사용자용 전용창 launcher를 시작하지 못했습니다. RUN_00_INSTALL_OTHER_PC.cmd를 다시 실행하세요.'};for($i=0;$i-lt40;$i++){Start-Sleep -Milliseconds 250;if(Test-Path -LiteralPath $ReadyPath){try{$ready=Get-Content -LiteralPath $ReadyPath -Raw|ConvertFrom-Json}catch{$ready=$null}};if($null-ne$ready -and [int]$ready.pid -gt0){try{$null=Get-Process -Id ([int]$ready.pid) -ErrorAction Stop;$alive=$true;break}catch{$alive=$false}}}}
  if(-not$alive){throw '현재 로그인 사용자 세션의 전용창 launcher가 준비되지 않았습니다.'}
}
function Request-InteractiveWindow([string]$LaunchMode,[string]$StartUrl){
  Ensure-InteractiveLauncher
  $manifest=Get-Content -LiteralPath (Join-Path $ExtensionRoot 'manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
  $requestId=[Guid]::NewGuid().ToString('N');Remove-Item -LiteralPath $ResultPath -Force -ErrorAction SilentlyContinue
  $payload=[ordered]@{requestId=$requestId;browserFamily=$BrowserFamily;launchMode=$LaunchMode;startUrl=$StartUrl;extensionId=$ExtensionId;extensionRoot=$ExtensionRoot;extensionVersion=[string]$manifest.version;forceRuntimeRestart=$true;requestedAt=(Get-Date).ToUniversalTime().ToString('o')}
  Write-JsonUtf8Atomic $RequestPath $payload
  for($i=0;$i-lt120;$i++){Start-Sleep -Milliseconds 250;if(-not(Test-Path -LiteralPath $ResultPath)){continue};try{$candidate=Get-Content -LiteralPath $ResultPath -Raw|ConvertFrom-Json}catch{continue};if([string]$candidate.requestId-ne$requestId){continue};if($candidate.ok-ne$true){throw ('전용 프로필 등록창 열기 실패 · '+[string]$candidate.error)};return $candidate}
  throw '전용 프로필 등록창을 30초 안에 열지 못했습니다.'
}
if(-not(Test-Path -LiteralPath (Join-Path $ExtensionRoot 'manifest.json') -PathType Leaf)){throw 'Collector 확장 폴더를 찾지 못했습니다.'}
New-Item -ItemType Directory -Path $Profile -Force|Out-Null
Write-Host ('확장 원본 폴더: '+$ExtensionRoot) -ForegroundColor DarkGray
# v1.5.29: the sync helper already refreshes the ProgramData interactive launcher in the same elevated pass.
# Do not invoke RUN_09 again here; repeated UAC/launcher restarts were part of the confusing repair loop.
if(Test-Registered){Write-Host '✅ SmartPage Collector 전용 프로필 등록 완료 · 전용창 launcher도 현재 버전으로 동기화했습니다.' -ForegroundColor Green;Write-NetworkHostRestartNotice;exit 0}
try{Set-Clipboard -Value $ExtensionRoot -ErrorAction Stop}catch{}
$null=Request-InteractiveWindow -LaunchMode 'register-direct' -StartUrl 'chrome://extensions/'
Start-Sleep -Milliseconds 600
$staleDedicated=@(Get-CimInstance Win32_Process -Filter ("Name='"+$BrowserExecutable+"'") -ErrorAction SilentlyContinue|Where-Object{
  [string]$_.CommandLine -like ('*'+$Profile+'*') -and (([string]$_.CommandLine -match '(?i)--load-extension(?:=|\s)') -or ([string]$_.CommandLine -match '(?i)--disable-extensions-except(?:=|\s)'))
})
if($staleDedicated.Count -gt 0){
  foreach($proc in $staleDedicated){try{Stop-Process -Id ([int]$proc.ProcessId) -Force -ErrorAction SilentlyContinue}catch{}}
  throw '구형 전용창 실행 옵션(--load-extension/--disable-extensions-except)이 아직 남아 있었습니다. RUN_09_REFRESH_NORMAL_CHROME_LAUNCHER.cmd를 실행한 뒤 다시 등록하세요.'
}
Write-Host ''
Write-Host ('SmartPage Collector 최초 등록 · '+$BrowserFamily+' 전용 프로필') -ForegroundColor Green
Write-Host '열린 확장 프로그램 화면에서 아래 3가지만 해주세요.' -ForegroundColor Cyan
Write-Host '1) 오른쪽 위 [개발자 모드] 켜기'
Write-Host '2) [압축해제된 확장 프로그램을 로드합니다] 클릭'
Write-Host ('3) 이 폴더 선택: '+$ExtensionRoot) -ForegroundColor Yellow
Write-Host '폴더 경로는 클립보드에도 복사했습니다. WING 로그인과는 관계없는 설치 단계입니다.' -ForegroundColor DarkYellow
Write-Host ''
$deadline=(Get-Date).AddSeconds([Math]::Max(30,$TimeoutSeconds))
while((Get-Date)-lt$deadline){if(Test-Registered){Write-Host '✅ 확장 등록 완료 · 이후에는 전용창이 일반 Chrome 새 프로필에서 바로 열립니다.' -ForegroundColor Green;Write-NetworkHostRestartNotice;exit 0};Start-Sleep -Seconds 1}
Write-Host '확장 등록을 아직 확인하지 못했습니다. 열린 chrome://extensions 화면에서 SmartPage Sourcing Collector가 켜져 있는지 확인하세요.' -ForegroundColor Red
if($InstallGate){Write-Host '설치는 여기에서 멈췄습니다. 확장 등록은 Collector 실행에 필요하지만 WING 로그인은 필요하지 않습니다.' -ForegroundColor Yellow}
exit 3
