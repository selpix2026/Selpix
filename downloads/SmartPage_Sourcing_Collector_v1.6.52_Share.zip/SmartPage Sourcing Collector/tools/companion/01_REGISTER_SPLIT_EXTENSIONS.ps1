﻿﻿param([switch]$Approve)
$ErrorActionPreference='Stop'
if(-not $Approve){throw '승인 필요: RUN_01_REGISTER_SPLIT_EXTENSIONS.cmd 로 실행하세요.'}
$CollectorId='olmpllofoggohefbdkgkjjnlanfnaocd'
$ManagerId='cikfdcalhneenfppkcplacnheaecfnai'
$InstallDir=Join-Path $env:ProgramData 'SmartPageEx\NetworkHostV33'
$NativeManifest=Join-Path $InstallDir 'com.smartpage.spx_network_v7.json'
$Config=Join-Path $InstallDir 'network-host-config.json'
if(!(Test-Path $NativeManifest)){throw 'NetworkHostV33 Native manifest를 찾지 못했습니다.'}
$packageRoot=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$parent=Split-Path -Parent $packageRoot
$collectorCandidates=@(
  (Join-Path $parent 'SmartPage_Sourcing_Collector_v1.1.0'),
  (Join-Path $parent 'SmartPage_Sourcing_Collector_v1.0.4'),
  (Join-Path $parent 'SmartPage_Sourcing_Collector_v1.0.3'),
  (Join-Path $parent 'SmartPage_Sourcing_Collector_v1.0.2'),
  (Join-Path $parent 'SmartPage Sourcing Collector'),
  $packageRoot
)
$PinnedCollectorRoot='D:\01. Work In Process\쿠팡 수집기\SmartPage Sourcing Collector'
$CollectorRoot=''
foreach($candidate in $collectorCandidates){
  $manifest=Join-Path $candidate 'manifest.json'
  if(!(Test-Path -LiteralPath $manifest)){continue}
  try{$m=([IO.File]::ReadAllText($manifest,[Text.Encoding]::UTF8)|ConvertFrom-Json);if([string]$m.name -eq 'SmartPage Sourcing Collector'){$CollectorRoot=[IO.Path]::GetFullPath($candidate);break}}catch{}
}
if([string]::IsNullOrWhiteSpace($CollectorRoot)){throw 'Collector 폴더를 찾지 못했습니다. Manager와 Collector 폴더를 같은 상위 폴더에 압축 해제한 뒤 다시 실행하세요.'}
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
Copy-Item -LiteralPath $NativeManifest -Destination ($NativeManifest+'.split-backup-'+$stamp) -Force
$n=([IO.File]::ReadAllText($NativeManifest,[Text.Encoding]::UTF8)|ConvertFrom-Json)
$orig=@($n.allowed_origins)
foreach($id in @($CollectorId,$ManagerId)){$o='chrome-extension://'+$id+'/';if($orig -notcontains $o){$orig+=$o}}
$n.allowed_origins=@($orig|Select-Object -Unique)
[IO.File]::WriteAllText($NativeManifest,($n|ConvertTo-Json -Depth 20),(New-Object Text.UTF8Encoding($false)))
if(Test-Path $Config){
  Copy-Item -LiteralPath $Config -Destination ($Config+'.split-backup-'+$stamp) -Force
  $c=([IO.File]::ReadAllText($Config,[Text.Encoding]::UTF8)|ConvertFrom-Json)
  $ids=@($c.extensionIds);foreach($id in @($CollectorId,$ManagerId)){if($ids -notcontains $id){$ids+=$id}}
  $c.extensionIds=@($ids|Select-Object -Unique)
  $c.allowedOrigins=@($c.extensionIds|ForEach-Object{'chrome-extension://'+$_+'/' })
  # Dedicated selected-network Chrome must load the Collector, not the Manager. Existing helper executable,
  # ports, selected adapter and integration-secrets are preserved; only the unpacked extension root changes.
  $c.extensionRoot=$CollectorRoot
  $c.extensionRootFound=$true
  $c.extensionId=$CollectorId
  [IO.File]::WriteAllText($Config,($c|ConvertTo-Json -Depth 30),(New-Object Text.UTF8Encoding($true)))
}
Write-Host ('CollectorRoot='+$CollectorRoot)
Write-Host 'NetworkHostV33 allowed_origins에 Collector/Manager ID를 추가하고 전용창 extensionRoot를 Collector로 지정했습니다.'
Write-Host '기존 integration-secrets.json은 변경하지 않았습니다.'
Write-Host 'HELPER_RESTART=0 / ROUTE_CHANGE=0 / IP_CHANGE=0 / CHROME_FORCE_KILL=0'
Write-Host 'FINAL=SPLIT_EXTENSIONS_REGISTER_PASS'
