using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Web.Script.Serialization;

public static class SpxNetworkHost
{
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = 1024 * 1024 };
    private static readonly string BaseDir = ResolveBaseDir();

    private static string ResolveBaseDir()
    {
        try
        {
            string configured = Environment.GetEnvironmentVariable("SPX_NETWORK_HOST_DIR");
            if (!String.IsNullOrWhiteSpace(configured) && Directory.Exists(configured)) return Path.GetFullPath(configured);
        }
        catch { }
        try
        {
            string location = typeof(SpxNetworkHost).Assembly.Location;
            if (!String.IsNullOrWhiteSpace(location))
            {
                string dir = Path.GetDirectoryName(location);
                if (!String.IsNullOrWhiteSpace(dir) && Directory.Exists(dir)) return dir;
            }
        }
        catch { }
        return AppDomain.CurrentDomain.BaseDirectory;
    }
    private static readonly string RouteCommandQueueDir = Path.Combine(BaseDir, "network-command-queue-v3083");
    private static readonly string RouteResultQueueDir = Path.Combine(BaseDir, "network-result-queue-v3083");
    private static readonly string RuntimePath = Path.Combine(BaseDir, "network-runtime.json");
    private static readonly string ProxyStatePath = Path.Combine(BaseDir, "coupang-window-proxy.json");
    private static readonly string ConfigPath = Path.Combine(BaseDir, "network-host-config.json");
    private static readonly string BridgeLogPath = Path.Combine(BaseDir, "local-bridge.log");
    private static readonly string MobileResetScriptPath = Path.Combine(BaseDir, "reset-mobile-network.ps1");
    private static readonly string MobileResetStatePath = Path.Combine(BaseDir, "mobile-reset-state.json");
    private static readonly string DedicatedWindowRequestPath = Path.Combine(BaseDir, "dedicated-window-request.json");
    private static readonly string DedicatedWindowResultPath = Path.Combine(BaseDir, "dedicated-window-result.json");
    private static readonly string DedicatedSettingsPath = Path.Combine(BaseDir, "dedicated-profile-settings.dpapi");
    private static readonly string DedicatedSettingsMachinePath = Path.Combine(BaseDir, "dedicated-profile-settings-machine.dpapi");
    private static readonly string IntegrationSecretsPath = Path.Combine(BaseDir, "integration-secrets.json");
    private static readonly string ManagerLayoutPath = Path.Combine(BaseDir, "manager-layout-v30823.json");
    private static readonly string ManagerDataFolderConfigPath = Path.Combine(BaseDir, "manager-data-folder-v4184.json");
    private const string ManagerLiveDbFileName = "SmartPage_Manager_Live.sqlite";
    private const string ManagerBuildingDbFileName = "SmartPage_Manager_Live.building.sqlite";
    private const string ManagerBackupCatalogFileName = "SmartPage_Manager_Backups.json";
    private const string ManagerBackupPrefix = "SmartPage_Manager_Backup_";
    private const int ManagerBackupCatalogVersion = 1;
    private const int SQLITE_OK = 0;
    private const int SQLITE_ROW = 100;
    private const int SQLITE_DONE = 101;
    private static readonly IntPtr SQLITE_TRANSIENT = new IntPtr(-1);
    private static readonly string RouteGuardStatePath = Path.Combine(BaseDir, "selected-route-guard.json");
    private static readonly string SystemRoutePinStatePath = Path.Combine(BaseDir, "system-route-pin.json");
    private static readonly byte[] DedicatedSettingsEntropy = Encoding.UTF8.GetBytes("SmartPageEx.DedicatedProfile.Settings.v1");
    private static readonly byte[] DedicatedSettingsMachineEntropy = Encoding.UTF8.GetBytes("SmartPageEx.DedicatedProfile.Settings.v2.LocalMachine");
    private const string TaskName = "SmartPageEx Network Switch";
    private const string DedicatedWindowTaskName = "SmartPageEx Open Dedicated Browser";
    private const string IntegrationSettingsTaskName = "SmartPageEx Open Integration Settings";
    private const string BridgeToken = "spx-v7-8e3c0af4640b4a20a1d706a1fba5e6d7";
    private const string BridgePrefix = "http://127.0.0.1:30765/";
    private static int ProxyPort = 30766;
    private static readonly int[] ProxyPortCandidates = new int[] { 30766, 30767, 30768, 30769 };
    private const string HelperVersion = "3.0.45";
    private const string BuildMarker = "v3.0.45-v1651-coupang-only";
    private static readonly string[] IntegrationSecretKeys = new string[]
    {
        "supabaseUrl", "serviceKey",
        "naverApiKey", "naverSecretKey", "naverCustomerId",
        "naverDataLabHubClientId", "naverDataLabHubClientSecret",
        "naverDataLabLegacyClientId", "naverDataLabLegacyClientSecret",
        "geminiApiKey", "openaiApiKey"
    };
    private static readonly object ModeLock = new object();
    private static readonly object ProxyStateLock = new object();
    private static readonly object ProxyTrafficLock = new object();
    private static readonly object PublicIpLock = new object();
    private static readonly object DnsCacheLock = new object();
    private static readonly object LogLock = new object();
    private static readonly object RouteStateLock = new object();
    private static readonly object ManagerLayoutLock = new object();
    private static readonly object StatusSnapshotLock = new object();
    private static readonly object MobileResetProcessLock = new object();
    private static readonly object AdbIdentityLock = new object();
    private static DateTime AdbIdentityCachedAtUtc = DateTime.MinValue;
    private static Dictionary<string, string> AdbIdentityCache = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    private static Process ActiveMobileResetProcess = null;
    private static volatile bool MobileResetCancelRequested = false;
    private static DateTime RouteStateCachedAtUtc = DateTime.MinValue;
    private static Dictionary<string, object> RouteStateCache = new Dictionary<string, object>();
    private static DateTime StatusSnapshotCachedAtUtc = DateTime.MinValue;
    private static Dictionary<string, object> StatusSnapshotCache = null;
    private static TcpListener ProxyListener;
    private static volatile bool ProxyReady;
    private static int ControlActiveConnections = 0;
    private static int ProxyActiveConnections = 0;
    private static long RawHttpClientDisconnects = 0;
    private static long ProxyConnectionsClosed = 0;
    private static long ProxyTrafficUpBytes = 0;
    private static long ProxyTrafficDownBytes = 0;
    private static readonly Dictionary<string, ProxyTrafficCounter> ProxyTrafficByHost = new Dictionary<string, ProxyTrafficCounter>(StringComparer.OrdinalIgnoreCase);
    private static bool LogEncodingPrepared = false;
    private static readonly Dictionary<string, DnsCacheEntry> DnsCache = new Dictionary<string, DnsCacheEntry>(StringComparer.OrdinalIgnoreCase);

    private sealed class AdapterBinding
    {
        public string Id;
        public string Name;
        public string Description;
        public IPAddress Address;
        public int InterfaceIndex;
        public IPAddress[] DnsServers;
    }

    private sealed class DnsCacheEntry
    {
        public IPAddress[] Addresses;
        public DateTime ExpiresAtUtc;
        public string ResolutionMode;
    }

    private sealed class ProxyTrafficCounter
    {
        public long UpBytes;
        public long DownBytes;
        public long Connections;
    }

    private sealed class RawHttpRequest
    {
        public string Method;
        public string Path;
        public string Query;
        public Dictionary<string, string> Headers;
        public byte[] Body;
    }


    private static bool IsLoopbackPortOpen(int port, int timeoutMs)
    {
        TcpClient client = null;
        try
        {
            client = new TcpClient();
            IAsyncResult result = client.BeginConnect(IPAddress.Loopback, port, null, null);
            if (!result.AsyncWaitHandle.WaitOne(timeoutMs)) return false;
            client.EndConnect(result);
            return true;
        }
        catch { return false; }
        finally { try { if (client != null) client.Close(); } catch { } }
    }

    private static bool IsBridgeControlHttpHealthy(int timeoutMs)
    {
        TcpClient client = null;
        try
        {
            client = new TcpClient();
            IAsyncResult connected = client.BeginConnect(IPAddress.Loopback, 30765, null, null);
            if (!connected.AsyncWaitHandle.WaitOne(Math.Max(250, timeoutMs))) return false;
            client.EndConnect(connected);
            client.ReceiveTimeout = Math.Max(350, timeoutMs);
            client.SendTimeout = Math.Max(350, timeoutMs);
            using (NetworkStream stream = client.GetStream())
            {
                byte[] request = Encoding.ASCII.GetBytes("GET /health HTTP/1.1\r\nHost: 127.0.0.1:30765\r\nConnection: close\r\n\r\n");
                stream.Write(request, 0, request.Length);
                stream.Flush();
                byte[] buffer = new byte[2048];
                int read = stream.Read(buffer, 0, buffer.Length);
                if (read <= 0) return false;
                string text = Encoding.UTF8.GetString(buffer, 0, read);
                return Regex.IsMatch(text, "^HTTP/1\\.[01] 200\\b", RegexOptions.IgnoreCase) && text.IndexOf("\r\n\r\n", StringComparison.Ordinal) >= 0;
            }
        }
        catch { return false; }
        finally { try { if (client != null) client.Close(); } catch { } }
    }

    private static bool IsBridgeProxyReady()
    {
        // The persistent SYSTEM bridge may bind any member of the fixed V33 proxy bank.
        // A transient Native Messaging process starts with ProxyPort=30766, so checking only
        // that port can falsely report the bridge as down when the live bridge selected 30767-30769.
        if (!IsLoopbackPortOpen(30765, 350)) return false;
        foreach (int candidate in ProxyPortCandidates)
        {
            if (!IsLoopbackPortOpen(candidate, 350)) continue;
            ProxyPort = candidate;
            return true;
        }
        return false;
    }

    private static Dictionary<string, object> BuildQuickHealth()
    {
        Dictionary<string, object> health = new Dictionary<string, object>();
        health["ok"] = true;
        health["transport"] = "raw_loopback_http";
        health["helperVersion"] = HelperVersion;
        health["buildMarker"] = BuildMarker;
        health["bridgePort"] = 30765;
        health["proxyPort"] = ProxyPort;
        health["proxyReady"] = ProxyReady;
        health["pid"] = Process.GetCurrentProcess().Id;
        health["activeControlConnections"] = Interlocked.CompareExchange(ref ControlActiveConnections, 0, 0);
        health["activeProxyConnections"] = Interlocked.CompareExchange(ref ProxyActiveConnections, 0, 0);
        health["rawHttpClientDisconnects"] = Interlocked.Read(ref RawHttpClientDisconnects);
        health["proxyConnectionsClosed"] = Interlocked.Read(ref ProxyConnectionsClosed);
        health["proxyTrafficUpBytes"] = Interlocked.Read(ref ProxyTrafficUpBytes);
        health["proxyTrafficDownBytes"] = Interlocked.Read(ref ProxyTrafficDownBytes);
        lock (ProxyTrafficLock)
        {
            health["proxyTrafficTopHosts"] = ProxyTrafficByHost
                .OrderByDescending(pair => pair.Value.UpBytes + pair.Value.DownBytes)
                .Take(12)
                .Select(pair => (object)new Dictionary<string, object>
                {
                    { "host", pair.Key },
                    { "upBytes", pair.Value.UpBytes },
                    { "downBytes", pair.Value.DownBytes },
                    { "totalBytes", pair.Value.UpBytes + pair.Value.DownBytes },
                    { "connections", pair.Value.Connections }
                }).ToArray();
        }
        health["statusSnapshotAgeMs"] = StatusSnapshotCachedAtUtc == DateTime.MinValue ? -1L : Math.Max(0L, (long)(DateTime.UtcNow - StatusSnapshotCachedAtUtc).TotalMilliseconds);
        try
        {
            Dictionary<string, object> resetState = ReadJsonFile(MobileResetStatePath);
            health["mobileResetRunning"] = IsMobileResetRunning();
            health["mobileResetPhase"] = Text(resetState, "phase");
            health["mobileResetHeartbeatAt"] = Text(resetState, "heartbeatAt");
        }
        catch { health["mobileResetRunning"] = false; }
        return health;
    }


    private static bool TryStartDirectBridge(out string detail)
    {
        detail = "";
        try
        {
            string exePath = Path.Combine(BaseDir, "SpxNetworkHost.exe");
            if (String.IsNullOrWhiteSpace(exePath) || !File.Exists(exePath))
            {
                detail = "native launcher path is unavailable";
                return false;
            }
            ProcessStartInfo info = new ProcessStartInfo
            {
                FileName = exePath,
                Arguments = "--http-server",
                WorkingDirectory = BaseDir,
                UseShellExecute = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            Process child = Process.Start(info);
            if (child == null)
            {
                detail = "Process.Start returned null";
                return false;
            }
            detail = "pid=" + child.Id + " exe=" + exePath;
            return true;
        }
        catch (Exception ex)
        {
            detail = ex.Message;
            return false;
        }
    }

    private static bool EnsureBridgeProcess(int waitMs)
    {
        if (IsBridgeProxyReady() && IsBridgeControlHttpHealthy(1200)) return true;

        // Prefer the installed SYSTEM recovery path when it exists.
        string recoveryOutput = "";
        int recoveryExit = RunScheduledTask("SmartPageEx Network Bridge Recovery", out recoveryOutput);
        AppendLog("On-demand SYSTEM bridge recovery requested by Native Messaging. exit=" + recoveryExit + " output=" + recoveryOutput);
        if (recoveryExit == 0)
        {
            DateTime recoveryDeadline = DateTime.UtcNow.AddMilliseconds(Math.Min(5000, Math.Max(2500, waitMs / 2)));
            while (DateTime.UtcNow < recoveryDeadline)
            {
                if (IsBridgeProxyReady() && IsBridgeControlHttpHealthy(1200)) return true;
                Thread.Sleep(180);
            }
        }

        // Try the canonical bridge task once. Missing/broken tasks must not make Native Messaging
        // wait through the full recovery timeout.
        string bridgeOutput = "";
        int bridgeExit = RunScheduledTask("SmartPageEx Network Local Bridge", out bridgeOutput);
        AppendLog("On-demand SYSTEM bridge task run requested by Native Messaging. exit=" + bridgeExit + " output=" + bridgeOutput);
        if (bridgeExit == 0)
        {
            DateTime taskDeadline = DateTime.UtcNow.AddMilliseconds(Math.Min(3000, Math.Max(1600, waitMs / 4)));
            while (DateTime.UtcNow < taskDeadline)
            {
                if (IsBridgeProxyReady() && IsBridgeControlHttpHealthy(1200)) return true;
                Thread.Sleep(180);
            }
        }

        // v4.1.83: the loopback HTTP/proxy bridge itself does not require elevation.
        // If Task Scheduler definitions are missing or broken, the Chrome-launched Native
        // Messaging helper starts the same installed executable directly in user context.
        // SYSTEM-only route changes still remain delegated to SmartPageEx Network Switch.
        string directDetail = "";
        bool directStarted = TryStartDirectBridge(out directDetail);
        AppendLog("Native direct bridge fallback requested. started=" + directStarted + " detail=" + directDetail);
        if (directStarted)
        {
            DateTime directDeadline = DateTime.UtcNow.AddMilliseconds(Math.Min(5000, Math.Max(2800, waitMs / 2)));
            while (DateTime.UtcNow < directDeadline)
            {
                if (IsBridgeProxyReady() && IsBridgeControlHttpHealthy(1200)) return true;
                Thread.Sleep(160);
            }
        }

        AppendLog("Bridge recovery did not open the fixed V33 bridge/proxy bank. SYSTEM tasks and direct fallback were both checked.");
        return false;
    }

    public static int Main(string[] args)
    {
        try
        {
            if (args != null && args.Any(a => String.Equals(a, "--http-server", StringComparison.OrdinalIgnoreCase)))
                return RunHttpServer();
            return RunNativeMessaging();
        }
        catch (Exception ex)
        {
            AppendLog("Fatal: " + ex);
            try { WriteMessage(Console.OpenStandardOutput(), Error(ex.Message)); } catch { }
            return 1;
        }
    }

    private static int RunNativeMessaging()
    {
        Stream input = Console.OpenStandardInput();
        Stream output = Console.OpenStandardOutput();
        while (true)
        {
            byte[] header = ReadExact(input, 4);
            if (header == null) break;
            int length = BitConverter.ToInt32(header, 0);
            if (length <= 0 || length > 64 * 1024 * 1024) throw new InvalidDataException("Invalid Native Messaging message length.");
            byte[] payload = ReadExact(input, length);
            if (payload == null) break;
            Dictionary<string, object> request = Json.Deserialize<Dictionary<string, object>>(Encoding.UTF8.GetString(payload));
            Dictionary<string, object> response = Handle(request ?? new Dictionary<string, object>());
            WriteMessage(output, response);
        }
        return 0;
    }

    private static int RunHttpServer()
    {
        bool createdNew = false;
        using (Mutex mutex = new Mutex(true, "Global\\SmartPageExNetworkBridgeV33", out createdNew))
        {
            if (!createdNew)
            {
                AppendLog("A local bridge instance is already running.");
                return 0;
            }

            AppendLog("Bridge startup begin. PID=" + Process.GetCurrentProcess().Id + " BuildMarker=" + BuildMarker + " ControlFirst=true");
            int minWorkerThreads, minCompletionPortThreads;
            ThreadPool.GetMinThreads(out minWorkerThreads, out minCompletionPortThreads);
            ThreadPool.SetMinThreads(Math.Max(minWorkerThreads, 128), Math.Max(minCompletionPortThreads, 64));
            AppendLog("ThreadPool minimum raised for proxy relay. Worker=" + Math.Max(minWorkerThreads, 128) + " IO=" + Math.Max(minCompletionPortThreads, 64));
            TcpListener controlListener = new TcpListener(IPAddress.Loopback, 30765);
            controlListener.Start(128);
            StartProxyServer();
            if (!ProxyReady)
            {
                try { controlListener.Stop(); } catch { }
                throw new InvalidOperationException("No safe loopback proxy port is available on 30766-30769.");
            }
            AppendLog("Local bridge V33 started. PID=" + Process.GetCurrentProcess().Id + " Control=127.0.0.1:30765 ProxyReady=" + ProxyReady + " ProxyPort=" + ProxyPort);
            while (true)
            {
                try
                {
                    TcpClient client = controlListener.AcceptTcpClient();
                    ThreadPool.QueueUserWorkItem(delegate(object state) { HandleRawHttpClient((TcpClient)state); }, client);
                }
                catch (Exception ex)
                {
                    AppendLog("Control bridge accept failed: " + ex);
                    Thread.Sleep(500);
                }
            }
        }
    }

    private static void HandleRawHttpClient(TcpClient client)
    {
        Interlocked.Increment(ref ControlActiveConnections);
        NetworkStream responseStream = null;
        try
        {
            client.NoDelay = true;
            client.ReceiveTimeout = 12000;
            client.SendTimeout = 12000;
            using (NetworkStream stream = client.GetStream())
            {
                responseStream = stream;
                RawHttpRequest request = ReadRawHttpRequest(stream);
                if (request == null) return;

                string origin = "";
                string headerOrigin;
                if (request.Headers.TryGetValue("Origin", out headerOrigin)) origin = NormalizeOrigin(headerOrigin);
                bool originAllowed = String.IsNullOrWhiteSpace(origin) || IsAllowedExtensionOrigin(origin);
                Dictionary<string, string> cors = BuildRawCorsHeaders(originAllowed ? (String.IsNullOrWhiteSpace(origin) ? "*" : origin) : "null");

                if (String.Equals(request.Method, "GET", StringComparison.OrdinalIgnoreCase) &&
                    String.Equals(request.Path, "/health", StringComparison.OrdinalIgnoreCase))
                {
                    Dictionary<string, object> health = BuildQuickHealth();
                    WriteRawHttpJson(stream, 200, "OK", health, cors);
                    return;
                }

                if (String.Equals(request.Method, "GET", StringComparison.OrdinalIgnoreCase) &&
                    String.Equals(request.Path, "/coupang-proxy.pac", StringComparison.OrdinalIgnoreCase))
                {
                    WriteRawHttpText(stream, 200, "OK", BuildProxyPacScript(), "application/x-ns-proxy-autoconfig; charset=utf-8", new Dictionary<string, string>());
                    return;
                }

                if (String.Equals(request.Method, "OPTIONS", StringComparison.OrdinalIgnoreCase))
                {
                    WriteRawHttpText(stream, originAllowed ? 204 : 403, originAllowed ? "No Content" : "Forbidden", "", "text/plain; charset=utf-8", cors);
                    return;
                }

                if (!originAllowed)
                {
                    WriteRawHttpJson(stream, 403, "Forbidden", Error("Extension origin is not allowed."), cors);
                    return;
                }

                string token = "";
                string headerToken;
                if (request.Headers.TryGetValue("X-SmartPageEx-Token", out headerToken)) token = headerToken;
                if (String.IsNullOrWhiteSpace(token)) token = QueryValue(request.Query, "token");
                if (!String.Equals(token, BridgeToken, StringComparison.Ordinal))
                {
                    WriteRawHttpJson(stream, 403, "Forbidden", Error("Local bridge token is invalid."), cors);
                    return;
                }

                if (!String.Equals(request.Method, "POST", StringComparison.OrdinalIgnoreCase) ||
                    !String.Equals(request.Path, "/api", StringComparison.OrdinalIgnoreCase))
                {
                    WriteRawHttpJson(stream, 404, "Not Found", Error("Use POST /api."), cors);
                    return;
                }

                string body = Encoding.UTF8.GetString(request.Body ?? new byte[0]);
                Dictionary<string, object> payload = Json.Deserialize<Dictionary<string, object>>(body) ?? new Dictionary<string, object>();
                if (IsNativeOnlyCommand(Text(payload, "command")))
                {
                    WriteRawHttpJson(stream, 403, "Forbidden", Error("This command is available only through Chrome Native Messaging."), cors);
                    return;
                }
                Dictionary<string, object> response = Handle(payload);
                response["transport"] = "raw_loopback_http";
                response["bridgePort"] = 30765;
                response["proxyPort"] = ProxyPort;
                bool ok = response.ContainsKey("ok") && Convert.ToBoolean(response["ok"]);
                WriteRawHttpJson(stream, ok ? 200 : 400, ok ? "OK" : "Bad Request", response, cors);
            }
        }
        catch (IOException ex)
        {
            Interlocked.Increment(ref RawHttpClientDisconnects);
            AppendLog("Raw HTTP client disconnected before response completed: " + ex.Message);
        }
        catch (SocketException ex)
        {
            Interlocked.Increment(ref RawHttpClientDisconnects);
            AppendLog("Raw HTTP socket closed by client: " + ex.Message);
        }
        catch (Exception ex)
        {
            AppendLog("Raw HTTP request error: " + ex);
            try
            {
                if (responseStream != null && responseStream.CanWrite)
                    WriteRawHttpJson(responseStream, 500, "Internal Server Error", Error(ex.Message), BuildRawCorsHeaders("*"));
            }
            catch { }
        }
        finally
        {
            try { if (client != null && client.Client != null) client.Client.Shutdown(SocketShutdown.Both); } catch { }
            try { if (client != null) client.Close(); } catch { }
            Interlocked.Decrement(ref ControlActiveConnections);
        }
    }

    private static RawHttpRequest ReadRawHttpRequest(NetworkStream stream)
    {
        byte[] headerBytes = ReadHttpHeader(stream, 65536);
        if (headerBytes == null || headerBytes.Length == 0) return null;
        string headerText = Encoding.ASCII.GetString(headerBytes);
        string[] lines = headerText.Split(new string[] { "\r\n" }, StringSplitOptions.None);
        if (lines.Length == 0) throw new InvalidDataException("Invalid HTTP request.");

        string[] requestLine = lines[0].Split(new char[] { ' ' }, 3);
        if (requestLine.Length < 2) throw new InvalidDataException("Invalid HTTP request line.");

        string target = requestLine[1];
        Uri uri;
        if (!Uri.TryCreate("http://127.0.0.1" + (target.StartsWith("/", StringComparison.Ordinal) ? target : "/" + target), UriKind.Absolute, out uri))
            throw new InvalidDataException("Invalid HTTP target.");

        Dictionary<string, string> headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        for (int i = 1; i < lines.Length; i++)
        {
            string line = lines[i];
            if (String.IsNullOrEmpty(line)) continue;
            int colon = line.IndexOf(':');
            if (colon <= 0) continue;
            headers[line.Substring(0, colon).Trim()] = line.Substring(colon + 1).Trim();
        }

        int contentLength = 0;
        string lengthText;
        if (headers.TryGetValue("Content-Length", out lengthText) && !String.IsNullOrWhiteSpace(lengthText))
        {
            if (!Int32.TryParse(lengthText, out contentLength) || contentLength < 0 || contentLength > 1024 * 1024)
                throw new InvalidDataException("Invalid Content-Length.");
        }

        byte[] body = contentLength > 0 ? ReadExact(stream, contentLength) : new byte[0];
        return new RawHttpRequest
        {
            Method = requestLine[0],
            Path = uri.AbsolutePath,
            Query = uri.Query,
            Headers = headers,
            Body = body
        };
    }

    private static byte[] ReadHttpHeader(NetworkStream stream, int maximumLength)
    {
        MemoryStream buffer = new MemoryStream();
        byte[] ending = new byte[] { 13, 10, 13, 10 };
        int matched = 0;
        while (buffer.Length < maximumLength)
        {
            int value = stream.ReadByte();
            if (value < 0) return buffer.Length == 0 ? null : buffer.ToArray();
            byte current = (byte)value;
            buffer.WriteByte(current);
            if (current == ending[matched])
            {
                matched++;
                if (matched == ending.Length) return buffer.ToArray();
            }
            else
            {
                matched = current == ending[0] ? 1 : 0;
            }
        }
        throw new InvalidDataException("HTTP request header is too large.");
    }

    private static Dictionary<string, string> BuildRawCorsHeaders(string requestOrigin)
    {
        Dictionary<string, string> headers = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        headers["Access-Control-Allow-Origin"] = requestOrigin;
        headers["Vary"] = "Origin";
        headers["Access-Control-Allow-Methods"] = "POST, OPTIONS";
        headers["Access-Control-Allow-Headers"] = "Content-Type, X-SmartPageEx-Token";
        headers["Access-Control-Allow-Private-Network"] = "true";
        headers["Cache-Control"] = "no-store";
        return headers;
    }

    private static void WriteRawHttpJson(NetworkStream stream, int statusCode, string reason, Dictionary<string, object> value, Dictionary<string, string> headers)
    {
        WriteRawHttpBytes(stream, statusCode, reason, Encoding.UTF8.GetBytes(Json.Serialize(value)), "application/json; charset=utf-8", headers);
    }

    private static void WriteRawHttpText(NetworkStream stream, int statusCode, string reason, string value, string contentType, Dictionary<string, string> headers)
    {
        WriteRawHttpBytes(stream, statusCode, reason, Encoding.UTF8.GetBytes(value ?? ""), contentType, headers);
    }

    private static void WriteRawHttpBytes(NetworkStream stream, int statusCode, string reason, byte[] payload, string contentType, Dictionary<string, string> headers)
    {
        payload = payload ?? new byte[0];
        StringBuilder builder = new StringBuilder();
        builder.Append("HTTP/1.1 ").Append(statusCode).Append(' ').Append(reason).Append("\r\n");
        builder.Append("Content-Type: ").Append(contentType).Append("\r\n");
        builder.Append("Content-Length: ").Append(payload.Length).Append("\r\n");
        builder.Append("Connection: close\r\n");
        builder.Append("X-Content-Type-Options: nosniff\r\n");
        if (headers != null)
        {
            foreach (KeyValuePair<string, string> row in headers)
                builder.Append(row.Key).Append(": ").Append(row.Value).Append("\r\n");
        }
        builder.Append("\r\n");
        byte[] header = Encoding.ASCII.GetBytes(builder.ToString());
        stream.Write(header, 0, header.Length);
        if (payload.Length > 0) stream.Write(payload, 0, payload.Length);
        stream.Flush();
    }

    private static string BuildProxyPacScript()
    {
        return "function FindProxyForURL(url, host) {\n" +
            "  host = (host || '').toLowerCase();\n" +
            "  if (host === 'localhost' || host === '127.0.0.1' || host === '::1' ||\n" +
            "      host === 'supabase.co' || dnsDomainIs(host, '.supabase.co') ||\n" +
            "      host === 'supabase.in' || dnsDomainIs(host, '.supabase.in') ||\n" +
            "      host === 'naver.com' || dnsDomainIs(host, '.naver.com') ||\n" +
            "      host === 'naver.net' || dnsDomainIs(host, '.naver.net') ||\n" +
            "      host === 'api.openai.com' || dnsDomainIs(host, '.openai.com') ||\n" +
            "      host === 'generativelanguage.googleapis.com' || dnsDomainIs(host, '.googleapis.com') ||\n" +
            "      host === 'smartpage-ai.vercel.app' || dnsDomainIs(host, '.vercel.app')) return 'DIRECT';\n" +
            "  if (host === 'coupang.com' || host === 'www.coupang.com')\n" +
            "    return 'PROXY 127.0.0.1:" + ProxyPort + "';\n" +
            "  return 'DIRECT';\n" +
            "}\n";
    }

    private static void StartProxyServer()
    {
        Exception lastError = null;
        foreach (int candidatePort in ProxyPortCandidates)
        {
            TcpListener candidate = null;
            try
            {
                candidate = new TcpListener(IPAddress.Loopback, candidatePort);
                candidate.Start(128);
                ProxyListener = candidate;
                ProxyPort = candidatePort;
                ProxyReady = true;
                Thread thread = new Thread(ProxyAcceptLoop);
                thread.IsBackground = true;
                thread.Name = "SmartPageExSelectedNetworkProxy";
                thread.Start();
                if (candidatePort != 30766)
                    AppendLog("Primary proxy port 30766 was unavailable. Safe loopback fallback selected: 127.0.0.1:" + candidatePort);
                AppendLog("Selected-network dedicated-window proxy started on 127.0.0.1:" + ProxyPort);
                return;
            }
            catch (Exception ex)
            {
                lastError = ex;
                try { if (candidate != null) candidate.Stop(); } catch { }
                AppendLog("Proxy port 127.0.0.1:" + candidatePort + " unavailable: " + ex.Message);
            }
        }
        ProxyReady = false;
        AppendLog("Proxy start failed on all safe loopback ports 30766-30769: " + (lastError == null ? "unknown error" : lastError.ToString()));
    }

    private static void ProxyAcceptLoop()
    {
        while (true)
        {
            try
            {
                TcpClient client = ProxyListener.AcceptTcpClient();
                ThreadPool.QueueUserWorkItem(delegate(object state) { HandleProxyClient((TcpClient)state); }, client);
            }
            catch (Exception ex)
            {
                ProxyReady = false;
                AppendLog("Proxy accept failed: " + ex.Message);
                Thread.Sleep(1000);
            }
        }
    }

    private static void HandleProxyClient(TcpClient tcpClient)
    {
        Interlocked.Increment(ref ProxyActiveConnections);
        Socket client = null;
        Socket remote = null;
        try
        {
            client = tcpClient.Client;
            client.NoDelay = true;
            client.ReceiveTimeout = 30000;
            client.SendTimeout = 30000;
            byte[] headerBytes = ReadProxyHeader(client, 65536);
            if (headerBytes == null || headerBytes.Length == 0) return;
            string headerText = Encoding.ASCII.GetString(headerBytes);
            string[] lines = headerText.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            if (lines.Length == 0) return;
            string[] requestParts = lines[0].Split(new char[] { ' ' }, 3);
            if (requestParts.Length < 3) throw new InvalidDataException("Invalid proxy request line.");
            string method = requestParts[0].ToUpperInvariant();

            if (method == "CONNECT")
            {
                string host;
                int port;
                ParseHostPort(requestParts[1], 443, out host, out port);
                bool selectedNetworkTraffic = IsSelectedNetworkCoupangHost(host);
                remote = ConnectForProxyTarget(host, port);
                if (selectedNetworkTraffic) RecordProxyConnection(host);
                SendAll(client, Encoding.ASCII.GetBytes("HTTP/1.1 200 Connection Established\r\nProxy-Agent: SmartPageEx\r\n\r\n"));
                RelayBidirectional(client, remote, host, selectedNetworkTraffic);
                return;
            }

            Uri targetUri;
            if (!Uri.TryCreate(requestParts[1], UriKind.Absolute, out targetUri))
            {
                string hostHeader = HeaderValue(lines, "Host");
                if (String.IsNullOrWhiteSpace(hostHeader)) throw new InvalidDataException("Proxy request has no target host.");
                Uri.TryCreate("http://" + hostHeader + requestParts[1], UriKind.Absolute, out targetUri);
            }
            if (targetUri == null) throw new InvalidDataException("Invalid proxy target URL.");
            int targetPort = targetUri.IsDefaultPort ? (targetUri.Scheme == "https" ? 443 : 80) : targetUri.Port;
            bool selectedNetworkTrafficHttp = IsSelectedNetworkCoupangHost(targetUri.Host);
            remote = ConnectForProxyTarget(targetUri.Host, targetPort);
            if (selectedNetworkTrafficHttp) RecordProxyConnection(targetUri.Host);
            string path = String.IsNullOrEmpty(targetUri.PathAndQuery) ? "/" : targetUri.PathAndQuery;
            StringBuilder rewritten = new StringBuilder();
            rewritten.Append(method).Append(' ').Append(path).Append(' ').Append(requestParts[2]).Append("\r\n");
            for (int i = 1; i < lines.Length; i++)
            {
                string line = lines[i];
                if (String.IsNullOrEmpty(line)) continue;
                int colon = line.IndexOf(':');
                string name = colon > 0 ? line.Substring(0, colon).Trim() : "";
                if (String.Equals(name, "Proxy-Connection", StringComparison.OrdinalIgnoreCase)) continue;
                if (String.Equals(name, "Connection", StringComparison.OrdinalIgnoreCase)) continue;
                rewritten.Append(line).Append("\r\n");
            }
            rewritten.Append("Connection: close\r\n\r\n");
            byte[] rewrittenBytes = Encoding.ASCII.GetBytes(rewritten.ToString());
            SendAll(remote, rewrittenBytes);
            if (selectedNetworkTrafficHttp) RecordProxyTraffic(targetUri.Host, rewrittenBytes.Length, true);
            RelayBidirectional(client, remote, targetUri.Host, selectedNetworkTrafficHttp);
        }
        catch (Exception ex)
        {
            AppendLog("Proxy request failed: " + ex.Message);
            try
            {
                if (client != null && client.Connected)
                    SendAll(client, Encoding.ASCII.GetBytes("HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\nContent-Length: 0\r\n\r\n"));
            }
            catch { }
        }
        finally
        {
            try { if (remote != null) remote.Shutdown(SocketShutdown.Both); } catch { }
            try { if (client != null) client.Shutdown(SocketShutdown.Both); } catch { }
            try { if (remote != null) remote.Close(); } catch { }
            try { if (client != null) client.Close(); } catch { }
            try { tcpClient.Close(); } catch { }
            Interlocked.Decrement(ref ProxyActiveConnections);
            Interlocked.Increment(ref ProxyConnectionsClosed);
        }
    }

    private static byte[] ReadProxyHeader(Socket socket, int maximumLength)
    {
        MemoryStream buffer = new MemoryStream();
        int matched = 0;
        byte[] ending = new byte[] { 13, 10, 13, 10 };
        while (buffer.Length < maximumLength)
        {
            byte[] one = new byte[1];
            int read = socket.Receive(one, 0, 1, SocketFlags.None);
            if (read <= 0) return buffer.Length == 0 ? null : buffer.ToArray();
            buffer.WriteByte(one[0]);
            if (one[0] == ending[matched])
            {
                matched++;
                if (matched == ending.Length) return buffer.ToArray();
            }
            else
            {
                matched = one[0] == ending[0] ? 1 : 0;
            }
        }
        throw new InvalidDataException("Proxy request header is too large.");
    }

    private static string HeaderValue(string[] lines, string wantedName)
    {
        foreach (string line in lines)
        {
            int colon = line.IndexOf(':');
            if (colon <= 0) continue;
            string name = line.Substring(0, colon).Trim();
            if (String.Equals(name, wantedName, StringComparison.OrdinalIgnoreCase))
                return line.Substring(colon + 1).Trim();
        }
        return "";
    }

    private static bool IsSelectedNetworkCoupangHost(string host)
    {
        string value = (host ?? "").Trim().TrimEnd('.').ToLowerInvariant();
        return value == "coupang.com" || value == "www.coupang.com";
    }

    private static void RecordProxyConnection(string host)
    {
        string key = (host ?? "").Trim().TrimEnd('.').ToLowerInvariant();
        if (String.IsNullOrWhiteSpace(key)) key = "(unknown)";
        lock (ProxyTrafficLock)
        {
            ProxyTrafficCounter counter;
            if (!ProxyTrafficByHost.TryGetValue(key, out counter))
            {
                counter = new ProxyTrafficCounter();
                ProxyTrafficByHost[key] = counter;
            }
            counter.Connections++;
        }
    }

    private static void RecordProxyTraffic(string host, int byteCount, bool clientToRemote)
    {
        if (byteCount <= 0) return;
        string key = (host ?? "").Trim().TrimEnd('.').ToLowerInvariant();
        if (String.IsNullOrWhiteSpace(key)) key = "(unknown)";
        if (clientToRemote) Interlocked.Add(ref ProxyTrafficUpBytes, byteCount);
        else Interlocked.Add(ref ProxyTrafficDownBytes, byteCount);
        lock (ProxyTrafficLock)
        {
            ProxyTrafficCounter counter;
            if (!ProxyTrafficByHost.TryGetValue(key, out counter))
            {
                counter = new ProxyTrafficCounter();
                ProxyTrafficByHost[key] = counter;
            }
            if (clientToRemote) counter.UpBytes += byteCount;
            else counter.DownBytes += byteCount;
        }
    }

    private static void ParseHostPort(string value, int defaultPort, out string host, out int port)
    {
        host = value == null ? "" : value.Trim();
        port = defaultPort;
        if (host.StartsWith("[", StringComparison.Ordinal))
        {
            int close = host.IndexOf(']');
            if (close > 0)
            {
                string tail = host.Substring(close + 1);
                string inside = host.Substring(1, close - 1);
                host = inside;
                if (tail.StartsWith(":", StringComparison.Ordinal))
                {
                    int parsedPort;
                    if (Int32.TryParse(tail.Substring(1), out parsedPort)) port = parsedPort;
                }
                return;
            }
        }
        int colon = host.LastIndexOf(':');
        int parsed;
        if (colon > 0 && Int32.TryParse(host.Substring(colon + 1), out parsed))
        {
            port = parsed;
            host = host.Substring(0, colon);
        }
    }

    private static void ApplySocketInterface(Socket socket, AdapterBinding binding)
    {
        try
        {
            int optionValue = IPAddress.HostToNetworkOrder(binding.InterfaceIndex);
            socket.SetSocketOption(SocketOptionLevel.IP, (SocketOptionName)31, optionValue);
        }
        catch (Exception optionError)
        {
            AppendLog("IP_UNICAST_IF option warning: " + optionError.Message);
        }
    }

    private static byte[] BuildDnsQuery(string host, ushort requestId)
    {
        string clean = (host ?? "").Trim().TrimEnd('.');
        if (String.IsNullOrWhiteSpace(clean)) throw new InvalidDataException("DNS host is empty.");
        using (MemoryStream stream = new MemoryStream())
        {
            Action<ushort> writeU16 = delegate(ushort value)
            {
                stream.WriteByte((byte)(value >> 8));
                stream.WriteByte((byte)(value & 255));
            };
            writeU16(requestId); writeU16(0x0100); writeU16(1); writeU16(0); writeU16(0); writeU16(0);
            foreach (string label in clean.Split('.'))
            {
                byte[] bytes = Encoding.ASCII.GetBytes(label);
                if (bytes.Length == 0 || bytes.Length > 63) throw new InvalidDataException("Invalid DNS label: " + label);
                stream.WriteByte((byte)bytes.Length);
                stream.Write(bytes, 0, bytes.Length);
            }
            stream.WriteByte(0); writeU16(1); writeU16(1);
            return stream.ToArray();
        }
    }

    private static ushort ReadDnsU16(byte[] data, int offset)
    {
        if (data == null || offset < 0 || offset + 1 >= data.Length) throw new InvalidDataException("Invalid DNS response.");
        return (ushort)((data[offset] << 8) | data[offset + 1]);
    }

    private static int SkipDnsName(byte[] data, int offset)
    {
        int guard = 0;
        while (offset < data.Length && guard++ < 128)
        {
            int length = data[offset];
            if (length == 0) return offset + 1;
            if ((length & 0xC0) == 0xC0)
            {
                if (offset + 1 >= data.Length) throw new InvalidDataException("Invalid DNS compression pointer.");
                return offset + 2;
            }
            if (length > 63 || offset + 1 + length > data.Length) throw new InvalidDataException("Invalid DNS name.");
            offset += 1 + length;
        }
        throw new InvalidDataException("DNS name exceeded the parser limit.");
    }

    private static IPAddress[] QueryDnsServer(AdapterBinding binding, IPAddress dnsServer, string host)
    {
        Socket socket = null;
        try
        {
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            socket.SendTimeout = 1200;
            socket.ReceiveTimeout = 1200;
            ApplySocketInterface(socket, binding);
            socket.Bind(new IPEndPoint(binding.Address, 0));
            ushort requestId = unchecked((ushort)(Guid.NewGuid().GetHashCode() & 0xFFFF));
            byte[] query = BuildDnsQuery(host, requestId);
            socket.SendTo(query, new IPEndPoint(dnsServer, 53));
            byte[] response = new byte[4096];
            EndPoint remote = new IPEndPoint(IPAddress.Any, 0);
            int length = socket.ReceiveFrom(response, ref remote);
            if (length < 12 || ReadDnsU16(response, 0) != requestId) throw new InvalidDataException("DNS response ID mismatch.");
            int flags = ReadDnsU16(response, 2);
            if ((flags & 0x000F) != 0) throw new InvalidDataException("DNS server returned error " + (flags & 0x000F) + ".");
            int questionCount = ReadDnsU16(response, 4);
            int answerCount = ReadDnsU16(response, 6);
            int offset = 12;
            for (int i = 0; i < questionCount; i++)
            {
                offset = SkipDnsName(response, offset);
                if (offset + 4 > length) throw new InvalidDataException("Truncated DNS question.");
                offset += 4;
            }
            List<IPAddress> addresses = new List<IPAddress>();
            for (int i = 0; i < answerCount && offset < length; i++)
            {
                offset = SkipDnsName(response, offset);
                if (offset + 10 > length) break;
                int type = ReadDnsU16(response, offset);
                int recordClass = ReadDnsU16(response, offset + 2);
                int dataLength = ReadDnsU16(response, offset + 8);
                offset += 10;
                if (offset + dataLength > length) break;
                if (type == 1 && recordClass == 1 && dataLength == 4)
                    addresses.Add(new IPAddress(new byte[] { response[offset], response[offset + 1], response[offset + 2], response[offset + 3] }));
                offset += dataLength;
            }
            return addresses.Distinct().ToArray();
        }
        finally { try { if (socket != null) socket.Close(); } catch { } }
    }

    private static IPAddress[] ResolveHostThroughSelectedAdapter(AdapterBinding binding, string host)
    {
        string ignoredMode;
        return ResolveHostThroughSelectedAdapter(binding, host, out ignoredMode);
    }

    private static IPAddress[] ResolveHostThroughSelectedAdapter(AdapterBinding binding, string host, out string resolutionMode)
    {
        resolutionMode = "";
        IPAddress literal;
        if (IPAddress.TryParse(host, out literal))
        {
            resolutionMode = "literal";
            return literal.AddressFamily == AddressFamily.InterNetwork ? new IPAddress[] { literal } : new IPAddress[0];
        }
        string cacheKey = NormalizeGuid(binding.Id) + "|" + (host ?? "").Trim().ToLowerInvariant();
        lock (DnsCacheLock)
        {
            DnsCacheEntry cached;
            if (DnsCache.TryGetValue(cacheKey, out cached) && cached.ExpiresAtUtc > DateTime.UtcNow && cached.Addresses != null && cached.Addresses.Length > 0)
            {
                resolutionMode = String.IsNullOrWhiteSpace(cached.ResolutionMode) ? "adapter_dns" : cached.ResolutionMode;
                return cached.Addresses;
            }
        }
        List<IPAddress> adapterServers = new List<IPAddress>();
        if (binding.DnsServers != null) adapterServers.AddRange(binding.DnsServers);
        Exception lastError = null;
        foreach (IPAddress server in adapterServers.Where(a => a != null && a.AddressFamily == AddressFamily.InterNetwork).Distinct().Take(2))
        {
            try
            {
                IPAddress[] resolved = QueryDnsServer(binding, server, host);
                if (resolved.Length == 0) continue;
                resolutionMode = "adapter_dns";
                lock (DnsCacheLock) DnsCache[cacheKey] = new DnsCacheEntry { Addresses = resolved, ExpiresAtUtc = DateTime.UtcNow.AddMinutes(2), ResolutionMode = resolutionMode };
                return resolved;
            }
            catch (Exception ex) { lastError = ex; }
        }

        /* Some Android RNDIS adapters expose a valid IPv4 gateway but no usable DNS server and
           also block direct UDP/53 to public resolvers. Resolve the name through Windows only as
           a fallback; every subsequent Coupang TCP socket is still explicitly bound to the
           selected adapter below, so website traffic never falls back to the default network. */
        try
        {
            IAsyncResult lookup = Dns.BeginGetHostAddresses(host, null, null);
            if (!lookup.AsyncWaitHandle.WaitOne(2200)) throw new TimeoutException("Windows DNS fallback timed out.");
            IPAddress[] resolved = Dns.EndGetHostAddresses(lookup)
                .Where(a => a != null && a.AddressFamily == AddressFamily.InterNetwork)
                .Distinct().ToArray();
            if (resolved.Length > 0)
            {
                resolutionMode = "system_dns_fallback";
                lock (DnsCacheLock) DnsCache[cacheKey] = new DnsCacheEntry { Addresses = resolved, ExpiresAtUtc = DateTime.UtcNow.AddSeconds(45), ResolutionMode = resolutionMode };
                AppendLog("Selected adapter DNS unavailable; Windows DNS fallback supplied addresses for " + host + ". Coupang TCP remains bound to " + binding.Name + " / " + binding.Address + ".");
                return resolved;
            }
        }
        catch (Exception ex) { lastError = ex; }

        /* Public resolvers are the final DNS fallback. Their UDP packets are explicitly bound to
           the selected interface, but Android carriers often block them; short deadlines prevent
           a dead RNDIS DNS path from delaying the dedicated window for many seconds. */
        foreach (IPAddress server in new IPAddress[] { IPAddress.Parse("1.1.1.1"), IPAddress.Parse("8.8.8.8") })
        {
            try
            {
                IPAddress[] resolved = QueryDnsServer(binding, server, host);
                if (resolved.Length == 0) continue;
                resolutionMode = "selected_public_dns";
                lock (DnsCacheLock) DnsCache[cacheKey] = new DnsCacheEntry { Addresses = resolved, ExpiresAtUtc = DateTime.UtcNow.AddMinutes(2), ResolutionMode = resolutionMode };
                return resolved;
            }
            catch (Exception ex) { lastError = ex; }
        }
        throw new InvalidOperationException("Unable to resolve " + host + " through selected adapter DNS or Windows DNS fallback. " + (lastError == null ? "" : lastError.Message));
    }

    private static Socket ConnectThroughBinding(AdapterBinding binding, string host, int port, int timeoutMs)
    {
        return ConnectThroughBinding(binding, host, port, timeoutMs, 0);
    }

    private static Socket ConnectThroughBinding(AdapterBinding binding, string host, int port, int timeoutMs, int maxTargets)
    {
        IPAddress[] targets = ResolveHostThroughSelectedAdapter(binding, host);
        if (targets.Length == 0) throw new SocketException((int)SocketError.HostNotFound);
        Exception lastError = null;
        IEnumerable<IPAddress> candidates = targets;
        if (maxTargets > 0) candidates = candidates.Take(maxTargets);
        foreach (IPAddress target in candidates)
        {
            Socket socket = null;
            try
            {
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                socket.NoDelay = true;
                socket.SendTimeout = 30000;
                socket.ReceiveTimeout = 30000;
                ApplySocketInterface(socket, binding);
                socket.Bind(new IPEndPoint(binding.Address, 0));
                IAsyncResult result = socket.BeginConnect(new IPEndPoint(target, port), null, null);
                if (!result.AsyncWaitHandle.WaitOne(Math.Max(1000, timeoutMs))) throw new TimeoutException("Selected adapter connection timed out.");
                socket.EndConnect(result);
                return socket;
            }
            catch (Exception ex)
            {
                lastError = ex;
                try { if (socket != null) socket.Close(); } catch { }
            }
        }
        throw new InvalidOperationException("Unable to connect through selected adapter " + binding.Name + ". " + (lastError == null ? "" : lastError.Message));
    }

    // SPX_V160_DEFAULT_INTERNET_AUTOPIN: keep ordinary Windows traffic on a physical
    // non-tethering Wi-Fi/Ethernet route.  This is especially important on laptops where
    // Windows may temporarily prefer the phone RNDIS route after USB tethering appears.
    // The privileged worker chooses from active IPv4 default-route candidates, rejects
    // USB/RNDIS/virtual adapters, prefers an Internet-connected Windows profile and then
    // Windows' own route metric, and pins that normal adapter before Coupang tethering.
    // v1.6.4 compatibility: Windows owns its default route. Older callers may still invoke
    // this helper, but it only observes the current default and restores legacy metric state.
    private static Dictionary<string, object> EnsureNormalDefaultInternetPinnedV160()
    {
        Dictionary<string, object> restored = RestoreLegacyRouteMutationsV164();
        if (!BooleanValue(restored, "ok")) return restored;
        Dictionary<string, object> route = GetDefaultRouteSnapshot(true);
        return new Dictionary<string, object>
        {
            { "ok", BooleanValue(route, "found") },
            { "systemPinApplied", false },
            { "alreadyPinned", false },
            { "systemDefaultInterfaceIndex", IntValue(route, "interfaceIndex", 0) },
            { "systemDefaultInterfaceAlias", Text(route, "interfaceAlias") },
            { "routeMutationDisabled", true },
            { "message", "Windows default Internet is OS-managed. Collector does not change interface metrics." }
        };
    }

    // SPX_V160_AUTO_RECOVER_SINGLE_TETHER retained under v1.6.4 selected-bind architecture.
    // v1.6.4: if selected-adapter state is missing, recover only one usable tethering adapter
    // that is NOT the Windows default route. We observe the OS route but never modify metrics.
    // ApplyWindowAdapter performs strict isolation + Coupang DNS/TCP verification and stays fail-closed.
    private static Dictionary<string, object> TryAutoRecoverSingleTetheringAdapter()
    {
        lock (ProxyStateLock)
        {
            Dictionary<string, object> existing = ReadProxyState();
            if (BooleanValue(existing, "enabled"))
                return new Dictionary<string, object> { { "ok", true }, { "alreadyEnabled", true }, { "autoRecovered", false } };

            Dictionary<string, object> route = GetDefaultRouteSnapshot(true);
            int defaultIndex = IntValue(route, "interfaceIndex", 0);
            if (!BooleanValue(route, "found") || defaultIndex <= 0)
                return Error("Automatic tether recovery stayed fail-closed because the Windows IPv4 default route could not be confirmed.");

            List<AdapterBinding> candidates = new List<AdapterBinding>();
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni == null || ni.NetworkInterfaceType == NetworkInterfaceType.Loopback || ni.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
                if (!AdapterStatusCanBeTested(ni.OperationalStatus) || !LooksLikeTetheringAdapter(ni)) continue;
                try
                {
                    AdapterBinding candidateBinding = BuildAdapterBinding(ni);
                    if (candidateBinding.InterfaceIndex == defaultIndex) continue;
                    candidates.Add(candidateBinding);
                }
                catch { }
            }

            if (candidates.Count != 1)
            {
                Dictionary<string, object> blocked = Error(candidates.Count == 0
                    ? "Automatic tether recovery found no single usable USB/RNDIS phone adapter. Connect one phone tether and try again."
                    : "Automatic tether recovery found more than one usable tethering adapter. Select one adapter explicitly in Collector.");
                blocked["errorCode"] = candidates.Count == 0 ? "AUTO_TETHER_NOT_FOUND" : "AUTO_TETHER_AMBIGUOUS";
                blocked["candidateCount"] = candidates.Count;
                return blocked;
            }

            AdapterBinding candidate = candidates[0];
            if (candidate.InterfaceIndex == defaultIndex)
                return Error("Automatic tether recovery refused the Windows default Internet adapter.");

            Dictionary<string, object> request = new Dictionary<string, object>
            {
                { "adapterId", candidate.Id },
                { "adapterName", candidate.Name },
                { "adapterDescription", candidate.Description ?? "" }
            };
            Dictionary<string, object> applied = ApplyWindowAdapter(request);
            if (!BooleanValue(applied, "ok")) return applied;
            applied["autoRecovered"] = true;
            applied["autoRecoveredAdapterId"] = candidate.Id;
            applied["autoRecoveredAdapterName"] = candidate.Name;
            AppendLog("Automatically recovered the single non-default tethering adapter: " + candidate.Name + " / " + candidate.Address);
            return applied;
        }
    }

    private static Socket ConnectThroughSelectedAdapter(string host, int port)
    {
        Dictionary<string, object> state = ReadProxyState();
        if (!BooleanValue(state, "enabled"))
        {
            Dictionary<string, object> recovered = TryAutoRecoverSingleTetheringAdapter();
            state = ReadProxyState();
            if (!BooleanValue(state, "enabled"))
                throw new InvalidOperationException("Select and apply a dedicated-window network adapter first. " + Text(recovered, "error"));
        }
        AdapterBinding binding = ResolveAdapter(Text(state, "adapterId"), Text(state, "adapterName"), Text(state, "adapterDescription"));
        return ConnectThroughBinding(binding, host, port, 15000);
    }

    private static Socket ConnectThroughDefaultNetwork(string host, int port, int timeoutMs)
    {
        IPAddress literal;
        IPAddress[] targets = IPAddress.TryParse(host, out literal)
            ? new IPAddress[] { literal }
            : Dns.GetHostAddresses(host);
        Exception lastError = null;
        foreach (IPAddress target in targets.Where(address => address != null &&
                     (address.AddressFamily == AddressFamily.InterNetwork || address.AddressFamily == AddressFamily.InterNetworkV6)))
        {
            Socket socket = null;
            try
            {
                socket = new Socket(target.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                socket.NoDelay = true;
                socket.SendTimeout = 30000;
                socket.ReceiveTimeout = 30000;
                IAsyncResult result = socket.BeginConnect(new IPEndPoint(target, port), null, null);
                if (!result.AsyncWaitHandle.WaitOne(Math.Max(1000, timeoutMs))) throw new TimeoutException("Default-network connection timed out.");
                socket.EndConnect(result);
                return socket;
            }
            catch (Exception ex)
            {
                lastError = ex;
                try { if (socket != null) socket.Close(); } catch { }
            }
        }
        throw new InvalidOperationException("Unable to connect through the Windows default network. " + (lastError == null ? "" : lastError.Message));
    }

    private static Socket ConnectForProxyTarget(string host, int port)
    {
        /* v1.6.1 defense in depth: only the Coupang main shopping origin is ever bound
           to the selected adapter. CDN/static/auxiliary Coupang hosts, Supabase, Naver and
           every other API use the normal Windows routing table. */
        return IsSelectedNetworkCoupangHost(host)
            ? ConnectThroughSelectedAdapter(host, port)
            : ConnectThroughDefaultNetwork(host, port, 15000);
    }

    private static void RelayBidirectional(Socket first, Socket second, string host, bool selectedNetworkTraffic)
    {
        byte[] buffer = new byte[32768];
        while (true)
        {
            List<Socket> readable = new List<Socket> { first, second };
            try { Socket.Select(readable, null, null, 1000000); }
            catch { return; }
            if (readable.Count == 0) continue;
            foreach (Socket source in readable)
            {
                Socket destination = Object.ReferenceEquals(source, first) ? second : first;
                int read;
                try { read = source.Receive(buffer, 0, buffer.Length, SocketFlags.None); }
                catch { return; }
                if (read <= 0) return;
                if (selectedNetworkTraffic) RecordProxyTraffic(host, read, Object.ReferenceEquals(source, first));
                int offset = 0;
                while (offset < read)
                {
                    int sent;
                    try { sent = destination.Send(buffer, offset, read - offset, SocketFlags.None); }
                    catch { return; }
                    if (sent <= 0) return;
                    offset += sent;
                }
            }
        }
    }

    private static void SendAll(Socket socket, byte[] payload)
    {
        int offset = 0;
        while (offset < payload.Length)
        {
            int sent = socket.Send(payload, offset, payload.Length - offset, SocketFlags.None);
            if (sent <= 0) throw new IOException("Socket send failed.");
            offset += sent;
        }
    }

    private static string RequestPublicIp(AdapterBinding binding, string host, string path)
    {
        Socket socket = null;
        try
        {
            socket = ConnectThroughBinding(binding, host, 80, 4500);
            socket.ReceiveTimeout = 4500;
            socket.SendTimeout = 4500;
            string request = "GET " + path + " HTTP/1.1\r\nHost: " + host + "\r\nAccept: text/plain\r\nConnection: close\r\nUser-Agent: SmartPageEx-NetworkHost\r\n\r\n";
            SendAll(socket, Encoding.ASCII.GetBytes(request));
            using (MemoryStream response = new MemoryStream())
            {
                byte[] buffer = new byte[4096];
                while (response.Length < 65536)
                {
                    int read;
                    try { read = socket.Receive(buffer, 0, buffer.Length, SocketFlags.None); }
                    catch (SocketException) { if (response.Length > 0) break; throw; }
                    if (read <= 0) break;
                    response.Write(buffer, 0, read);
                }
                string text = Encoding.ASCII.GetString(response.ToArray());
                int headerEnd = text.IndexOf("\r\n\r\n", StringComparison.Ordinal);
                if (headerEnd < 0 || !Regex.IsMatch(text.Substring(0, headerEnd), "^HTTP/1\\.[01] 2\\d\\d", RegexOptions.IgnoreCase))
                    throw new InvalidDataException("Public IP service returned an invalid HTTP response.");
                string body = text.Substring(headerEnd + 4).Trim();
                Match match = Regex.Match(body, @"(?<!\d)(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}(?!\d)");
                if (!match.Success) throw new InvalidDataException("Public IP was not present in the response.");
                IPAddress parsed;
                if (!IPAddress.TryParse(match.Value, out parsed)) throw new InvalidDataException("Public IP response was invalid.");
                return parsed.ToString();
            }
        }
        finally { try { if (socket != null) socket.Close(); } catch { } }
    }

    private static Dictionary<string, object> RefreshPublicIpState(bool force)
    {
        lock (PublicIpLock)
        {
            Dictionary<string, object> state = ReadProxyState();
            if (!BooleanValue(state, "enabled")) return state;
            DateTime checkedAt;
            string checkedText = Text(state, "publicIpCheckedAt");
            if (!force && DateTime.TryParse(checkedText, out checkedAt) && checkedAt.ToUniversalTime() > DateTime.UtcNow.AddSeconds(-60))
                return state;
            AdapterBinding binding = ResolveAdapter(Text(state, "adapterId"), Text(state, "adapterName"), Text(state, "adapterDescription"));
            string lastKnownPublicIp = Text(state, "publicIp");
            string lastError = "";
            string observedPublicIp = "";
            foreach (string[] endpoint in new string[][]
            {
                new string[] { "api.ipify.org", "/" },
                new string[] { "checkip.amazonaws.com", "/" }
            })
            {
                try { observedPublicIp = RequestPublicIp(binding, endpoint[0], endpoint[1]); if (!String.IsNullOrWhiteSpace(observedPublicIp)) break; }
                catch (Exception ex) { lastError = ex.Message; }
            }
            bool lookupOk = !String.IsNullOrWhiteSpace(observedPublicIp);
            string checkedNow = DateTime.UtcNow.ToString("o");
            state["publicIpLookupOk"] = lookupOk;
            state["publicIpObserved"] = lookupOk ? observedPublicIp : "";
            state["publicIpCheckedAt"] = checkedNow;
            state["publicIpError"] = lookupOk ? "" : (String.IsNullOrWhiteSpace(lastError) ? "Unable to determine the public IP through the selected adapter." : lastError);
            if (lookupOk)
            {
                state["publicIp"] = observedPublicIp;
                state["publicIpLastKnown"] = observedPublicIp;
                state["publicIpLastKnownAt"] = checkedNow;
            }
            else
            {
                state["publicIp"] = lastKnownPublicIp;
                if (!state.ContainsKey("publicIpLastKnown") && !String.IsNullOrWhiteSpace(lastKnownPublicIp)) state["publicIpLastKnown"] = lastKnownPublicIp;
            }
            state["adapterId"] = binding.Id;
            state["adapterName"] = binding.Name;
            state["adapterDescription"] = binding.Description ?? "";
            state["ipv4Address"] = binding.Address.ToString();
            state["interfaceIndex"] = binding.InterfaceIndex;
            state["updatedAt"] = DateTime.UtcNow.ToString("o");
            WriteJsonFile(ProxyStatePath, state);
            return state;
        }
    }

    private static Dictionary<string, object> VerifySelectedAdapterConnectivity(AdapterBinding binding, bool force)
    {
        Dictionary<string, object> cached = ReadProxyState();
        DateTime checkedAt;
        if (!force &&
            DateTime.TryParse(Text(cached, "selectedNetworkCheckedAt"), out checkedAt) &&
            checkedAt.ToUniversalTime() > DateTime.UtcNow.AddSeconds(-30) &&
            cached.ContainsKey("selectedNetworkReady"))
            return cached;

        bool dnsReady = false;
        bool coupangTcpReady = false;
        string connectedHost = "";
        string dnsMode = "";
        string lastError = "";
        for (int attempt = 0; attempt < 3 && !coupangTcpReady; attempt++)
        {
            foreach (string host in new string[] { "www.coupang.com", "wing.coupang.com" })
            {
                try
                {
                    string resolvedMode;
                    IPAddress[] resolved = ResolveHostThroughSelectedAdapter(binding, host, out resolvedMode);
                    dnsReady = resolved != null && resolved.Length > 0;
                    if (dnsReady) dnsMode = resolvedMode;
                    if (!dnsReady) continue;
                    Socket probe = null;
                    try
                    {
                        probe = ConnectThroughBinding(binding, host, 443, 2500, 2);
                        coupangTcpReady = probe != null && probe.Connected;
                        if (coupangTcpReady) connectedHost = host;
                    }
                    finally { try { if (probe != null) probe.Close(); } catch { } }
                    if (coupangTcpReady) break;
                }
                catch (Exception ex) { lastError = ex.Message; }
            }
            if (!coupangTcpReady && attempt < 2) Thread.Sleep(450);
        }

        Dictionary<string, object> state = ReadProxyState();
        string checkedNow = DateTime.UtcNow.ToString("o");
        state["selectedNetworkReady"] = coupangTcpReady;
        state["selectedNetworkDnsReady"] = dnsReady;
        state["selectedNetworkDnsMode"] = dnsMode;
        state["selectedNetworkCoupangTcpReady"] = coupangTcpReady;
        state["selectedNetworkProbeHost"] = connectedHost;
        state["selectedNetworkCheckedAt"] = checkedNow;
        state["selectedNetworkError"] = coupangTcpReady ? "" :
            (String.IsNullOrWhiteSpace(lastError)
                ? "The selected adapter has IPv4 but could not reach Coupang over TCP 443."
                : lastError);
        state["adapterId"] = binding.Id;
        state["adapterName"] = binding.Name;
        state["adapterDescription"] = binding.Description ?? "";
        state["ipv4Address"] = binding.Address.ToString();
        state["interfaceIndex"] = binding.InterfaceIndex;
        state["updatedAt"] = checkedNow;
        WriteJsonFile(ProxyStatePath, state);
        return state;
    }

    private static void HandleHttpContext(HttpListenerContext context)
    {
        try
        {
            if (String.Equals(context.Request.HttpMethod, "GET", StringComparison.OrdinalIgnoreCase) &&
                context.Request.Url != null &&
                String.Equals(context.Request.Url.AbsolutePath, "/coupang-proxy.pac", StringComparison.OrdinalIgnoreCase))
            {
                WriteProxyPac(context.Response);
                return;
            }

            string origin = NormalizeOrigin(context.Request.Headers["Origin"] ?? "");
            bool originAllowed = IsAllowedExtensionOrigin(origin);
            ApplyCors(context.Response, originAllowed ? origin : "null");

            if (String.Equals(context.Request.HttpMethod, "OPTIONS", StringComparison.OrdinalIgnoreCase))
            {
                context.Response.StatusCode = originAllowed ? 204 : 403;
                context.Response.Close();
                return;
            }

            if (!originAllowed)
            {
                WriteHttpJson(context.Response, Error("Extension origin is not allowed."), 403);
                return;
            }

            string token = context.Request.Headers["X-SmartPageEx-Token"] ?? "";
            if (String.IsNullOrWhiteSpace(token) && context.Request.Url != null)
                token = QueryValue(context.Request.Url.Query, "token");
            if (!String.Equals(token, BridgeToken, StringComparison.Ordinal))
            {
                WriteHttpJson(context.Response, Error("Local bridge token is invalid."), 403);
                return;
            }

            if (!String.Equals(context.Request.HttpMethod, "POST", StringComparison.OrdinalIgnoreCase) || context.Request.Url == null || context.Request.Url.AbsolutePath != "/api")
            {
                WriteHttpJson(context.Response, Error("Use POST /api."), 404);
                return;
            }

            string body;
            using (StreamReader reader = new StreamReader(context.Request.InputStream, Encoding.UTF8, true, 4096))
                body = reader.ReadToEnd();
            if (body.Length > 1024 * 1024)
            {
                WriteHttpJson(context.Response, Error("Request is too large."), 413);
                return;
            }

            Dictionary<string, object> request = Json.Deserialize<Dictionary<string, object>>(body) ?? new Dictionary<string, object>();
            if (IsNativeOnlyCommand(Text(request, "command")))
            {
                WriteHttpJson(context.Response, Error("This command is available only through Chrome Native Messaging."), 403);
                return;
            }
            Dictionary<string, object> response = Handle(request);
            response["transport"] = "local_http";
            response["bridgePort"] = 30765;
            response["proxyPort"] = ProxyPort;
            WriteHttpJson(context.Response, response, response.ContainsKey("ok") && Convert.ToBoolean(response["ok"]) ? 200 : 400);
        }
        catch (Exception ex)
        {
            AppendLog("HTTP request error: " + ex);
            try { WriteHttpJson(context.Response, Error(ex.Message), 500); } catch { }
        }
    }

    private static void WriteProxyPac(HttpListenerResponse response)
    {
        string script = BuildProxyPacScript();
        byte[] payload = Encoding.UTF8.GetBytes(script);
        response.StatusCode = 200;
        response.ContentType = "application/x-ns-proxy-autoconfig; charset=utf-8";
        response.ContentEncoding = Encoding.UTF8;
        response.Headers["Cache-Control"] = "no-store, no-cache, must-revalidate";
        response.ContentLength64 = payload.Length;
        response.OutputStream.Write(payload, 0, payload.Length);
        response.OutputStream.Close();
    }

    private static string NormalizeOrigin(string origin)
    {
        return String.IsNullOrWhiteSpace(origin) ? "" : origin.Trim().TrimEnd('/');
    }

    private static bool IsAllowedExtensionOrigin(string origin)
    {
        if (String.IsNullOrWhiteSpace(origin)) return false;
        Uri uri;
        if (!Uri.TryCreate(origin, UriKind.Absolute, out uri)) return false;
        if (!String.Equals(uri.Scheme, "chrome-extension", StringComparison.OrdinalIgnoreCase)) return false;
        if (!String.IsNullOrEmpty(uri.AbsolutePath) && uri.AbsolutePath != "/") return false;
        return Regex.IsMatch(uri.Host ?? "", "^[a-p]{32}$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    }

    private static void ApplyCors(HttpListenerResponse response, string requestOrigin)
    {
        response.Headers["Access-Control-Allow-Origin"] = requestOrigin;
        response.Headers["Vary"] = "Origin";
        response.Headers["Access-Control-Allow-Methods"] = "POST, OPTIONS";
        response.Headers["Access-Control-Allow-Headers"] = "Content-Type, X-SmartPageEx-Token";
        response.Headers["Access-Control-Allow-Private-Network"] = "true";
        response.Headers["Cache-Control"] = "no-store";
    }

    private static void WriteHttpJson(HttpListenerResponse response, Dictionary<string, object> value, int statusCode)
    {
        byte[] payload = Encoding.UTF8.GetBytes(Json.Serialize(value));
        response.StatusCode = statusCode;
        response.ContentType = "application/json; charset=utf-8";
        response.ContentEncoding = Encoding.UTF8;
        response.ContentLength64 = payload.Length;
        response.OutputStream.Write(payload, 0, payload.Length);
        response.OutputStream.Close();
    }

    private static string QueryValue(string query, string key)
    {
        if (String.IsNullOrWhiteSpace(query) || String.IsNullOrWhiteSpace(key)) return "";
        string text = query.TrimStart('?');
        foreach (string part in text.Split('&'))
        {
            int equals = part.IndexOf('=');
            string name = equals >= 0 ? part.Substring(0, equals) : part;
            if (!String.Equals(Uri.UnescapeDataString(name.Replace("+", " ")), key, StringComparison.OrdinalIgnoreCase)) continue;
            string value = equals >= 0 ? part.Substring(equals + 1) : "";
            return Uri.UnescapeDataString(value.Replace("+", " "));
        }
        return "";
    }


    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_open16([MarshalAs(UnmanagedType.LPWStr)] string filename, out IntPtr db);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_open_v2(IntPtr filenameUtf8, out IntPtr db, int flags, IntPtr zVfs);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_close(IntPtr db);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_prepare16_v2(IntPtr db, [MarshalAs(UnmanagedType.LPWStr)] string sql, int nByte, out IntPtr stmt, IntPtr tail);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_step(IntPtr stmt);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_finalize(IntPtr stmt);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_reset(IntPtr stmt);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_clear_bindings(IntPtr stmt);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_bind_text16(IntPtr stmt, int index, [MarshalAs(UnmanagedType.LPWStr)] string value, int nByte, IntPtr destructor);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_bind_int64(IntPtr stmt, int index, long value);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern IntPtr sqlite3_column_text16(IntPtr stmt, int column);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern long sqlite3_column_int64(IntPtr stmt, int column);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern IntPtr sqlite3_errmsg16(IntPtr db);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr sqlite3_backup_init(IntPtr pDest, string zDestName, IntPtr pSource, string zSourceName);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_backup_step(IntPtr pBackup, int nPage);
    [DllImport("winsqlite3.dll", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_backup_finish(IntPtr pBackup);
    [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = true)]
    private static extern int SHCreateItemFromParsingName([MarshalAs(UnmanagedType.LPWStr)] string pszPath, IntPtr pbc, ref Guid riid, out IShellItem ppv);

    [ComImport, Guid("42F85136-DB7E-439C-85F1-E4075D135FC8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IFileDialog
    {
        [PreserveSig] int Show(IntPtr parent);
        void SetFileTypes(uint cFileTypes, IntPtr rgFilterSpec);
        void SetFileTypeIndex(uint iFileType);
        void GetFileTypeIndex(out uint piFileType);
        void Advise(IntPtr pfde, out uint pdwCookie);
        void Unadvise(uint dwCookie);
        void SetOptions(uint fos);
        void GetOptions(out uint pfos);
        void SetDefaultFolder(IShellItem psi);
        void SetFolder(IShellItem psi);
        void GetFolder(out IShellItem ppsi);
        void GetCurrentSelection(out IShellItem ppsi);
        void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string pszName);
        void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string pszName);
        void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string pszTitle);
        void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string pszText);
        void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string pszLabel);
        void GetResult(out IShellItem ppsi);
        void AddPlace(IShellItem psi, uint fdap);
        void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string pszDefaultExtension);
        void Close(int hr);
        void SetClientGuid(ref Guid guid);
        void ClearClientData();
        void SetFilter(IntPtr pFilter);
    }
    [ComImport, Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IShellItem
    {
        void BindToHandler(IntPtr pbc, ref Guid bhid, ref Guid riid, out IntPtr ppv);
        void GetParent(out IShellItem ppsi);
        void GetDisplayName(uint sigdnName, out IntPtr ppszName);
        void GetAttributes(uint sfgaoMask, out uint psfgaoAttribs);
        void Compare(IShellItem psi, uint hint, out int piOrder);
    }
    [ComImport, Guid("DC1C5A9C-E88A-4DDE-A5A1-60F82A20AEF7")]
    private class FileOpenDialogCom { }
    private const uint FOS_PICKFOLDERS = 0x00000020;
    private const uint FOS_FORCEFILESYSTEM = 0x00000040;
    private const uint FOS_PATHMUSTEXIST = 0x00000800;
    private const uint FOS_NOCHANGEDIR = 0x00000008;
    private const uint SIGDN_FILESYSPATH = 0x80058000;
    private const int HRESULT_CANCELLED = unchecked((int)0x800704C7);

    private static string SqliteError(IntPtr db)
    {
        try { IntPtr p = sqlite3_errmsg16(db); return p == IntPtr.Zero ? "SQLite error" : Marshal.PtrToStringUni(p); }
        catch { return "SQLite error"; }
    }
    private static void SqliteExec(IntPtr db, string sql)
    {
        IntPtr stmt = IntPtr.Zero;
        int rc = sqlite3_prepare16_v2(db, sql, -1, out stmt, IntPtr.Zero);
        if (rc != SQLITE_OK) throw new InvalidOperationException(SqliteError(db));
        try { rc = sqlite3_step(stmt); if (rc != SQLITE_DONE && rc != SQLITE_ROW) throw new InvalidOperationException(SqliteError(db)); }
        finally { if (stmt != IntPtr.Zero) sqlite3_finalize(stmt); }
    }
    private const int SQLITE_OPEN_READONLY = 0x00000001;
    private static IntPtr OpenMirrorDbReadOnly(string path)
    {
        IntPtr db = IntPtr.Zero, utf8 = IntPtr.Zero;
        try
        {
            byte[] bytes = Encoding.UTF8.GetBytes((path ?? "") + "\0");
            utf8 = Marshal.AllocHGlobal(bytes.Length); Marshal.Copy(bytes, 0, utf8, bytes.Length);
            int rc = sqlite3_open_v2(utf8, out db, SQLITE_OPEN_READONLY, IntPtr.Zero);
            if (rc != SQLITE_OK || db == IntPtr.Zero) throw new InvalidOperationException("Live DB read-only open failed: " + (db == IntPtr.Zero ? "unknown" : SqliteError(db)));
            return db;
        }
        catch { if (db != IntPtr.Zero) sqlite3_close(db); throw; }
        finally { if (utf8 != IntPtr.Zero) Marshal.FreeHGlobal(utf8); }
    }
    private static IntPtr OpenMirrorDb(string path, bool createSchema)
    {
        IntPtr db;
        int rc = sqlite3_open16(path, out db);
        if (rc != SQLITE_OK || db == IntPtr.Zero) throw new InvalidOperationException("Live DB open failed: " + (db == IntPtr.Zero ? "unknown" : SqliteError(db)));
        if (createSchema)
        {
            SqliteExec(db, "PRAGMA journal_mode=DELETE;");
            SqliteExec(db, "PRAGMA synchronous=NORMAL;");
            SqliteExec(db, "CREATE TABLE IF NOT EXISTS mirror_rows(kind TEXT NOT NULL, keyword_canonical_key TEXT NOT NULL, keyword TEXT, updated_at TEXT, row_json TEXT NOT NULL, PRIMARY KEY(kind, keyword_canonical_key));");
            SqliteExec(db, "CREATE INDEX IF NOT EXISTS idx_mirror_rows_kind_updated ON mirror_rows(kind, updated_at);");
            SqliteExec(db, "CREATE TABLE IF NOT EXISTS mirror_meta(meta_key TEXT PRIMARY KEY, meta_value TEXT NOT NULL);");
        }
        return db;
    }
    private static string ReadManagerDataFolder()
    {
        try
        {
            if (!File.Exists(ManagerDataFolderConfigPath)) return "";
            Dictionary<string, object> cfg = ReadJsonFile(ManagerDataFolderConfigPath);
            string path = Text(cfg, "path").Trim();
            return !String.IsNullOrWhiteSpace(path) && Directory.Exists(path) ? Path.GetFullPath(path) : "";
        }
        catch { return ""; }
    }
    private static void SaveManagerDataFolder(string path)
    {
        path = Path.GetFullPath(path);
        Directory.CreateDirectory(path);
        WriteJsonFile(ManagerDataFolderConfigPath, new Dictionary<string, object> {
            { "path", path }, { "savedAt", DateTime.UtcNow.ToString("o") }, { "version", 4184 }
        });
    }
    private static string LiveDbPath(bool building)
    {
        string folder = ReadManagerDataFolder();
        if (String.IsNullOrWhiteSpace(folder)) throw new InvalidOperationException("DB backup folder is not configured.");
        return Path.Combine(folder, building ? ManagerBuildingDbFileName : ManagerLiveDbFileName);
    }
    private static List<object> RequestObjectList(Dictionary<string, object> request, string key)
    {
        object raw;
        List<object> result = new List<object>();
        if (request == null || !request.TryGetValue(key, out raw) || raw == null) return result;
        IEnumerable enumerable = raw as IEnumerable;
        if (enumerable == null || raw is string) return result;
        foreach (object item in enumerable) result.Add(item);
        return result;
    }
    private static Dictionary<string, object> ManagerDataFolderStatus()
    {
        string folder = ReadManagerDataFolder();
        string live = String.IsNullOrWhiteSpace(folder) ? "" : Path.Combine(folder, ManagerLiveDbFileName);
        return new Dictionary<string, object> {
            { "ok", true }, { "configured", !String.IsNullOrWhiteSpace(folder) }, { "path", folder },
            { "liveDbPath", live }, { "liveDbExists", !String.IsNullOrWhiteSpace(live) && File.Exists(live) }, { "storageVersion", 4184 }
        };
    }
    private static string PickManagerFolderExplorer(string initial)
    {
        IFileDialog dialog = null; IShellItem initialItem = null; IShellItem resultItem = null;
        try
        {
            dialog = (IFileDialog)new FileOpenDialogCom();
            uint options; dialog.GetOptions(out options);
            dialog.SetOptions(options | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST | FOS_NOCHANGEDIR);
            dialog.SetTitle("SmartPage Ex data folder");
            dialog.SetOkButtonLabel("Select folder");
            if (!String.IsNullOrWhiteSpace(initial) && Directory.Exists(initial))
            {
                Guid shellItemGuid = new Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE");
                if (SHCreateItemFromParsingName(initial, IntPtr.Zero, ref shellItemGuid, out initialItem) == 0 && initialItem != null) dialog.SetFolder(initialItem);
            }
            int hr = dialog.Show(IntPtr.Zero);
            if (hr == HRESULT_CANCELLED) return null;
            if (hr < 0) Marshal.ThrowExceptionForHR(hr);
            dialog.GetResult(out resultItem);
            if (resultItem == null) return null;
            IntPtr pathPtr = IntPtr.Zero;
            try
            {
                resultItem.GetDisplayName(SIGDN_FILESYSPATH, out pathPtr);
                return pathPtr == IntPtr.Zero ? null : Marshal.PtrToStringUni(pathPtr);
            }
            finally { if (pathPtr != IntPtr.Zero) Marshal.FreeCoTaskMem(pathPtr); }
        }
        finally
        {
            if (resultItem != null) Marshal.FinalReleaseComObject(resultItem);
            if (initialItem != null) Marshal.FinalReleaseComObject(initialItem);
            if (dialog != null) Marshal.FinalReleaseComObject(dialog);
        }
    }
    private static Dictionary<string, object> ChooseManagerDataFolder(Dictionary<string, object> request)
    {
        try
        {
            string initial = Text(request, "initialPath").Trim(); if (String.IsNullOrWhiteSpace(initial)) initial = ReadManagerDataFolder();
            string selected = null; Exception failure = null;
            Thread thread = new Thread(() => { try { selected = PickManagerFolderExplorer(initial); } catch (Exception ex) { failure = ex; } });
            thread.SetApartmentState(ApartmentState.STA); thread.Start(); thread.Join();
            if (failure != null) return Error("DB folder picker failed: " + failure.Message);
            if (String.IsNullOrWhiteSpace(selected)) return new Dictionary<string, object> { { "ok", true }, { "cancelled", true }, { "configured", !String.IsNullOrWhiteSpace(ReadManagerDataFolder()) }, { "path", initial } };
            selected = Path.GetFullPath(selected); Directory.CreateDirectory(selected);
            bool save = !request.ContainsKey("save") || BooleanValue(request, "save");
            if (save) SaveManagerDataFolder(selected);
            Dictionary<string, object> status = save ? ManagerDataFolderStatus() : InspectManagerDataFolder(selected); status["selected"] = true; status["saved"] = save; return status;
        }
        catch (Exception ex) { return Error("DB folder picker failed: " + ex.Message); }
    }
    private static Dictionary<string, object> SetManagerDataFolder(Dictionary<string, object> request)
    {
        try { string path = Text(request, "path").Trim(); if (String.IsNullOrWhiteSpace(path)) return Error("DB folder path is empty."); SaveManagerDataFolder(path); return ManagerDataFolderStatus(); }
        catch (Exception ex) { return Error("DB folder save failed: " + ex.Message); }
    }
    private static void SetMirrorMeta(IntPtr db, string key, string value)
    {
        IntPtr stmt = IntPtr.Zero;
        int rc = sqlite3_prepare16_v2(db, "INSERT INTO mirror_meta(meta_key,meta_value) VALUES(?,?) ON CONFLICT(meta_key) DO UPDATE SET meta_value=excluded.meta_value;", -1, out stmt, IntPtr.Zero);
        if (rc != SQLITE_OK) throw new InvalidOperationException(SqliteError(db));
        try
        {
            sqlite3_bind_text16(stmt, 1, key ?? "", -1, SQLITE_TRANSIENT);
            sqlite3_bind_text16(stmt, 2, value ?? "", -1, SQLITE_TRANSIENT);
            rc = sqlite3_step(stmt); if (rc != SQLITE_DONE) throw new InvalidOperationException(SqliteError(db));
        }
        finally { if (stmt != IntPtr.Zero) sqlite3_finalize(stmt); }
    }
    private static string GetMirrorMeta(IntPtr db, string key)
    {
        IntPtr stmt = IntPtr.Zero;
        int rc = sqlite3_prepare16_v2(db, "SELECT meta_value FROM mirror_meta WHERE meta_key=? LIMIT 1;", -1, out stmt, IntPtr.Zero);
        if (rc != SQLITE_OK) return "";
        try
        {
            sqlite3_bind_text16(stmt, 1, key ?? "", -1, SQLITE_TRANSIENT);
            rc = sqlite3_step(stmt); if (rc != SQLITE_ROW) return "";
            IntPtr p = sqlite3_column_text16(stmt, 0); return p == IntPtr.Zero ? "" : Marshal.PtrToStringUni(p);
        }
        finally { if (stmt != IntPtr.Zero) sqlite3_finalize(stmt); }
    }
    private static string ManagerBackupCatalogPath(string folder) { return Path.Combine(folder, ManagerBackupCatalogFileName); }
    private static string BackupProtectionMarkerPath(string backupPath) { return backupPath + ".spx-protected"; }
    private static string BackupManagedMarkerPath(string backupPath) { return backupPath + ".spx-managed"; }
    private static void SetBackupProtectionMarker(string backupPath, bool protect) { string marker = BackupProtectionMarkerPath(backupPath); if (protect) File.WriteAllText(marker, "protected\n", new UTF8Encoding(false)); else if (File.Exists(marker)) File.Delete(marker); }
    private static void SetBackupManagedMarker(string backupPath, bool managed) { string marker = BackupManagedMarkerPath(backupPath); if (managed) File.WriteAllText(marker, "managed-v1\n", new UTF8Encoding(false)); else if (File.Exists(marker)) File.Delete(marker); }
    private static string SqliteScalarText(IntPtr db, string sql)
    {
        IntPtr stmt = IntPtr.Zero; int rc = sqlite3_prepare16_v2(db, sql, -1, out stmt, IntPtr.Zero); if (rc != SQLITE_OK) throw new InvalidOperationException(SqliteError(db));
        try { rc = sqlite3_step(stmt); if (rc != SQLITE_ROW) return ""; IntPtr p = sqlite3_column_text16(stmt, 0); return p == IntPtr.Zero ? "" : Marshal.PtrToStringUni(p); }
        finally { if (stmt != IntPtr.Zero) sqlite3_finalize(stmt); }
    }
    private static long SqliteScalarLong(IntPtr db, string sql)
    {
        IntPtr stmt = IntPtr.Zero; int rc = sqlite3_prepare16_v2(db, sql, -1, out stmt, IntPtr.Zero); if (rc != SQLITE_OK) throw new InvalidOperationException(SqliteError(db));
        try { rc = sqlite3_step(stmt); return rc == SQLITE_ROW ? sqlite3_column_int64(stmt, 0) : 0; }
        finally { if (stmt != IntPtr.Zero) sqlite3_finalize(stmt); }
    }
    private static bool IsTrustedSourceRevision(string revision)
    {
        if (String.IsNullOrWhiteSpace(revision)) return false;
        string value = revision.Trim();
        try
        {
            if (value.StartsWith("{", StringComparison.Ordinal))
            {
                Dictionary<string, object> row = Json.DeserializeObject(value) as Dictionary<string, object>;
                if (row == null) return false;
                DateTime parsed;
                return new [] { "keyword_latest", "state_latest", "exclusion_latest", "queue_latest" }.All(k => row.ContainsKey(k) && DateTime.TryParse(Convert.ToString(row[k]), out parsed));
            }
            string[] parts = value.Split('|'); DateTime dt;
            return parts.Length >= 4 && parts.Take(4).All(v => DateTime.TryParse(v, out dt));
        }
        catch { return false; }
    }
    private static Dictionary<string, object> InspectMirrorDbFile(string path)
    {
        Dictionary<string, object> result = new Dictionary<string, object> { { "path", path }, { "filename", Path.GetFileName(path) }, { "exists", File.Exists(path) }, { "integrity", false }, { "rowCount", 0L }, { "sourceRevision", "" }, { "revisionKnown", false }, { "generation", "" }, { "buildState", "" }, { "schemaVersion", "" }, { "completedAt", "" } };
        if (!File.Exists(path)) return result;
        IntPtr db = OpenMirrorDbReadOnly(path);
        try
        {
            string quick = SqliteScalarText(db, "PRAGMA quick_check;"); bool ok = String.Equals(quick, "ok", StringComparison.OrdinalIgnoreCase); result["integrity"] = ok;
            if (!ok) { result["error"] = "SQLite quick_check: " + quick; return result; }
            long count = SqliteScalarLong(db, "SELECT count(*) FROM mirror_rows WHERE kind='display';"); string revision = GetMirrorMeta(db, "source_revision");
            result["rowCount"] = count; result["sourceRevision"] = revision; result["revisionKnown"] = IsTrustedSourceRevision(revision); result["generation"] = GetMirrorMeta(db, "generation_id"); result["pipelineVersion"] = GetMirrorMeta(db, "pipeline_version"); result["buildState"] = GetMirrorMeta(db, "build_state"); result["schemaVersion"] = GetMirrorMeta(db, "schema_version"); result["completedAt"] = GetMirrorMeta(db, "completed_at"); result["extensionVersion"] = GetMirrorMeta(db, "extension_version");
        }
        catch (Exception ex) { result["integrity"] = false; result["error"] = ex.Message; }
        finally { sqlite3_close(db); }
        return result;
    }
    private static Dictionary<string, object> InspectManagerDataFolder(string folder)
    {
        try
        {
            folder = String.IsNullOrWhiteSpace(folder) ? "" : Path.GetFullPath(folder); string live = String.IsNullOrWhiteSpace(folder) ? "" : Path.Combine(folder, ManagerLiveDbFileName); string building = String.IsNullOrWhiteSpace(folder) ? "" : Path.Combine(folder, ManagerBuildingDbFileName);
            Dictionary<string, object> result = new Dictionary<string, object> { { "ok", true }, { "path", folder }, { "configured", !String.IsNullOrWhiteSpace(folder) }, { "liveDbPath", live }, { "buildingDbPath", building }, { "liveDbExists", File.Exists(live) }, { "buildingDbExists", File.Exists(building) } };
            if (File.Exists(live)) result["live"] = InspectMirrorDbFile(live); if (File.Exists(building)) result["building"] = InspectMirrorDbFile(building); return result;
        }
        catch (Exception ex) { return Error("DB folder inspect failed: " + ex.Message); }
    }
    private static void SqliteOnlineBackup(string sourcePath, string targetPath)
    {
        if (String.IsNullOrWhiteSpace(sourcePath) || !File.Exists(sourcePath)) throw new InvalidOperationException("Source SQLite DB is missing.");
        if (File.Exists(targetPath)) File.Delete(targetPath);
        IntPtr source = IntPtr.Zero, target = IntPtr.Zero, backup = IntPtr.Zero;
        try
        {
            source = OpenMirrorDbReadOnly(sourcePath); target = OpenMirrorDb(targetPath, false); backup = sqlite3_backup_init(target, "main", source, "main");
            if (backup == IntPtr.Zero) throw new InvalidOperationException("SQLite online backup init failed: " + SqliteError(target));
            int rc = sqlite3_backup_step(backup, -1); if (rc != SQLITE_DONE && rc != SQLITE_OK) throw new InvalidOperationException("SQLite online backup step failed: " + rc);
            rc = sqlite3_backup_finish(backup); backup = IntPtr.Zero; if (rc != SQLITE_OK) throw new InvalidOperationException("SQLite online backup finish failed: " + rc);
        }
        finally { if (backup != IntPtr.Zero) sqlite3_backup_finish(backup); if (target != IntPtr.Zero) sqlite3_close(target); if (source != IntPtr.Zero) sqlite3_close(source); }
    }
    private static Dictionary<string, object> ReadBackupCatalogRaw(string folder)
    {
        string path = ManagerBackupCatalogPath(folder); if (!File.Exists(path)) return new Dictionary<string, object>();
        try { return ReadJsonFile(path); } catch { return new Dictionary<string, object>(); }
    }
    private static Dictionary<string, Dictionary<string, object>> BackupCatalogPreviousMap(Dictionary<string, object> raw)
    {
        Dictionary<string, Dictionary<string, object>> map = new Dictionary<string, Dictionary<string, object>>(StringComparer.OrdinalIgnoreCase); object entriesRaw;
        if (raw != null && raw.TryGetValue("entries", out entriesRaw) && entriesRaw is IEnumerable && !(entriesRaw is string))
            foreach (object item in (IEnumerable)entriesRaw) { Dictionary<string, object> row = item as Dictionary<string, object>; if (row == null) continue; string name = Text(row, "filename").Trim(); if (!String.IsNullOrWhiteSpace(name)) map[name] = row; }
        return map;
    }
    private static DateTime BackupTimestampFromNameOrFile(string path)
    {
        string name = Path.GetFileNameWithoutExtension(path); Match m = Regex.Match(name ?? "", @"(\d{8})_(\d{6})$"); DateTime parsed;
        if (m.Success && DateTime.TryParseExact(m.Groups[1].Value + m.Groups[2].Value, "yyyyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.AssumeLocal, out parsed)) return parsed;
        return File.GetLastWriteTime(path);
    }
    private static Dictionary<string, object> RebuildBackupCatalog(string folder, bool write)
    {
        Dictionary<string, object> previous = ReadBackupCatalogRaw(folder); Dictionary<string, Dictionary<string, object>> previousMap = BackupCatalogPreviousMap(previous); List<object> entries = new List<object>();
        foreach (string path in Directory.GetFiles(folder, "*.sqlite", SearchOption.TopDirectoryOnly).OrderByDescending(BackupTimestampFromNameOrFile))
        {
            string filename = Path.GetFileName(path);
            if (String.Equals(filename, ManagerLiveDbFileName, StringComparison.OrdinalIgnoreCase) || String.Equals(filename, ManagerBuildingDbFileName, StringComparison.OrdinalIgnoreCase) || filename.EndsWith(".restore-previous", StringComparison.OrdinalIgnoreCase) || filename.EndsWith(".previous", StringComparison.OrdinalIgnoreCase)) continue;
            Dictionary<string, object> info = InspectMirrorDbFile(path);
            DateTime at = BackupTimestampFromNameOrFile(path); Dictionary<string, object> prior = previousMap.ContainsKey(filename) ? previousMap[filename] : null;
            bool markerManaged = File.Exists(BackupManagedMarkerPath(path));
            bool managed = markerManaged || (prior != null && BooleanValue(prior, "managed"));
            bool markerProtected = File.Exists(BackupProtectionMarkerPath(path));
            bool protect = markerProtected || (prior != null && BooleanValue(prior, "protected")); string kind = prior == null ? (protect ? "protected" : (managed ? "backup" : "legacy")) : Text(prior, "kind").Trim(); if (String.IsNullOrWhiteSpace(kind)) kind = protect ? "protected" : (managed ? "backup" : "legacy");
            info["createdAt"] = at.ToUniversalTime().ToString("o"); info["protected"] = protect; info["kind"] = kind; info["managed"] = managed; info["filenameContract"] = managed; entries.Add(info);
        }
        bool approved = previous != null && BooleanValue(previous, "policyApproved"); Dictionary<string, object> catalog = new Dictionary<string, object> { { "version", ManagerBackupCatalogVersion }, { "policyApproved", approved }, { "rebuiltAt", DateTime.UtcNow.ToString("o") }, { "entries", entries.ToArray() } };
        if (write) WriteJsonFile(ManagerBackupCatalogPath(folder), catalog); return catalog;
    }
    private static List<Dictionary<string, object>> CatalogEntries(Dictionary<string, object> catalog)
    {
        List<Dictionary<string, object>> result = new List<Dictionary<string, object>>(); object raw; if (catalog == null || !catalog.TryGetValue("entries", out raw) || !(raw is IEnumerable) || raw is string) return result;
        foreach (object item in (IEnumerable)raw) { Dictionary<string, object> row = item as Dictionary<string, object>; if (row != null) result.Add(row); } return result;
    }
    private static Dictionary<string, object> BackupRetentionPlan(string folder, Dictionary<string, object> catalog)
    {
        List<Dictionary<string, object>> valid = CatalogEntries(catalog).Where(r => BooleanValue(r, "integrity") && Convert.ToInt64(r.ContainsKey("rowCount") ? r["rowCount"] : 0) > 0).OrderByDescending(r => DateTime.Parse(Text(r, "createdAt"))).ToList();
        HashSet<string> keep = new HashSet<string>(StringComparer.OrdinalIgnoreCase); foreach (Dictionary<string, object> r in valid.Where(r => BooleanValue(r, "protected") || !BooleanValue(r, "managed") || Text(r, "kind") == "pre_restore" || Text(r, "kind") == "pre_update")) keep.Add(Text(r, "filename"));
        foreach (Dictionary<string, object> r in valid.Take(2)) keep.Add(Text(r, "filename"));
        DateTime now = DateTime.Now;
        /* Retention means recovery points, not every file created in the period.
           Keep at most one newest managed recovery point per local calendar day for the latest 7 days,
           then one per week for 4 weeks and one per month for 6 months. Protected/legacy/safety backups
           and the two newest valid recovery points are already pinned above. */
        HashSet<string> days = new HashSet<string>();
        foreach (Dictionary<string, object> r in valid)
        {
            DateTime at = DateTime.Parse(Text(r, "createdAt")).ToLocalTime();
            if ((now.Date - at.Date).TotalDays < 0 || (now.Date - at.Date).TotalDays >= 7) continue;
            string key = at.ToString("yyyy-MM-dd");
            if (!days.Contains(key)) { days.Add(key); keep.Add(Text(r, "filename")); }
        }
        HashSet<string> weeks = new HashSet<string>(); foreach (Dictionary<string, object> r in valid) { DateTime at = DateTime.Parse(Text(r, "createdAt")).ToLocalTime(); string key = at.Year + "-W" + System.Globalization.CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(at, System.Globalization.CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday); if (weeks.Count < 4 && !weeks.Contains(key)) { weeks.Add(key); keep.Add(Text(r, "filename")); } }
        HashSet<string> months = new HashSet<string>(); foreach (Dictionary<string, object> r in valid) { DateTime at = DateTime.Parse(Text(r, "createdAt")).ToLocalTime(); string key = at.ToString("yyyy-MM"); if (months.Count < 6 && !months.Contains(key)) { months.Add(key); keep.Add(Text(r, "filename")); } }
        List<object> delete = new List<object>(), kept = new List<object>(), protectedRows = new List<object>(); foreach (Dictionary<string, object> r in valid) { string name = Text(r, "filename"); if (BooleanValue(r, "protected")) protectedRows.Add(r); if (keep.Contains(name) || !BooleanValue(r, "managed")) kept.Add(r); else delete.Add(r); }
        return new Dictionary<string, object> { { "ok", true }, { "delete", delete.ToArray() }, { "keep", kept.ToArray() }, { "protected", protectedRows.ToArray() }, { "deleteCount", delete.Count }, { "keepCount", kept.Count }, { "protectedCount", protectedRows.Count }, { "policyApproved", BooleanValue(catalog, "policyApproved") }, { "minimumRecoveryPoints", 2 }, { "dailyDays", 7 }, { "weeklyCount", 4 }, { "monthlyCount", 6 } };
    }
    private static Dictionary<string, object> BackupCatalogList(Dictionary<string, object> request)
    {
        try { string folder = ReadManagerDataFolder(); if (String.IsNullOrWhiteSpace(folder)) return Error("DB folder is not configured."); bool existed = File.Exists(ManagerBackupCatalogPath(folder)); Dictionary<string, object> catalog = RebuildBackupCatalog(folder, true), plan = BackupRetentionPlan(folder, catalog); return new Dictionary<string, object> { { "ok", true }, { "catalog", catalog }, { "plan", plan }, { "catalogRebuilt", !existed }, { "folder", folder } }; }
        catch (Exception ex) { return Error("Backup catalog failed: " + ex.Message); }
    }
    private static Dictionary<string, object> BackupSetProtected(Dictionary<string, object> request)
    {
        try { string folder = ReadManagerDataFolder(), filename = Path.GetFileName(Text(request, "filename")); if (String.IsNullOrWhiteSpace(folder) || String.IsNullOrWhiteSpace(filename)) return Error("Backup file is not selected."); Dictionary<string, object> catalog = RebuildBackupCatalog(folder, false); List<Dictionary<string, object>> entries = CatalogEntries(catalog); bool found = false, protect = BooleanValue(request, "protected"); foreach (Dictionary<string, object> row in entries) if (String.Equals(Text(row, "filename"), filename, StringComparison.OrdinalIgnoreCase)) { string kind = Text(row, "kind"); if (kind == "pre_restore" || kind == "pre_update") { row["protected"] = true; protect = true; } else { row["protected"] = protect; row["kind"] = protect ? "protected" : (BooleanValue(row, "managed") ? "backup" : "legacy"); } found = true; } if (!found) return Error("Backup file is not in the catalog."); SetBackupProtectionMarker(Path.Combine(folder, filename), protect); catalog["entries"] = entries.ToArray(); WriteJsonFile(ManagerBackupCatalogPath(folder), catalog); return BackupCatalogList(request); }
        catch (Exception ex) { return Error("Backup protection update failed: " + ex.Message); }
    }
    private static Dictionary<string, object> BackupRetentionApply(Dictionary<string, object> request)
    {
        try { string folder = ReadManagerDataFolder(); if (String.IsNullOrWhiteSpace(folder)) return Error("DB folder is not configured."); Dictionary<string, object> catalog = RebuildBackupCatalog(folder, false), plan = BackupRetentionPlan(folder, catalog); if (!BooleanValue(request, "confirm")) return new Dictionary<string, object> { { "ok", true }, { "preview", true }, { "plan", plan }, { "deleted", 0 } }; int deleted = 0; foreach (Dictionary<string, object> row in CatalogEntries(new Dictionary<string, object> { { "entries", plan["delete"] } })) { string name = Path.GetFileName(Text(row, "filename")); if (String.IsNullOrWhiteSpace(name) || BooleanValue(row, "protected") || !BooleanValue(row, "managed")) continue; string path = Path.Combine(folder, name); if (File.Exists(path)) { File.Delete(path); try { SetBackupProtectionMarker(path, false); SetBackupManagedMarker(path, false); } catch { } deleted++; } } catalog["policyApproved"] = true; WriteJsonFile(ManagerBackupCatalogPath(folder), catalog); Dictionary<string, object> rebuilt = RebuildBackupCatalog(folder, true); return new Dictionary<string, object> { { "ok", true }, { "deleted", deleted }, { "catalog", rebuilt }, { "plan", BackupRetentionPlan(folder, rebuilt) } }; }
        catch (Exception ex) { return Error("Backup retention failed: " + ex.Message); }
    }
    private static Dictionary<string, object> BackupDelete(Dictionary<string, object> request)
    {
        try { string folder = ReadManagerDataFolder(), name = Path.GetFileName(Text(request, "filename")); if (String.IsNullOrWhiteSpace(folder) || String.IsNullOrWhiteSpace(name)) return Error("Backup file is not selected."); Dictionary<string, object> catalog = RebuildBackupCatalog(folder, false); Dictionary<string, object> row = CatalogEntries(catalog).FirstOrDefault(r => String.Equals(Text(r, "filename"), name, StringComparison.OrdinalIgnoreCase)); if (row == null) return Error("Backup file is not in the catalog."); if (BooleanValue(row, "protected")) return Error("Protected backup cannot be deleted. Unprotect it first."); List<Dictionary<string, object>> valid = CatalogEntries(catalog).Where(r => BooleanValue(r, "integrity") && Convert.ToInt64(r.ContainsKey("rowCount") ? r["rowCount"] : 0) > 0).ToList(); if (valid.Count <= 2) return Error("At least two valid recovery backups must remain."); string path = Path.Combine(folder, name); if (File.Exists(path)) File.Delete(path); try { SetBackupProtectionMarker(path, false); SetBackupManagedMarker(path, false); } catch { } return BackupCatalogList(request); }
        catch (Exception ex) { return Error("Backup delete failed: " + ex.Message); }
    }
    private static Dictionary<string, object> LiveDbSnapshot(Dictionary<string, object> request)
    {
        string target = "";
        try
        {
            string live = LiveDbPath(false); if (!File.Exists(live)) return Error("Live DB file is missing."); Dictionary<string, object> liveInfo = InspectMirrorDbFile(live); if (!BooleanValue(liveInfo, "integrity") || Convert.ToInt64(liveInfo["rowCount"]) <= 0) return Error("Live DB integrity verification failed.");
            string folder = ReadManagerDataFolder(); DateTime now = DateTime.Now; string stem = ManagerBackupPrefix + now.ToString("yyyyMMdd_HHmmss"), name = stem + ".sqlite"; target = Path.Combine(folder, name);
            for (int suffix = 1; File.Exists(target); suffix++) { name = stem + "_" + suffix.ToString("00") + ".sqlite"; target = Path.Combine(folder, name); }
            SqliteOnlineBackup(live, target);
            Dictionary<string, object> backupInfo = InspectMirrorDbFile(target); if (!BooleanValue(backupInfo, "integrity") || Convert.ToInt64(backupInfo["rowCount"]) != Convert.ToInt64(liveInfo["rowCount"])) throw new InvalidOperationException("Backup verification failed.");
            bool protect = BooleanValue(request, "protected"); string kind = Text(request, "kind").Trim(); if (kind == "pre_restore" || kind == "pre_update") protect = true;
            SetBackupProtectionMarker(target, protect);
            SetBackupManagedMarker(target, true);
            Dictionary<string, object> catalog = RebuildBackupCatalog(folder, false); List<Dictionary<string, object>> entries = CatalogEntries(catalog); foreach (Dictionary<string, object> row in entries) if (String.Equals(Text(row, "filename"), name, StringComparison.OrdinalIgnoreCase)) { row["protected"] = protect; row["kind"] = protect ? (String.IsNullOrWhiteSpace(kind) ? "protected" : kind) : (String.IsNullOrWhiteSpace(kind) ? "backup" : kind); } catalog["entries"] = entries.ToArray(); WriteJsonFile(ManagerBackupCatalogPath(folder), catalog);
            /* A backup is a read-only operation on the active Live DB. Do not write last-backup metadata
               into SmartPage_Manager_Live.sqlite; the backup catalog and extension local state own that UI metadata. */
            Dictionary<string, object> plan = BackupRetentionPlan(folder, catalog); int pruned = 0; if (!protect && String.IsNullOrWhiteSpace(kind) && BooleanValue(catalog, "policyApproved")) { Dictionary<string, object> applied = BackupRetentionApply(new Dictionary<string, object> { { "confirm", true } }); if (BooleanValue(applied, "ok")) pruned = IntValue(applied, "deleted", 0); }
            return new Dictionary<string, object> { { "ok", true }, { "filename", name }, { "path", target }, { "bytes", new FileInfo(target).Length }, { "rowCount", backupInfo["rowCount"] }, { "sourceRevision", backupInfo["sourceRevision"] }, { "revisionKnown", backupInfo["revisionKnown"] }, { "protected", protect }, { "kind", kind }, { "pruned", pruned }, { "retentionPreview", plan } };
        }
        catch (Exception ex) { try { if (!String.IsNullOrWhiteSpace(target)) { if (File.Exists(target)) File.Delete(target); SetBackupProtectionMarker(target, false); SetBackupManagedMarker(target, false); } } catch { } return Error("Live DB snapshot failed: " + ex.Message); }
    }
    private static Dictionary<string, object> BackupRestore(Dictionary<string, object> request)
    {
        try
        {
            string folder = ReadManagerDataFolder(), name = Path.GetFileName(Text(request, "filename")); if (String.IsNullOrWhiteSpace(folder) || String.IsNullOrWhiteSpace(name)) return Error("Backup file is not selected."); string source = Path.Combine(folder, name); Dictionary<string, object> sourceInfo = InspectMirrorDbFile(source); if (!BooleanValue(sourceInfo, "integrity") || Convert.ToInt64(sourceInfo["rowCount"]) <= 0) return Error("Selected backup is not a valid SmartPage Local DB.");
            string live = LiveDbPath(false), building = LiveDbPath(true); Dictionary<string, object> safety = null; if (File.Exists(live)) { safety = LiveDbSnapshot(new Dictionary<string, object> { { "protected", true }, { "kind", "pre_restore" } }); if (!BooleanValue(safety, "ok")) return Error("Pre-restore safety backup failed. Restore was not started."); }
            if (File.Exists(building)) File.Delete(building); SqliteOnlineBackup(source, building); Dictionary<string, object> staged = InspectMirrorDbFile(building); if (!BooleanValue(staged, "integrity") || Convert.ToInt64(staged["rowCount"]) != Convert.ToInt64(sourceInfo["rowCount"])) { try { File.Delete(building); } catch { } return Error("Restore staging verification failed."); }
            string previous = live + ".restore-previous"; bool hadLive = File.Exists(live); try { if (File.Exists(previous)) File.Delete(previous); } catch { } if (hadLive) File.Replace(building, live, previous, true); else File.Move(building, live);
            Dictionary<string, object> finalInfo = InspectMirrorDbFile(live);
            if (!BooleanValue(finalInfo, "integrity") || Convert.ToInt64(finalInfo["rowCount"]) != Convert.ToInt64(sourceInfo["rowCount"]))
            {
                try { if (hadLive && File.Exists(previous)) { if (File.Exists(live)) File.Delete(live); File.Move(previous, live); } else if (!hadLive && File.Exists(live)) File.Delete(live); } catch { }
                return Error("Restored Live DB verification failed. Previous Live DB was preserved.");
            }
            try { if (File.Exists(previous)) File.Delete(previous); } catch { }
            return new Dictionary<string, object> { { "ok", true }, { "restored", true }, { "filename", name }, { "rowCount", finalInfo["rowCount"] }, { "sourceRevision", finalInfo["sourceRevision"] }, { "revisionKnown", finalInfo["revisionKnown"] }, { "safetyBackup", safety }, { "live", finalInfo } };
        }
        catch (Exception ex) { return Error("Backup restore failed: " + ex.Message); }
    }
    private static Dictionary<string, object> LiveDbBeginRebuild(Dictionary<string, object> request)
    {
        try
        {
            string path = LiveDbPath(true); if (File.Exists(path)) File.Delete(path);
            IntPtr db = OpenMirrorDb(path, true);
            try
            {
                SetMirrorMeta(db, "schema_version", "1");
                SetMirrorMeta(db, "extension_version", Text(request, "extensionVersion"));
                SetMirrorMeta(db, "build_state", "building");
                SetMirrorMeta(db, "expected_count", Convert.ToString(IntValue(request, "expectedCount", 0)));
                SetMirrorMeta(db, "started_at", DateTime.UtcNow.ToString("o"));
                SetMirrorMeta(db, "source_revision", Text(request, "sourceRevision"));
                SetMirrorMeta(db, "generation_id", Text(request, "generationId"));
                SetMirrorMeta(db, "pipeline_version", Text(request, "pipelineVersion"));
            }
            finally { sqlite3_close(db); }
            return new Dictionary<string, object> { { "ok", true }, { "path", path }, { "building", true }, { "storageVersion", 4184 } };
        }
        catch (Exception ex) { return Error("Live DB rebuild start failed: " + ex.Message); }
    }
    private static Dictionary<string, object> LiveDbUpsert(Dictionary<string, object> request)
    {
        try
        {
            bool building = BooleanValue(request, "building");
            string kind = Text(request, "kind").Trim(); if (String.IsNullOrWhiteSpace(kind)) kind = "display";
            List<object> rows = RequestObjectList(request, "rows");
            string path = LiveDbPath(building); IntPtr db = OpenMirrorDb(path, true); int saved = 0;
            try
            {
                SqliteExec(db, "BEGIN IMMEDIATE;");
                IntPtr stmt = IntPtr.Zero;
                int rc = sqlite3_prepare16_v2(db, "INSERT INTO mirror_rows(kind,keyword_canonical_key,keyword,updated_at,row_json) VALUES(?,?,?,?,?) ON CONFLICT(kind,keyword_canonical_key) DO UPDATE SET keyword=excluded.keyword,updated_at=excluded.updated_at,row_json=excluded.row_json;", -1, out stmt, IntPtr.Zero);
                if (rc != SQLITE_OK) throw new InvalidOperationException(SqliteError(db));
                try
                {
                    foreach (object item in rows)
                    {
                        Dictionary<string, object> row = item as Dictionary<string, object>; if (row == null) continue;
                        string key = Text(row, "keyword_canonical_key").Trim(); if (String.IsNullOrWhiteSpace(key)) key = Text(row, "_key").Trim(); if (String.IsNullOrWhiteSpace(key)) key = Text(row, "keyword").Trim(); if (String.IsNullOrWhiteSpace(key)) continue;
                        string keyword = Text(row, "keyword").Trim(); if (String.IsNullOrWhiteSpace(keyword)) keyword = key;
                        string updated = Text(row, "updated_at").Trim(); if (String.IsNullOrWhiteSpace(updated)) updated = Text(row, "_serverStateUpdatedAt").Trim();
                        string json = Json.Serialize(row);
                        sqlite3_reset(stmt); sqlite3_clear_bindings(stmt);
                        sqlite3_bind_text16(stmt, 1, kind, -1, SQLITE_TRANSIENT);
                        sqlite3_bind_text16(stmt, 2, key, -1, SQLITE_TRANSIENT);
                        sqlite3_bind_text16(stmt, 3, keyword, -1, SQLITE_TRANSIENT);
                        sqlite3_bind_text16(stmt, 4, updated, -1, SQLITE_TRANSIENT);
                        sqlite3_bind_text16(stmt, 5, json, -1, SQLITE_TRANSIENT);
                        rc = sqlite3_step(stmt); if (rc != SQLITE_DONE) throw new InvalidOperationException(SqliteError(db)); saved++;
                    }
                }
                finally { if (stmt != IntPtr.Zero) sqlite3_finalize(stmt); }
                SqliteExec(db, "COMMIT;");
                SetMirrorMeta(db, "last_write_at", DateTime.UtcNow.ToString("o"));
            }
            catch { try { SqliteExec(db, "ROLLBACK;"); } catch { } throw; }
            finally { sqlite3_close(db); }
            return new Dictionary<string, object> { { "ok", true }, { "saved", saved }, { "kind", kind }, { "building", building } };
        }
        catch (Exception ex) { return Error("Live DB upsert failed: " + ex.Message); }
    }
    private static Dictionary<string, object> LiveDbFinalize(Dictionary<string, object> request)
    {
        try
        {
            string building = LiveDbPath(true), live = LiveDbPath(false); if (!File.Exists(building)) return Error("Live DB building file is missing.");
            IntPtr db = OpenMirrorDb(building, true); long displayCount = 0;
            try
            {
                string expectedGeneration = Text(request, "generationId").Trim(), expectedPipeline = Text(request, "pipelineVersion").Trim();
                string actualGeneration = GetMirrorMeta(db, "generation_id"), actualPipeline = GetMirrorMeta(db, "pipeline_version");
                if (!String.IsNullOrWhiteSpace(expectedGeneration) && !String.Equals(expectedGeneration, actualGeneration, StringComparison.Ordinal)) return Error("Live DB generation mismatch. Building DB was not promoted.");
                if (!String.IsNullOrWhiteSpace(expectedPipeline) && !String.Equals(expectedPipeline, actualPipeline, StringComparison.Ordinal)) return Error("Live DB pipeline mismatch. Building DB was not promoted.");
                IntPtr stmt = IntPtr.Zero; int rc = sqlite3_prepare16_v2(db, "SELECT count(*) FROM mirror_rows WHERE kind='display';", -1, out stmt, IntPtr.Zero);
                if (rc == SQLITE_OK) { try { if (sqlite3_step(stmt) == SQLITE_ROW) displayCount = sqlite3_column_int64(stmt, 0); } finally { sqlite3_finalize(stmt); } }
                int expected = IntValue(request, "expectedCount", 0); if (expected > 0 && displayCount != expected) return Error("Live DB row verification failed: " + displayCount + "/" + expected);
                SetMirrorMeta(db, "build_state", "ready"); SetMirrorMeta(db, "completed_at", DateTime.UtcNow.ToString("o")); SetMirrorMeta(db, "display_count", Convert.ToString(displayCount));
                SetMirrorMeta(db, "source_revision", Text(request, "sourceRevision"));
            }
            finally { sqlite3_close(db); }
            string previous = live + ".previous"; try { if (File.Exists(previous)) File.Delete(previous); } catch { }
            if (File.Exists(live)) File.Replace(building, live, previous, true); else File.Move(building, live);
            try { if (File.Exists(previous)) File.Delete(previous); } catch { }
            return new Dictionary<string, object> { { "ok", true }, { "ready", true }, { "path", live }, { "count", displayCount }, { "sourceRevision", Text(request, "sourceRevision") } };
        }
        catch (Exception ex) { return Error("Live DB finalize failed: " + ex.Message); }
    }
    private static Dictionary<string, object> LiveDbStatus()
    {
        try
        {
            Dictionary<string, object> folderStatus = ManagerDataFolderStatus(); if (!(bool)folderStatus["configured"]) return folderStatus;
            string path = LiveDbPath(false), building = LiveDbPath(true); folderStatus["buildingDbExists"] = File.Exists(building); if (File.Exists(building)) folderStatus["building"] = InspectMirrorDbFile(building);
            if (!File.Exists(path)) { folderStatus["ready"] = false; folderStatus["count"] = 0; folderStatus["integrity"] = false; return folderStatus; }
            Dictionary<string, object> info = InspectMirrorDbFile(path); folderStatus["ready"] = BooleanValue(info, "integrity") && Convert.ToInt64(info["rowCount"]) > 0 && String.Equals(Text(info, "buildState"), "ready", StringComparison.OrdinalIgnoreCase); folderStatus["integrity"] = BooleanValue(info, "integrity"); folderStatus["count"] = info["rowCount"]; folderStatus["sourceRevision"] = info["sourceRevision"]; folderStatus["revisionKnown"] = info["revisionKnown"]; folderStatus["completedAt"] = info["completedAt"]; folderStatus["generation"] = info["generation"];
            try { IntPtr db = OpenMirrorDbReadOnly(path); try { folderStatus["lastBackupFile"] = GetMirrorMeta(db, "last_backup_file"); folderStatus["lastBackupAt"] = GetMirrorMeta(db, "last_backup_at"); } finally { sqlite3_close(db); } } catch { }
            return folderStatus;
        }
        catch (Exception ex) { return Error("Live DB status failed: " + ex.Message); }
    }
    private static Dictionary<string, object> LiveDbBuildingStatus()
    {
        try { string folder = ReadManagerDataFolder(); if (String.IsNullOrWhiteSpace(folder)) return new Dictionary<string, object> { { "ok", true }, { "exists", false }, { "configured", false } }; string path = LiveDbPath(true); if (!File.Exists(path)) return new Dictionary<string, object> { { "ok", true }, { "exists", false }, { "configured", true }, { "path", path } }; Dictionary<string, object> info = InspectMirrorDbFile(path); info["ok"] = true; info["exists"] = true; return info; }
        catch (Exception ex) { return Error("Building DB status failed: " + ex.Message); }
    }
    private static Dictionary<string, object> LiveDbRead(Dictionary<string, object> request)
    {
        try
        {
            string kind = Text(request, "kind").Trim(); if (String.IsNullOrWhiteSpace(kind)) kind = "display";
            int offset = Math.Max(0, IntValue(request, "offset", 0)); int limit = Math.Max(1, Math.Min(80, IntValue(request, "limit", 40)));
            bool building = BooleanValue(request, "building");
            string path = LiveDbPath(building); if (!File.Exists(path)) return new Dictionary<string, object> { { "ok", true }, { "rows", new object[0] }, { "nextOffset", null }, { "count", 0 }, { "building", building } };
            IntPtr db = OpenMirrorDb(path, true); List<object> rows = new List<object>(); long total = 0;
            try
            {
                IntPtr countStmt = IntPtr.Zero; int rc = sqlite3_prepare16_v2(db, "SELECT count(*) FROM mirror_rows WHERE kind=?;", -1, out countStmt, IntPtr.Zero);
                if (rc == SQLITE_OK) { try { sqlite3_bind_text16(countStmt, 1, kind, -1, SQLITE_TRANSIENT); if (sqlite3_step(countStmt) == SQLITE_ROW) total = sqlite3_column_int64(countStmt, 0); } finally { sqlite3_finalize(countStmt); } }
                /* Chrome Native Messaging host -> extension responses are limited to about 1 MB.
                   Live mirror rows can contain trend arrays and analysis text, so cap each read page
                   by both row count and serialized source size. This keeps full-table restore reliable
                   without falling back to scroll-time hydration. */
                const int MirrorReadMaxChars = 180000;
                int sourceChars = 0;
                IntPtr stmt = IntPtr.Zero; rc = sqlite3_prepare16_v2(db, "SELECT row_json FROM mirror_rows WHERE kind=? ORDER BY keyword_canonical_key LIMIT ? OFFSET ?;", -1, out stmt, IntPtr.Zero);
                if (rc != SQLITE_OK) throw new InvalidOperationException(SqliteError(db));
                try
                {
                    sqlite3_bind_text16(stmt, 1, kind, -1, SQLITE_TRANSIENT); sqlite3_bind_int64(stmt, 2, limit); sqlite3_bind_int64(stmt, 3, offset);
                    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW)
                    {
                        IntPtr p = sqlite3_column_text16(stmt, 0); string json = p == IntPtr.Zero ? "{}" : Marshal.PtrToStringUni(p);
                        if (rows.Count > 0 && sourceChars + json.Length > MirrorReadMaxChars) break;
                        object row = Json.DeserializeObject(json); if (row != null) { rows.Add(row); sourceChars += json.Length; }
                    }
                    if (rc != SQLITE_DONE && rc != SQLITE_ROW) throw new InvalidOperationException(SqliteError(db));
                }
                finally { sqlite3_finalize(stmt); }
            }
            finally { sqlite3_close(db); }
            object next = offset + rows.Count < total ? (object)(offset + rows.Count) : null;
            return new Dictionary<string, object> { { "ok", true }, { "rows", rows.ToArray() }, { "nextOffset", next }, { "count", total }, { "kind", kind }, { "building", building } };
        }
        catch (Exception ex) { return Error("Live DB read failed: " + ex.Message); }
    }
    private static Dictionary<string, object> LiveDbSetRevision(Dictionary<string, object> request)
    {
        try
        {
            string path = LiveDbPath(false); if (!File.Exists(path)) return Error("Live DB file is missing."); string revision = Text(request, "sourceRevision").Trim();
            if (!IsTrustedSourceRevision(revision)) return Error("Source revision is not trustworthy.");
            IntPtr db = OpenMirrorDb(path, true); try { SetMirrorMeta(db, "source_revision", revision); SetMirrorMeta(db, "last_delta_sync_at", DateTime.UtcNow.ToString("o")); } finally { sqlite3_close(db); }
            return new Dictionary<string, object> { { "ok", true }, { "sourceRevision", revision }, { "revisionKnown", true } };
        }
        catch (Exception ex) { return Error("Live DB revision update failed: " + ex.Message); }
    }
    private static Dictionary<string, object> LiveDbDelete(Dictionary<string, object> request)
    {
        try
        {
            List<object> rawKeys = RequestObjectList(request, "keys");
            List<string> keys = new List<string>(); foreach (object item in rawKeys) { string key = Convert.ToString(item).Trim(); if (!String.IsNullOrWhiteSpace(key)) keys.Add(key); }
            if (keys.Count == 0) return new Dictionary<string, object> { { "ok", true }, { "deleted", 0 } };
            string path = LiveDbPath(false); if (!File.Exists(path)) return new Dictionary<string, object> { { "ok", true }, { "deleted", 0 } };
            IntPtr db = OpenMirrorDb(path, true); int deleted = 0;
            try
            {
                SqliteExec(db, "BEGIN IMMEDIATE;");
                IntPtr stmt = IntPtr.Zero; int rc = sqlite3_prepare16_v2(db, "DELETE FROM mirror_rows WHERE keyword_canonical_key=?;", -1, out stmt, IntPtr.Zero);
                if (rc != SQLITE_OK) throw new InvalidOperationException(SqliteError(db));
                try { foreach (string key in keys) { sqlite3_reset(stmt); sqlite3_clear_bindings(stmt); sqlite3_bind_text16(stmt, 1, key, -1, SQLITE_TRANSIENT); rc = sqlite3_step(stmt); if (rc != SQLITE_DONE) throw new InvalidOperationException(SqliteError(db)); deleted++; } }
                finally { sqlite3_finalize(stmt); }
                SqliteExec(db, "COMMIT;"); SetMirrorMeta(db, "last_write_at", DateTime.UtcNow.ToString("o"));
            }
            catch { try { SqliteExec(db, "ROLLBACK;"); } catch { } throw; }
            finally { sqlite3_close(db); }
            return new Dictionary<string, object> { { "ok", true }, { "deleted", deleted } };
        }
        catch (Exception ex) { return Error("Live DB delete failed: " + ex.Message); }
    }


    private static Dictionary<string, object> Handle(Dictionary<string, object> request)
    {
        string command = Text(request, "command");
        if (command == "save_profile_settings") return SaveDedicatedProfileSettings(request);
        if (command == "load_profile_settings") return LoadDedicatedProfileSettings();
        if (command == "integration_settings_status") return IntegrationSettingsStatus();
        if (command == "load_integration_settings") return LoadIntegrationSettings();
        if (command == "save_integration_settings") return SaveIntegrationSettings(request);
        if (command == "open_integration_settings") return OpenIntegrationSettings();
        if (command == "save_manager_layout") return SaveManagerLayout(request);
        if (command == "load_manager_layout") return LoadManagerLayout();
        if (command == "manager_data_folder_status") return ManagerDataFolderStatus();
        if (command == "manager_data_folder_inspect") return InspectManagerDataFolder(Text(request, "path"));
        if (command == "choose_manager_data_folder") return ChooseManagerDataFolder(request);
        if (command == "set_manager_data_folder") return SetManagerDataFolder(request);
        if (command == "live_db_status") return LiveDbStatus();
        if (command == "live_db_building_status") return LiveDbBuildingStatus();
        if (command == "live_db_begin_rebuild") return LiveDbBeginRebuild(request);
        if (command == "live_db_upsert") return LiveDbUpsert(request);
        if (command == "live_db_finalize") return LiveDbFinalize(request);
        if (command == "live_db_read") return LiveDbRead(request);
        if (command == "live_db_set_revision") return LiveDbSetRevision(request);
        if (command == "live_db_delete") return LiveDbDelete(request);
        if (command == "live_db_snapshot") return LiveDbSnapshot(request);
        if (command == "backup_catalog_list") return BackupCatalogList(request);
        if (command == "backup_set_protected") return BackupSetProtected(request);
        if (command == "backup_retention_preview") return BackupRetentionApply(new Dictionary<string, object> { { "confirm", false } });
        if (command == "backup_retention_apply") return BackupRetentionApply(request);
        if (command == "backup_delete") return BackupDelete(request);
        if (command == "backup_restore") return BackupRestore(request);
        if (command == "mobile_reset_status") return MobileResetStatus();
        if (command == "adb_status") return AdbConnectionStatusV168();
        if (command == "adb_recover") return RecoverAdbConnectionV168();
        if (command == "airplane_mode_status") return RunAirplaneModeCommand(request, "status");
        if (command == "set_airplane_mode") return RunAirplaneModeCommand(request, BooleanValue(request, "enabled") ? "on" : "off");
        if (command == "ensure_bridge")
        {
            bool ready = EnsureBridgeProcess(10000);
            Dictionary<string, object> state = BuildStatus();
            state["ok"] = ready;
            state["proxyReady"] = ready;
            state["onDemand"] = true;
            state["message"] = ready ? "SmartPage Ex network helper started on demand." : "SmartPage Ex network helper did not open the local bridge ports.";
            if (!ready) state["error"] = state["message"];
            return state;
        }
        if (command == "list_adapters" || command == "status")
        {
            Dictionary<string, object> state = GetStatusSnapshot(command == "list_adapters" ? 1000 : 3000);
            state["ok"] = true;
            return state;
        }
        if (command == "set_mode")
        {
            lock (ModeLock) { Dictionary<string, object> result = ApplyMode(request); InvalidateStatusSnapshot(); return result; }
        }
        if (command == "set_system_adapter")
        {
            lock (ModeLock) { Dictionary<string, object> result = ApplySystemAdapter(request); InvalidateStatusSnapshot(); return result; }
        }
        if (command == "clear_system_adapter")
        {
            lock (ModeLock) { Dictionary<string, object> result = ClearSystemAdapter(); InvalidateStatusSnapshot(); return result; }
        }
        if (command == "set_window_adapter")
        {
            lock (ProxyStateLock)
            {
                Dictionary<string, object> result = ApplyWindowAdapter(request);
                InvalidateStatusSnapshot();
                return result;
            }
        }
        if (command == "clear_window_adapter")
        {
            lock (ProxyStateLock) { Dictionary<string, object> result = ClearWindowAdapter(); InvalidateStatusSnapshot(); return result; }
        }
        if (command == "open_coupang_window")
        {
            lock (ProxyStateLock) { Dictionary<string, object> result = OpenCoupangWindow(request); InvalidateStatusSnapshot(); return result; }
        }
        if (command == "cancel_mobile_reset")
        {
            Dictionary<string, object> result = CancelMobileReset(request);
            InvalidateStatusSnapshot();
            return result;
        }
        if (command == "reset_mobile_network")
        {
            Dictionary<string, object> result = ResetMobileNetwork(request);
            InvalidateStatusSnapshot();
            return result;
        }
        return Error("Unsupported command: " + command);
    }

    private static bool IsNativeOnlyCommand(string command)
    {
        // v3.0.8.14: local bridge validates the exact extension origin and a private token.
        // Settings are protected with DPAPI LocalMachine, so the dedicated profile no longer
        // depends on Chrome Native Messaging registration.
        return false;
    }

    private static Dictionary<string, object> SaveManagerLayout(Dictionary<string, object> request)
    {
        try
        {
            object rawLayout;
            if (request == null || !request.TryGetValue("layout", out rawLayout) || rawLayout == null)
                return Error("Manager layout payload is missing.");
            Dictionary<string, object> layout = rawLayout as Dictionary<string, object>;
            if (layout == null) return Error("Manager layout payload is invalid.");
            string serializedLayout = Json.Serialize(layout);
            if (Encoding.UTF8.GetByteCount(serializedLayout) > 1024 * 1024)
                return Error("Manager layout payload is too large.");

            Dictionary<string, object> envelope = new Dictionary<string, object>
            {
                { "format", "spx-manager-layout-envelope-v1" },
                { "savedAt", DateTime.UtcNow.ToString("o") },
                { "savedAtUnixMs", DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() },
                { "extensionId", Text(request, "extensionId") },
                { "layout", layout }
            };
            lock (ManagerLayoutLock) WriteJsonFile(ManagerLayoutPath, envelope);
            return new Dictionary<string, object>
            {
                { "ok", true }, { "saved", true },
                { "savedAt", envelope["savedAtUnixMs"] },
                { "savedAtIso", envelope["savedAt"] },
                { "path", ManagerLayoutPath },
                { "layoutSyncVersion", "v1" }
            };
        }
        catch (Exception ex) { return Error("Manager layout save failed: " + ex.Message); }
    }

    private static Dictionary<string, object> LoadManagerLayout()
    {
        try
        {
            lock (ManagerLayoutLock)
            {
                if (!File.Exists(ManagerLayoutPath))
                    return new Dictionary<string, object> { { "ok", true }, { "found", false }, { "layoutSyncVersion", "v1" } };
                Dictionary<string, object> envelope = ReadJsonFile(ManagerLayoutPath);
                object rawLayout;
                Dictionary<string, object> layout = envelope.TryGetValue("layout", out rawLayout) ? rawLayout as Dictionary<string, object> : null;
                if (layout == null) return Error("Saved manager layout file is invalid.");
                object savedAt = envelope.ContainsKey("savedAtUnixMs") ? envelope["savedAtUnixMs"] : (envelope.ContainsKey("savedAt") ? envelope["savedAt"] : "");
                return new Dictionary<string, object>
                {
                    { "ok", true }, { "found", true }, { "layout", layout },
                    { "savedAt", savedAt }, { "savedAtIso", Text(envelope, "savedAt") },
                    { "path", ManagerLayoutPath }, { "layoutSyncVersion", "v1" }
                };
            }
        }
        catch (Exception ex) { return Error("Manager layout load failed: " + ex.Message); }
    }

    private static Dictionary<string, object> EmptyIntegrationSettings()
    {
        Dictionary<string, object> values = new Dictionary<string, object>();
        foreach (string key in IntegrationSecretKeys) values[key] = "";
        return values;
    }

    private static Dictionary<string, object> SanitizeIntegrationSettings(Dictionary<string, object> source)
    {
        Dictionary<string, object> values = EmptyIntegrationSettings();
        if (source == null) return values;
        foreach (string key in IntegrationSecretKeys)
        {
            object value;
            if (source.TryGetValue(key, out value) && value != null) values[key] = Convert.ToString(value).Trim();
        }
        return values;
    }

    private static string NormalizeIntegrationJson(string raw)
    {
        if (String.IsNullOrEmpty(raw)) return "{}";
        StringBuilder noComments = new StringBuilder(raw.Length);
        bool inString = false, escaped = false, lineComment = false, blockComment = false;
        for (int i = 0; i < raw.Length; i++)
        {
            char c = raw[i];
            char n = i + 1 < raw.Length ? raw[i + 1] : '\0';
            if (lineComment)
            {
                if (c == '\r' || c == '\n') { lineComment = false; noComments.Append(c); }
                continue;
            }
            if (blockComment)
            {
                if (c == '*' && n == '/') { blockComment = false; i++; continue; }
                if (c == '\r' || c == '\n') noComments.Append(c);
                continue;
            }
            if (inString)
            {
                noComments.Append(c);
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '"') inString = false;
                continue;
            }
            if (c == '"') { inString = true; noComments.Append(c); continue; }
            if (c == '/' && n == '/') { lineComment = true; i++; continue; }
            if (c == '/' && n == '*') { blockComment = true; i++; continue; }
            noComments.Append(c);
        }

        string text = noComments.ToString();
        StringBuilder clean = new StringBuilder(text.Length);
        inString = false; escaped = false;
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (inString)
            {
                clean.Append(c);
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '"') inString = false;
                continue;
            }
            if (c == '"') { inString = true; clean.Append(c); continue; }
            if (c == ',')
            {
                int j = i + 1;
                while (j < text.Length && Char.IsWhiteSpace(text[j])) j++;
                if (j < text.Length && (text[j] == '}' || text[j] == ']')) continue;
            }
            clean.Append(c);
        }
        return clean.ToString().TrimStart('\uFEFF', ' ', '\t', '\r', '\n');
    }

    private static Dictionary<string, object> ReadIntegrationSettingsFile()
    {
        if (!File.Exists(IntegrationSecretsPath)) return EmptyIntegrationSettings();
        string raw = File.ReadAllText(IntegrationSecretsPath, Encoding.UTF8);
        if (String.IsNullOrWhiteSpace(raw)) return EmptyIntegrationSettings();
        try
        {
            string normalized = NormalizeIntegrationJson(raw);
            Dictionary<string, object> parsed = Json.Deserialize<Dictionary<string, object>>(normalized) ?? new Dictionary<string, object>();
            return SanitizeIntegrationSettings(parsed);
        }
        catch
        {
            // Never include parser exception text here. JavaScriptSerializer can echo nearby JSON text,
            // which may expose service keys in the extension UI or logs.
            throw new InvalidDataException("Integration settings JSON syntax is invalid. Comments and trailing commas are supported; check quote and comma pairs.");
        }
    }

    private static void WriteIntegrationSettingsFile(Dictionary<string, object> settings)
    {
        Dictionary<string, object> clean = SanitizeIntegrationSettings(settings);
        StringBuilder builder = new StringBuilder();
        builder.AppendLine("{");
        for (int i = 0; i < IntegrationSecretKeys.Length; i++)
        {
            string key = IntegrationSecretKeys[i];
            object value;
            clean.TryGetValue(key, out value);
            builder.Append("  ").Append(Json.Serialize(key)).Append(": ").Append(Json.Serialize(Convert.ToString(value) ?? ""));
            if (i < IntegrationSecretKeys.Length - 1) builder.Append(",");
            builder.AppendLine();
        }
        builder.AppendLine("}");
        string temp = IntegrationSecretsPath + ".tmp";
        File.WriteAllText(temp, builder.ToString(), new UTF8Encoding(false));
        File.Copy(temp, IntegrationSecretsPath, true);
        File.Delete(temp);
    }

    private static int CountConfiguredIntegrationSettings(Dictionary<string, object> settings)
    {
        int count = 0;
        foreach (string key in IntegrationSecretKeys)
        {
            object value;
            if (settings != null && settings.TryGetValue(key, out value) && !String.IsNullOrWhiteSpace(Convert.ToString(value))) count++;
        }
        return count;
    }

    private static Dictionary<string, object> IntegrationSettingsStatus()
    {
        try
        {
            bool found = File.Exists(IntegrationSecretsPath);
            Dictionary<string, object> settings = found ? ReadIntegrationSettingsFile() : EmptyIntegrationSettings();
            DateTime updated = found ? File.GetLastWriteTimeUtc(IntegrationSecretsPath) : DateTime.MinValue;
            return new Dictionary<string, object>
            {
                { "ok", true }, { "found", found }, { "path", IntegrationSecretsPath },
                { "configuredCount", CountConfiguredIntegrationSettings(settings) },
                { "updatedAt", updated == DateTime.MinValue ? "" : updated.ToString("o") },
                { "helperVersion", HelperVersion }
            };
        }
        catch (Exception ex) { return Error("Integration settings status failed: " + ex.Message); }
    }

    private static Dictionary<string, object> LoadIntegrationSettings()
    {
        try
        {
            if (!File.Exists(IntegrationSecretsPath)) WriteIntegrationSettingsFile(EmptyIntegrationSettings());
            Dictionary<string, object> settings = ReadIntegrationSettingsFile();
            return new Dictionary<string, object>
            {
                { "ok", true }, { "found", true }, { "path", IntegrationSecretsPath },
                { "settings", settings }, { "configuredCount", CountConfiguredIntegrationSettings(settings) },
                { "updatedAt", File.GetLastWriteTimeUtc(IntegrationSecretsPath).ToString("o") },
                { "helperVersion", HelperVersion }
            };
        }
        catch (Exception ex) { return Error("Integration settings load failed: " + ex.Message); }
    }

    private static Dictionary<string, object> SaveIntegrationSettings(Dictionary<string, object> request)
    {
        try
        {
            object raw;
            Dictionary<string, object> settings = request != null && request.TryGetValue("settings", out raw) ? raw as Dictionary<string, object> : null;
            if (settings == null) return Error("Integration settings payload is missing or invalid.");
            WriteIntegrationSettingsFile(settings);
            Dictionary<string, object> clean = ReadIntegrationSettingsFile();
            return new Dictionary<string, object>
            {
                { "ok", true }, { "saved", true }, { "path", IntegrationSecretsPath },
                { "configuredCount", CountConfiguredIntegrationSettings(clean) },
                { "updatedAt", File.GetLastWriteTimeUtc(IntegrationSecretsPath).ToString("o") },
                { "helperVersion", HelperVersion }
            };
        }
        catch (Exception ex) { return Error("Integration settings save failed: " + ex.Message); }
    }

    private static Dictionary<string, object> OpenIntegrationSettings()
    {
        try
        {
            if (!File.Exists(IntegrationSecretsPath)) WriteIntegrationSettingsFile(EmptyIntegrationSettings());
            string taskOutput;
            int exitCode = RunScheduledTask(IntegrationSettingsTaskName, out taskOutput);
            if (exitCode != 0) return Error("Integration settings editor task failed: " + taskOutput);
            return new Dictionary<string, object>
            {
                { "ok", true }, { "opened", true }, { "path", IntegrationSecretsPath },
                { "message", "Integration settings file opened in Notepad." }, { "helperVersion", HelperVersion }
            };
        }
        catch (Exception ex) { return Error("Integration settings editor failed: " + ex.Message); }
    }

    private static Dictionary<string, object> SaveDedicatedProfileSettings(Dictionary<string, object> request)
    {
        try
        {
            object rawSettings;
            if (request == null || !request.TryGetValue("settings", out rawSettings) || rawSettings == null)
                return Error("Dedicated-profile settings payload is missing.");
            Dictionary<string, object> settings = rawSettings as Dictionary<string, object>;
            if (settings == null) return Error("Dedicated-profile settings payload is invalid.");
            Dictionary<string, object> envelope = new Dictionary<string, object>
            {
                { "format", "spx-dedicated-settings-v2-machine" },
                { "extensionId", Text(request, "extensionId") },
                { "savedAt", DateTime.UtcNow.ToString("o") },
                { "settings", settings }
            };
            byte[] plain = Encoding.UTF8.GetBytes(Json.Serialize(envelope));
            if (plain.Length > 256 * 1024) return Error("Dedicated-profile settings payload is too large.");
            byte[] encrypted = ProtectedData.Protect(plain, DedicatedSettingsMachineEntropy, DataProtectionScope.LocalMachine);
            string temporary = DedicatedSettingsMachinePath + ".tmp";
            File.WriteAllText(temporary, Convert.ToBase64String(encrypted), new UTF8Encoding(false));
            File.Copy(temporary, DedicatedSettingsMachinePath, true);
            File.Delete(temporary);
            return new Dictionary<string, object>
            {
                { "ok", true }, { "saved", true }, { "protectedBy", "Windows DPAPI LocalMachine" },
                { "savedAt", envelope["savedAt"] }, { "settingCount", settings.Count },
                { "transportReady", true }, { "profileSyncVersion", "v2-machine" }
            };
        }
        catch (Exception ex) { return Error("Dedicated-profile settings protection failed: " + ex.Message); }
    }

    private static Dictionary<string, object> ReadDedicatedProfileSettingsFile(string path, byte[] entropy, DataProtectionScope scope, string protectedBy)
    {
        byte[] encrypted = Convert.FromBase64String(File.ReadAllText(path, Encoding.UTF8).Trim());
        byte[] plain = ProtectedData.Unprotect(encrypted, entropy, scope);
        Dictionary<string, object> envelope = Json.Deserialize<Dictionary<string, object>>(Encoding.UTF8.GetString(plain)) ?? new Dictionary<string, object>();
        object rawSettings;
        Dictionary<string, object> settings = envelope.TryGetValue("settings", out rawSettings) ? rawSettings as Dictionary<string, object> : null;
        if (settings == null) return Error("Protected dedicated-profile settings are invalid.");
        return new Dictionary<string, object>
        {
            { "ok", true }, { "found", true }, { "protectedBy", protectedBy },
            { "savedAt", Text(envelope, "savedAt") }, { "settings", settings }
        };
    }

    private static Dictionary<string, object> LoadDedicatedProfileSettings()
    {
        try
        {
            if (File.Exists(DedicatedSettingsMachinePath))
            {
                Dictionary<string, object> result = ReadDedicatedProfileSettingsFile(
                    DedicatedSettingsMachinePath, DedicatedSettingsMachineEntropy,
                    DataProtectionScope.LocalMachine, "Windows DPAPI LocalMachine");
                result["profileSyncVersion"] = "v2-machine";
                return result;
            }

            // One-time compatibility migration. If the old user-scoped file cannot be opened in
            // the bridge account, the normal profile will simply create the v2 file on next sync.
            if (File.Exists(DedicatedSettingsPath))
            {
                try
                {
                    Dictionary<string, object> legacy = ReadDedicatedProfileSettingsFile(
                        DedicatedSettingsPath, DedicatedSettingsEntropy,
                        DataProtectionScope.CurrentUser, "Windows DPAPI CurrentUser");
                    object settingsObject;
                    if (legacy.TryGetValue("settings", out settingsObject) && settingsObject is Dictionary<string, object>)
                    {
                        Dictionary<string, object> migrated = SaveDedicatedProfileSettings(new Dictionary<string, object>
                        {
                            { "extensionId", "" }, { "settings", settingsObject }
                        });
                        if (migrated.ContainsKey("ok") && Convert.ToBoolean(migrated["ok"]))
                        {
                            legacy["protectedBy"] = "Windows DPAPI LocalMachine";
                            legacy["profileSyncVersion"] = "v2-machine-migrated";
                        }
                    }
                    return legacy;
                }
                catch (Exception) { }
            }

            return new Dictionary<string, object>
            {
                { "ok", true }, { "found", false }, { "settings", new Dictionary<string, object>() },
                { "protectedBy", "Windows DPAPI LocalMachine" }, { "profileSyncVersion", "v2-machine" }
            };
        }
        catch (Exception ex) { return Error("Dedicated-profile settings recovery failed: " + ex.Message); }
    }

    private static Dictionary<string, object> RunMobileResetAttempt(string powershell, string arguments, int holdSeconds, int reconnectSeconds, string serial, int attempt)
    {
        DateTime started = DateTime.UtcNow;
        string attemptArguments = arguments + (attempt > 1 ? " -ForceMobileDataCycle" : "");
        ProcessStartInfo info = new ProcessStartInfo
        {
            FileName = powershell,
            Arguments = attemptArguments,
            WorkingDirectory = BaseDir,
            UseShellExecute = false,
            CreateNoWindow = true,
            WindowStyle = ProcessWindowStyle.Hidden,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = new UTF8Encoding(false),
            StandardErrorEncoding = new UTF8Encoding(false)
        };
        using (Process process = Process.Start(info))
        {
            if (process == null) return Error("Unable to start the ADB mobile network reset script.");
            lock (MobileResetProcessLock) { ActiveMobileResetProcess = process; }
            int timeoutMs = (holdSeconds + reconnectSeconds + 35) * 1000;
            try
            {
                if (!process.WaitForExit(timeoutMs))
                {
                    TryEmergencyAirplaneModeOff(serial);
                    try { if (!process.HasExited) process.Kill(); } catch { }
                    try { process.WaitForExit(5000); } catch { }
                    return Error("ADB mobile network reset response timed out. The stuck reset process was terminated after an emergency airplane-mode OFF command.");
                }
                if (MobileResetCancelRequested)
                {
                    Dictionary<string, object> cancelled = Error("Mobile network reset was cancelled by the user.");
                    cancelled["errorCode"] = "MOBILE_RESET_CANCELLED";
                    cancelled["cancelled"] = true;
                    cancelled["completed"] = false;
                    cancelled["attempt"] = attempt;
                    return cancelled;
                }
            }
            finally
            {
                lock (MobileResetProcessLock) { if (Object.ReferenceEquals(ActiveMobileResetProcess, process)) ActiveMobileResetProcess = null; }
            }
            string standardOutput = process.StandardOutput.ReadToEnd();
            string standardError = process.StandardError.ReadToEnd();
            string jsonLine = (standardOutput ?? "").Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries).LastOrDefault() ?? "";
            Dictionary<string, object> result = new Dictionary<string, object>();
            try { result = Json.Deserialize<Dictionary<string, object>>(jsonLine.Trim('\uFEFF', ' ', '\t')) ?? result; }
            catch { }
            bool ok = process.ExitCode == 0 && BooleanValue(result, "ok");
            result["ok"] = ok;
            result["completed"] = ok;
            result["command"] = "reset_mobile_network";
            result["attempt"] = attempt;
            result["startedAt"] = started.ToString("o");
            result["finishedAt"] = DateTime.UtcNow.ToString("o");
            result["durationMs"] = Math.Max(0, (long)(DateTime.UtcNow - started).TotalMilliseconds);
            if (!ok && !result.ContainsKey("error"))
            {
                string detail = String.IsNullOrWhiteSpace(standardError) ? "ADB mobile network reset failed." : standardError.Trim();
                result["error"] = detail.Length > 500 ? detail.Substring(0, 500) : detail;
            }
            return result;
        }
    }

    private static bool IsMobileResetRunning()
    {
        try
        {
            using (Mutex existing = Mutex.OpenExisting("Global\\SmartPageExMobileNetworkResetV1"))
            {
                try
                {
                    if (existing.WaitOne(0)) { existing.ReleaseMutex(); return false; }
                    return true;
                }
                catch (AbandonedMutexException)
                {
                    try { existing.ReleaseMutex(); } catch { }
                    return false;
                }
            }
        }
        catch (WaitHandleCannotBeOpenedException) { return false; }
        catch { return false; }
    }

    private static void UpdateMobileResetProgress(string phase, string label, int attempt, string initialPublicIp, string errorCode, string errorText)
    {
        try
        {
            Dictionary<string, object> state = ReadJsonFile(MobileResetStatePath);
            DateTime now = DateTime.UtcNow;
            state["status"] = "running";
            state["running"] = true;
            state["inProgress"] = true;
            state["completed"] = false;
            state["resetOk"] = false;
            state["phase"] = phase ?? "";
            state["phaseLabel"] = label ?? "";
            state["phaseStartedAt"] = now.ToString("o");
            state["updatedAt"] = now.ToString("o");
            state["heartbeatAt"] = now.ToString("o");
            state["attempt"] = attempt;
            state["helperVersion"] = HelperVersion;
            if (!String.IsNullOrWhiteSpace(initialPublicIp)) state["initialPublicIp"] = initialPublicIp;
            if (!String.IsNullOrWhiteSpace(errorCode)) state["errorCode"] = errorCode; else state["errorCode"] = "";
            state["lastError"] = errorText ?? "";
            WriteJsonFile(MobileResetStatePath, state);
        }
        catch { }
    }

    private static AdapterBinding WaitForSelectedAdapterAfterMobileReset(int timeoutSeconds, int attempt, string initialPublicIp, out string lastError)
    {
        DateTime deadline = DateTime.UtcNow.AddSeconds(Math.Max(20, Math.Min(120, timeoutSeconds)));
        lastError = "";
        while (DateTime.UtcNow < deadline)
        {
            if (MobileResetCancelRequested) throw new OperationCanceledException("Mobile network reset cancelled.");
            Dictionary<string, object> state = ReadProxyState();
            try
            {
                AdapterBinding binding = ResolveAdapter(Text(state, "adapterId"), Text(state, "adapterName"), Text(state, "adapterDescription"));
                state["adapterId"] = binding.Id;
                state["adapterName"] = binding.Name;
                state["adapterDescription"] = binding.Description ?? "";
                state["ipv4Address"] = binding.Address.ToString();
                state["interfaceIndex"] = binding.InterfaceIndex;
                state["updatedAt"] = DateTime.UtcNow.ToString("o");
                WriteJsonFile(ProxyStatePath, state);
                InvalidateStatusSnapshot();
                UpdateMobileResetProgress("windows-adapter-ready", "Windows USB \uD14C\uB354\uB9C1 \uC5B4\uB311\uD130\u00B7IPv4 \uBCF5\uAD6C \uD655\uC778 \u00B7 \uC0C8 \uACF5\uC778 IP \uAC80\uC99D \uC900\uBE44", attempt, initialPublicIp, "", "");
                return binding;
            }
            catch (Exception ex)
            {
                lastError = ex.Message;
                bool waitingIpv4 = Regex.IsMatch(lastError ?? "", "IPv4|not connected|\uC5F0\uACB0", RegexOptions.IgnoreCase);
                string phase = waitingIpv4 ? "windows-ipv4-wait" : "windows-adapter-wait";
                string label = waitingIpv4
                    ? "Windows USB \uD14C\uB354\uB9C1 \uC5B4\uB311\uD130 \uC7AC\uC5F0\uACB0\u00B7IPv4 \uD560\uB2F9 \uB300\uAE30 \uC911"
                    : "Windows\uC5D0\uC11C \uC120\uD0DD USB \uD14C\uB354\uB9C1 \uC5B4\uB311\uD130 \uC7AC\uAC10\uC9C0 \uB300\uAE30 \uC911";
                UpdateMobileResetProgress(phase, label, attempt, initialPublicIp, "", lastError);
            }
            Thread.Sleep(1000);
        }
        throw new InvalidOperationException("Windows\uC5D0\uC11C \uC120\uD0DD USB \uD14C\uB354\uB9C1 \uC5B4\uB311\uD130\uC640 \uC0AC\uC6A9 \uAC00\uB2A5\uD55C IPv4\uAC00 \uC81C\uD55C \uC2DC\uAC04 \uC548\uC5D0 \uBCF5\uAD6C\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4. " + lastError);
    }

    private static Dictionary<string, object> RunAirplaneModeCommand(Dictionary<string, object> request, string action)
    {
        if (!File.Exists(MobileResetScriptPath)) return Error("reset-mobile-network.ps1 is missing. Reinstall the SmartPage Ex network helper.");
        string normalized = (action ?? "status").Trim().ToLowerInvariant();
        if (normalized != "status" && normalized != "on" && normalized != "off" && normalized != "toggle") return Error("Invalid airplane mode action.");
        if (normalized != "status" && IsMobileResetRunning())
        {
            Dictionary<string, object> busy = MobileResetStatus();
            busy["ok"] = false;
            busy["busy"] = true;
            busy["error"] = "IP \uBCC0\uACBD \uC791\uC5C5\uC774 \uC9C4\uD589 \uC911\uC774\uC5B4\uC11C \uC218\uB3D9 \uBE44\uD589\uAE30\uBAA8\uB4DC \uC804\uD658\uC744 \uAE30\uB2E4\uB9BD\uB2C8\uB2E4.";
            return busy;
        }
        if (normalized != "status")
        {
            Dictionary<string, object> adbPreflight = AdbConnectionStatusV168();
            if (!BooleanValue(adbPreflight, "adbReady")) adbPreflight = RecoverAdbConnectionV168();
            if (!BooleanValue(adbPreflight, "adbReady"))
            {
                string adbState = Text(adbPreflight, "adbDeviceState");
                adbPreflight["ok"] = false;
                adbPreflight["error"] = String.Equals(adbState, "unauthorized", StringComparison.OrdinalIgnoreCase)
                    ? "ADB device is unauthorized. Unlock the phone and approve USB debugging for this computer."
                    : "ADB recovery completed but no ready Android device was found. Check the USB cable and USB debugging.";
                return adbPreflight;
            }
        }
        try
        {
            Dictionary<string, object> config = ReadJsonFile(ConfigPath);
            string serial = Text(request, "deviceSerial").Trim();
            if (String.IsNullOrWhiteSpace(serial)) serial = Text(config, "adbSerial").Trim();
            string adbPath = Text(config, "adbPath").Trim();
            if (String.IsNullOrWhiteSpace(adbPath)) adbPath = Path.Combine(BaseDir, "platform-tools", "adb.exe");
            string adbVendorKeysPath = Text(config, "adbVendorKeysPath").Trim();
            if (String.IsNullOrWhiteSpace(adbVendorKeysPath)) adbVendorKeysPath = Path.Combine(BaseDir, "adb-keys");
            if (!File.Exists(adbPath)) return Error("ADB is not installed in the network helper. Run install-network-host.cmd as administrator.");
            string powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
            string arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + Quote(MobileResetScriptPath)
                + " -AdbPath " + Quote(adbPath)
                + " -AdbVendorKeysPath " + Quote(adbVendorKeysPath)
                + " -AirplaneOnly " + normalized;
            if (!String.IsNullOrWhiteSpace(serial)) arguments += " -DeviceSerial " + Quote(serial);
            ProcessStartInfo info = new ProcessStartInfo
            {
                FileName = powershell, Arguments = arguments, WorkingDirectory = BaseDir,
                UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden,
                RedirectStandardOutput = true, RedirectStandardError = true,
                StandardOutputEncoding = new UTF8Encoding(false), StandardErrorEncoding = new UTF8Encoding(false)
            };
            using (Process process = Process.Start(info))
            {
                if (process == null) return Error("Unable to start the airplane-mode control script.");
                if (!process.WaitForExit(45000))
                {
                    try { if (!process.HasExited) process.Kill(); } catch { }
                    return Error("Airplane-mode control timed out.");
                }
                string output = process.StandardOutput.ReadToEnd();
                string stderr = process.StandardError.ReadToEnd();
                string jsonLine = (output ?? "").Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries).LastOrDefault() ?? "";
                Dictionary<string, object> result = new Dictionary<string, object>();
                try { result = Json.Deserialize<Dictionary<string, object>>(jsonLine.Trim('\uFEFF', ' ', '\t')) ?? result; } catch { }
                bool ok = process.ExitCode == 0 && BooleanValue(result, "ok");
                result["ok"] = ok;
                result["command"] = normalized == "status" ? "airplane_mode_status" : "set_airplane_mode";
                result["helperVersion"] = HelperVersion;
                if (!ok && !result.ContainsKey("error")) result["error"] = String.IsNullOrWhiteSpace(stderr) ? "Airplane-mode control failed." : stderr.Trim();
                return result;
            }
        }
        catch (Exception ex) { return Error("Airplane-mode control failed: " + ex.Message); }
    }

    private static Dictionary<string, object> MobileResetStatus()
    {
        Dictionary<string, object> state = ReadJsonFile(MobileResetStatePath);
        bool running = IsMobileResetRunning();
        state["ok"] = true;
        state["command"] = "mobile_reset_status";
        state["running"] = running;
        state["inProgress"] = running;
        state["helperVersion"] = HelperVersion;
        string storedStatus = Text(state, "status");
        if (!running && String.Equals(storedStatus, "running", StringComparison.OrdinalIgnoreCase))
        {
            state["status"] = "idle";
            state["staleStateRecovered"] = true;
        }
        else if (!state.ContainsKey("status")) state["status"] = running ? "running" : "idle";
        return state;
    }

    private static Dictionary<string, object> ResetMobileNetwork(Dictionary<string, object> request)
    {
        if (!String.Equals(Text(request, "reasonKind"), "connectivity", StringComparison.OrdinalIgnoreCase))
            return Error("Mobile network reset is allowed only for transport connectivity recovery.");
        if (!File.Exists(MobileResetScriptPath))
            return Error("reset-mobile-network.ps1 is missing. Reinstall the SmartPage Ex network helper.");

        Dictionary<string, object> adbPreflight = AdbConnectionStatusV168();
        if (!BooleanValue(adbPreflight, "adbReady")) adbPreflight = RecoverAdbConnectionV168();
        if (!BooleanValue(adbPreflight, "adbReady"))
        {
            string adbState = Text(adbPreflight, "adbDeviceState");
            adbPreflight["ok"] = false;
            adbPreflight["error"] = String.Equals(adbState, "unauthorized", StringComparison.OrdinalIgnoreCase)
                ? "ADB device is unauthorized. Unlock the phone and approve USB debugging for this computer."
                : "ADB recovery completed but no ready Android device was found. Check the USB cable and USB debugging.";
            return adbPreflight;
        }

        bool createdNew = false;
        using (Mutex mutex = new Mutex(false, "Global\\SmartPageExMobileNetworkResetV1", out createdNew))
        {
            bool lockTaken = false;
            try
            {
                try { lockTaken = mutex.WaitOne(0); }
                catch (AbandonedMutexException) { lockTaken = true; }
                if (!lockTaken)
                {
                    Dictionary<string, object> busy = MobileResetStatus();
                    busy["ok"] = true;
                    busy["joinedExisting"] = true;
                    busy["inProgress"] = true;
                    busy["completed"] = false;
                    busy["message"] = "A mobile network reset is already running. Joined the existing reset without starting another one.";
                    return busy;
                }

                MobileResetCancelRequested = false;
                DateTime overallStarted = DateTime.UtcNow;
                WriteJsonFile(MobileResetStatePath, new Dictionary<string, object>
                {
                    { "status", "running" }, { "running", true }, { "inProgress", true }, { "completed", false }, { "resetOk", false },
                    { "phase", "starting" }, { "phaseLabel", "\uBAA8\uBC14\uC77C \uB124\uD2B8\uC6CC\uD06C \uBCF5\uAD6C \uC2DC\uC791" },
                    { "startedAt", overallStarted.ToString("o") }, { "updatedAt", overallStarted.ToString("o") }, { "heartbeatAt", overallStarted.ToString("o") },
                    { "initialPublicIp", "" }, { "helperVersion", HelperVersion }
                });
                int holdSeconds = Math.Max(4, Math.Min(300, IntValue(request, "airplaneHoldSeconds", 20)));
                int reconnectSeconds = Math.Max(15, Math.Min(180, IntValue(request, "reconnectTimeoutSeconds", 75)));
                int maxAttempts = Math.Max(1, Math.Min(3, IntValue(request, "maxIpChangeAttempts", 2)));
                Dictionary<string, object> config = ReadJsonFile(ConfigPath);
                string serial = Text(request, "deviceSerial").Trim();
                if (String.IsNullOrWhiteSpace(serial)) serial = Text(config, "adbSerial").Trim();
                string adbPath = Text(config, "adbPath").Trim();
                if (String.IsNullOrWhiteSpace(adbPath)) adbPath = Path.Combine(BaseDir, "platform-tools", "adb.exe");
                string adbVendorKeysPath = Text(config, "adbVendorKeysPath").Trim();
                if (String.IsNullOrWhiteSpace(adbVendorKeysPath)) adbVendorKeysPath = Path.Combine(BaseDir, "adb-keys");
                if (!File.Exists(adbPath))
                    return Error("ADB is not installed in the network helper. Run install-network-host.cmd as administrator to install Google Android SDK Platform-Tools.");
                string powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
                string arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + Quote(MobileResetScriptPath)
                    + " -AdbPath " + Quote(adbPath)
                    + " -AdbVendorKeysPath " + Quote(adbVendorKeysPath)
                    + " -AirplaneHoldSeconds " + holdSeconds
                    + " -ReconnectTimeoutSeconds " + reconnectSeconds;
                if (!String.IsNullOrWhiteSpace(serial)) arguments += " -DeviceSerial " + Quote(serial);

                Dictionary<string, object> proxyBefore = ReadProxyState();
                bool selectedAdapterEnabled = BooleanValue(proxyBefore, "enabled");
                string initialPublicIp = "";
                if (selectedAdapterEnabled)
                {
                    string cachedPublicIp = Text(proxyBefore, "publicIp");
                    DateTime cachedCheckedAt;
                    IPAddress cachedParsed;
                    if (!String.IsNullOrWhiteSpace(cachedPublicIp) && IPAddress.TryParse(cachedPublicIp, out cachedParsed) &&
                        DateTime.TryParse(Text(proxyBefore, "publicIpCheckedAt"), out cachedCheckedAt) && cachedCheckedAt.ToUniversalTime() > DateTime.UtcNow.AddMinutes(-15))
                        initialPublicIp = cachedPublicIp;
                    UpdateMobileResetProgress("baseline-public-ip", "IP \uBCC0\uACBD \uC804 \uC120\uD0DD\uB9DD \uACF5\uC778 IP \uD655\uC778 \uC911", 0, initialPublicIp, "", "");
                    try
                    {
                        Dictionary<string, object> baselineState = RefreshPublicIpState(true);
                        string observedBaseline = BooleanValue(baselineState, "publicIpLookupOk") ? Text(baselineState, "publicIpObserved") : "";
                        if (!String.IsNullOrWhiteSpace(observedBaseline)) initialPublicIp = observedBaseline;
                    }
                    catch (Exception ex) { AppendLog("Initial selected-adapter public IP check failed; recent known value will be kept when available: " + ex.Message); }
                }
                UpdateMobileResetProgress("reset-command", "\uD604\uC7AC \uD0A4\uC6CC\uB4DC\u00B7\uD398\uC774\uC9C0 \uBCF4\uC874 \uC644\uB8CC \u00B7 \uD734\uB300\uD3F0 \uB124\uD2B8\uC6CC\uD06C \uB9AC\uC14B \uC2E4\uD589 \uC900\uBE44", 0, initialPublicIp, "", "");

                Dictionary<string, object> lastResult = new Dictionary<string, object>();
                bool terminalWithoutRetry = false;
                for (int attempt = 1; attempt <= maxAttempts; attempt++)
                {
                    try { lastResult = RunMobileResetAttempt(powershell, arguments, holdSeconds, reconnectSeconds, serial, attempt); }
                    catch (Exception ex) { lastResult = Error(ex.Message); }
                    if (MobileResetCancelRequested || String.Equals(Text(lastResult, "errorCode"), "MOBILE_RESET_CANCELLED", StringComparison.OrdinalIgnoreCase))
                    {
                        Dictionary<string, object> cancelledState = new Dictionary<string, object>(lastResult);
                        cancelledState["ok"] = false; cancelledState["cancelled"] = true; cancelledState["completed"] = false;
                        cancelledState["status"] = "cancelled"; cancelledState["running"] = false; cancelledState["inProgress"] = false;
                        cancelledState["phase"] = "cancelled"; cancelledState["phaseLabel"] = "\uC0AC\uC6A9\uC790\uAC00 IP \uBCC0\uACBD\uC744 \uC911\uB2E8\uD568";
                        cancelledState["errorCode"] = "MOBILE_RESET_CANCELLED"; cancelledState["helperVersion"] = HelperVersion;
                        cancelledState["updatedAt"] = DateTime.UtcNow.ToString("o"); cancelledState["heartbeatAt"] = DateTime.UtcNow.ToString("o");
                        WriteJsonFile(MobileResetStatePath, cancelledState);
                        return cancelledState;
                    }
                    if (!BooleanValue(lastResult, "ok"))
                    {
                        AppendLog("ADB mobile network reset attempt " + attempt + " failed: " + Text(lastResult, "error"));
                        if (attempt < maxAttempts) Thread.Sleep(3000);
                        continue;
                    }

                    string publicIp = "";
                    string publicIpError = "";
                    string checkedAt = "";
                    if (selectedAdapterEnabled)
                    {
                        try
                        {
                            string adapterWaitError;
                            int adapterWaitSeconds = Math.Min(90, Math.Max(45, reconnectSeconds));
                            WaitForSelectedAdapterAfterMobileReset(adapterWaitSeconds, attempt, initialPublicIp, out adapterWaitError);
                        }
                        catch (OperationCanceledException)
                        {
                            Dictionary<string, object> cancelledState = ReadJsonFile(MobileResetStatePath);
                            cancelledState["ok"] = false; cancelledState["cancelled"] = true; cancelledState["completed"] = false;
                            cancelledState["status"] = "cancelled"; cancelledState["running"] = false; cancelledState["inProgress"] = false;
                            cancelledState["phase"] = "cancelled"; cancelledState["errorCode"] = "MOBILE_RESET_CANCELLED"; cancelledState["helperVersion"] = HelperVersion;
                            cancelledState["updatedAt"] = DateTime.UtcNow.ToString("o"); cancelledState["heartbeatAt"] = DateTime.UtcNow.ToString("o");
                            WriteJsonFile(MobileResetStatePath, cancelledState);
                            return cancelledState;
                        }
                        catch (Exception ex)
                        {
                            publicIpError = ex.Message;
                            lastResult["errorCode"] = "WINDOWS_ADAPTER_RESTORE_TIMEOUT";
                            lastResult["error"] = ex.Message;
                            UpdateMobileResetProgress("windows-adapter-failed", "Windows USB \uD14C\uB354\uB9C1 \uC5B4\uB311\uD130/IPv4 \uC790\uB3D9 \uBCF5\uAD6C \uC2E4\uD328", attempt, initialPublicIp, "WINDOWS_ADAPTER_RESTORE_TIMEOUT", ex.Message);
                            terminalWithoutRetry = true;
                        }

                        if (!terminalWithoutRetry)
                        {
                            DateTime ipDeadline = DateTime.UtcNow.AddSeconds(Math.Min(90, Math.Max(45, reconnectSeconds)));
                            do
                            {
                                if (MobileResetCancelRequested)
                                {
                                    Dictionary<string, object> cancelledState = ReadJsonFile(MobileResetStatePath);
                                    cancelledState["ok"] = false; cancelledState["cancelled"] = true; cancelledState["completed"] = false;
                                    cancelledState["status"] = "cancelled"; cancelledState["running"] = false; cancelledState["inProgress"] = false;
                                    cancelledState["phase"] = "cancelled"; cancelledState["errorCode"] = "MOBILE_RESET_CANCELLED"; cancelledState["helperVersion"] = HelperVersion;
                                    cancelledState["updatedAt"] = DateTime.UtcNow.ToString("o"); cancelledState["heartbeatAt"] = DateTime.UtcNow.ToString("o");
                                    WriteJsonFile(MobileResetStatePath, cancelledState);
                                    return cancelledState;
                                }
                                UpdateMobileResetProgress("public-ip-check", "\uC120\uD0DD\uB9DD \uC5F0\uACB0 \uBCF5\uAD6C \uD655\uC778 \u00B7 \uC0C8 \uACF5\uC778 IP \uC870\uD68C \uC911", attempt, initialPublicIp, "", publicIpError);
                                try
                                {
                                    Dictionary<string, object> publicState = RefreshPublicIpState(true);
                                    publicIp = BooleanValue(publicState, "publicIpLookupOk") ? Text(publicState, "publicIpObserved") : "";
                                    checkedAt = Text(publicState, "publicIpCheckedAt");
                                    publicIpError = Text(publicState, "publicIpError");
                                }
                                catch (Exception ex) { publicIpError = ex.Message; }
                                if (!String.IsNullOrWhiteSpace(publicIp))
                                {
                                    if (String.IsNullOrWhiteSpace(initialPublicIp) || !String.Equals(publicIp, initialPublicIp, StringComparison.OrdinalIgnoreCase)) break;
                                }
                                Thread.Sleep(2000);
                            } while (DateTime.UtcNow < ipDeadline);
                        }
                    }

                    bool ipChanged = !String.IsNullOrWhiteSpace(initialPublicIp) && !String.IsNullOrWhiteSpace(publicIp) &&
                        !String.Equals(publicIp, initialPublicIp, StringComparison.OrdinalIgnoreCase);
                    lastResult["initialPublicIp"] = initialPublicIp;
                    lastResult["publicIp"] = publicIp;
                    lastResult["publicIpCheckedAt"] = checkedAt;
                    lastResult["publicIpError"] = publicIpError;
                    lastResult["ipChanged"] = ipChanged;
                    lastResult["attempts"] = attempt;
                    lastResult["maxAttempts"] = maxAttempts;

                    if (terminalWithoutRetry) break;
                    if (ipChanged)
                    {
                        lastResult["ok"] = true;
                        lastResult["completed"] = true;
                        lastResult["message"] = "Airplane-mode cycle completed and the selected-adapter public IP changed.";
                        lastResult["finishedAt"] = DateTime.UtcNow.ToString("o");
                        lastResult["durationMs"] = Math.Max(0, (long)(DateTime.UtcNow - overallStarted).TotalMilliseconds);
                        AppendLog("ADB mobile network reset completed. Public IP changed from " + initialPublicIp + " to " + publicIp + ".");
                        Dictionary<string, object> completedState = new Dictionary<string, object>(lastResult);
                        completedState["status"] = "completed"; completedState["running"] = false; completedState["inProgress"] = false;
                        completedState["completed"] = true; completedState["resetOk"] = true; completedState["helperVersion"] = HelperVersion;
                        completedState["phase"] = "public-ip-confirmed"; completedState["phaseLabel"] = "\uC0C8 \uACF5\uC778 IP \uBCC0\uACBD \uD655\uC778 \uC644\uB8CC";
                        completedState["updatedAt"] = DateTime.UtcNow.ToString("o"); completedState["heartbeatAt"] = DateTime.UtcNow.ToString("o");
                        WriteJsonFile(MobileResetStatePath, completedState);
                        return lastResult;
                    }

                    lastResult["ok"] = false;
                    lastResult["completed"] = false;
                    if (String.IsNullOrWhiteSpace(initialPublicIp))
                    {
                        lastResult["errorCode"] = "PUBLIC_IP_BASELINE_UNKNOWN";
                        lastResult["error"] = "The selected-adapter public IP could not be confirmed before reset, so an IP change cannot be verified safely.";
                        terminalWithoutRetry = true;
                    }
                    else if (String.IsNullOrWhiteSpace(publicIp))
                    {
                        lastResult["errorCode"] = "PUBLIC_IP_LOOKUP_FAILED";
                        lastResult["error"] = "Windows USB tethering recovered, but the selected-adapter public IP lookup did not succeed within the verification window. " + publicIpError;
                        terminalWithoutRetry = true;
                    }
                    else
                    {
                        lastResult["errorCode"] = "PUBLIC_IP_UNCHANGED";
                        lastResult["error"] = "Airplane mode was toggled, but the selected-adapter public IP remained " + publicIp + ".";
                    }
                    UpdateMobileResetProgress(terminalWithoutRetry ? "public-ip-failed" : "public-ip-unchanged", terminalWithoutRetry ? "\uACF5\uC778 IP \uD655\uC778 \uC2E4\uD328" : "\uACF5\uC778 IP\uAC00 \uBCC0\uACBD\uB418\uC9C0 \uC54A\uC74C \u00B7 \uD544\uC694 \uC2DC 1\uD68C \uC7AC\uC2DC\uB3C4", attempt, initialPublicIp, Text(lastResult, "errorCode"), Text(lastResult, "error"));
                    AppendLog("Public IP verification after reset attempt " + attempt + ": code=" + Text(lastResult, "errorCode") + " ip=" + publicIp + " error=" + Text(lastResult, "error"));
                    if (terminalWithoutRetry) break;
                    if (attempt < maxAttempts) Thread.Sleep(3000);
                }

                lastResult["ok"] = false;
                lastResult["completed"] = false;
                lastResult["command"] = "reset_mobile_network";
                lastResult["initialPublicIp"] = initialPublicIp;
                lastResult["maxAttempts"] = maxAttempts;
                lastResult["finishedAt"] = DateTime.UtcNow.ToString("o");
                lastResult["durationMs"] = Math.Max(0, (long)(DateTime.UtcNow - overallStarted).TotalMilliseconds);
                if (!lastResult.ContainsKey("errorCode")) lastResult["errorCode"] = "MOBILE_RESET_FAILED";
                if (!lastResult.ContainsKey("error")) lastResult["error"] = "Mobile network reset did not produce a verified new public IP.";
                Dictionary<string, object> failedState = new Dictionary<string, object>(lastResult);
                failedState["status"] = "failed"; failedState["running"] = false; failedState["inProgress"] = false;
                failedState["completed"] = true; failedState["resetOk"] = false; failedState["lastError"] = Text(lastResult, "error"); failedState["helperVersion"] = HelperVersion;
                failedState["phase"] = "failed"; failedState["phaseLabel"] = "\uBAA8\uBC14\uC77C \uB124\uD2B8\uC6CC\uD06C \uC790\uB3D9 \uBCF5\uAD6C \uC2E4\uD328";
                failedState["updatedAt"] = DateTime.UtcNow.ToString("o"); failedState["heartbeatAt"] = DateTime.UtcNow.ToString("o");
                WriteJsonFile(MobileResetStatePath, failedState);
                return lastResult;
            }
            finally
            {
                if (lockTaken) { try { mutex.ReleaseMutex(); } catch { } }
            }
        }
    }

    private static Dictionary<string, object> CancelMobileReset(Dictionary<string, object> request)
    {
        MobileResetCancelRequested = true;
        bool killed = false;
        lock (MobileResetProcessLock)
        {
            try
            {
                if (ActiveMobileResetProcess != null && !ActiveMobileResetProcess.HasExited)
                {
                    ActiveMobileResetProcess.Kill();
                    killed = true;
                }
            }
            catch { }
        }
        string serial = "";
        try
        {
            Dictionary<string, object> config = ReadJsonFile(ConfigPath);
            serial = Text(config, "adbSerial").Trim();
        }
        catch { }
        TryEmergencyAirplaneModeOff(serial);
        Dictionary<string, object> state = ReadJsonFile(MobileResetStatePath);
        state["ok"] = true; state["cancelled"] = true; state["completed"] = false; state["resetOk"] = false;
        state["running"] = false; state["inProgress"] = false; state["status"] = "cancelled"; state["phase"] = "cancelled";
        state["phaseLabel"] = "\uC0AC\uC6A9\uC790\uAC00 IP \uBCC0\uACBD\uC744 \uC911\uB2E8\uD568 \u00B7 \uBE44\uD589\uAE30 \uBAA8\uB4DC OFF \uD655\uC778";
        state["lastError"] = ""; state["errorCode"] = "MOBILE_RESET_CANCELLED"; state["helperVersion"] = HelperVersion;
        state["cancelledAt"] = DateTime.UtcNow.ToString("o"); state["updatedAt"] = DateTime.UtcNow.ToString("o"); state["heartbeatAt"] = DateTime.UtcNow.ToString("o");
        state["processKilled"] = killed; state["reason"] = Text(request, "reason");
        WriteJsonFile(MobileResetStatePath, state);
        AppendLog("Mobile network reset cancellation requested. processKilled=" + killed);
        return state;
    }

    private static void TryEmergencyAirplaneModeOff(string serial)
    {
        try
        {
            string powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
            string arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + Quote(MobileResetScriptPath) + " -ForceDisableOnly";
            if (!String.IsNullOrWhiteSpace(serial)) arguments += " -DeviceSerial " + Quote(serial);
            ProcessStartInfo info = new ProcessStartInfo
            {
                FileName = powershell, Arguments = arguments, WorkingDirectory = BaseDir,
                UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden
            };
            using (Process process = Process.Start(info))
            {
                if (process != null) process.WaitForExit(30000);
            }
        }
        catch (Exception ex) { AppendLog("Emergency airplane-mode OFF failed: " + ex.Message); }
    }

    private static bool IsScheduledTaskRegistered(string taskName, out string detail)
    {
        detail = "";
        try
        {
            string schtasksPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "schtasks.exe");
            ProcessStartInfo info = new ProcessStartInfo
            {
                FileName = schtasksPath,
                Arguments = "/Query /TN " + Quote(taskName),
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            using (Process process = Process.Start(info))
            {
                if (process == null) { detail = "schtasks.exe did not start."; return false; }
                string stdOut = process.StandardOutput.ReadToEnd();
                string stdErr = process.StandardError.ReadToEnd();
                if (!process.WaitForExit(8000)) { detail = "Scheduled task query timed out."; return false; }
                detail = (stdOut + " " + stdErr).Trim();
                return process.ExitCode == 0;
            }
        }
        catch (Exception ex) { detail = ex.Message; return false; }
    }

    private static Dictionary<string, object> RunRouteGuardTask(string mode, AdapterBinding binding)
    {
        string requestId = Guid.NewGuid().ToString("N");
        string requestPath = Path.Combine(RouteCommandQueueDir, requestId + ".json");
        string resultPath = Path.Combine(RouteResultQueueDir, requestId + ".json");
        List<string> runnerAttempts = new List<string>();
        try
        {
            Directory.CreateDirectory(RouteCommandQueueDir);
            Directory.CreateDirectory(RouteResultQueueDir);
            Dictionary<string, object> payload = new Dictionary<string, object>
            {
                { "requestId", requestId }, { "mode", mode },
                { "adapterId", binding == null ? "" : binding.Id },
                { "adapterName", binding == null ? "" : binding.Name },
                { "adapterDescription", binding == null ? "" : (binding.Description ?? "") },
                { "interfaceIndex", binding == null ? 0 : binding.InterfaceIndex },
                { "requestedAt", DateTime.UtcNow.ToString("o") },
                { "helperVersion", HelperVersion }
            };
            WriteJsonFile(requestPath, payload);

            Dictionary<string, object> result = null;
            DateTime deadline = DateTime.UtcNow.AddSeconds(String.Equals(mode, "recover_window_ipv4", StringComparison.OrdinalIgnoreCase) ? 32 : 60);
            DateTime nextRunnerKick = DateTime.MinValue;
            while (DateTime.UtcNow < deadline)
            {
                if (DateTime.UtcNow >= nextRunnerKick)
                {
                    string taskOutput;
                    int taskExitCode = RunScheduledTask(TaskName, out taskOutput);
                    runnerAttempts.Add("exit=" + taskExitCode + " " + taskOutput);
                    nextRunnerKick = DateTime.UtcNow.AddSeconds(3);
                }
                Thread.Sleep(120);
                try
                {
                    if (!File.Exists(resultPath)) continue;
                    Dictionary<string, object> candidate = ReadJsonFile(resultPath);
                    if (!String.Equals(Text(candidate, "requestId"), requestId, StringComparison.Ordinal)) continue;
                    result = candidate;
                    break;
                }
                catch { }
            }
            lock (RouteStateLock) { RouteStateCache.Clear(); RouteStateCachedAtUtc = DateTime.MinValue; }
            if (result == null)
            {
                string taskDetail = runnerAttempts.Count == 0 ? "\uC791\uC5C5 \uC2E4\uD589 \uAE30\uB85D \uC5C6\uC74C" : runnerAttempts[runnerAttempts.Count - 1];
                return Error("\uAD00\uB9AC\uC790 \uB124\uD2B8\uC6CC\uD06C \uB2E8\uBC1C \uC791\uC5C5\uC5D0\uC11C \uACB0\uACFC\uB97C \uBC1B\uC9C0 \uBABB\uD588\uC2B5\uB2C8\uB2E4. \uC791\uC5C5 \uC2A4\uCF00\uC904\uB7EC\uC758 SmartPageEx Network Switch\uB97C \uD655\uC778\uD55C \uB4A4 install-network-host.cmd\uB97C \uAD00\uB9AC\uC790 \uAD8C\uD55C\uC73C\uB85C \uB2E4\uC2DC \uC2E4\uD589\uD558\uC138\uC694. \uC694\uCCAD " + requestId.Substring(0, 8) + ", " + taskDetail);
            }
            if (!BooleanValue(result, "ok")) return Error(Text(result, "error"));
            result["networkSwitchDaemonReady"] = true;
            result["networkSwitchRunnerReady"] = true;
            result["requestId"] = requestId;
            result["networkCommandTransport"] = "per_request_one_shot_task_queue_v3083";
            return result;
        }
        finally
        {
            try { if (File.Exists(requestPath)) File.Delete(requestPath); } catch { }
            try { if (File.Exists(resultPath)) File.Delete(resultPath); } catch { }
        }
    }

    private static Dictionary<string, object> PrepareWindowRouteGuard(AdapterBinding binding)
    {
        // v1.6.4: route-guard is verification only. Collector never changes Windows metrics.
        Dictionary<string, object> isolation = BuildIsolationStatus(binding, true);
        Dictionary<string, object> result = new Dictionary<string, object>(isolation);
        result["ok"] = BooleanValue(isolation, "strictIsolationOk");
        result["routeGuardApplied"] = false;
        result["routeMutationDisabled"] = true;
        if (!BooleanValue(result, "ok")) result["error"] = Text(isolation, "isolationMessage");
        return result;
    }

    private static Dictionary<string, object> RestoreWindowRouteGuard()
    {
        if (!File.Exists(RouteGuardStatePath)) return new Dictionary<string, object> { { "ok", true }, { "routeGuardRestored", false } };
        return RunRouteGuardTask("restore_window", null);
    }

    private static Dictionary<string, object> RestoreLegacyRouteMutationsV164()
    {
        bool hadLegacyState = File.Exists(RouteGuardStatePath) || File.Exists(SystemRoutePinStatePath);
        if (!hadLegacyState)
            return new Dictionary<string, object> { { "ok", true }, { "legacyRouteStateFound", false }, { "legacyRouteRestored", false }, { "routeMutationDisabled", true } };
        Dictionary<string, object> restored = RunRouteGuardTask("restore_system", null);
        if (!BooleanValue(restored, "ok")) return restored;
        restored["legacyRouteStateFound"] = true;
        restored["legacyRouteRestored"] = true;
        restored["routeMutationDisabled"] = true;
        AppendLog("v1.6.4 restored legacy Collector metric state. Future routing is selected-socket-bind only.");
        return restored;
    }

    private static Dictionary<string, object> ApplySystemAdapter(Dictionary<string, object> request)
    {
        Dictionary<string, object> restored = RestoreLegacyRouteMutationsV164();
        if (!BooleanValue(restored, "ok")) return restored;
        Dictionary<string, object> status = BuildStatus();
        status["ok"] = true;
        status["systemPinApplied"] = false;
        status["systemPinHealthy"] = false;
        status["routeMutationDisabled"] = true;
        status["message"] = "Windows default Internet is managed by Windows. Collector no longer pins Wi-Fi/Ethernet metrics.";
        return status;
    }

    private static Dictionary<string, object> ClearSystemAdapter()
    {
        Dictionary<string, object> restored = RestoreLegacyRouteMutationsV164();
        if (!BooleanValue(restored, "ok")) return restored;
        Dictionary<string, object> status = BuildStatus();
        status["ok"] = true;
        status["systemPinApplied"] = false;
        status["systemPinHealthy"] = false;
        status["routeMutationDisabled"] = true;
        status["message"] = "Windows default Internet remains OS-managed. Any legacy Collector metric state was restored.";
        return status;
    }

    private static Dictionary<string, object> ApplyWindowAdapter(Dictionary<string, object> request)
    {
        string adapterId = Text(request, "adapterId");
        string adapterName = Text(request, "adapterName");
        string adapterDescription = Text(request, "adapterDescription");
        bool dhcpRecoveryRequested;
        AdapterBinding binding = WaitForSelectedAdapterBinding(adapterId, adapterName, adapterDescription, out dhcpRecoveryRequested);

        Dictionary<string, object> legacy = RestoreLegacyRouteMutationsV164();
        if (!BooleanValue(legacy, "ok")) return legacy;

        Dictionary<string, object> isolation = BuildIsolationStatus(binding, true);
        if (!BooleanValue(isolation, "strictIsolationOk"))
        {
            Dictionary<string, object> blocked = Error("Selected-network isolation failed closed without changing Windows routing. " + Text(isolation, "isolationMessage"));
            foreach (KeyValuePair<string, object> row in isolation) blocked[row.Key] = row.Value;
            blocked["errorCode"] = "NETWORK_ISOLATION_UNSAFE";
            blocked["routeMutationDisabled"] = true;
            return blocked;
        }

        Dictionary<string, object> state = new Dictionary<string, object>
        {
            { "enabled", true },
            { "adapterId", binding.Id },
            { "adapterName", binding.Name },
            { "adapterDescription", binding.Description ?? "" },
            { "ipv4Address", binding.Address.ToString() },
            { "interfaceIndex", binding.InterfaceIndex },
            { "selectedNetworkIpv4RecoveryRequested", dhcpRecoveryRequested },
            { "routingMode", "selected_socket_bind_only" },
            { "updatedAt", DateTime.UtcNow.ToString("o") }
        };
        WriteJsonFile(ProxyStatePath, state);
        state = VerifySelectedAdapterConnectivity(binding, true);
        if (BooleanValue(state, "selectedNetworkReady"))
        {
            try { state = RefreshPublicIpState(true); }
            catch (Exception ex)
            {
                state["publicIp"] = "";
                state["publicIpLookupOk"] = false;
                state["publicIpCheckedAt"] = DateTime.UtcNow.ToString("o");
                state["publicIpError"] = ex.Message;
                WriteJsonFile(ProxyStatePath, state);
            }
        }
        Dictionary<string, object> result = BuildStatus();
        foreach (KeyValuePair<string, object> row in isolation) result[row.Key] = row.Value;
        result["ok"] = BooleanValue(result, "strictIsolationOk") && BooleanValue(result, "selectedNetworkReady");
        result["routeGuardApplied"] = false;
        result["routeMutationDisabled"] = true;
        result["legacyRouteRestored"] = BooleanValue(legacy, "legacyRouteRestored");
        result["message"] = BooleanValue(result, "selectedNetworkReady")
            ? "Selected-network adapter verified without changing Windows default routing: " + binding.Name
            : "Selected adapter has IPv4 but no verified Coupang Internet path: " + Text(result, "selectedNetworkError");
        if (!BooleanValue(result, "ok"))
        {
            result["error"] = Text(result, "message");
            result["errorCode"] = "SELECTED_NETWORK_OFFLINE";
            state["enabled"] = false;
            state["updatedAt"] = DateTime.UtcNow.ToString("o");
            WriteJsonFile(ProxyStatePath, state);
        }
        return result;
    }

    private static Dictionary<string, object> ClearWindowAdapter()
    {
        Dictionary<string, object> restored = RestoreLegacyRouteMutationsV164();
        if (!BooleanValue(restored, "ok")) return restored;
        Dictionary<string, object> previous = ReadProxyState();
        previous["enabled"] = false;
        previous["publicIp"] = "";
        previous["publicIpCheckedAt"] = "";
        previous["publicIpError"] = "";
        previous["selectedNetworkReady"] = false;
        previous["selectedNetworkDnsReady"] = false;
        previous["selectedNetworkDnsMode"] = "";
        previous["selectedNetworkCoupangTcpReady"] = false;
        previous["selectedNetworkCheckedAt"] = "";
        previous["selectedNetworkError"] = "";
        previous["selectedNetworkIpv4RecoveryRequested"] = false;
        previous["routingMode"] = "selected_socket_bind_only";
        previous["updatedAt"] = DateTime.UtcNow.ToString("o");
        WriteJsonFile(ProxyStatePath, previous);
        Dictionary<string, object> result = BuildStatus();
        result["ok"] = true;
        result["routeGuardRestored"] = false;
        result["legacyRouteRestored"] = BooleanValue(restored, "legacyRouteRestored");
        result["routeMutationDisabled"] = true;
        result["message"] = "Selected-network adapter cleared. Windows default routing remains OS-managed.";
        return result;
    }

    private static Dictionary<string, object> OpenCoupangWindow(Dictionary<string, object> request)
    {
        if (!EnsureBridgeProcess(12000))
            return Error("The selected-network local bridge is not healthy. Native Messaging recovery could not restore /health on 127.0.0.1:30765.");
        ProxyReady = IsBridgeProxyReady();
        string adapterId = Text(request, "adapterId");
        if (!String.IsNullOrWhiteSpace(adapterId))
        {
            Dictionary<string, object> applied = ApplyWindowAdapter(request);
            if (!BooleanValue(applied, "ok")) return applied;
        }

        Dictionary<string, object> proxyState = ReadProxyState();
        if (!BooleanValue(proxyState, "enabled"))
        {
            Dictionary<string, object> recovered = TryAutoRecoverSingleTetheringAdapter();
            proxyState = ReadProxyState();
            if (!BooleanValue(proxyState, "enabled"))
                return Error("Select and apply an adapter for the selected-network dedicated window first. " + Text(recovered, "error"));
        }
        if (!ProxyReady)
            return Error("The selected-network dedicated-window proxy is not running. Restart the helper and try again.");

        bool dhcpRecoveryRequested;
        AdapterBinding binding = WaitForSelectedAdapterBinding(Text(proxyState, "adapterId"), Text(proxyState, "adapterName"), Text(proxyState, "adapterDescription"), out dhcpRecoveryRequested);
        Dictionary<string, object> isolation = BuildIsolationStatus(binding, true);
        if (!BooleanValue(isolation, "strictIsolationOk"))
            return Error("Strict selected-network isolation failed closed without changing Windows routing. " + Text(isolation, "isolationMessage") +
                " Keep Wi-Fi/Ethernet connected. If Windows makes tethering the default route, fix that in Windows/driver settings rather than Collector.");
        Dictionary<string, object> connectivity = VerifySelectedAdapterConnectivity(binding, true);
        if (!BooleanValue(connectivity, "selectedNetworkReady"))
            return Error("The selected adapter has IPv4 but cannot reach Coupang through its own DNS/TCP path. " +
                Text(connectivity, "selectedNetworkError") +
                " Re-enable USB tethering or mobile data, then apply the adapter again.");
        Dictionary<string, object> config = ReadJsonFile(ConfigPath);
        string extensionRoot = Text(config, "extensionRoot");
        bool extensionRootValid = !String.IsNullOrWhiteSpace(extensionRoot) && File.Exists(Path.Combine(extensionRoot, "manifest.json"));
        string extensionId = Text(request, "extensionId");
        if (String.IsNullOrWhiteSpace(extensionId)) extensionId = Text(config, "extensionId");
        if (!Regex.IsMatch(extensionId ?? "", "^[a-p]{32}$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)) extensionId = "";
        if (!extensionRootValid)
            AppendLog("Configured extension folder is unavailable. The interactive launcher will try Chrome profile discovery and can still open the selected-network browser without loading the extension. ConfiguredPath=" + extensionRoot);

        string startUrl = Text(request, "startUrl");
        Uri requestedStartUrl;
        if (String.IsNullOrWhiteSpace(startUrl) ||
            !Uri.TryCreate(startUrl, UriKind.Absolute, out requestedStartUrl) ||
            !(String.Equals(requestedStartUrl.Scheme, "http", StringComparison.OrdinalIgnoreCase) ||
              String.Equals(requestedStartUrl.Scheme, "https", StringComparison.OrdinalIgnoreCase)))
        {
            startUrl = "https://www.coupang.com/";
        }

        string requestId = Guid.NewGuid().ToString("N");
        Dictionary<string, object> launchRequest = new Dictionary<string, object>
        {
            { "requestId", requestId },
            { "startUrl", startUrl },
            { "extensionRoot", extensionRoot },
            { "extensionRootValid", extensionRootValid },
            { "extensionId", extensionId },
            { "extensionVersion", Text(request, "extensionVersion") },
            { "launchMode", Text(request, "launchMode") },
            { "browserFamily", Text(request, "browserFamily") },
            { "forceRuntimeRestart", BooleanValue(request, "forceRuntimeRestart") },
            { "proxyPort", ProxyPort },
            { "selectedAdapterId", binding.Id },
            { "selectedAdapterName", binding.Name },
            { "singleTab", true },
            { "requestedAt", DateTime.UtcNow.ToString("o") }
        };
        try { if (File.Exists(DedicatedWindowResultPath)) File.Delete(DedicatedWindowResultPath); } catch { }
        WriteJsonFile(DedicatedWindowRequestPath, launchRequest);

        // v1.5.6: the interactive watcher normally stays alive in the logged-in user session.
        // Give that watcher a short chance to consume the request before asking Task Scheduler to start/restart it.
        Dictionary<string, object> launchResult = null;
        for (int i = 0; i < 10; i++)
        {
            Thread.Sleep(200);
            try
            {
                if (!File.Exists(DedicatedWindowResultPath)) continue;
                Dictionary<string, object> candidate = ReadJsonFile(DedicatedWindowResultPath);
                if (!String.Equals(Text(candidate, "requestId"), requestId, StringComparison.Ordinal)) continue;
                launchResult = candidate;
                break;
            }
            catch { }
        }

        string taskOutput = "watcher-already-running";
        int taskExitCode = 0;
        if (launchResult == null)
        {
            taskExitCode = RunScheduledTask(DedicatedWindowTaskName, out taskOutput);
            // Fresh Chrome-for-Testing + unpacked extension startup can exceed the old 12 second limit.
            // Wait up to 30 seconds for the user-session watcher to confirm the actual Chrome process.
            for (int i = 0; i < 150; i++)
            {
                Thread.Sleep(200);
                try
                {
                    if (!File.Exists(DedicatedWindowResultPath)) continue;
                    Dictionary<string, object> candidate = ReadJsonFile(DedicatedWindowResultPath);
                    if (!String.Equals(Text(candidate, "requestId"), requestId, StringComparison.Ordinal)) continue;
                    launchResult = candidate;
                    break;
                }
                catch { }
            }
        }

        if (launchResult == null)
        {
            AppendLog("Dedicated interactive launcher timeout. TaskExitCode=" + taskExitCode + "; TaskOutput=" + (taskOutput ?? ""));
            return Error("The interactive browser launcher did not confirm the window launch within 30 seconds. Task exit code: " + taskExitCode + ". Check dedicated-window-launch.log.");
        }
        if (!BooleanValue(launchResult, "ok"))
            return Error("Dedicated browser launch failed: " + Text(launchResult, "error"));

        Dictionary<string, object> result = BuildStatus();
        foreach (KeyValuePair<string, object> row in isolation) result[row.Key] = row.Value;
        result["ok"] = true;
        result["windowOpened"] = true;
        result["browserPid"] = launchResult.ContainsKey("pid") ? launchResult["pid"] : 0;
        result["extensionLoaded"] = launchResult.ContainsKey("extensionLoaded") ? launchResult["extensionLoaded"] : false;
        result["extensionRoot"] = launchResult.ContainsKey("extensionRoot") ? launchResult["extensionRoot"] : "";
        result["extensionVersion"] = launchResult.ContainsKey("extensionVersion") ? launchResult["extensionVersion"] : Text(request, "extensionVersion");
        result["runtimeRestarted"] = launchResult.ContainsKey("runtimeRestarted") ? launchResult["runtimeRestarted"] : false;
        foreach (string key in new string[] { "browserFamily", "browserExecutable", "profileDir", "registrationRequired", "expectedExtensionRoot" })
            if (launchResult.ContainsKey(key)) result[key] = launchResult[key];
        result["proxyPort"] = ProxyPort;
        result["selectedAdapterId"] = binding.Id;
        result["selectedAdapterName"] = binding.Name;
        result["message"] = "Selected-network dedicated window opened with fail-closed verification and no Windows route mutation. Only Coupang PAC traffic uses " + binding.Name + "; all other traffic stays on the Windows default route " + Text(isolation, "systemDefaultInterfaceAlias") + ".";
        return result;
    }

    private static int RunScheduledTask(string taskName, out string output)
    {
        output = "";
        try
        {
            string schtasksPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "schtasks.exe");
            ProcessStartInfo info = new ProcessStartInfo
            {
                FileName = schtasksPath,
                Arguments = "/Run /TN " + Quote(taskName),
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            try
            {
                Encoding oem = Encoding.GetEncoding(System.Globalization.CultureInfo.CurrentCulture.TextInfo.OEMCodePage);
                info.StandardOutputEncoding = oem;
                info.StandardErrorEncoding = oem;
            }
            catch { }
            using (Process process = Process.Start(info))
            {
                if (process == null)
                {
                    output = "schtasks.exe did not start.";
                    return 1;
                }
                string stdOut = process.StandardOutput.ReadToEnd();
                string stdErr = process.StandardError.ReadToEnd();
                if (!process.WaitForExit(10000))
                {
                    output = "Timed out while starting the scheduled task. No process was terminated.";
                    return 1;
                }
                output = (stdOut + " " + stdErr).Trim();
                return process.ExitCode;
            }
        }
        catch (Exception ex)
        {
            output = ex.Message;
            return 1;
        }
    }

    private static string Quote(string value)
    {
        return "\"" + (value ?? "").Replace("\"", "\\\"") + "\"";
    }

    private static string FindChromePath()
    {
        try
        {
            object currentUser = Registry.GetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe", "", null);
            if (currentUser != null && File.Exists(Convert.ToString(currentUser))) return Convert.ToString(currentUser);
        }
        catch { }
        try
        {
            object localMachine = Registry.GetValue(@"HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe", "", null);
            if (localMachine != null && File.Exists(Convert.ToString(localMachine))) return Convert.ToString(localMachine);
        }
        catch { }
        string[] candidates = new string[]
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Google", "Chrome", "Application", "chrome.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Google", "Chrome", "Application", "chrome.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Google", "Chrome", "Application", "chrome.exe")
        };
        return candidates.FirstOrDefault(File.Exists) ?? "";
    }

    private static Dictionary<string, object> RunPowerShellJson(string script, int timeoutMs)
    {
        string powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
        string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script ?? ""));
        ProcessStartInfo info = new ProcessStartInfo
        {
            FileName = powershell,
            Arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + encoded,
            WorkingDirectory = BaseDir,
            UseShellExecute = false,
            CreateNoWindow = true,
            WindowStyle = ProcessWindowStyle.Hidden,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = new UTF8Encoding(false),
            StandardErrorEncoding = new UTF8Encoding(false)
        };
        using (Process process = Process.Start(info))
        {
            if (process == null) throw new InvalidOperationException("PowerShell route inspection did not start.");
            if (!process.WaitForExit(Math.Max(3000, timeoutMs)))
                throw new TimeoutException("Windows default-route inspection timed out.");
            string output = process.StandardOutput.ReadToEnd().Trim().Trim('\uFEFF');
            string error = process.StandardError.ReadToEnd().Trim();
            if (process.ExitCode != 0 || String.IsNullOrWhiteSpace(output))
                throw new InvalidOperationException(String.IsNullOrWhiteSpace(error) ? "Windows default-route inspection returned no data." : error);
            return Json.Deserialize<Dictionary<string, object>>(output) ?? new Dictionary<string, object>();
        }
    }

    private static Dictionary<string, object> GetDefaultRouteSnapshot(bool force)
    {
        lock (RouteStateLock)
        {
            if (!force && RouteStateCache.Count > 0 && RouteStateCachedAtUtc > DateTime.UtcNow.AddSeconds(-5))
                return new Dictionary<string, object>(RouteStateCache);
            string script =
                "$routes = Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | " +
                "Where-Object { $_.State -eq 'Alive' -or $null -eq $_.State } | ForEach-Object { " +
                "$iface = Get-NetIPInterface -AddressFamily IPv4 -InterfaceIndex $_.InterfaceIndex -ErrorAction SilentlyContinue | Select-Object -First 1; " +
                "$im = if($null -ne $iface){[int]$iface.InterfaceMetric}else{0}; " +
                "[pscustomobject]@{interfaceIndex=[int]$_.InterfaceIndex;interfaceAlias=[string]$_.InterfaceAlias;routeMetric=[int]$_.RouteMetric;interfaceMetric=$im;totalMetric=([int]$_.RouteMetric+$im)} " +
                "} | Sort-Object totalMetric,routeMetric | Select-Object -First 1; " +
                "if($null -eq $routes){[pscustomobject]@{interfaceIndex=0;interfaceAlias='';routeMetric=0;interfaceMetric=0;totalMetric=0;found=$false}|ConvertTo-Json -Compress} " +
                "else{$routes|Add-Member -NotePropertyName found -NotePropertyValue $true -PassThru|ConvertTo-Json -Compress}";
            Dictionary<string, object> snapshot;
            try { snapshot = RunPowerShellJson(script, 8000); }
            catch (Exception ex)
            {
                snapshot = new Dictionary<string, object>
                {
                    { "found", false }, { "interfaceIndex", 0 }, { "interfaceAlias", "" },
                    { "inspectionError", ex.Message }
                };
            }
            snapshot["checkedAt"] = DateTime.UtcNow.ToString("o");
            RouteStateCache = new Dictionary<string, object>(snapshot);
            RouteStateCachedAtUtc = DateTime.UtcNow;
            return new Dictionary<string, object>(snapshot);
        }
    }

    private static int CountAlternateInternetAdapters(AdapterBinding selected)
    {
        int count = 0;
        foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
        {
            if (selected != null && NormalizeGuid(ni.Id) == NormalizeGuid(selected.Id)) continue;
            if (!AdapterStatusCanBeTested(ni.OperationalStatus)) continue;
            if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback || ni.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
            try
            {
                IPInterfaceProperties props = ni.GetIPProperties();
                bool hasIpv4 = props.UnicastAddresses.Any(a => a.Address.AddressFamily == AddressFamily.InterNetwork &&
                    !IPAddress.IsLoopback(a.Address) && !a.Address.ToString().StartsWith("169.254.", StringComparison.Ordinal));
                bool hasGateway = props.GatewayAddresses.Any(g => g != null && g.Address != null &&
                    g.Address.AddressFamily == AddressFamily.InterNetwork && !g.Address.Equals(IPAddress.Any));
                if (hasIpv4 && hasGateway) count++;
            }
            catch { }
        }
        return count;
    }

    private static Dictionary<string, object> BuildIsolationStatus(AdapterBinding binding, bool forceRouteRefresh)
    {
        Dictionary<string, object> route = GetDefaultRouteSnapshot(forceRouteRefresh);
        int defaultIndex = IntValue(route, "interfaceIndex", 0);
        bool routeFound = BooleanValue(route, "found") && defaultIndex > 0;
        bool selectedIsDefault = routeFound && binding != null && defaultIndex == binding.InterfaceIndex;
        int alternates = binding == null ? 0 : CountAlternateInternetAdapters(binding);
        /* The real safety condition is that the selected tethering adapter is not the active
           Windows IPv4 default route. Some Ethernet drivers expose an empty GatewayAddresses
           collection even while that adapter owns the default route, so gateway counting is
           informational only and must not create a false failure. */
        bool alternateReady = (routeFound && !selectedIsDefault) || alternates > 0;
        bool strictIsolationOk = binding != null && routeFound && !selectedIsDefault;
        return new Dictionary<string, object>
        {
            { "strictIsolationOk", strictIsolationOk },
            { "selectedAdapterIsSystemDefault", selectedIsDefault },
            { "alternateDefaultInternetAvailable", alternateReady },
            { "alternateInternetAdapterCount", alternates },
            { "systemDefaultInterfaceIndex", defaultIndex },
            { "systemDefaultInterfaceAlias", Text(route, "interfaceAlias") },
            { "routeInspectionError", Text(route, "inspectionError") },
            { "isolationMessage", strictIsolationOk
                ? "Strict split-route check passed. Windows default traffic stays on " + Text(route, "interfaceAlias") + "; only Coupang PAC traffic uses the selected adapter."
                : (!routeFound
                    ? "The Windows IPv4 default route could not be inspected yet."
                    : (selectedIsDefault
                        ? "Selected adapter is currently the Windows default Internet route. Other Chrome windows and Windows apps can consume the tethering connection."
                        : "The Windows default-route safety check could not be confirmed.")) }
        };
    }

    private static bool AdapterStatusCanBeTested(OperationalStatus status)
    {
        return status != OperationalStatus.Down &&
               status != OperationalStatus.NotPresent &&
               status != OperationalStatus.LowerLayerDown;
    }

    private static bool LooksLikeTetheringAdapter(NetworkInterface ni)
    {
        string text = ((ni == null ? "" : ni.Name) + " " + (ni == null ? "" : ni.Description)).ToLowerInvariant();
        return text.Contains("usb") || text.Contains("rndis") || text.Contains("ndis") || text.Contains("tether") ||
               text.Contains("mobile") || text.Contains("android") || text.Contains("samsung") ||
               text.Contains("galaxy") || text.Contains("iphone") || text.Contains("apple") ||
               text.Contains("\uD14C\uB354");
    }

    private static bool LooksLikeVirtualAdapterV162(NetworkInterface ni)
    {
        if (ni == null) return true;
        string text = ((ni.Name ?? "") + " " + (ni.Description ?? "") + " " + ni.NetworkInterfaceType.ToString()).ToLowerInvariant();
        return text.Contains("virtual") || text.Contains("hyper-v") || text.Contains("vmware") ||
               text.Contains("virtualbox") || text.Contains("wsl") || text.Contains("vpn") ||
               text.Contains("bluetooth") || text.Contains("loopback") || text.Contains("tap") || text.Contains("tunnel");
    }

    private static AdapterBinding ResolveSystemAdapterIdentityV162(string adapterId, string adapterName, string adapterDescription)
    {
        string wanted = NormalizeGuid(adapterId);
        NetworkInterface[] all = NetworkInterface.GetAllNetworkInterfaces();
        NetworkInterface ni = all.FirstOrDefault(candidate =>
            (!String.IsNullOrWhiteSpace(wanted) && NormalizeGuid(candidate.Id) == wanted) ||
            (!String.IsNullOrWhiteSpace(adapterName) && String.Equals(candidate.Name, adapterName, StringComparison.CurrentCultureIgnoreCase)));
        if (ni == null && !String.IsNullOrWhiteSpace(adapterDescription))
        {
            List<NetworkInterface> descriptionMatches = all.Where(candidate =>
                String.Equals((candidate.Description ?? "").Trim(), adapterDescription.Trim(), StringComparison.CurrentCultureIgnoreCase)).ToList();
            if (descriptionMatches.Count == 1) ni = descriptionMatches[0];
        }
        if (ni == null) throw new InvalidOperationException("Requested Windows base Internet adapter was not found.");
        if (LooksLikeTetheringAdapter(ni)) throw new InvalidOperationException("Phone/USB tethering cannot be selected as Windows base Internet.");
        if (LooksLikeVirtualAdapterV162(ni)) throw new InvalidOperationException("Virtual/VPN adapters cannot be selected as Windows base Internet.");
        int interfaceIndex = GetAdapterInterfaceIndex(ni);
        if (interfaceIndex <= 0) throw new InvalidOperationException("Requested Windows base Internet adapter has no IPv4 interface identity.");
        return new AdapterBinding
        {
            Id = ni.Id,
            Name = ni.Name,
            Description = ni.Description,
            Address = null,
            InterfaceIndex = interfaceIndex,
            DnsServers = new IPAddress[0]
        };
    }

    private static NetworkInterface FindAdapterIdentity(string adapterId, string adapterName, string adapterDescription)
    {
        string wanted = NormalizeGuid(adapterId);
        NetworkInterface[] all = NetworkInterface.GetAllNetworkInterfaces();
        NetworkInterface exact = all.FirstOrDefault(ni =>
            (!String.IsNullOrWhiteSpace(wanted) && NormalizeGuid(ni.Id) == wanted) ||
            (!String.IsNullOrWhiteSpace(adapterName) && String.Equals(ni.Name, adapterName, StringComparison.CurrentCultureIgnoreCase)));
        if (exact != null) return exact;

        string description = (adapterDescription ?? "").Trim();
        if (String.IsNullOrWhiteSpace(description)) return null;
        List<NetworkInterface> restored = all.Where(ni =>
            String.Equals((ni.Description ?? "").Trim(), description, StringComparison.CurrentCultureIgnoreCase) &&
            LooksLikeTetheringAdapter(ni)).ToList();
        return restored.Count == 1 ? restored[0] : null;
    }

    private static int GetAdapterInterfaceIndex(NetworkInterface ni)
    {
        try
        {
            IPv4InterfaceProperties ipv4 = ni == null ? null : ni.GetIPProperties().GetIPv4Properties();
            return ipv4 == null ? 0 : ipv4.Index;
        }
        catch { return 0; }
    }

    private static AdapterBinding WaitForSelectedAdapterBinding(string adapterId, string adapterName, string adapterDescription, out bool dhcpRecoveryRequested)
    {
        dhcpRecoveryRequested = false;
        string lastError = "";
        NetworkInterface identity = FindAdapterIdentity(adapterId, adapterName, adapterDescription);
        string requestedIdentity = ((adapterName ?? "") + " " + (adapterDescription ?? "")).ToLowerInvariant();
        bool requestedTethering = Regex.IsMatch(requestedIdentity, "usb|rndis|ndis|tether|mobile|android|samsung|galaxy|iphone|apple|\uD14C\uB354", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        bool tethering = identity != null ? LooksLikeTetheringAdapter(identity) : requestedTethering;
        DateTime deadline = DateTime.UtcNow.AddSeconds(tethering ? 24 : 6);
        bool recoveryAttempted = false;

        while (DateTime.UtcNow < deadline)
        {
            try { return ResolveAdapter(adapterId, adapterName, adapterDescription); }
            catch (Exception ex) { lastError = ex.Message; }

            identity = FindAdapterIdentity(adapterId, adapterName, adapterDescription);
            tethering = identity != null && LooksLikeTetheringAdapter(identity);
            int interfaceIndex = GetAdapterInterfaceIndex(identity);
            if (!recoveryAttempted && tethering && interfaceIndex > 0)
            {
                recoveryAttempted = true;
                dhcpRecoveryRequested = true;
                AdapterBinding pending = new AdapterBinding
                {
                    Id = identity.Id,
                    Name = identity.Name,
                    Description = identity.Description,
                    InterfaceIndex = interfaceIndex,
                    Address = null,
                    DnsServers = new IPAddress[0]
                };
                Dictionary<string, object> recovery = RunRouteGuardTask("recover_window_ipv4", pending);
                if (!BooleanValue(recovery, "ok"))
                    lastError = Text(recovery, "error");
                else
                    AppendLog("Selected tether IPv4 recovery: " + identity.Name +
                        ", ready=" + BooleanValue(recovery, "ipv4Ready") +
                        ", renew=" + BooleanValue(recovery, "dhcpRenewAttempted") +
                        ", address=" + Text(recovery, "ipv4Address"));
                continue;
            }
            Thread.Sleep(400);
        }

        throw new InvalidOperationException((dhcpRecoveryRequested
            ? "Selected USB tethering adapter still has no usable IPv4 after bounded DHCP renewal/restart recovery and a 24-second readiness check: "
            : "Selected adapter has no usable IPv4 address: ") + adapterName +
            (String.IsNullOrWhiteSpace(lastError) ? "" : ". " + lastError));
    }

    private static AdapterBinding BuildAdapterBinding(NetworkInterface ni)
    {
        if (ni == null) throw new InvalidOperationException("Selected Windows network adapter was not found.");
        if (!AdapterStatusCanBeTested(ni.OperationalStatus)) throw new InvalidOperationException("Selected adapter is not connected: " + ni.Name);
        IPInterfaceProperties properties = ni.GetIPProperties();
        IPv4InterfaceProperties ipv4 = properties.GetIPv4Properties();
        if (ipv4 == null) throw new InvalidOperationException("Selected adapter has no IPv4 interface: " + ni.Name);
        IPAddress address = properties.UnicastAddresses
            .Where(a => a.Address.AddressFamily == AddressFamily.InterNetwork)
            .Select(a => a.Address)
            .FirstOrDefault(a => !IPAddress.IsLoopback(a) && !a.ToString().StartsWith("169.254.", StringComparison.Ordinal));
        if (address == null) throw new InvalidOperationException("Selected adapter has no usable IPv4 address. Windows is still restoring USB tethering: " + ni.Name);
        IPAddress[] dnsServers = properties.DnsAddresses
            .Where(a => a != null && a.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(a) && !a.Equals(IPAddress.Any))
            .Distinct()
            .ToArray();
        return new AdapterBinding { Id = ni.Id, Name = ni.Name, Description = ni.Description, Address = address, InterfaceIndex = ipv4.Index, DnsServers = dnsServers };
    }

    private static AdapterBinding ResolveAdapter(string adapterId, string adapterName)
    {
        return ResolveAdapter(adapterId, adapterName, "");
    }

    private static AdapterBinding ResolveAdapter(string adapterId, string adapterName, string adapterDescription)
    {
        string wanted = NormalizeGuid(adapterId);
        NetworkInterface[] all = NetworkInterface.GetAllNetworkInterfaces();
        Exception exactError = null;
        bool exactFound = false;
        foreach (NetworkInterface ni in all)
        {
            bool exact = (!String.IsNullOrWhiteSpace(wanted) && NormalizeGuid(ni.Id) == wanted) ||
                (!String.IsNullOrWhiteSpace(adapterName) && String.Equals(ni.Name, adapterName, StringComparison.CurrentCultureIgnoreCase));
            if (!exact) continue;
            exactFound = true;
            try { return BuildAdapterBinding(ni); }
            catch (Exception ex) { exactError = ex; }
        }

        /* USB/RNDIS adapters can be re-enumerated by Windows after airplane-mode OFF. In that case
           the GUID or Ethernet N alias can change even though the physical phone adapter is the same.
           Fall back only to one usable tethering adapter whose device description exactly matches the
           adapter that the user previously selected; never guess between ordinary Ethernet adapters. */
        string description = String.IsNullOrWhiteSpace(adapterDescription) ? "" : adapterDescription.Trim();
        bool priorLooksTethering = !String.IsNullOrWhiteSpace(description) &&
            (description + " " + adapterName).ToLowerInvariant().IndexOf("usb", StringComparison.Ordinal) >= 0;
        if (!priorLooksTethering && !String.IsNullOrWhiteSpace(description))
        {
            string probe = (description + " " + adapterName).ToLowerInvariant();
            priorLooksTethering = probe.Contains("rndis") || probe.Contains("ndis") || probe.Contains("tether") || probe.Contains("mobile") || probe.Contains("android") || probe.Contains("samsung") || probe.Contains("galaxy") || probe.Contains("iphone") || probe.Contains("apple");
        }
        if (priorLooksTethering)
        {
            List<AdapterBinding> matches = new List<AdapterBinding>();
            foreach (NetworkInterface ni in all)
            {
                if (!String.Equals((ni.Description ?? "").Trim(), description, StringComparison.CurrentCultureIgnoreCase)) continue;
                if (!LooksLikeTetheringAdapter(ni)) continue;
                try { matches.Add(BuildAdapterBinding(ni)); } catch { }
            }
            if (matches.Count == 1) return matches[0];
            if (matches.Count > 1) throw new InvalidOperationException("More than one restored USB tethering adapter matches the saved device description. Refresh the adapter list and select one adapter again.");
        }
        if (exactFound && exactError != null) throw exactError;
        throw new InvalidOperationException("Selected Windows network adapter was not found. Windows may still be restoring USB tethering after airplane mode OFF.");
    }

    private static string NormalizeGuid(string value)
    {
        return (value ?? "").Replace("{", "").Replace("}", "").Trim().ToLowerInvariant();
    }

    private static Dictionary<string, object> ApplyMode(Dictionary<string, object> request)
    {
        if (String.Equals(Text(request, "mode"), "adapter", StringComparison.OrdinalIgnoreCase))
            return Error("Windows-wide adapter routing is disabled. Use the selected-network dedicated Chrome window.");
        Dictionary<string, object> restored = RestoreLegacyRouteMutationsV164();
        if (!BooleanValue(restored, "ok")) return restored;
        Dictionary<string, object> runtime = ReadRuntime();
        runtime["mode"] = "system";
        runtime["selectedAdapterId"] = "";
        runtime["selectedAdapterName"] = "";
        runtime["updatedAt"] = DateTime.UtcNow.ToString("o");
        WriteJsonFile(RuntimePath, runtime);
        Dictionary<string, object> status = BuildStatus();
        status["ok"] = true;
        status["mode"] = BooleanValue(ReadProxyState(), "enabled") ? "window" : "system";
        status["routeGuardRestored"] = BooleanValue(restored, "routeGuardRestored");
        status["message"] = "Windows default Internet is OS-managed. Collector does not change interface metrics.";
        return status;
    }

    private static string ResolveAdbPathV168(Dictionary<string, object> config)
    {
        List<string> candidates = new List<string>();
        string configured = Text(config, "adbPath").Trim();
        if (!String.IsNullOrWhiteSpace(configured)) candidates.Add(configured);
        try
        {
            string env = Environment.GetEnvironmentVariable("SPX_ADB_PATH");
            if (!String.IsNullOrWhiteSpace(env)) candidates.Add(env.Trim());
        }
        catch { }
        candidates.Add(Path.Combine(BaseDir, "platform-tools", "adb.exe"));
        try
        {
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (!String.IsNullOrWhiteSpace(local)) candidates.Add(Path.Combine(local, "Android", "Sdk", "platform-tools", "adb.exe"));
        }
        catch { }
        try
        {
            string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            if (!String.IsNullOrWhiteSpace(pf)) candidates.Add(Path.Combine(pf, "Android", "android-sdk", "platform-tools", "adb.exe"));
        }
        catch { }
        try
        {
            string pfx86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
            if (!String.IsNullOrWhiteSpace(pfx86)) candidates.Add(Path.Combine(pfx86, "Android", "android-sdk", "platform-tools", "adb.exe"));
        }
        catch { }
        try
        {
            string path = Environment.GetEnvironmentVariable("PATH") ?? "";
            foreach (string part in path.Split(new char[] { Path.PathSeparator }, StringSplitOptions.RemoveEmptyEntries))
                candidates.Add(Path.Combine(part.Trim().Trim('"'), "adb.exe"));
        }
        catch { }
        foreach (string candidate in candidates)
        {
            try
            {
                if (String.IsNullOrWhiteSpace(candidate)) continue;
                string full = Path.GetFullPath(Environment.ExpandEnvironmentVariables(candidate));
                if (!File.Exists(full)) continue;
                config["adbPath"] = full;
                return full;
            }
            catch { }
        }
        return "";
    }

    private static string RunAdbAtPathV168(Dictionary<string, object> config, string adbPath, string arguments, int timeoutMs)
    {
        Dictionary<string, object> local = new Dictionary<string, object>(config);
        local["adbPath"] = adbPath;
        return RunAdbCaptureV1514(local, arguments, timeoutMs);
    }

    private static bool WaitForAdbPortV168(int timeoutMs)
    {
        DateTime deadline = DateTime.UtcNow.AddMilliseconds(Math.Max(500, timeoutMs));
        while (DateTime.UtcNow < deadline)
        {
            if (IsLoopbackPortOpen(5037, 250)) return true;
            Thread.Sleep(200);
        }
        return IsLoopbackPortOpen(5037, 250);
    }

    private static string KillMatchingAdbProcessesV168(string adbPath)
    {
        int killed = 0;
        string expected = "";
        try { expected = Path.GetFullPath(adbPath); } catch { expected = adbPath ?? ""; }
        try
        {
            foreach (Process process in Process.GetProcessesByName("adb"))
            {
                try
                {
                    string actual = "";
                    try { actual = process.MainModule != null ? process.MainModule.FileName : ""; } catch { }
                    if (!String.IsNullOrWhiteSpace(actual) && !String.IsNullOrWhiteSpace(expected) &&
                        !String.Equals(Path.GetFullPath(actual), expected, StringComparison.OrdinalIgnoreCase)) continue;
                    process.Kill();
                    killed++;
                }
                catch { }
                finally { try { process.Dispose(); } catch { } }
            }
        }
        catch { }
        return killed > 0 ? "killed-matching-adb-processes:" + killed : "no-matching-adb-process-killed";
    }

    private static bool StartAdbNodaemonV168(Dictionary<string, object> config, string adbPath)
    {
        try
        {
            ProcessStartInfo info = new ProcessStartInfo
            {
                FileName = adbPath,
                Arguments = "nodaemon server",
                WorkingDirectory = Path.GetDirectoryName(adbPath) ?? BaseDir,
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            string vendorKeys = Text(config, "adbVendorKeysPath").Trim();
            if (!String.IsNullOrWhiteSpace(vendorKeys)) info.EnvironmentVariables["ADB_VENDOR_KEYS"] = vendorKeys;
            Process process = Process.Start(info);
            if (process == null) return false;
            return WaitForAdbPortV168(8000);
        }
        catch { return false; }
    }

    private static Dictionary<string, object> BuildAdbConnectionStatusV168(Dictionary<string, object> config, string adbPath, string recoveryAction)
    {
        Dictionary<string, object> result = new Dictionary<string, object>();
        result["ok"] = true;
        result["adbPath"] = adbPath ?? "";
        result["adbExecutableReady"] = !String.IsNullOrWhiteSpace(adbPath) && File.Exists(adbPath);
        result["adbServerReady"] = IsLoopbackPortOpen(5037, 350);
        result["adbServerMode"] = Text(config, "adbServerMode");
        result["recoveryAction"] = recoveryAction ?? "status-only";
        result["checkedAt"] = DateTime.UtcNow.ToString("o");
        if (!BooleanValue(result, "adbExecutableReady"))
        {
            result["adbReady"] = false;
            result["adbDeviceState"] = "adb-missing";
            result["message"] = "ADB executable was not found. Run the Collector installer once to restore Android Platform-Tools.";
            result["requiresUserAction"] = true;
            return result;
        }
        if (!BooleanValue(result, "adbServerReady"))
        {
            result["adbReady"] = false;
            result["adbDeviceState"] = "server-down";
            result["message"] = "ADB server is not listening on 127.0.0.1:5037.";
            result["requiresUserAction"] = false;
            return result;
        }
        string devices = RunAdbAtPathV168(config, adbPath, "devices -l", 3000);
        string state = "not-connected";
        string serial = "";
        string model = "";
        if (!String.IsNullOrWhiteSpace(devices))
        {
            string[] lines = devices.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            string configuredSerial = Text(config, "adbSerial").Trim();
            string selected = "";
            if (!String.IsNullOrWhiteSpace(configuredSerial))
                selected = lines.FirstOrDefault(line => Regex.IsMatch(line ?? "", "^" + Regex.Escape(configuredSerial) + @"\s+(?:device|unauthorized|offline)(?:\s|$)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)) ?? "";
            if (String.IsNullOrWhiteSpace(selected))
                selected = lines.FirstOrDefault(line => Regex.IsMatch(line ?? "", @"^\S+\s+(?:device|unauthorized|offline)(?:\s|$)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)) ?? "";
            if (!String.IsNullOrWhiteSpace(selected))
            {
                Match m = Regex.Match(selected, @"^(\S+)\s+(device|unauthorized|offline)(?:\s|$)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
                if (m.Success)
                {
                    serial = m.Groups[1].Value.Trim();
                    state = m.Groups[2].Value.Trim().ToLowerInvariant();
                    Match modelMatch = Regex.Match(selected, @"(?:^|\s)model:([^\s]+)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
                    if (modelMatch.Success) model = modelMatch.Groups[1].Value.Replace("_", " ").Trim();
                }
            }
        }
        if (state == "device")
        {
            Dictionary<string, object> liveConfig = new Dictionary<string, object>(config);
            liveConfig["adbPath"] = adbPath;
            Dictionary<string, string> identity = GetLiveAdbIdentityV1514(liveConfig, true);
            if (identity.ContainsKey("serial") && !String.IsNullOrWhiteSpace(identity["serial"])) serial = identity["serial"];
            if (identity.ContainsKey("name") && !String.IsNullOrWhiteSpace(identity["name"])) model = identity["name"];
        }
        result["adbDeviceState"] = state;
        result["adbDeviceSerial"] = serial;
        result["adbDeviceModel"] = model;
        result["adbReady"] = state == "device";
        result["requiresUserAction"] = state == "unauthorized" || state == "not-connected";
        if (state == "device") result["message"] = "ADB device connected.";
        else if (state == "unauthorized") result["message"] = "ADB device is unauthorized. Unlock the phone and approve USB debugging for this computer.";
        else if (state == "offline") result["message"] = "ADB device is offline.";
        else result["message"] = "ADB server is ready but no Android device is connected.";
        return result;
    }

    private static Dictionary<string, object> PersistAdbConnectionStatusV168(Dictionary<string, object> config, string adbPath, Dictionary<string, object> status)
    {
        config["adbPath"] = adbPath ?? "";
        config["adbServerReady"] = BooleanValue(status, "adbServerReady");
        config["adbMobileRecoveryReady"] = BooleanValue(status, "adbReady");
        config["adbDeviceState"] = Text(status, "adbDeviceState");
        config["adbSerial"] = Text(status, "adbDeviceSerial");
        config["adbDeviceModel"] = Text(status, "adbDeviceModel");
        string action = Text(status, "recoveryAction");
        if (!String.IsNullOrWhiteSpace(action)) config["adbServerMode"] = action;
        config["updatedAt"] = DateTime.UtcNow.ToString("o");
        try { WriteJsonFile(ConfigPath, config); } catch { }
        InvalidateStatusSnapshot();
        return status;
    }

    private static Dictionary<string, object> AdbConnectionStatusV168()
    {
        Dictionary<string, object> config = ReadJsonFile(ConfigPath);
        string adbPath = ResolveAdbPathV168(config);
        Dictionary<string, object> status = BuildAdbConnectionStatusV168(config, adbPath, "status-only");
        return PersistAdbConnectionStatusV168(config, adbPath, status);
    }

    private static Dictionary<string, object> RecoverAdbConnectionV168()
    {
        lock (ModeLock)
        {
            Dictionary<string, object> config = ReadJsonFile(ConfigPath);
            string adbPath = ResolveAdbPathV168(config);
            if (String.IsNullOrWhiteSpace(adbPath) || !File.Exists(adbPath))
                return PersistAdbConnectionStatusV168(config, adbPath, BuildAdbConnectionStatusV168(config, adbPath, "adb-missing"));

            Dictionary<string, object> before = BuildAdbConnectionStatusV168(config, adbPath, "initial-check");
            if (BooleanValue(before, "adbReady")) return PersistAdbConnectionStatusV168(config, adbPath, before);
            if (String.Equals(Text(before, "adbDeviceState"), "unauthorized", StringComparison.OrdinalIgnoreCase))
            {
                before["recoveryAction"] = "unauthorized-user-approval-required";
                return PersistAdbConnectionStatusV168(config, adbPath, before);
            }

            RunAdbAtPathV168(config, adbPath, "start-server", 6000);
            WaitForAdbPortV168(5000);
            Dictionary<string, object> afterStart = BuildAdbConnectionStatusV168(config, adbPath, "start-server");
            if (BooleanValue(afterStart, "adbReady")) return PersistAdbConnectionStatusV168(config, adbPath, afterStart);
            if (String.Equals(Text(afterStart, "adbDeviceState"), "unauthorized", StringComparison.OrdinalIgnoreCase)) return PersistAdbConnectionStatusV168(config, adbPath, afterStart);

            RunAdbAtPathV168(config, adbPath, "kill-server", 5000);
            Thread.Sleep(350);
            string forcedKill = "";
            if (IsLoopbackPortOpen(5037, 250)) forcedKill = KillMatchingAdbProcessesV168(adbPath);
            RunAdbAtPathV168(config, adbPath, "start-server", 6000);
            WaitForAdbPortV168(5000);
            Dictionary<string, object> afterRestart = BuildAdbConnectionStatusV168(config, adbPath, "kill-server -> " + forcedKill + " -> start-server");
            if (BooleanValue(afterRestart, "adbReady")) return PersistAdbConnectionStatusV168(config, adbPath, afterRestart);
            if (String.Equals(Text(afterRestart, "adbDeviceState"), "unauthorized", StringComparison.OrdinalIgnoreCase)) return PersistAdbConnectionStatusV168(config, adbPath, afterRestart);

            if (!BooleanValue(afterRestart, "adbServerReady"))
            {
                bool fallbackReady = StartAdbNodaemonV168(config, adbPath);
                Dictionary<string, object> afterFallback = BuildAdbConnectionStatusV168(config, adbPath, fallbackReady ? "nodaemon server" : "nodaemon server failed");
                afterRestart = afterFallback;
            }

            return PersistAdbConnectionStatusV168(config, adbPath, afterRestart);
        }
    }

    private static string RunAdbCaptureV1514(Dictionary<string, object> config, string arguments, int timeoutMs)
    {
        string adbPath = Text(config, "adbPath").Trim();
        if (String.IsNullOrWhiteSpace(adbPath)) adbPath = Path.Combine(BaseDir, "platform-tools", "adb.exe");
        if (!File.Exists(adbPath)) return "";
        try
        {
            ProcessStartInfo info = new ProcessStartInfo
            {
                FileName = adbPath,
                Arguments = arguments ?? "",
                WorkingDirectory = BaseDir,
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = new UTF8Encoding(false),
                StandardErrorEncoding = new UTF8Encoding(false)
            };
            string vendorKeys = Text(config, "adbVendorKeysPath").Trim();
            if (!String.IsNullOrWhiteSpace(vendorKeys)) info.EnvironmentVariables["ADB_VENDOR_KEYS"] = vendorKeys;
            using (Process process = Process.Start(info))
            {
                if (process == null) return "";
                if (!process.WaitForExit(Math.Max(800, timeoutMs)))
                {
                    try { if (!process.HasExited) process.Kill(); } catch { }
                    return "";
                }
                string output = process.StandardOutput.ReadToEnd();
                if (process.ExitCode != 0) return "";
                return (output ?? "").Trim();
            }
        }
        catch { return ""; }
    }

    private static Dictionary<string, string> GetLiveAdbIdentityV1514(Dictionary<string, object> config, bool force)
    {
        lock (AdbIdentityLock)
        {
            if (!force && AdbIdentityCache.Count > 0 && AdbIdentityCachedAtUtc > DateTime.UtcNow.AddSeconds(-5))
                return new Dictionary<string, string>(AdbIdentityCache, StringComparer.OrdinalIgnoreCase);

            Dictionary<string, string> result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string fallbackName = Text(config, "adbDeviceName").Trim();
            if (String.IsNullOrWhiteSpace(fallbackName)) fallbackName = Text(config, "adbDeviceModel").Trim().Replace("_", " ");
            string fallbackSerial = Text(config, "adbSerial").Trim();
            string fallbackState = Text(config, "adbDeviceState").Trim();
            result["name"] = fallbackName;
            result["serial"] = fallbackSerial;
            result["state"] = fallbackState;

            string devices = RunAdbCaptureV1514(config, "devices -l", 2500);
            if (!String.IsNullOrWhiteSpace(devices))
            {
                string[] lines = devices.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                List<string> ready = lines.Where(line => Regex.IsMatch(line ?? "", @"^\S+\s+device(?:\s|$)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)).ToList();
                List<string> unauthorized = lines.Where(line => Regex.IsMatch(line ?? "", @"^\S+\s+unauthorized(?:\s|$)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)).ToList();
                string selected = "";
                if (!String.IsNullOrWhiteSpace(fallbackSerial))
                    selected = ready.FirstOrDefault(line => Regex.IsMatch(line ?? "", "^" + Regex.Escape(fallbackSerial) + @"\s+device(?:\s|$)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)) ?? "";
                if (String.IsNullOrWhiteSpace(selected) && ready.Count == 1) selected = ready[0];
                if (!String.IsNullOrWhiteSpace(selected))
                {
                    Match serialMatch = Regex.Match(selected, @"^(\S+)\s+device(?:\s|$)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
                    string serial = serialMatch.Success ? serialMatch.Groups[1].Value.Trim() : fallbackSerial;
                    Match modelMatch = Regex.Match(selected, @"(?:^|\s)model:([^\s]+)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
                    string listModel = modelMatch.Success ? modelMatch.Groups[1].Value.Replace("_", " ").Trim() : "";
                    string market = String.IsNullOrWhiteSpace(serial) ? "" : RunAdbCaptureV1514(config, "-s " + Quote(serial) + " shell getprop ro.product.marketname", 1800);
                    string model = String.IsNullOrWhiteSpace(serial) ? "" : RunAdbCaptureV1514(config, "-s " + Quote(serial) + " shell getprop ro.product.model", 1800);
                    string maker = String.IsNullOrWhiteSpace(serial) ? "" : RunAdbCaptureV1514(config, "-s " + Quote(serial) + " shell getprop ro.product.manufacturer", 1800);
                    string candidate = !String.IsNullOrWhiteSpace(market) ? market.Trim() : (!String.IsNullOrWhiteSpace(model) ? model.Trim() : listModel);
                    candidate = (candidate ?? "").Replace("_", " ").Trim();
                    maker = (maker ?? "").Replace("_", " ").Trim();
                    if (!String.IsNullOrWhiteSpace(candidate) && !String.IsNullOrWhiteSpace(maker) &&
                        candidate.IndexOf(maker, StringComparison.OrdinalIgnoreCase) < 0 &&
                        candidate.IndexOf("Galaxy", StringComparison.OrdinalIgnoreCase) < 0 &&
                        candidate.IndexOf("iPhone", StringComparison.OrdinalIgnoreCase) < 0)
                        candidate = (maker + " " + candidate).Trim();
                    if (candidate.StartsWith("SM-", StringComparison.OrdinalIgnoreCase)) candidate = "Samsung " + candidate;
                    result["serial"] = serial;
                    result["state"] = "device";
                    if (!String.IsNullOrWhiteSpace(candidate)) result["name"] = candidate;
                }
                else if (unauthorized.Count > 0)
                {
                    result["state"] = "unauthorized";
                    result["name"] = "";
                }
                else
                {
                    result["state"] = "not-connected";
                    result["name"] = "";
                }
            }
            AdbIdentityCache = new Dictionary<string, string>(result, StringComparer.OrdinalIgnoreCase);
            AdbIdentityCachedAtUtc = DateTime.UtcNow;
            return new Dictionary<string, string>(result, StringComparer.OrdinalIgnoreCase);
        }
    }

    private static object[] ListAdapters()
    {
        List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
        Dictionary<string, object> route = GetDefaultRouteSnapshot(false);
        int defaultIndex = IntValue(route, "interfaceIndex", 0);
        Dictionary<string, object> proxy = ReadProxyState();
        string selectedWindowId = Text(proxy, "adapterId");
        Dictionary<string, object> systemPin = ReadJsonFile(SystemRoutePinStatePath);
        string pinnedSystemId = BooleanValue(systemPin, "applied") ? Text(systemPin, "adapterId") : "";
        Dictionary<string, object> config = ReadJsonFile(ConfigPath);
        Dictionary<string, string> adbIdentity = GetLiveAdbIdentityV1514(config, false);
        string adbDeviceName = adbIdentity.ContainsKey("name") ? (adbIdentity["name"] ?? "").Trim() : "";
        foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
        {
            if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback || ni.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
            IPInterfaceProperties props;
            try { props = ni.GetIPProperties(); } catch { continue; }
            bool hasGateway = props.GatewayAddresses.Any(g => g != null && g.Address != null && g.Address.AddressFamily == AddressFamily.InterNetwork && !g.Address.Equals(IPAddress.Any));
            string[] gatewayAddresses = props.GatewayAddresses
                .Where(g => g != null && g.Address != null)
                .Select(g => g.Address.ToString())
                .Where(a => !String.IsNullOrWhiteSpace(a) && a != "0.0.0.0")
                .Distinct()
                .Take(8)
                .ToArray();
            string[] addresses = props.UnicastAddresses.Select(a => a.Address.ToString()).Where(a => !String.IsNullOrWhiteSpace(a)).Take(12).ToArray();
            int interfaceIndex = 0;
            string ipv4Address = "";
            bool hasLinkLocalIpv4 = false;
            try
            {
                IPv4InterfaceProperties ipv4 = props.GetIPv4Properties();
                if (ipv4 != null) interfaceIndex = ipv4.Index;
                IPAddress[] ipv4Addresses = props.UnicastAddresses
                    .Where(a => a.Address.AddressFamily == AddressFamily.InterNetwork)
                    .Select(a => a.Address)
                    .Where(a => !IPAddress.IsLoopback(a))
                    .ToArray();
                hasLinkLocalIpv4 = ipv4Addresses.Any(a => a.ToString().StartsWith("169.254.", StringComparison.Ordinal));
                IPAddress address = ipv4Addresses.FirstOrDefault(a => !a.ToString().StartsWith("169.254.", StringComparison.Ordinal));
                if (address != null) ipv4Address = address.ToString();
            }
            catch { }
            bool selectable = AdapterStatusCanBeTested(ni.OperationalStatus) && !String.IsNullOrWhiteSpace(ipv4Address);
            bool likelyTethering = LooksLikeTetheringAdapter(ni);
            rows.Add(new Dictionary<string, object>
            {
                { "id", ni.Id }, { "name", ni.Name }, { "description", ni.Description },
                { "status", ni.OperationalStatus.ToString() }, { "type", ni.NetworkInterfaceType.ToString() },
                { "speed", ni.Speed }, { "hasGateway", hasGateway }, { "gatewayAddresses", gatewayAddresses }, { "addresses", addresses },
                { "ipv4Address", ipv4Address }, { "interfaceIndex", interfaceIndex }, { "hasLinkLocalIpv4", hasLinkLocalIpv4 },
                { "likelyTethering", likelyTethering }, { "selectable", selectable },
                { "phoneModel", "" },
                { "internetReady", selectable },
                { "isSystemDefault", defaultIndex > 0 && interfaceIndex == defaultIndex },
                { "isPinnedSystemAdapter", !String.IsNullOrWhiteSpace(pinnedSystemId) && NormalizeGuid(ni.Id) == NormalizeGuid(pinnedSystemId) },
                { "isSelectedWindowAdapter", !String.IsNullOrWhiteSpace(selectedWindowId) && NormalizeGuid(ni.Id) == NormalizeGuid(selectedWindowId) }
            });
        }
        List<Dictionary<string, object>> tetherRows = rows.Where(r => Convert.ToBoolean(r["likelyTethering"])).ToList();
        if (!String.IsNullOrWhiteSpace(adbDeviceName) && tetherRows.Count == 1)
        {
            tetherRows[0]["phoneModel"] = adbDeviceName;
            tetherRows[0]["phoneName"] = adbDeviceName;
            tetherRows[0]["friendlyName"] = adbDeviceName;
        }
        bool hasNormalDefault = rows.Any(r => Convert.ToBoolean(r["isSystemDefault"]) && Convert.ToBoolean(r["selectable"]) && !Convert.ToBoolean(r["likelyTethering"]));
        foreach (Dictionary<string, object> row in rows)
        {
            string text = (Convert.ToString(row["name"]) + " " + Convert.ToString(row["description"]) + " " + Convert.ToString(row["type"])).ToLowerInvariant();
            bool virtualLike = text.Contains("virtual") || text.Contains("hyper-v") || text.Contains("vmware") || text.Contains("virtualbox") || text.Contains("wsl") || text.Contains("vpn") || text.Contains("bluetooth") || text.Contains("loopback");
            bool selectable = Convert.ToBoolean(row["selectable"]);
            bool systemDefault = Convert.ToBoolean(row["isSystemDefault"]);
            bool likelyTethering = Convert.ToBoolean(row["likelyTethering"]);
            bool dedicatedCandidate = selectable && !virtualLike && !systemDefault && (likelyTethering || hasNormalDefault);
            row["dedicatedCandidate"] = dedicatedCandidate;
            row["adapterRoleHint"] = systemDefault ? "system_default" : likelyTethering ? "tethering" : dedicatedCandidate ? "non_default_candidate" : "other";
        }
        return rows.OrderByDescending(r => Convert.ToBoolean(r["selectable"]))
                   .ThenByDescending(r => Convert.ToBoolean(r["likelyTethering"]))
                   .ThenByDescending(r => Convert.ToBoolean(r["dedicatedCandidate"]))
                   .ThenByDescending(r => Convert.ToBoolean(r["hasGateway"]))
                   .ThenByDescending(r => String.Equals(Convert.ToString(r["status"]), "Up", StringComparison.OrdinalIgnoreCase))
                   .ThenBy(r => Convert.ToString(r["name"]), StringComparer.CurrentCultureIgnoreCase)
                   .Cast<object>().ToArray();
    }

    private static Dictionary<string, object> GetStatusSnapshot(int maxAgeMs)
    {
        lock (StatusSnapshotLock)
        {
            DateTime now = DateTime.UtcNow;
            if (StatusSnapshotCache != null && StatusSnapshotCachedAtUtc != DateTime.MinValue &&
                (now - StatusSnapshotCachedAtUtc).TotalMilliseconds <= Math.Max(250, maxAgeMs))
                return new Dictionary<string, object>(StatusSnapshotCache);
            Dictionary<string, object> fresh = BuildStatus();
            StatusSnapshotCache = new Dictionary<string, object>(fresh);
            StatusSnapshotCachedAtUtc = now;
            return new Dictionary<string, object>(fresh);
        }
    }

    private static void InvalidateStatusSnapshot()
    {
        lock (StatusSnapshotLock)
        {
            StatusSnapshotCache = null;
            StatusSnapshotCachedAtUtc = DateTime.MinValue;
        }
    }

    private static Dictionary<string, object> BuildStatus()
    {
        Dictionary<string, object> runtime = ReadRuntime();
        Dictionary<string, object> proxy = ReadProxyState();
        /* Status polling must never perform an external public-IP request. Public IP is refreshed
           when the dedicated adapter is applied and after an explicit mobile-network reset. This
           keeps /api status bounded even when tether DNS or IP echo services are temporarily slow. */
        bool windowEnabled = BooleanValue(proxy, "enabled");
        string mode = windowEnabled ? "window" : "system";
        runtime["mode"] = mode;
        runtime["helperVersion"] = HelperVersion;
        runtime["buildMarker"] = BuildMarker;
        Dictionary<string, object> config = ReadJsonFile(ConfigPath);
        string configuredAdbPath = Text(config, "adbPath");
        bool adbExecutableReady = !String.IsNullOrWhiteSpace(configuredAdbPath) && File.Exists(configuredAdbPath);
        bool adbServerReady = BooleanValue(config, "adbServerReady");
        bool adbMobileRecoveryReady = BooleanValue(config, "adbMobileRecoveryReady");
        runtime["adbPath"] = configuredAdbPath;
        runtime["adbExecutableReady"] = adbExecutableReady;
        runtime["adbServerReady"] = adbServerReady;
        runtime["adbMobileRecoveryReady"] = adbMobileRecoveryReady;
        runtime["adbReady"] = adbExecutableReady && adbServerReady && adbMobileRecoveryReady;
        runtime["adbServerMode"] = Text(config, "adbServerMode");
        Dictionary<string, string> liveAdbIdentity = GetLiveAdbIdentityV1514(config, false);
        runtime["adbDeviceState"] = liveAdbIdentity.ContainsKey("state") ? liveAdbIdentity["state"] : Text(config, "adbDeviceState");
        runtime["adbDeviceSerial"] = liveAdbIdentity.ContainsKey("serial") ? liveAdbIdentity["serial"] : Text(config, "adbSerial");
        runtime["adbDeviceModel"] = liveAdbIdentity.ContainsKey("name") ? liveAdbIdentity["name"] : Text(config, "adbDeviceModel");
        runtime["adbInstallSource"] = Text(config, "adbInstallSource");
        runtime["splitRouteSafetyVersion"] = 1;
        runtime["windowAdapterEnabled"] = windowEnabled;
        runtime["windowAdapterId"] = Text(proxy, "adapterId");
        runtime["windowAdapterName"] = Text(proxy, "adapterName");
        runtime["windowAdapterIpv4"] = Text(proxy, "ipv4Address");
        runtime["publicIp"] = Text(proxy, "publicIp");
        runtime["publicIpObserved"] = Text(proxy, "publicIpObserved");
        runtime["publicIpLookupOk"] = BooleanValue(proxy, "publicIpLookupOk");
        runtime["publicIpCheckedAt"] = Text(proxy, "publicIpCheckedAt");
        runtime["publicIpLastKnownAt"] = Text(proxy, "publicIpLastKnownAt");
        runtime["publicIpError"] = Text(proxy, "publicIpError");
        runtime["selectedNetworkReady"] = BooleanValue(proxy, "selectedNetworkReady");
        runtime["selectedNetworkDnsReady"] = BooleanValue(proxy, "selectedNetworkDnsReady");
        runtime["selectedNetworkDnsMode"] = Text(proxy, "selectedNetworkDnsMode");
        runtime["selectedNetworkCoupangTcpReady"] = BooleanValue(proxy, "selectedNetworkCoupangTcpReady");
        runtime["selectedNetworkProbeHost"] = Text(proxy, "selectedNetworkProbeHost");
        runtime["selectedNetworkCheckedAt"] = Text(proxy, "selectedNetworkCheckedAt");
        runtime["selectedNetworkError"] = Text(proxy, "selectedNetworkError");
        runtime["selectedNetworkIpv4RecoveryRequested"] = BooleanValue(proxy, "selectedNetworkIpv4RecoveryRequested");
        runtime["proxyReady"] = IsBridgeProxyReady();
        runtime["proxyPort"] = ProxyPort;
        runtime["routeGuardApplied"] = File.Exists(RouteGuardStatePath);
        runtime["routeGuardMode"] = File.Exists(RouteGuardStatePath) ? "selected_adapter_metric_only" : "none";
        Dictionary<string, object> systemPin = ReadJsonFile(SystemRoutePinStatePath);
        bool systemPinApplied = File.Exists(SystemRoutePinStatePath) && BooleanValue(systemPin, "applied");
        runtime["systemPinApplied"] = systemPinApplied;
        runtime["systemPinnedAdapterId"] = systemPinApplied ? Text(systemPin, "adapterId") : "";
        runtime["systemPinnedAdapterName"] = systemPinApplied ? Text(systemPin, "adapterName") : "";
        runtime["systemPinnedInterfaceIndex"] = systemPinApplied ? IntValue(systemPin, "interfaceIndex", 0) : 0;
        string runnerDetail;
        bool runnerRegistered = IsScheduledTaskRegistered(TaskName, out runnerDetail);
        runtime["networkSwitchDaemonReady"] = runnerRegistered;
        runtime["networkSwitchRunnerReady"] = runnerRegistered;
        runtime["networkSwitchDaemonDetail"] = runnerRegistered ? "\uC694\uCCAD\uD560 \uB54C\uB9CC \uC2E4\uD589\uB418\uB294 \uAD00\uB9AC\uC790 \uB2E8\uBC1C \uC791\uC5C5 \uD050" : runnerDetail;
        runtime["networkSwitchTransport"] = "per_request_one_shot_task_queue_v3083";
        Dictionary<string, object> defaultRoute = GetDefaultRouteSnapshot(false);
        runtime["systemDefaultInterfaceIndex"] = IntValue(defaultRoute, "interfaceIndex", 0);
        runtime["systemDefaultInterfaceAlias"] = Text(defaultRoute, "interfaceAlias");
        runtime["routeInspectionError"] = Text(defaultRoute, "inspectionError");
        runtime["systemPinHealthy"] = systemPinApplied && IntValue(systemPin, "interfaceIndex", 0) > 0
            && IntValue(defaultRoute, "interfaceIndex", 0) == IntValue(systemPin, "interfaceIndex", 0);
        try
        {
            int defaultIndex = IntValue(defaultRoute, "interfaceIndex", 0);
            NetworkInterface defaultAdapter = NetworkInterface.GetAllNetworkInterfaces().FirstOrDefault(ni =>
            {
                try { IPv4InterfaceProperties ip = ni.GetIPProperties().GetIPv4Properties(); return ip != null && ip.Index == defaultIndex; }
                catch { return false; }
            });
            if (defaultAdapter != null)
            {
                runtime["systemDefaultAdapterId"] = defaultAdapter.Id;
                runtime["systemDefaultInterfaceDescription"] = defaultAdapter.Description;
                IPAddress defaultIpv4 = defaultAdapter.GetIPProperties().UnicastAddresses.Where(a => a.Address.AddressFamily == AddressFamily.InterNetwork).Select(a => a.Address).FirstOrDefault(a => !IPAddress.IsLoopback(a) && !a.ToString().StartsWith("169.254.", StringComparison.Ordinal));
                runtime["systemDefaultInterfaceIpv4"] = defaultIpv4 == null ? "" : defaultIpv4.ToString();
            }
        }
        catch { }
        runtime["adapters"] = ListAdapters();
        if (mode == "window")
        {
            runtime["selectedAdapterId"] = Text(proxy, "adapterId");
            runtime["selectedAdapterName"] = Text(proxy, "adapterName");
            try
            {
                AdapterBinding binding = ResolveAdapter(Text(proxy, "adapterId"), Text(proxy, "adapterName"), Text(proxy, "adapterDescription"));
                foreach (KeyValuePair<string, object> row in BuildIsolationStatus(binding, false)) runtime[row.Key] = row.Value;
            }
            catch (Exception ex)
            {
                runtime["strictIsolationOk"] = false;
                runtime["isolationMessage"] = ex.Message;
            }
        }
        runtime["activeControlConnections"] = Interlocked.CompareExchange(ref ControlActiveConnections, 0, 0);
        runtime["activeProxyConnections"] = Interlocked.CompareExchange(ref ProxyActiveConnections, 0, 0);
        runtime["rawHttpClientDisconnects"] = Interlocked.Read(ref RawHttpClientDisconnects);
        runtime["proxyConnectionsClosed"] = Interlocked.Read(ref ProxyConnectionsClosed);
        return runtime;
    }

    private static Dictionary<string, object> ReadRuntime()
    {
        Dictionary<string, object> value = ReadJsonFile(RuntimePath);
        if (value.Count > 0) return value;
        return new Dictionary<string, object> { { "mode", "system" }, { "selectedAdapterId", "" }, { "selectedAdapterName", "" } };
    }

    private static Dictionary<string, object> ReadProxyState()
    {
        Dictionary<string, object> value = ReadJsonFile(ProxyStatePath);
        if (value.Count > 0) return value;
        return new Dictionary<string, object> { { "enabled", false }, { "adapterId", "" }, { "adapterName", "" }, { "ipv4Address", "" } };
    }

    private static Dictionary<string, object> ReadJsonFile(string path)
    {
        try
        {
            if (File.Exists(path))
            {
                Dictionary<string, object> value = Json.Deserialize<Dictionary<string, object>>(File.ReadAllText(path, Encoding.UTF8));
                if (value != null) return value;
            }
        }
        catch { }
        return new Dictionary<string, object>();
    }

    private static void WriteJsonFile(string path, Dictionary<string, object> value)
    {
        string directory = Path.GetDirectoryName(path);
        if (!String.IsNullOrWhiteSpace(directory)) Directory.CreateDirectory(directory);
        string tempPath = path + "." + Process.GetCurrentProcess().Id + "." + Guid.NewGuid().ToString("N") + ".tmp";
        File.WriteAllText(tempPath, Json.Serialize(value), new UTF8Encoding(false));
        try
        {
            if (File.Exists(path)) File.Replace(tempPath, path, null, true);
            else File.Move(tempPath, path);
        }
        catch
        {
            try { if (File.Exists(path)) File.Delete(path); } catch { }
            File.Move(tempPath, path);
        }
        finally { try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { } }
    }

    private static bool BooleanValue(Dictionary<string, object> source, string key)
    {
        object value;
        if (source == null || !source.TryGetValue(key, out value) || value == null) return false;
        bool result;
        return Boolean.TryParse(Convert.ToString(value), out result) && result;
    }

    private static int IntValue(Dictionary<string, object> source, string key, int fallback)
    {
        object value;
        int parsed;
        return source != null && source.TryGetValue(key, out value) && value != null && Int32.TryParse(Convert.ToString(value), out parsed) ? parsed : fallback;
    }

    private static string Text(Dictionary<string, object> source, string key)
    {
        object value;
        return source != null && source.TryGetValue(key, out value) && value != null ? Convert.ToString(value) ?? "" : "";
    }

    private static Dictionary<string, object> Error(string message)
    {
        return new Dictionary<string, object> { { "ok", false }, { "error", message ?? "Unknown error" } };
    }

    private static byte[] ReadExact(Stream stream, int length)
    {
        byte[] buffer = new byte[length];
        int offset = 0;
        while (offset < length)
        {
            int read = stream.Read(buffer, offset, length - offset);
            if (read <= 0)
            {
                if (offset == 0) return null;
                throw new EndOfStreamException();
            }
            offset += read;
        }
        return buffer;
    }

    private static void WriteMessage(Stream output, Dictionary<string, object> message)
    {
        byte[] payload = Encoding.UTF8.GetBytes(Json.Serialize(message));
        byte[] header = BitConverter.GetBytes(payload.Length);
        output.Write(header, 0, header.Length);
        output.Write(payload, 0, payload.Length);
        output.Flush();
    }

    private static void PrepareLogEncodingLocked()
    {
        if (LogEncodingPrepared) return;
        byte[] bom = Encoding.UTF8.GetPreamble();
        if (File.Exists(BridgeLogPath))
        {
            byte[] current = File.ReadAllBytes(BridgeLogPath);
            bool hasBom = current.Length >= bom.Length;
            for (int i = 0; hasBom && i < bom.Length; i++) if (current[i] != bom[i]) hasBom = false;
            if (!hasBom)
            {
                byte[] converted = new byte[bom.Length + current.Length];
                Buffer.BlockCopy(bom, 0, converted, 0, bom.Length);
                Buffer.BlockCopy(current, 0, converted, bom.Length, current.Length);
                File.WriteAllBytes(BridgeLogPath, converted);
            }
        }
        else File.WriteAllBytes(BridgeLogPath, bom);
        LogEncodingPrepared = true;
    }

    private static void AppendLog(string text)
    {
        try
        {
            lock (LogLock)
            {
                PrepareLogEncodingLocked();
                File.AppendAllText(BridgeLogPath, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " " + text + Environment.NewLine, new UTF8Encoding(false));
            }
        }
        catch { }
    }
}
