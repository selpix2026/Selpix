const test=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm');
const {sourceFunction}=require('./helpers.cjs');
const core='src/background/service-worker-core.js';
function pipeline(overrides={}){
  const events=[],writes=[];let clock=100000;
  const cp={wasRunning:true,runId:'r',keyword:'텀블러',page:1,automationTabId:7,searchUrl:'https://www.coupang.com/np/search?q=텀블러'};
  const ctx=vm.createContext({console,Date:{now:()=>clock},spxConnectivityRecoveryPromise:null,spxConnectivityRecoveryEpoch:0,
    spxConnectivityFailureTimes:[],readConnectivityRecoveryState:async()=>({}),writeConnectivityRecoveryState:async patch=>{writes.push(patch);return patch;},
    pauseAutomationForConnectivityReset:async()=>cp,spxSharedManualAirplaneTimingV1649:async()=>({airplaneHoldMs:20000,airplaneHoldSeconds:20}),
    performMemoryCleanup:async()=>({ok:true}),clearTargetSiteStorage:async()=>({verified:true,wingRecoveryCleanup:{ok:true}}),
    setAutoForRun:async()=>({}),runMobileResetWithVerifiedStart:async()=>{events.push('native');return{ok:true,completed:true,ipChanged:true};},
    isMobileResetAlreadyRunningResponse:()=>false,chrome:{alarms:{clear:async()=>true}},SPX_LEGACY_CONNECTIVITY_RESUME_ALARM:'legacy',
    reloadAutomationTabAfterConnectivityRecovery:async()=>{events.push('reload');return{tabId:7,url:cp.searchUrl};},
    probeAutomationTabForSameDocumentRecovery:async()=>({ok:true,reusable:true}),spxSleep:async ms=>{clock+=ms;},
    getAuto:async()=>({running:true,runId:'r'}),resumeAutomationAfterConnectivityReset:async()=>{events.push('resume');return{};},
    clearBlockRetryLoopV125R1:async()=>{},errorText:e=>String(e?.message||e),...overrides});
  vm.runInContext(sourceFunction(core,'triggerMobileConnectivityReset'),ctx);
  return{ctx,events,writes,cp};
}
test('stop during the preparing state write prevents a later native reset',async()=>{
  const p=pipeline();
  p.ctx.writeConnectivityRecoveryState=async patch=>{if(patch.phase==='airplane-prepare')p.ctx.spxConnectivityRecoveryEpoch++;return patch;};
  await p.ctx.triggerMobileConnectivityReset('MANUAL_IP_CHANGE',p.cp,{manual:true});
  assert.equal(p.events.includes('native'),false);
});
test('F5 rechecks cancellation after async tab lookup',async()=>{
  let reloaded=0;
  const ctx=vm.createContext({spxConnectivityRecoveryEpoch:1,getAuto:async()=>({running:true,runId:'r'}),
    chrome:{tabs:{get:async()=>{ctx.spxConnectivityRecoveryEpoch++;return{id:7,url:'https://www.coupang.com/np/search?q=test'};},reload:async()=>{reloaded++;}}},
    waitForTabComplete:async()=>{},setAutoForRun:async()=>({})});
  vm.runInContext(sourceFunction(core,'reloadAutomationTabAfterConnectivityRecovery'),ctx);
  await ctx.reloadAutomationTabAfterConnectivityRecovery({automationTabId:7},1).catch(()=>null);
  assert.equal(reloaded,0);
});
test('verified success ends the block incident and rearms future real-block detection',async()=>{
  const p=pipeline();
  await p.ctx.triggerMobileConnectivityReset('MANUAL_IP_CHANGE',p.cp,{manual:true,autoTriggeredByBlock:true});
  const completed=p.writes.find(row=>row.status==='completed');
  assert.ok(completed);assert.equal(completed.blockAttempted,false);
});
