@echo off
chcp 65001 >nul
setlocal
set "PS=%~dp0tools\crosspc\07_REPAIR_RESTORE_NORMAL_CHROME.ps1"
if not exist "%PS%" (
  echo [ERROR] Normal Chrome repair PowerShell file not found.
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS%"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo [ERROR] Normal Chrome dedicated-window repair failed. Check the message above.
if "%RC%"=="0" echo [OK] Normal Chrome dedicated-window repair completed.
pause
exit /b %RC%
