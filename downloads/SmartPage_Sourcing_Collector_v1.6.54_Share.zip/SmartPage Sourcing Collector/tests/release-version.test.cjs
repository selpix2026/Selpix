const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
test('release content and worker versions match manifest so fresh tabs pass version handshake', () => {
 const version = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'))).version;
 for (const [file, constant] of [
  ['src/content/coupang-search.js','SPX_CONTENT_BUILD_VERSION'],
  ['src/background/service-worker.js','SPX_SW_BOOTSTRAP_BUILD'],
  ['src/background/service-worker-core.js','SPX_STANDALONE_COLLECTOR_BUILD']
 ]) {
  const source = fs.readFileSync(path.join(root,file),'utf8');
  const match = source.match(new RegExp(constant+"\\s*=\\s*['\"]([^'\"]+)"));
  assert.equal(match?.[1], version, file);
 }
});
